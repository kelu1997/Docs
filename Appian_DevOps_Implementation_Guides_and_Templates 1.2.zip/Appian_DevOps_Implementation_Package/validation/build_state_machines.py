from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Literal

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
ROOT = PACKAGE_ROOT / 'state-machines'

LAMBDA_RETRY = [{
    "ErrorEquals": [
        "Lambda.ServiceException",
        "Lambda.AWSLambdaException",
        "Lambda.SdkClientException",
        "Lambda.TooManyRequestsException",
    ],
    "IntervalSeconds": 2,
    "MaxAttempts": 4,
    "BackoffRate": 2.0,
}]

SAFE_OPERATION_RETRY = [{
    "ErrorEquals": ["States.ALL"],
    "IntervalSeconds": 3,
    "MaxAttempts": 3,
    "BackoffRate": 2.0,
}]

RetryMode = Literal["lambda", "safe", "none"]


def invoke(
    operation: str,
    next_state: str | None = None,
    *,
    suite: str | None = None,
    category: str | None = None,
    catch: bool = True,
    retry_mode: RetryMode = "lambda",
) -> Dict[str, Any]:
    payload: Dict[str, Any] = {"op": operation, "context.$": "$"}
    if suite:
        payload["suite"] = suite
    if category:
        payload["category"] = category
    state: Dict[str, Any] = {
        "Type": "Task",
        "Resource": "arn:aws:states:::lambda:invoke",
        "Parameters": {
            "FunctionName": "${OrchestratorFunctionArn}",
            "Payload": payload,
        },
        "OutputPath": "$.Payload",
    }
    if retry_mode == "lambda":
        state["Retry"] = LAMBDA_RETRY
    elif retry_mode == "safe":
        state["Retry"] = SAFE_OPERATION_RETRY
    if catch:
        state["Catch"] = [{
            "ErrorEquals": ["States.ALL"],
            "ResultPath": "$.error",
            "Next": "CaptureUnhandledError",
        }]
    if next_state:
        state["Next"] = next_state
    else:
        state["End"] = True
    return state


def report_state(next_state: str) -> Dict[str, Any]:
    return {
        "Type": "Task",
        "Resource": "arn:aws:states:::codebuild:startBuild.sync",
        "Parameters": {
            "ProjectName": "${ReportPublisherProjectName}",
            "EnvironmentVariablesOverride": [
                {
                    "Name": "RESULTS_BUCKET",
                    "Type": "PLAINTEXT",
                    "Value": "${ResultsBucketName}",
                },
                {
                    "Name": "RESULT_PREFIX",
                    "Type": "PLAINTEXT",
                    "Value.$": "States.Format('{}/test-results', $.evidencePrefix)",
                },
            ],
        },
        "ResultPath": None,
        "Retry": LAMBDA_RETRY,
        "Next": next_state,
        "Catch": [{
            "ErrorEquals": ["States.ALL"],
            "ResultPath": "$.error",
            "Next": "CaptureUnhandledError",
        }],
    }


def suite_branch(suite: str) -> Dict[str, Any]:
    return {
        "StartAt": f"Start{suite}",
        "States": {
            f"Start{suite}": invoke(
                "test_start",
                f"Wait{suite}",
                suite=suite,
                catch=False,
                retry_mode="none",
            ),
            f"Wait{suite}": {
                "Type": "Wait",
                "SecondsPath": "$.pollIntervalSeconds",
                "Next": f"Check{suite}Status",
            },
            f"Check{suite}Status": invoke(
                "test_status",
                f"Is{suite}Complete",
                suite=suite,
                catch=False,
                retry_mode="safe",
            ),
            f"Is{suite}Complete": {
                "Type": "Choice",
                "Choices": [
                    {
                        "Variable": f"$.testAutomation.{suite}.state",
                        "StringEquals": "RUNNING",
                        "Next": f"Wait{suite}",
                    },
                    {
                        "Variable": f"$.testAutomation.{suite}.state",
                        "StringEquals": "SUCCEEDED",
                        "Next": f"Get{suite}Results",
                    },
                ],
                "Default": f"{suite}InfrastructureFailure",
            },
            f"Get{suite}Results": invoke(
                "test_results",
                suite=suite,
                catch=False,
                retry_mode="safe",
            ),
            f"{suite}InfrastructureFailure": {"Type": "Succeed"},
        },
    }


def build(full_test_set: bool, include_appian_native_tests: bool) -> Dict[str, Any]:
    after_deployment = (
        "StartAppianNativeTests" if include_appian_native_tests else "StartSMOKE"
    )
    states: Dict[str, Any] = {
        "ValidatePackage": invoke("validate", "StartAppianInspection"),
        "StartAppianInspection": invoke(
            "appian_inspection_start",
            "WaitForInspection",
            retry_mode="none",
        ),
        "WaitForInspection": {
            "Type": "Wait",
            "SecondsPath": "$.pollIntervalSeconds",
            "Next": "CheckInspectionStatus",
        },
        "CheckInspectionStatus": invoke(
            "appian_inspection_status",
            "IsInspectionComplete",
            retry_mode="safe",
        ),
        "IsInspectionComplete": {
            "Type": "Choice",
            "Choices": [
                {
                    "Variable": "$.appian.inspection.state",
                    "StringEquals": "RUNNING",
                    "Next": "WaitForInspection",
                },
                {
                    "Variable": "$.appian.inspection.state",
                    "StringEquals": "SUCCEEDED",
                    "Next": "StartAppianDeployment",
                },
            ],
            "Default": "MarkInspectionFailure",
        },
        "MarkInspectionFailure": invoke(
            "mark_failure",
            "DiagnoseFailure",
            category="APPIAN_INSPECTION",
        ),
        "StartAppianDeployment": invoke(
            "appian_deployment_start",
            "WaitForDeployment",
            retry_mode="none",
        ),
        "WaitForDeployment": {
            "Type": "Wait",
            "SecondsPath": "$.pollIntervalSeconds",
            "Next": "CheckDeploymentStatus",
        },
        "CheckDeploymentStatus": invoke(
            "appian_deployment_status",
            "IsDeploymentComplete",
            retry_mode="safe",
        ),
        "IsDeploymentComplete": {
            "Type": "Choice",
            "Choices": [
                {
                    "Variable": "$.appian.deployment.state",
                    "StringEquals": "RUNNING",
                    "Next": "WaitForDeployment",
                },
                {
                    "Variable": "$.appian.deployment.state",
                    "StringEquals": "SUCCEEDED",
                    "Next": after_deployment,
                },
            ],
            "Default": "MarkDeploymentFailure",
        },
        "MarkDeploymentFailure": invoke(
            "mark_failure",
            "DiagnoseFailure",
            category="APPIAN_DEPLOYMENT",
        ),
        "StartSMOKE": invoke(
            "test_start",
            "WaitSMOKE",
            suite="SMOKE",
            retry_mode="none",
        ),
        "WaitSMOKE": {
            "Type": "Wait",
            "SecondsPath": "$.pollIntervalSeconds",
            "Next": "CheckSMOKEStatus",
        },
        "CheckSMOKEStatus": invoke(
            "test_status",
            "IsSMOKEComplete",
            suite="SMOKE",
            retry_mode="safe",
        ),
        "IsSMOKEComplete": {
            "Type": "Choice",
            "Choices": [
                {
                    "Variable": "$.testAutomation.SMOKE.state",
                    "StringEquals": "RUNNING",
                    "Next": "WaitSMOKE",
                },
                {
                    "Variable": "$.testAutomation.SMOKE.state",
                    "StringEquals": "SUCCEEDED",
                    "Next": "GetSMOKEResults",
                },
            ],
            "Default": "MarkSmokeInfrastructureFailure",
        },
        "MarkSmokeInfrastructureFailure": invoke(
            "mark_failure",
            "PublishInfrastructureFailureReport",
            category="SMOKE_TEST",
        ),
        "PublishInfrastructureFailureReport": report_state("DiagnoseFailure"),
        "GetSMOKEResults": invoke(
            "test_results",
            "IsSmokePassing",
            suite="SMOKE",
            retry_mode="safe",
        ),
        "IsSmokePassing": {
            "Type": "Choice",
            "Choices": [{
                "Variable": "$.testResults.SMOKE.status",
                "StringEquals": "PASSED",
                "Next": "RunRegressionAndE2E" if full_test_set else "PublishReports",
            }],
            "Default": "PublishEarlyFailureReports",
        },
        "PublishEarlyFailureReports": report_state("MarkSmokeFailure"),
        "MarkSmokeFailure": invoke(
            "mark_failure",
            "DiagnoseFailure",
            category="SMOKE_TEST",
        ),
        "PublishReports": report_state("EvaluateQualityGate"),
        "EvaluateQualityGate": invoke("evaluate", "QualityGatePassed"),
        "QualityGatePassed": {
            "Type": "Choice",
            "Choices": [{
                "Variable": "$.qualityGate.status",
                "StringEquals": "PASSED",
                "Next": "FinalizeSuccess",
            }],
            "Default": "DiagnoseFailure",
        },
        "FinalizeSuccess": invoke("finalize", "ReleaseSucceeded"),
        "ReleaseSucceeded": {"Type": "Succeed"},
        "CaptureUnhandledError": invoke(
            "capture_error",
            "DiagnoseFailure",
            catch=False,
        ),
        "DiagnoseFailure": invoke(
            "diagnose",
            "FinalizeFailure",
            catch=False,
        ),
        "FinalizeFailure": invoke(
            "finalize",
            "ReleaseFailed",
            catch=False,
        ),
        "ReleaseFailed": {
            "Type": "Fail",
            "Error": "ReleaseQualityGateFailed",
            "Cause": "See the encrypted S3 evidence package and diagnostic JSON.",
        },
    }

    if include_appian_native_tests:
        states.update({
            "StartAppianNativeTests": invoke(
                "appian_native_tests_start",
                "AppianNativeTestsRequested",
                retry_mode="none",
            ),
            "AppianNativeTestsRequested": {
                "Type": "Choice",
                "Choices": [
                    {
                        "Variable": "$.appian.nativeTests.state",
                        "StringEquals": "SKIPPED",
                        "Next": "StartSMOKE",
                    },
                    {
                        "Variable": "$.appian.nativeTests.state",
                        "StringEquals": "RUNNING",
                        "Next": "WaitForAppianNativeTests",
                    },
                ],
                "Default": "MarkAppianNativeTestFailure",
            },
            "WaitForAppianNativeTests": {
                "Type": "Wait",
                "SecondsPath": "$.pollIntervalSeconds",
                "Next": "CheckAppianNativeTestStatus",
            },
            "CheckAppianNativeTestStatus": invoke(
                "appian_native_tests_status",
                "IsAppianNativeTestComplete",
                retry_mode="safe",
            ),
            "IsAppianNativeTestComplete": {
                "Type": "Choice",
                "Choices": [
                    {
                        "Variable": "$.appian.nativeTests.state",
                        "StringEquals": "RUNNING",
                        "Next": "WaitForAppianNativeTests",
                    },
                    {
                        "Variable": "$.appian.nativeTests.state",
                        "StringEquals": "SUCCEEDED",
                        "Next": "GetAppianNativeTestResults",
                    },
                    {
                        "Variable": "$.appian.nativeTests.state",
                        "StringEquals": "SKIPPED",
                        "Next": "StartSMOKE",
                    },
                ],
                "Default": "MarkAppianNativeTestFailure",
            },
            "GetAppianNativeTestResults": invoke(
                "appian_native_tests_results",
                "IsAppianNativeTestPassing",
                retry_mode="safe",
            ),
            "IsAppianNativeTestPassing": {
                "Type": "Choice",
                "Choices": [{
                    "Variable": "$.testResults.APPIAN_NATIVE.status",
                    "StringEquals": "PASSED",
                    "Next": "StartSMOKE",
                }],
                "Default": "PublishAppianNativeTestFailureReport",
            },
            "PublishAppianNativeTestFailureReport": report_state(
                "MarkAppianNativeTestFailure"
            ),
            "MarkAppianNativeTestFailure": invoke(
                "mark_failure",
                "DiagnoseFailure",
                category="APPIAN_NATIVE_TEST",
            ),
        })

    if full_test_set:
        states["RunRegressionAndE2E"] = {
            "Type": "Parallel",
            "Branches": [suite_branch("REGRESSION"), suite_branch("E2E")],
            "ResultPath": "$.parallelResults",
            "Next": "MergeParallelResults",
            "Catch": [{
                "ErrorEquals": ["States.ALL"],
                "ResultPath": "$.error",
                "Next": "CaptureUnhandledError",
            }],
        }
        states["MergeParallelResults"] = invoke(
            "merge_parallel",
            "PublishReports",
        )

    workflow_comment = (
        "Appian package release workflow: validate, inspect, deploy, execute "
        "Appian native expression-rule and Tosca quality gates, publish evidence, "
        "and diagnose failures."
        if include_appian_native_tests
        else
        "Appian production release workflow: validate the pinned package, inspect and "
        "deploy to Appian PROD, execute production smoke, and archive evidence."
    )

    return {
        "Comment": workflow_comment,
        "StartAt": "ValidatePackage",
        "TimeoutSeconds": 21600,
        "States": states,
    }


for filename, definition in {
    "demo_release.asl.json": build(True, True),
    "production_preprod.asl.json": build(True, True),
    "production_prod.asl.json": build(False, False),
}.items():
    path = ROOT / filename
    path.write_text(json.dumps(definition, indent=2), encoding="utf-8")
    print(filename, len(definition["States"]), "top-level states")
