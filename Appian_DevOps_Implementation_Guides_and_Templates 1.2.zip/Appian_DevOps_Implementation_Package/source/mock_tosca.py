"""Production-shaped mock of the Tricentis Tosca Execution API.

The demo integration client uses the same token/enqueue/poll/results contract
that it will use against a real Tosca Server. Only the endpoint changes.

Implemented routes:
  POST /tua/connect/token
  POST /api/Execution/Enqueue
  GET  /api/Execution/{executionId}/Status
  GET  /api/Execution/{executionId}/Results
  GET  /api/Execution/{executionId}/Results/Summary
"""
from __future__ import annotations

import base64
import json
import os
import time
import urllib.parse
import uuid
from html import escape
from typing import Any, Dict, Mapping

import boto3
from botocore.exceptions import ClientError

secrets = boto3.client("secretsmanager")
ssm = boto3.client("ssm")
table = boto3.resource("dynamodb").Table(os.environ["EXECUTION_TABLE"])


def _response(status: int, body: Any, content_type: str = "application/json") -> Dict[str, Any]:
    payload = json.dumps(body) if isinstance(body, (dict, list)) else str(body)
    return {
        "statusCode": status,
        "headers": {
            "content-type": content_type,
            "cache-control": "no-store",
        },
        "body": payload,
    }


def _secret() -> Mapping[str, Any]:
    raw = secrets.get_secret_value(SecretId=os.environ["MOCK_SECRET_ARN"])["SecretString"]
    config = json.loads(raw)
    profiles = config.get("providers")
    if isinstance(profiles, dict):
        selected = profiles.get("TOSCA")
        if not isinstance(selected, dict):
            raise ValueError("Mock provider secret does not contain providers.TOSCA")
        common = {key: value for key, value in config.items() if key != "providers"}
        return {**common, **dict(selected)}
    return config


def _scenario() -> str:
    try:
        return str(
            ssm.get_parameter(Name=os.environ["SCENARIO_PARAMETER"])["Parameter"]["Value"]
        ).upper()
    except ClientError as exc:
        if exc.response.get("Error", {}).get("Code") == "ParameterNotFound":
            return "SUCCESS"
        raise


def _path(event: Mapping[str, Any]) -> str:
    return str(event.get("rawPath") or event.get("path") or "/")


def _method(event: Mapping[str, Any]) -> str:
    return str(
        ((event.get("requestContext") or {}).get("http") or {}).get("method")
        or event.get("httpMethod")
        or "GET"
    ).upper()


def _body(event: Mapping[str, Any]) -> str:
    value = event.get("body") or ""
    if event.get("isBase64Encoded"):
        value = base64.b64decode(value).decode("utf-8")
    return str(value)


def _headers(event: Mapping[str, Any]) -> Dict[str, str]:
    return {
        str(key).lower(): str(value)
        for key, value in (event.get("headers") or {}).items()
    }


def _authorized(event: Mapping[str, Any]) -> bool:
    current = _headers(event)
    return (
        current.get("authorization") == "Bearer demo-tosca-access-token"
        and current.get("x-tricentis", "").upper() == "OK"
    )


def _execution_id(request_path: str) -> str:
    parts = [part for part in request_path.split("/") if part]
    lowered = [part.lower() for part in parts]
    index = lowered.index("execution")
    return parts[index + 1]


def _suite(event_id: str) -> str:
    value = event_id.upper()
    if "SMOKE" in value:
        return "SMOKE"
    if "REGRESSION" in value:
        return "REGRESSION"
    if "E2E" in value or "END_TO_END" in value or "END-TO-END" in value:
        return "E2E"
    return "UNKNOWN"


def _should_fail(test_suite: str, selected_scenario: str) -> bool:
    return (
        selected_scenario == f"{test_suite}_FAILURE"
        or selected_scenario == "ALL_TESTS_FAILURE"
    )


def _junit(test_suite: str, selected_scenario: str) -> str:
    totals = {"SMOKE": 8, "REGRESSION": 127, "E2E": 24}
    names = {
        "SMOKE": [
            "Login",
            "Open application",
            "Load critical record",
            "Create basic case",
        ],
        "REGRESSION": [
            "Create Customer",
            "Update Customer",
            "Submit Customer Approval",
            "Search Customer",
        ],
        "E2E": [
            "Create Case",
            "Approve Case",
            "Complete Workflow",
            "Verify Audit Record",
        ],
    }
    total = totals.get(test_suite, 4)
    failures = (
        3
        if _should_fail(test_suite, selected_scenario)
        and test_suite == "REGRESSION"
        else (1 if _should_fail(test_suite, selected_scenario) else 0)
    )
    case_names = names.get(test_suite, ["Test"])
    testcases = []
    for index in range(total):
        name = case_names[index % len(case_names)]
        if index >= len(case_names):
            name += f" #{index + 1}"
        if index < failures:
            message = {
                "SMOKE": "Application home page did not load after login.",
                "REGRESSION": (
                    "Expected confirmation message was not displayed after customer update."
                ),
                "E2E": "Approval workflow did not reach the Completed state.",
            }.get(test_suite, "Expected result was not observed.")
            testcases.append(
                f'<testcase classname="Appian.{escape(test_suite)}" '
                f'name="{escape(name)}" time="1.23">'
                f'<failure message="{escape(message)}">{escape(message)}</failure>'
                "</testcase>"
            )
        else:
            testcases.append(
                f'<testcase classname="Appian.{escape(test_suite)}" '
                f'name="{escape(name)}" time="0.42"/>'
            )
    return (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        f'<testsuite name="APPIAN_{escape(test_suite)}" tests="{total}" '
        f'failures="{failures}" errors="0" skipped="0" time="12.4">\n'
        + "\n".join(testcases)
        + "\n</testsuite>"
    )


def handler(event: Mapping[str, Any], context: Any) -> Dict[str, Any]:
    request_path = _path(event)
    normalized = request_path.lower().rstrip("/")
    request_method = _method(event)
    selected_scenario = _scenario()

    if normalized.endswith("/tua/connect/token") and request_method == "POST":
        if selected_scenario in {"TOSCA_AUTH_FAILURE", "TEST_PROVIDER_AUTH_FAILURE"}:
            return _response(
                401,
                {
                    "error": "invalid_client",
                    "error_description": "Simulated authentication failure",
                },
            )
        form = urllib.parse.parse_qs(_body(event))
        credentials = _secret()
        if (
            form.get("client_id", [""])[0] != credentials.get("clientId")
            or form.get("client_secret", [""])[0]
            != credentials.get("clientSecret")
        ):
            return _response(401, {"error": "invalid_client"})
        return _response(
            200,
            {
                "access_token": "demo-tosca-access-token",
                "token_type": "Bearer",
                "expires_in": 300,
            },
        )

    if normalized.endswith("/api/execution/enqueue") and request_method == "POST":
        if not _authorized(event):
            return _response(401, {"error": "unauthorized"})
        if selected_scenario in {"TOSCA_SERVICE_FAILURE", "TEST_PROVIDER_SERVICE_FAILURE"}:
            return _response(
                503,
                {
                    "error": "service_unavailable",
                    "message": "Simulated Tosca execution-service outage",
                },
            )
        try:
            request = json.loads(_body(event))
            events = request.get("events") or request.get("Events") or []
            first = events[0]
            if isinstance(first, str):
                event_id = first
                parameters = {}
            else:
                event_id = first.get("eventId") or first.get("EventId")
                parameters = first.get("parameters") or first.get("Parameters") or {}
            if not event_id:
                raise ValueError("eventId is required")
        except Exception as exc:
            return _response(
                400,
                {"error": "invalid_request", "message": str(exc)},
            )

        execution_id = str(uuid.uuid4())
        selected_for_run = str(
            parameters.get("Scenario") or selected_scenario
        ).upper()
        table.put_item(
            Item={
                "executionId": execution_id,
                "eventId": event_id,
                "suite": _suite(event_id),
                "scenario": selected_for_run,
                "status": "Queued",
                "pollCount": 0,
                "createdAt": int(time.time()),
                "expiresAt": int(time.time()) + 86400,
            }
        )
        return _response(202, {"ExecutionId": execution_id})

    if (
        normalized.endswith("/status")
        and "/execution/" in normalized
        and request_method == "GET"
    ):
        if not _authorized(event):
            return _response(401, {"error": "unauthorized"})
        try:
            execution_id = _execution_id(request_path)
            item = table.get_item(Key={"executionId": execution_id}).get("Item")
        except Exception as exc:
            return _response(400, {"error": str(exc)})
        if not item:
            return _response(404, {"error": "execution_not_found"})
        if item["scenario"] in {"TOSCA_STATUS_ERROR", "TEST_PROVIDER_STATUS_ERROR"}:
            return _response(500, {"error": "status_service_error"})

        poll_count = int(item.get("pollCount", 0)) + 1
        status = "Running"
        if item["scenario"] not in {"TOSCA_TIMEOUT", "TEST_PROVIDER_TIMEOUT"} and poll_count >= 2:
            status = "Completed"
        table.update_item(
            Key={"executionId": execution_id},
            UpdateExpression="SET pollCount = :poll, #status = :status",
            ExpressionAttributeNames={"#status": "status"},
            ExpressionAttributeValues={":poll": poll_count, ":status": status},
        )
        return _response(
            200,
            {"status": status, "resultsImported": status == "Completed"},
        )

    is_summary = (
        normalized.endswith("/results/summary")
        and "/execution/" in normalized
    )
    is_results = (
        normalized.endswith("/results")
        and "/execution/" in normalized
    )
    if (is_summary or is_results) and request_method == "GET":
        if not _authorized(event):
            return _response(401, {"error": "unauthorized"})
        try:
            execution_id = _execution_id(request_path)
            item = table.get_item(Key={"executionId": execution_id}).get("Item")
        except Exception as exc:
            return _response(400, {"error": str(exc)})
        if not item:
            return _response(404, {"error": "execution_not_found"})
        if item.get("status") != "Completed":
            return _response(409, {"error": "execution_not_complete"})

        failed = _should_fail(item["suite"], item["scenario"])
        if is_summary:
            return _response(
                200,
                {
                    "inProgress": 0,
                    "passed": 0 if failed else 1,
                    "failed": 1 if failed else 0,
                    "skipped": 0,
                    "eventId": item["eventId"],
                },
            )
        if item["scenario"] in {"MALFORMED_RESULTS", "TEST_PROVIDER_MALFORMED_RESULTS"}:
            return _response(200, "<testsuite><broken>", "application/xml")
        return _response(
            200,
            _junit(item["suite"], item["scenario"]),
            "application/xml",
        )

    if normalized.endswith("/health"):
        return _response(
            200,
            {"status": "ok", "service": "mock-tosca-execution-api"},
        )

    return _response(
        404,
        {"error": "not_found", "method": request_method, "path": request_path},
    )
