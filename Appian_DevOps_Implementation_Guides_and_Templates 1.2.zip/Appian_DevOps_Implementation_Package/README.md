# Appian DevOps on AWS — Implementation Package

Version 1.2 — 31 August 2026

This package contains two implementation paths for a tested Appian deployment ZIP after it leaves Appian:

1. **Client demo** — a self-contained AWS demonstration. The AWS pipeline, orchestration, security, reporting, evidence, manual gate, and diagnostics are real. Appian defaults to a deterministic adapter simulation, including the post-deployment native expression-rule test start/status/results loop. The external smoke, regression, and end-to-end gates use one provider-neutral adapter contract with a `TestAutomationProvider` switch for `TOSCA` or `UIPATH`. Tosca is represented by a production-shaped HTTP API mock; UiPath uses the same CodeBuild adapter and `uip tm` launch/wait/report/JUnit flow intended for a real tenant, with deterministic results in `MOCK` mode.
2. **Production reference** — real Appian TEST/PROD Deployment REST API connections, a pipeline-triggered Appian native expression-rule test gate in TEST, a selectable Tricentis Tosca Execution API or UiPath Test Manager connection, pre-production quality gates, an authorized production approval, production deployment/smoke, retained evidence, and optional AI-assisted diagnostics.

## Package layout

- `guides/` — comprehensive DOCX and PDF implementation guides.
- `cloudformation/` — complete demo and production CloudFormation templates.
- `source/` — the shared Appian/provider-neutral integration, evidence, quality-gate, and diagnostic Lambda source; the Tosca HTTP mock; and the UiPath Test Manager CodeBuild adapter buildspec.
- `state-machines/` — readable Amazon States Language definitions embedded in the templates.
- `validation/` — local template/state-machine validation and regeneration tools.
- `diagrams/` — architecture, demo-storyboard, and release-flow figures used in the guides.

## Test automation adapter boundary

The state machines call only these normalized operations:

- `test_start`
- `test_status`
- `test_results`

They receive provider-independent execution state under `$.testAutomation.<SUITE>` and JUnit-backed summaries under `$.testResults.<SUITE>`. Smoke remains blocking; regression and E2E run in parallel after smoke passes. Bedrock receives the same normalized evidence regardless of provider.

`TOSCA` uses the direct Lambda HTTPS connector for client-credentials authentication, enqueue, asynchronous status polling, result summary, and JUnit retrieval. `UIPATH` uses a CodeBuild project that installs the pinned UiPath CLI and Test Manager tool, authenticates with an External Application, launches the mapped test set, waits for a terminal execution, retrieves the report, downloads JUnit XML, and uploads normalized evidence. Changing provider does not change the state machines, reporting, quality-gate logic, or diagnostics workflow.

## Demo quick start

1. Open **AWS CloudFormation → Stacks → Create stack → With new resources (standard)**.
2. Select **Upload a template file** and choose `cloudformation/appian-devops-demo.yaml`.
3. Keep `AppianIntegrationMode=MOCK`, `EnableAppianNativeTests=true`, and `TestProviderIntegrationMode=MOCK` for a self-contained presentation. Select `TestAutomationProvider=TOSCA` to demonstrate the HTTP Execution API boundary or `TestAutomationProvider=UIPATH` to demonstrate the CodeBuild/UiPath CLI boundary. Select `EnableAiDiagnostics=true` only in a Region/account with the chosen Bedrock model enabled and approved.
4. Acknowledge IAM resource creation and create the stack.
5. Confirm any optional SNS email subscription.
6. From stack **Outputs**, record `SourceBucketName`, `SourceObjectKey`, `PipelineName`, `ResultsBucketName`, `ScenarioParameterName`, `TestAutomationProvider`, `TestProviderSecretArn`, and `UiPathAdapterProjectName`.
7. Upload a structurally representative Appian ZIP to the exact source bucket/key. Every overwrite creates a new S3 version and a new pipeline execution.
8. Run the three recommended scenarios by changing the SSM scenario parameter before uploading a new object version:
   - `SUCCESS`
   - `REGRESSION_FAILURE`
   - `TEST_PROVIDER_TIMEOUT`
9. Review CodePipeline, the Step Functions execution graph, the selected provider path, CodeBuild test reports, and the encrypted evidence prefix in the results bucket.

The demo guide contains the exact console paths, presentation narrative, provider-switch procedure, failure scenarios, acceptance criteria, and cleanup sequence.

## Production prerequisites

Before creating the production stack, prepare three existing Secrets Manager secrets and supply their ARNs as stack parameters:

- Appian TEST connection JSON, including the native-test Web API paths
- Appian PROD connection JSON
- test-provider connection JSON containing the selected provider profile directly or both profiles under `providers.TOSCA` and `providers.UIPATH`

The guides define API-key and OAuth 2.0 Appian examples, the three Appian TEST native-test Web APIs, the normalized adapter contract, Tosca token/enqueue/status/result settings, UiPath External Application/Test Manager settings, network/TLS options, commissioning tests, ownership boundaries, and change-control decisions.

Production deployment must also confirm:

- the client-installed Appian Deployment REST API behavior and account permissions;
- the Appian TEST Web APIs that start application-scoped expression-rule tests, poll run status, and return `TestRunResult` XML, using the same CI identity with viewer rights to the selected applications and rules;
- for Tosca: the installed Tosca Server/AOS Swagger contract, authentication, event IDs, status values, result paths, and JUnit behavior;
- for UiPath: the approved UiPath CLI version, External Application scopes, tenant/organization/authority, Test Manager project and test-set keys, Orchestrator/robot capacity, launch/wait/report/JUnit behavior, and software-supply-chain access required by CodeBuild;
- Region/model access and data-handling approval for Bedrock, or `EnableAiDiagnostics=false`;
- public egress or private connectivity from Lambda to Appian and Tosca, plus the required CodeBuild egress path to UiPath and approved package/tool sources;
- permissions boundary, KMS/IAM/SCP requirements, evidence retention, notification integration, approver identities, rollback/forward-fix process, and operational ownership.

## CloudFormation upload note

Both templates are larger than the 51,200-byte direct `TemplateBody` API limit. Use the CloudFormation console **Upload a template file** path, or an AWS CLI deployment path that uploads the template through S3. Do not paste the template into the console editor.

## Validation completed

The delivered artifacts passed local checks for:

- YAML parsing and resource/parameter sizing;
- intrinsic `Ref`, `Fn::GetAtt`, `Fn::Sub`, `Fn::If`, and `DependsOn` references;
- embedded and readable Python syntax compilation;
- provider-neutral state-machine operation checks and state graph transition validation;
- UiPath buildspec parsing and required `uip tm` launch/wait/report/result/JUnit/evidence contract elements;
- deterministic UiPath `MOCK` execution producing a 127-test regression JUnit file with three failures and a matching normalized summary;
- JUnit fallback generation and XML parsing, including Appian native `TestRunResult` XML conversion;
- representative pure helper behavior, including Appian native-test start/status/results evaluation and Appian `COMPLETED_AND_SYNCING` remaining non-terminal;
- DOCX rendering and page-by-page visual inspection;
- accessibility audit with zero high-severity findings;
- PDF rendering/preflight and archive integrity.

A live CloudFormation `ValidateTemplate` call, change set, endpoint contract test, and stack deployment were not executed because they require the client AWS account, Region, network, IAM boundaries, Appian endpoints, and selected Tosca or UiPath environment. Those are explicit commissioning steps in the guides.

## Important operating boundaries

- Do not edit Appian-generated XML or the internal structure of an exported Appian ZIP as a remediation technique.
- AI output is advisory. It creates a structured diagnostic and recommended action; it does not modify Appian, UiPath/Tosca assets, AWS infrastructure, or production systems.
- The same S3 object version is processed once per target environment through the release ledger.
- After Appian TEST deployment, the pipeline-triggered Appian native expression-rule test gate must pass before selected-provider smoke starts.
- A completed provider invocation is not automatically a passed test gate. Provider/integration errors fail as infrastructure failures; completed JUnit containing failed tests is evaluated by the downstream quality gate and blocks promotion.
- Smoke is blocking. In pre-production, regression and E2E run in parallel only after smoke passes.
- The production approval must be assigned to authorized personnel under the client change-control and segregation-of-duties process.
- A `COMPLETED_AND_SYNCING` Appian deployment status is polled until terminal `COMPLETED`; if post-deployment sync is used, record-sync success still requires the client monitoring/control defined in the guide.
