# Demo runbook

Use **Release change** for every execution so the developer can set the V2 pipeline variables.

## Normal happy-path demonstration

```text
ToscaTestSet      = REGRESSION_1
MockToscaOutcome  = PASS
SastMode          = MOCK_PASS
```

Expected:

```text
Source               SUCCEEDED
SAST                 SUCCEEDED  → SAST_STATUS=PASSED
ValidateAndTest      SUCCEEDED  → Tosca=PASSED
CentralQualityGate   SUCCEEDED
```

Central gate outputs should include:

```text
CENTRAL_GATE_STATUS=PASSED
SAST_STATUS=PASSED
PACKAGE_VALIDATION_STATUS=SKIPPED
APPIAN_UNIT_TEST_STATUS=SKIPPED
TOSCA_STATUS=PASSED
TOSCA_ADAPTER_MODE=MOCK
TOSCA_TEST_SET=REGRESSION_1
```

## Developer selects a different Tosca scope

```text
ToscaTestSet      = REGRESSION_2
MockToscaOutcome  = PASS
SastMode          = MOCK_PASS
```

Verify Step Functions output:

```text
resolvedTestSet=REGRESSION_2
executionListKey=DEMO_REGRESSION_2
```

## AUTO demonstration

```text
ToscaTestSet=AUTO
```

Verify:

```text
requestedTestSet=AUTO
resolvedTestSet=FULL_REGRESSION
selectionMode=AUTO_SAFE_FALLBACK
selectionReason=NO_PACKAGE_IMPACT_DATA_FULL_REGRESSION_SELECTED
```

Explain that full regression is selected conservatively until real Appian package-impact metadata is available.

## Tosca quality failure

```text
ToscaTestSet      = REGRESSION_1
MockToscaOutcome  = FAIL
SastMode          = MOCK_PASS
```

Expected:

```text
Source               SUCCEEDED
SAST                 SUCCEEDED
ValidateAndTest      SUCCEEDED
CentralQualityGate   FAILED
```

The Step Functions output must show:

```text
Tosca status=FAILED
failedTests=2
```

This proves the adapter itself executed successfully and the **central policy gate** rejected the quality result.

## SAST quality failure

```text
ToscaTestSet      = REGRESSION_1
MockToscaOutcome  = PASS
SastMode          = MOCK_FAIL
```

Expected:

```text
Source               SUCCEEDED
SAST                 SUCCEEDED  → SAST_STATUS=FAILED
ValidateAndTest      SUCCEEDED
CentralQualityGate   FAILED
```

This demonstrates the same centralized policy behavior for SAST.

## Invalid developer input

```text
ToscaTestSet=REGRESSION_99
```

Expected:

```text
ValidateAndTest=FAILED
```

This is a configuration/orchestration failure, so the pipeline should stop before the central quality gate.

## What to say during the demo

- Package validation is intentionally deferred until a genuine Appian export is available.
- Appian unit tests are intentionally deferred until the pipeline has Appian DEV API connectivity.
- The Tosca adapter is mocked, but its asynchronous START/STATUS/RESULT contract is shaped so the real Tosca implementation replaces the adapter internals rather than the pipeline architecture.
- `AUTO` currently widens to full regression rather than pretending package impact analysis exists.
- The central quality gate is already real and is the authoritative release-policy decision.
- SAST is a first-class stage. It can be switched from mock status to real SonarQube scanning without changing downstream gate wiring.
