# Console implementation — from the current checkpoint

## Starting assumption

You already have:

```text
S3 Source
   ↓
ValidateAndTest
   ↓
Temporary Step Functions workflow
```

Your package-validation placeholder currently succeeds and you do not yet have Appian connectivity.

The target for this build segment is:

```text
Source
   ↓
SAST
   ↓
ValidateAndTest
   ├─ package validation SKIPPED
   ├─ Appian unit tests SKIPPED
   ├─ developer-selectable Tosca suite
   └─ mock Tosca adapter START → STATUS → RESULT
   ↓
CentralQualityGate
   ↓
PASS / FAIL
```

---

# Part A — create the mock Tosca adapter

## A1. Create the Lambda

1. Open **AWS Lambda**.
2. Choose **Create function** → **Author from scratch**.
3. Function name: `appian-demo-mock-tosca-adapter`.
4. Runtime: **Python 3.14**.
5. Architecture: **x86_64**.
6. Create a new role with basic Lambda permissions.
7. Create the function.
8. Open `lambdas/mock-tosca-adapter/lambda_function.py` from this package.
9. Replace the contents of `lambda_function.py` in the console with that file.
10. Choose **Deploy**.
11. Set timeout to **30 seconds** and memory to **256 MB**.
12. Copy the function ARN.

No secrets, VPC, Appian permissions, Tosca permissions, or S3 permissions are needed for this mock.

## A2. Test the adapter directly

Create these Lambda test events.

START:

```json
{
  "operation": "START",
  "pipelineExecutionId": "manual-001",
  "executionListKey": "DEMO_REGRESSION_1"
}
```

Expected: `status=RUNNING` and a `mock-tosca-...` execution ID.

STATUS (use the returned execution ID):

```json
{
  "operation": "STATUS",
  "executionId": "mock-tosca-example"
}
```

Expected: `status=COMPLETE`, `complete=true`.

RESULT pass:

```json
{
  "operation": "RESULT",
  "executionId": "mock-tosca-example",
  "mockOutcome": "PASS",
  "plannedTestCount": 8
}
```

Expected: `status=PASSED`, `failedTests=0`.

RESULT fail:

```json
{
  "operation": "RESULT",
  "executionId": "mock-tosca-example",
  "mockOutcome": "FAIL",
  "plannedTestCount": 8
}
```

Expected: `status=FAILED`, `failedTests=2`.

---

# Part B — update Step Functions

## B1. Give the Step Functions role permission to invoke the mock adapter

1. Open **Step Functions** → your existing state machine → **Details**.
2. Open its **Execution role** in IAM.
3. Add an inline policy:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "InvokeMockToscaAdapter",
      "Effect": "Allow",
      "Action": "lambda:InvokeFunction",
      "Resource": "YOUR_MOCK_TOSCA_LAMBDA_ARN"
    }
  ]
}
```

Policy name: `InvokeMockToscaAdapter`.

## B2. Replace the state-machine definition

1. Open `step-functions/validate-and-test-mock.asl.json`.
2. Replace every `__MOCK_TOSCA_ADAPTER_ARN__` with the real mock Tosca Lambda ARN.
3. Open your existing **Standard** state machine → **Edit** → **Code**.
4. Replace the complete current definition with the edited JSON.
5. Save.

Do not change the workflow to Express.

## B3. Direct-test Step Functions

Use:

```json
{
  "pipelineExecutionId": "manual-sfn-001",
  "environment": "DEV",
  "sourceVersion": "placeholder-version",
  "sourceETag": "placeholder-etag",
  "toscaTestSet": "REGRESSION_1",
  "mockToscaOutcome": "PASS"
}
```

Expected terminal status: **Succeeded**.

Expected output highlights:

```json
{
  "packageValidation": {"status": "SKIPPED"},
  "appianUnitTests": {"status": "SKIPPED"},
  "tosca": {
    "resolvedTestSet": "REGRESSION_1",
    "executionListKey": "DEMO_REGRESSION_1",
    "adapterMode": "MOCK",
    "status": "PASSED"
  }
}
```

Repeat with:

- `REGRESSION_2`
- `FULL_REGRESSION`
- `AUTO` — must resolve to `FULL_REGRESSION`
- `mockToscaOutcome=FAIL` — state machine must still **Succeed**, while the output says `tosca.status=FAILED`

That last behavior is deliberate: the adapter successfully reported a failed quality result; the central quality gate will reject it.

---

# Part C — create the Central Quality Gate

## C1. Create Lambda

1. Open **Lambda** → **Create function**.
2. Name: `appian-demo-central-quality-gate`.
3. Runtime: **Python 3.14**.
4. Architecture: **x86_64**.
5. Create a new basic execution role.
6. Replace `lambda_function.py` with `lambdas/central-quality-gate/lambda_function.py`.
7. Deploy.
8. Set timeout to **30 seconds**, memory **256 MB**.
9. Copy the function ARN.

Do not add a log statement that prints the full CodePipeline event.

## C2. Central-gate Lambda IAM

Open its execution role and add:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "ReadValidationExecution",
      "Effect": "Allow",
      "Action": "states:DescribeExecution",
      "Resource": "arn:aws:states:YOUR_REGION:YOUR_ACCOUNT_ID:execution:YOUR_STATE_MACHINE_NAME:*"
    },
    {
      "Sid": "ReportPipelineResult",
      "Effect": "Allow",
      "Action": [
        "codepipeline:PutJobSuccessResult",
        "codepipeline:PutJobFailureResult"
      ],
      "Resource": "*"
    }
  ]
}
```

Name: `EvaluateCentralQualityGate`.

---

# Part D — create the SonarQube-ready SAST CodeBuild project

The stage can operate immediately in `MOCK_PASS`/`MOCK_FAIL` mode. When SonarQube connectivity exists, change the pipeline execution variable to `REAL`.

## D1. Create placeholder Sonar token secret

1. Open **Secrets Manager** → **Store a new secret**.
2. Secret type: **Other type of secret**.
3. Key/value:

```text
token = REPLACE_ME_BEFORE_REAL_SAST
```

4. Secret name: `appian-demo/sonarqube/token`.
5. Store it.
6. Copy the secret ARN.

## D2. Create CodeBuild project

1. Open **CodeBuild** → **Build projects** → **Create build project**.
2. Project name: `appian-demo-sast`.
3. Source provider: **CodePipeline**.
4. Environment:
   - Managed image
   - Operating system: Amazon Linux
   - Image: `aws/codebuild/amazonlinux-x86_64-standard:6.0` (5.0 is also supported)
   - Compute: small/general-purpose is sufficient for the demo
   - New service role
5. Buildspec: choose **Insert build commands** / buildspec editor and paste the complete contents of `codebuild/sast/buildspec.yml`.
6. Add project environment variables:

| Name | Value | Type |
|---|---|---|
| `SAST_MODE` | `MOCK_PASS` | Plaintext |
| `SONAR_HOST_URL` | `https://replace-me.invalid` | Plaintext |
| `SONAR_PROJECT_KEY` | `appian-devops-demo` | Plaintext |
| `SONAR_TOKEN` | `appian-demo/sonarqube/token:token` | Secrets Manager |

7. Create the project.

## D3. CodeBuild role permissions

Open the CodeBuild service role and add permission to read the Sonar token secret:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "secretsmanager:GetSecretValue",
      "Resource": "YOUR_SONAR_SECRET_ARN"
    }
  ]
}
```

The role also needs normal CodeBuild log permissions and access to the CodePipeline artifact bucket; the console-created CodeBuild role/pipeline integration normally establishes the baseline, but verify S3 access if the first build reports artifact AccessDenied.

### REAL mode later

Before selecting `REAL`:

1. Replace the placeholder token in Secrets Manager with a real SonarQube token.
2. Edit `SONAR_HOST_URL` and `SONAR_PROJECT_KEY`.
3. Ensure CodeBuild can reach the SonarQube server and `binaries.sonarsource.com` (or pre-stage the scanner if outbound internet is prohibited).
4. Ensure the pipeline artifact contains scan-compatible source.

A red Sonar quality gate becomes `SAST_STATUS=FAILED`; the build itself remains successful so the central gate can make the release decision. Scanner/network/compute-engine errors fail the SAST action directly.

---

# Part E — update CodePipeline

## E1. Pipeline properties

1. Open **CodePipeline** → your pipeline → **Edit**.
2. Pipeline type: **V2**.
3. Execution mode: **Queued**.

Queued execution is appropriate because all future Appian/Tosca testing targets one shared DEV environment.

## E2. Pipeline variables

Create/verify:

| Name | Default |
|---|---|
| `ToscaTestSet` | `FULL_REGRESSION` |
| `MockToscaOutcome` | `PASS` |
| `SastMode` | `MOCK_PASS` |

Descriptions:

- Tosca: `Allowed: REGRESSION_1, REGRESSION_2, FULL_REGRESSION, AUTO`
- Mock outcome: `DEMO ONLY: PASS or FAIL`
- SAST: `Allowed: MOCK_PASS, MOCK_FAIL, REAL`

## E3. Source action

1. Give the S3 source action the namespace `SourceVariables`.
2. Keep your existing bucket/object key.
3. Keep automatic change detection disabled for this demo so the developer can choose pipeline variables before **Release change**.
4. S3 bucket versioning should remain enabled.

This implementation uses only the consistently available S3 output variables:

```text
#{SourceVariables.VersionId}
#{SourceVariables.ETag}
```

The known bucket/object key are not needed until real package validation is added.

## E4. Add SAST stage

Add a stage immediately after Source:

```text
SAST
```

Add CodeBuild action:

| Field | Value |
|---|---|
| Action name | `RunSastScan` |
| Provider | AWS CodeBuild |
| Project | `appian-demo-sast` |
| Input artifact | `SourceArtifact` |
| Namespace | `SastVariables` |

In the action's environment-variable override, set:

```json
[
  {
    "name": "SAST_MODE",
    "value": "#{variables.SastMode}",
    "type": "PLAINTEXT"
  }
]
```

If the console presents individual rows instead of JSON, enter the same name/value/type as one row.

## E5. Update ValidateAndTest action

Edit your existing Step Functions action.

Set namespace:

```text
ValidationTestVariables
```

State machine: your updated Standard state machine.

Input type: **Literal**.

Use this exact input:

```json
{"pipelineExecutionId":"#{codepipeline.PipelineExecutionId}","environment":"DEV","sourceVersion":"#{SourceVariables.VersionId}","sourceETag":"#{SourceVariables.ETag}","toscaTestSet":"#{variables.ToscaTestSet}","mockToscaOutcome":"#{variables.MockToscaOutcome}"}
```

No Step Functions input artifact is required for this literal-input workflow.

## E6. Add CentralQualityGate stage

Add a stage after `ValidateAndTest`:

```text
CentralQualityGate
```

Add an AWS Lambda action:

| Field | Value |
|---|---|
| Action name | `EvaluateQualityGate` |
| Lambda | `appian-demo-central-quality-gate` |
| Input artifacts | none |
| Output artifacts | none |
| Namespace | `CentralGateVariables` |

User parameters:

```json
{"validationExecutionArn":"#{ValidationTestVariables.ExecutionArn}","sastStatus":"#{SastVariables.SAST_STATUS}","sastMode":"#{SastVariables.SAST_MODE_USED}","sastDetail":"#{SastVariables.SAST_DETAIL}","demoAllowSkippedChecks":"true","demoAllowMockedTosca":"true"}
```

Save the pipeline.

---

# Part F — CodePipeline service-role permissions

Open the existing CodePipeline service role and verify/add permissions for the three action providers.

Replace the ARNs below.

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "RunSastCodeBuild",
      "Effect": "Allow",
      "Action": [
        "codebuild:StartBuild",
        "codebuild:BatchGetBuilds"
      ],
      "Resource": "YOUR_CODEBUILD_PROJECT_ARN"
    },
    {
      "Sid": "RunValidationStateMachine",
      "Effect": "Allow",
      "Action": [
        "states:StartExecution",
        "states:DescribeStateMachine"
      ],
      "Resource": "YOUR_STATE_MACHINE_ARN"
    },
    {
      "Sid": "MonitorValidationStateMachine",
      "Effect": "Allow",
      "Action": "states:DescribeExecution",
      "Resource": "arn:aws:states:YOUR_REGION:YOUR_ACCOUNT_ID:execution:YOUR_STATE_MACHINE_NAME:*"
    },
    {
      "Sid": "InvokeCentralGate",
      "Effect": "Allow",
      "Action": "lambda:InvokeFunction",
      "Resource": "YOUR_CENTRAL_GATE_LAMBDA_ARN"
    }
  ]
}
```

Keep the existing S3/artifact-store permissions already used by your pipeline.

---

# Part G — upload the placeholder source

Use the provided `placeholder-source.zip`.

1. Open your source S3 bucket.
2. Upload `placeholder-source.zip` under the exact object key configured in the Source action.
3. If your source key has a different filename, rename the ZIP before upload; the contents do not matter yet.
4. Confirm a new S3 VersionId exists.

---

# Part H — run the checkpoint tests

Run the matrix in `DEMO_RUNBOOK.md`.

Minimum acceptance tests:

1. `SastMode=MOCK_PASS`, `ToscaTestSet=REGRESSION_1`, `MockToscaOutcome=PASS` → pipeline green.
2. `REGRESSION_2` → verify resolved execution list changes.
3. `AUTO` → verify it resolves to `FULL_REGRESSION` with safe-fallback reason.
4. `MockToscaOutcome=FAIL` → SAST green, ValidateAndTest green, **CentralQualityGate red**.
5. `SastMode=MOCK_FAIL`, Tosca PASS → SAST green, ValidateAndTest green, **CentralQualityGate red**.

At that point the official demo architecture is functioning end to end even though Appian-specific connectivity remains deferred.
