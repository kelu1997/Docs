# Replacement plan — mock to connected implementation

The point of the current package is that each deferred capability can be replaced independently.

## 1. Package validation

Current state:

```text
PackageValidationTemporarilySkipped (Pass)
```

Replace with:

```text
ValidatePackage (Lambda Task)
   ↓
Valid?
 ├─ no → technical/validation failure
 └─ yes → Appian test step
```

The package validator can read the exact S3 object version selected by CodePipeline. The source bucket and object key are known deployment configuration; `SourceVariables.VersionId` is already carried through the workflow.

When real package validation is active, change its central-gate result from `SKIPPED` to `PASSED`/`FAILED` and eventually set `demoAllowSkippedChecks=false`.

## 2. Appian DEV unit tests

Current state:

```text
AppianUnitTestsTemporarilySkipped (Pass)
```

Replace with an Appian adapter pattern:

```text
Start Appian rule tests
   ↓
Wait
   ↓
Poll status
   ↓
Retrieve result
```

All calls target the same existing Appian **DEV** environment. No extra Appian test environment is introduced.

Recommended adapter contract:

```json
{"operation":"START","environment":"DEV","pipelineExecutionId":"..."}
{"operation":"STATUS","testRunId":"..."}
{"operation":"RESULT","testRunId":"..."}
```

Store Appian API credentials in Secrets Manager and grant access only to the Appian adapter Lambda.

## 3. Tosca

Current implementation:

```text
Mock Tosca Lambda
START → STATUS → RESULT
```

Do **not** redesign the state machine. Replace the internals of `lambdas/mock-tosca-adapter/lambda_function.py` or deploy a new real adapter Lambda with the same contract.

Production-shaped request contract:

```json
{
  "operation": "START",
  "pipelineExecutionId": "...",
  "executionListKey": "REGRESSION_EXECUTION_LIST_ID"
}
```

Status:

```json
{
  "operation": "STATUS",
  "executionId": "external-run-id"
}
```

Result:

```json
{
  "operation": "RESULT",
  "executionId": "external-run-id"
}
```

Expected normalized result:

```json
{
  "adapterMode": "REAL",
  "status": "PASSED",
  "totalTests": 19,
  "passedTests": 19,
  "failedTests": 0
}
```

Delete pipeline variable `MockToscaOutcome` when the real adapter is active and set `demoAllowMockedTosca=false` in the central gate action.

## 4. AUTO test selection

Current:

```text
AUTO → FULL_REGRESSION
```

Future:

```text
Appian package/change metadata
   ↓
Impact resolver
   ↓
Object/component-to-test mapping
   ↓
One or more Tosca execution lists
```

Unknown impact should widen scope rather than omit tests.

The included `config/tosca-test-map.json` is the starting point for externalizing suite metadata. It is not consumed dynamically by the current workflow.

## 5. SonarQube

Current CodeBuild buildspec already supports `REAL`.

To enable:

1. Put a real token in `appian-demo/sonarqube/token`.
2. Set the CodeBuild project's `SONAR_HOST_URL`.
3. Set `SONAR_PROJECT_KEY`.
4. Ensure networking from CodeBuild to SonarQube.
5. Ensure the input artifact contains source that SonarQube analyzers can meaningfully inspect.
6. Run with `SastMode=REAL`.

A red Sonar quality gate is normalized to `SAST_STATUS=FAILED` and is rejected by CentralQualityGate. A scanner/infrastructure error fails the SAST action directly.

## 6. Tighten the central gate

During the current mock phase:

```json
"demoAllowSkippedChecks":"true",
"demoAllowMockedTosca":"true"
```

After package validation, Appian tests, and real Tosca are connected:

```json
"demoAllowSkippedChecks":"false",
"demoAllowMockedTosca":"false"
```

At that point the central gate requires every configured quality control to be genuinely passed.
