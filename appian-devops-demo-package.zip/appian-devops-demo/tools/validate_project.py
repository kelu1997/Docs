#!/usr/bin/env python3
"""Local consistency checks for the demo package (no AWS credentials required)."""

from __future__ import annotations

import hashlib
import json
import py_compile
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]


class CfnLoader(yaml.SafeLoader):
    pass


def _cfn_tag(loader, tag_suffix, node):
    if isinstance(node, yaml.ScalarNode):
        return loader.construct_scalar(node)
    if isinstance(node, yaml.SequenceNode):
        return loader.construct_sequence(node)
    return loader.construct_mapping(node)


CfnLoader.add_multi_constructor("!", _cfn_tag)


def validate_state_machine(path: Path) -> None:
    data = json.loads(path.read_text())
    states = data["States"]
    assert data["StartAt"] in states
    for name, state in states.items():
        if "Next" in state:
            assert state["Next"] in states, (name, state["Next"])
        for choice in state.get("Choices", []):
            assert choice["Next"] in states, (name, choice["Next"])
        if "Default" in state:
            assert state["Default"] in states, (name, state["Default"])
        for catcher in state.get("Catch", []):
            assert catcher["Next"] in states, (name, catcher["Next"])
    assert "__MOCK_TOSCA_ADAPTER_ARN__" in path.read_text()


def main() -> None:
    validate_state_machine(ROOT / "step-functions/validate-and-test-mock.asl.json")
    json.loads((ROOT / "config/tosca-test-map.json").read_text())

    py_compile.compile(str(ROOT / "lambdas/mock-tosca-adapter/lambda_function.py"), doraise=True)
    py_compile.compile(str(ROOT / "lambdas/central-quality-gate/lambda_function.py"), doraise=True)

    cfn = yaml.load(
        (ROOT / "cloudformation/official-demo-reference.yaml").read_text(),
        Loader=CfnLoader,
    )
    assert cfn["Resources"]["Pipeline"]["Properties"]["PipelineType"] == "V2"
    assert cfn["Resources"]["Pipeline"]["Properties"]["ExecutionMode"] == "QUEUED"

    test_map = json.loads((ROOT / "config/tosca-test-map.json").read_text())
    assert test_map["AUTO"]["fallback"] == "FULL_REGRESSION"

    print("Local validation passed:")
    print("- JSON syntax and state transitions")
    print("- Python syntax")
    print("- CloudFormation YAML syntax/basic structure")
    print("- pipeline V2/QUEUED and AUTO fallback invariants")


if __name__ == "__main__":
    main()
