"""Mock Tosca adapter for the Appian DevOps demo.

The public contract intentionally mirrors an asynchronous external-test adapter:
START -> STATUS -> RESULT. Replace the internals with real Tosca API calls later
while retaining the event/response shapes used by the Step Functions workflow.
"""

from __future__ import annotations

import hashlib
from typing import Any, Dict


ALLOWED_OPERATIONS = {"START", "STATUS", "RESULT"}
ALLOWED_OUTCOMES = {"PASS", "FAIL"}


def _require(event: Dict[str, Any], name: str) -> Any:
    value = event.get(name)
    if value is None or value == "":
        raise ValueError(f"Missing required field: {name}")
    return value


def _execution_id(pipeline_execution_id: str, execution_list_key: str) -> str:
    seed = f"{pipeline_execution_id}:{execution_list_key}".encode("utf-8")
    digest = hashlib.sha256(seed).hexdigest()[:16]
    return f"mock-tosca-{digest}"


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    operation = str(_require(event, "operation")).upper()
    if operation not in ALLOWED_OPERATIONS:
        raise ValueError(f"Unsupported operation: {operation}")

    if operation == "START":
        pipeline_execution_id = str(_require(event, "pipelineExecutionId"))
        execution_list_key = str(_require(event, "executionListKey"))
        return {
            "adapterMode": "MOCK",
            "operation": "START",
            "executionId": _execution_id(pipeline_execution_id, execution_list_key),
            "executionListKey": execution_list_key,
            "status": "RUNNING",
        }

    execution_id = str(_require(event, "executionId"))

    if operation == "STATUS":
        # The mock completes on the first status poll. The Step Functions loop is
        # still present so the real adapter can return RUNNING until Tosca finishes.
        return {
            "adapterMode": "MOCK",
            "operation": "STATUS",
            "executionId": execution_id,
            "status": "COMPLETE",
            "complete": True,
        }

    outcome = str(_require(event, "mockOutcome")).upper()
    if outcome not in ALLOWED_OUTCOMES:
        raise ValueError("mockOutcome must be PASS or FAIL")

    planned_test_count = int(_require(event, "plannedTestCount"))
    if planned_test_count < 1:
        raise ValueError("plannedTestCount must be >= 1")

    failed = 0 if outcome == "PASS" else min(2, planned_test_count)
    passed = planned_test_count - failed

    return {
        "adapterMode": "MOCK",
        "operation": "RESULT",
        "executionId": execution_id,
        "status": "PASSED" if failed == 0 else "FAILED",
        "totalTests": planned_test_count,
        "passedTests": passed,
        "failedTests": failed,
        "failureSummary": [] if failed == 0 else [
            "MOCK-TC-001: Simulated regression assertion failure",
            "MOCK-TC-002: Simulated UI validation failure",
        ][:failed],
    }
