"""Central release-quality gate for the Appian DevOps demo CodePipeline.

The Lambda is invoked as a CodePipeline Lambda action. It reads the completed
ValidateAndTest Step Functions execution, combines it with the SAST result, and
reports one authoritative PASS/FAIL decision back to CodePipeline.

Do not log the complete CodePipeline event: it can contain temporary artifact
credentials.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List

import boto3

stepfunctions = boto3.client("stepfunctions")
codepipeline = boto3.client("codepipeline")


def _bool(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def _fail(job_id: str, message: str) -> None:
    codepipeline.put_job_failure_result(
        jobId=job_id,
        failureDetails={"type": "JobFailed", "message": message[:5000]},
    )


def _get_user_parameters(job: Dict[str, Any]) -> Dict[str, Any]:
    raw = (
        job.get("data", {})
        .get("actionConfiguration", {})
        .get("configuration", {})
        .get("UserParameters", "{}")
    )
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValueError(f"UserParameters is not valid JSON: {exc}") from exc
    if not isinstance(parsed, dict):
        raise ValueError("UserParameters must be a JSON object")
    return parsed


def lambda_handler(event: Dict[str, Any], context: Any) -> None:
    job = event.get("CodePipeline.job")
    if not isinstance(job, dict) or not job.get("id"):
        raise ValueError("This Lambda must be invoked by a CodePipeline Lambda action")

    job_id = job["id"]

    try:
        parameters = _get_user_parameters(job)
        execution_arn = parameters["validationExecutionArn"]
        sast_status = str(parameters.get("sastStatus", "UNKNOWN")).upper()
        sast_mode = str(parameters.get("sastMode", "UNKNOWN")).upper()
        sast_detail = str(parameters.get("sastDetail", "UNSPECIFIED"))
        allow_skipped = _bool(parameters.get("demoAllowSkippedChecks"), default=True)
        allow_mocked_tosca = _bool(parameters.get("demoAllowMockedTosca"), default=True)

        execution = stepfunctions.describe_execution(executionArn=execution_arn)
        if execution.get("status") != "SUCCEEDED":
            _fail(
                job_id,
                "Central quality gate could not evaluate results because the "
                f"validation workflow status is {execution.get('status', 'UNKNOWN')}.",
            )
            return

        output = json.loads(execution.get("output") or "{}")
        package = output.get("packageValidation", {})
        appian = output.get("appianUnitTests", {})
        tosca = output.get("tosca", {})

        package_status = str(package.get("status", "UNKNOWN")).upper()
        appian_status = str(appian.get("status", "UNKNOWN")).upper()
        tosca_status = str(tosca.get("status", "UNKNOWN")).upper()
        tosca_mode = str(tosca.get("adapterMode", "UNKNOWN")).upper()
        tosca_test_set = str(tosca.get("resolvedTestSet", "UNKNOWN"))

        failures: List[str] = []
        permitted_deferred = {"PASSED", "SKIPPED"} if allow_skipped else {"PASSED"}

        if sast_status not in permitted_deferred:
            failures.append(f"SAST={sast_status} ({sast_detail})")
        if package_status not in permitted_deferred:
            failures.append(f"PackageValidation={package_status}")
        if appian_status not in permitted_deferred:
            failures.append(f"AppianUnitTests={appian_status}")
        if tosca_status != "PASSED":
            failures.append(f"Tosca={tosca_status}")
        if tosca_mode == "MOCK" and not allow_mocked_tosca:
            failures.append("Tosca adapter is still MOCK")

        if failures:
            _fail(job_id, "Central quality gate FAILED: " + "; ".join(failures))
            return

        codepipeline.put_job_success_result(
            jobId=job_id,
            outputVariables={
                "CENTRAL_GATE_STATUS": "PASSED",
                "SAST_STATUS": sast_status,
                "SAST_MODE": sast_mode,
                "PACKAGE_VALIDATION_STATUS": package_status,
                "APPIAN_UNIT_TEST_STATUS": appian_status,
                "TOSCA_STATUS": tosca_status,
                "TOSCA_ADAPTER_MODE": tosca_mode,
                "TOSCA_TEST_SET": tosca_test_set,
            },
        )
    except Exception as exc:  # CodePipeline must receive a terminal result.
        _fail(job_id, f"Central quality gate evaluation error: {type(exc).__name__}: {exc}")
