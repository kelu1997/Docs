# Appian DevOps AWS Demo Package

This repository is the console-first demo implementation package for the current architecture.
It intentionally keeps Appian-specific integrations deferred until Appian DEV connectivity and a real export package are available.

## Current official demo architecture

```text
S3 Source
   ↓
SAST (CodeBuild; SonarQube-ready, mockable until Sonar is connected)
   ↓
ValidateAndTest (Step Functions Standard)
   ├─ Package validation          SKIPPED temporarily
   ├─ Appian DEV unit tests      SKIPPED temporarily
   ├─ Tosca suite selection      REAL orchestration
   └─ Tosca adapter execution    MOCK adapter Lambda
   ↓
CentralQualityGate (Lambda)      REAL release decision
   ↓
PASS / FAIL
```

All future Appian testing is against the **single existing Appian DEV environment**. There is no test-environment deployment in this demo architecture.

## What is real vs mocked today

| Capability | Current implementation |
|---|---|
| S3 source / CodePipeline | Real |
| Pipeline variables / developer Tosca selection | Real |
| SAST stage | Real CodeBuild stage; `MOCK_PASS`, `MOCK_FAIL`, or `REAL` SonarQube mode |
| Package validation | Explicit `SKIPPED` placeholder |
| Appian unit tests | Explicit `SKIPPED` placeholder |
| Tosca selection | Real orchestration |
| Tosca API | Mock adapter with production-shaped START/STATUS/RESULT contract |
| Central quality gate | Real |
| Final pipeline PASS/FAIL | Real |

## Files you actually need now

- `step-functions/validate-and-test-mock.asl.json` — replace your current state-machine definition with this and substitute the mock Tosca Lambda ARN.
- `lambdas/mock-tosca-adapter/lambda_function.py` — deploy as the mock Tosca adapter.
- `lambdas/central-quality-gate/lambda_function.py` — deploy as the central gate CodePipeline Lambda action.
- `codebuild/sast/buildspec.yml` — paste into the SAST CodeBuild project's buildspec editor.
- `placeholder-source.zip` — upload to your existing S3 source object key until an Appian export exists.
- `docs/CONSOLE_IMPLEMENTATION.md` — exact console build sequence from the current checkpoint.
- `docs/DEMO_RUNBOOK.md` — test matrix and presentation behavior.
- `docs/REPLACEMENT_PLAN.md` — how to replace each mock later without redesigning the pipeline.

## Pipeline variables

Create these V2 pipeline variables:

| Variable | Default | Allowed for demo |
|---|---|---|
| `ToscaTestSet` | `FULL_REGRESSION` | `REGRESSION_1`, `REGRESSION_2`, `FULL_REGRESSION`, `AUTO` |
| `MockToscaOutcome` | `PASS` | `PASS`, `FAIL` |
| `SastMode` | `MOCK_PASS` | `MOCK_PASS`, `MOCK_FAIL`, `REAL` |

`MockToscaOutcome` is deleted when the real Tosca API is connected. `SastMode` can remain useful as an operational switch, but production should normally force `REAL`.

## AUTO behavior

`AUTO` currently resolves conservatively to `FULL_REGRESSION` because there is no real Appian package-impact data yet. This is deliberate; the demo never claims to have performed dependency analysis it did not perform.

## SonarQube behavior

The SAST buildspec exports three CodePipeline variables:

- `SAST_STATUS`: `PASSED`, `FAILED`, or `ERROR`
- `SAST_MODE_USED`: `MOCK_PASS`, `MOCK_FAIL`, or `REAL`
- `SAST_DETAIL`: compact reason code

In `REAL` mode, the scanner submits analysis, waits for SonarQube processing through the Web API, and turns a red Sonar quality gate into `SAST_STATUS=FAILED` **without failing the CodeBuild action**. This allows the downstream `CentralQualityGate` to remain the authoritative quality-policy decision. A scanner/compute-engine technical error still fails CodeBuild directly.

SonarQube scanning should be presented as SAST/code-quality analysis for scan-compatible source such as integration code, Lambda code, scripts, plug-ins, or IaC. Do not claim that generic SonarQube scanning provides semantic SAST of Appian design objects merely because they are exported as XML.

## Recommended use from your current checkpoint

Do **not** rebuild your existing pipeline from scratch. Follow `docs/CONSOLE_IMPLEMENTATION.md` and use the individual files above.

The `cloudformation/official-demo-reference.yaml` file is included for handoff/reproducibility and clean-room deployment. It is not the recommended way to modify the pipeline you already started manually.

## Authoritative references used when assembling this package

- AWS CodePipeline Step Functions action reference
- AWS CodePipeline Lambda action reference
- AWS CodePipeline variables reference
- AWS CodeBuild buildspec/exported-variable reference
- AWS CodePipeline V2/queued execution documentation
- SonarQube Server SonarScanner CLI documentation
- SonarQube Server Web API authentication documentation
- SonarQube quality-gate analysis parameters documentation
