# CloudFormation

`official-demo-reference.yaml` is a **greenfield/reference stack** for the official demo architecture. It creates its own:

- source S3 bucket (versioned)
- artifact bucket
- CodePipeline V2 in QUEUED mode
- CodeBuild SAST project
- placeholder SonarQube token secret
- mock Tosca adapter Lambda
- Step Functions Standard workflow
- central quality-gate Lambda
- IAM roles and 14-day log groups

## Do not use it to modify the pipeline you already built

Your current build is console-first. Follow `../docs/CONSOLE_IMPLEMENTATION.md` and reuse your existing Source/CodePipeline/Step Functions resources.

Use this template for one of three purposes:

1. client handoff / IaC reference;
2. a clean-room rebuild in a separate stack/account;
3. later consolidation once you intentionally decide to replace the manually-built demo with an IaC-managed version.

## Greenfield deployment

1. Open CloudFormation → Create stack → With new resources.
2. Upload `official-demo-reference.yaml`.
3. Set `ProjectName` if desired.
4. Leave Sonar URL/project defaults while using mock SAST.
5. Acknowledge IAM resource creation.
6. Create the stack.
7. Upload `../placeholder-source.zip` to the generated Source bucket using the stack output `SourceObjectKey`.
8. Open the created CodePipeline and choose Release change.
9. Use the test matrix in `../docs/DEMO_RUNBOOK.md`.

Before `SastMode=REAL`, update the generated Sonar secret and CodeBuild Sonar URL/project configuration.
