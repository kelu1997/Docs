Temporary source artifact for the Appian DevOps pipeline demo.

There is intentionally no real Appian export in this archive yet.
Package validation and Appian DEV unit-test execution are explicitly marked SKIPPED.
The SAST stage can run in MOCK_PASS/MOCK_FAIL until a SonarQube target and scan-compatible source are available.
