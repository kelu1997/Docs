import importlib.util
from pathlib import Path
import unittest

MODULE_PATH = Path(__file__).resolve().parents[1] / "lambdas/mock-tosca-adapter/lambda_function.py"
spec = importlib.util.spec_from_file_location("mock_tosca_adapter", MODULE_PATH)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class MockToscaAdapterTests(unittest.TestCase):
    def test_pass_flow(self):
        started = module.lambda_handler(
            {
                "operation": "START",
                "pipelineExecutionId": "pipeline-1",
                "executionListKey": "DEMO_REGRESSION_1",
            },
            None,
        )
        self.assertEqual(started["status"], "RUNNING")
        status = module.lambda_handler(
            {"operation": "STATUS", "executionId": started["executionId"]}, None
        )
        self.assertTrue(status["complete"])
        result = module.lambda_handler(
            {
                "operation": "RESULT",
                "executionId": started["executionId"],
                "mockOutcome": "PASS",
                "plannedTestCount": 8,
            },
            None,
        )
        self.assertEqual(result["status"], "PASSED")
        self.assertEqual(result["failedTests"], 0)

    def test_fail_flow(self):
        result = module.lambda_handler(
            {
                "operation": "RESULT",
                "executionId": "mock-example",
                "mockOutcome": "FAIL",
                "plannedTestCount": 11,
            },
            None,
        )
        self.assertEqual(result["status"], "FAILED")
        self.assertEqual(result["failedTests"], 2)


if __name__ == "__main__":
    unittest.main()
