"""AWS Lambda integration helper for Appian package CI/CD.

The function is deliberately stateless. AWS Step Functions owns waits, retries,
branching, and timeouts; each invocation performs one bounded operation.

The same implementation supports the client demo and production. In the demo,
Appian can be simulated and the Tosca endpoint is a production-shaped mock. In
production, connection details in Secrets Manager point to real Appian and Tosca
services.
"""
from __future__ import annotations

import base64
import hashlib
import io
import json
import os
import re
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import PurePosixPath
from typing import Any, Dict, Iterable, Mapping, Optional, Tuple

import boto3
from botocore.exceptions import ClientError

s3 = boto3.client("s3")
secrets = boto3.client("secretsmanager")
ssm = boto3.client("ssm")
bedrock = boto3.client("bedrock-runtime")
sns = boto3.client("sns")
dynamodb = boto3.resource("dynamodb")

_TOKEN_CACHE: Dict[str, Tuple[str, float]] = {}

# Appian publishes exact values by version. This implementation deliberately
# handles both documented terminal labels and common machine-form labels.
APPIAN_SUCCESS = {"COMPLETED", "SUCCESS", "SUCCEEDED"}
APPIAN_FAILURE = {
    "COMPLETED_WITH_IMPORT_ERRORS",
    "COMPLETED_WITH_PUBLISH_ERRORS",
    "COMPLETED_WITH_EXPORT_ERRORS",
    "COMPLETED_WITH_ERRORS",
    "FAILED",
    "REJECTED",
    "ERROR",
    "CANCELLED",
    "CANCELED",
}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _clone(value: Mapping[str, Any]) -> Dict[str, Any]:
    """Deep-copy Step Functions input without retaining boto/Decimal objects."""
    return json.loads(json.dumps(value, default=str))


def _secret(arn: str) -> Dict[str, Any]:
    if not arn:
        raise ValueError("A required Secrets Manager ARN is not configured")
    response = secrets.get_secret_value(SecretId=arn)
    raw = response.get("SecretString")
    if raw is None:
        raw = base64.b64decode(response["SecretBinary"]).decode("utf-8")
    value = json.loads(raw)
    if not isinstance(value, dict):
        raise ValueError("Secret content must be a JSON object")
    return value


def _ssl_context(config: Mapping[str, Any]) -> ssl.SSLContext:
    context = ssl.create_default_context()
    ca_pem = config.get("caCertificatePem")
    if ca_pem:
        context.load_verify_locations(cadata=str(ca_pem))
    cert_pem = config.get("mtlsCertificatePem")
    key_pem = config.get("mtlsPrivateKeyPem")
    if cert_pem and key_pem:
        cert_path = "/tmp/client-cert.pem"
        key_path = "/tmp/client-key.pem"
        with open(cert_path, "w", encoding="utf-8") as handle:
            handle.write(str(cert_pem))
        with open(key_path, "w", encoding="utf-8") as handle:
            handle.write(str(key_pem))
        os.chmod(key_path, 0o600)
        context.load_cert_chain(
            cert_path,
            key_path,
            password=config.get("mtlsPrivateKeyPassword"),
        )
    return context


def _http(
    method: str,
    url: str,
    *,
    headers: Optional[Mapping[str, str]] = None,
    body: Optional[bytes] = None,
    timeout: int = 180,
    ssl_config: Optional[Mapping[str, Any]] = None,
    acceptable: Iterable[int] = (200, 201, 202),
) -> Tuple[int, Mapping[str, str], bytes]:
    request = urllib.request.Request(url=url, data=body, method=method.upper())
    for key, value in (headers or {}).items():
        request.add_header(key, value)
    try:
        with urllib.request.urlopen(
            request,
            timeout=timeout,
            context=_ssl_context(ssl_config or {}),
        ) as response:
            status = int(response.status)
            response_headers = dict(response.headers.items())
            payload = response.read()
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:4000]
        raise RuntimeError(f"HTTP {exc.code} from {url}: {detail}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Unable to call {url}: {exc.reason}") from exc
    if status not in set(acceptable):
        raise RuntimeError(f"Unexpected HTTP {status} from {url}")
    return status, response_headers, payload


def _json_http(*args: Any, **kwargs: Any) -> Tuple[int, Mapping[str, str], Any]:
    status, headers, payload = _http(*args, **kwargs)
    text = payload.decode("utf-8", errors="replace").strip()
    if not text:
        return status, headers, {}
    try:
        return status, headers, json.loads(text)
    except json.JSONDecodeError:
        return status, headers, text


def _join(base: str, path: str) -> str:
    return base.rstrip("/") + "/" + path.lstrip("/")


def _client_credentials(config: Mapping[str, Any], token_url: str, cache_key: str) -> str:
    cached = _TOKEN_CACHE.get(cache_key)
    if cached and cached[1] > time.time() + 30:
        return cached[0]
    form = {
        "grant_type": "client_credentials",
        "client_id": str(config["clientId"]),
        "client_secret": str(config["clientSecret"]),
    }
    if config.get("scope"):
        form["scope"] = str(config["scope"])
    _, _, response = _json_http(
        "POST",
        token_url,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        body=urllib.parse.urlencode(form).encode("utf-8"),
        timeout=int(config.get("requestTimeoutSeconds", 180)),
        ssl_config=config,
    )
    if not isinstance(response, dict) or not response.get("access_token"):
        raise RuntimeError("OAuth token endpoint did not return access_token")
    token = str(response["access_token"])
    _TOKEN_CACHE[cache_key] = (
        token,
        time.time() + int(response.get("expires_in", 300)),
    )
    return token


def _multipart(parts: Iterable[Tuple[str, Optional[str], str, bytes]]) -> Tuple[str, bytes]:
    boundary = "----AwsAppianBoundary" + uuid.uuid4().hex
    output = io.BytesIO()
    for field_name, filename, content_type, data in parts:
        output.write(f"--{boundary}\r\n".encode("utf-8"))
        disposition = f'Content-Disposition: form-data; name="{field_name}"'
        if filename:
            disposition += f'; filename="{filename}"'
        output.write((disposition + "\r\n").encode("utf-8"))
        output.write(f"Content-Type: {content_type}\r\n\r\n".encode("utf-8"))
        output.write(data)
        output.write(b"\r\n")
    output.write(f"--{boundary}--\r\n".encode("utf-8"))
    return f"multipart/form-data; boundary={boundary}", output.getvalue()


def _object_args(ctx: Mapping[str, Any]) -> Dict[str, Any]:
    args: Dict[str, Any] = {
        "Bucket": ctx["sourceBucket"],
        "Key": ctx["sourceKey"],
    }
    version = ctx.get("sourceVersion")
    if version and str(version) not in {"null", "None", ""}:
        args["VersionId"] = version
    return args


def _download(ctx: Mapping[str, Any]) -> Tuple[str, bytes]:
    response = s3.get_object(**_object_args(ctx))
    return os.path.basename(str(ctx["sourceKey"])), response["Body"].read()


def _put_json(ctx: Mapping[str, Any], suffix: str, value: Any) -> str:
    key = f"{ctx['evidencePrefix']}/{suffix}"
    s3.put_object(
        Bucket=os.environ["RESULTS_BUCKET"],
        Key=key,
        Body=json.dumps(value, indent=2, default=str).encode("utf-8"),
        ContentType="application/json",
        ServerSideEncryption="aws:kms",
        SSEKMSKeyId=os.environ["KMS_KEY_ARN"],
    )
    return key


def _put_text(
    ctx: Mapping[str, Any],
    suffix: str,
    value: str,
    content_type: str,
) -> str:
    key = f"{ctx['evidencePrefix']}/{suffix}"
    s3.put_object(
        Bucket=os.environ["RESULTS_BUCKET"],
        Key=key,
        Body=value.encode("utf-8"),
        ContentType=content_type,
        ServerSideEncryption="aws:kms",
        SSEKMSKeyId=os.environ["KMS_KEY_ARN"],
    )
    return key


# ---------------------------------------------------------------------------
# Appian deployment integration
# ---------------------------------------------------------------------------


def _appian_config(environment: str) -> Dict[str, Any]:
    return _secret(os.environ[f"APPIAN_{environment.upper()}_SECRET_ARN"])


def _appian_base(config: Mapping[str, Any]) -> str:
    base = str(config["baseUrl"]).rstrip("/")
    if base.endswith("/suite"):
        base = base[:-6]
    api_version = str(config.get("deploymentApiVersion", "v3")).strip("/")
    return f"{base}/suite/deployment-management/{api_version}"


def _appian_headers(config: Mapping[str, Any]) -> Dict[str, str]:
    auth_type = str(config.get("authType", "API_KEY")).upper()
    if auth_type == "API_KEY":
        return {"Appian-API-Key": str(config["apiKey"])}
    if auth_type == "OAUTH2":
        token_url = str(
            config.get("tokenUrl")
            or _join(str(config["baseUrl"]), "/suite/oauth/token")
        )
        token = _client_credentials(
            config,
            token_url,
            f"appian:{token_url}:{config.get('clientId', '')}",
        )
        return {"Authorization": f"Bearer {token}"}
    raise ValueError(f"Unsupported Appian authType: {auth_type}")


def _appian_post(ctx: Mapping[str, Any], operation: str) -> Dict[str, Any]:
    environment = str(ctx.get("environment", "TEST")).upper()
    config = _appian_config(environment)
    filename, package = _download(ctx)
    metadata: Dict[str, Any] = {"packageFileName": filename}
    endpoint = "inspections"
    if operation == "deployment":
        endpoint = "deployments"
        metadata.update(
            {
                "name": f"AWS release {ctx['releaseId']} to {environment}",
                "description": (
                    "Automated deployment from CodePipeline execution "
                    f"{ctx.get('pipelineExecutionId', 'manual')}"
                ),
            }
        )
    content_type, body = _multipart(
        [
            ("json", None, "application/json", json.dumps(metadata).encode("utf-8")),
            ("packageFileName", filename, "application/zip", package),
        ]
    )
    headers = _appian_headers(config)
    headers["Content-Type"] = content_type
    if operation == "deployment":
        headers["Action-Type"] = "import"
    _, _, response = _json_http(
        "POST",
        _join(_appian_base(config), endpoint),
        headers=headers,
        body=body,
        timeout=int(config.get("requestTimeoutSeconds", 600)),
        ssl_config=config,
    )
    if not isinstance(response, dict) or not response.get("uuid"):
        raise RuntimeError(f"Appian {operation} response did not contain uuid")
    return response


def _appian_get(ctx: Mapping[str, Any], operation: str, include_log: bool = False) -> Any:
    environment = str(ctx.get("environment", "TEST")).upper()
    config = _appian_config(environment)
    operation_data = ctx["appian"][operation]
    endpoint = "inspections" if operation == "inspection" else "deployments"
    path = f"{endpoint}/{operation_data['id']}"
    if include_log:
        path += "/log"
    _, response_headers, payload = _http(
        "GET",
        _join(_appian_base(config), path),
        headers=_appian_headers(config),
        timeout=int(config.get("requestTimeoutSeconds", 180)),
        ssl_config=config,
    )
    text = payload.decode("utf-8", errors="replace")
    if (
        "json" in response_headers.get("Content-Type", "").lower()
        or text.lstrip().startswith(("{", "["))
    ):
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass
    return {"content": text[:200000]}


def _appian_state(raw_status: str) -> str:
    value = str(raw_status or "UNKNOWN").upper().replace(" ", "_").replace(":", "_")
    if value in APPIAN_FAILURE or "ERROR" in value or "FAIL" in value or "REJECT" in value:
        return "FAILED"
    # Appian's "Completed: Syncing Record Types" state means import is complete
    # but record synchronization is still running. Do not begin Tosca smoke tests
    # until the API reports terminal COMPLETED.
    if value in {"COMPLETED_AND_SYNCING", "COMPLETED_SYNCING_RECORD_TYPES"}:
        return "RUNNING"
    if value in APPIAN_SUCCESS:
        return "SUCCEEDED"
    return "RUNNING"


# ---------------------------------------------------------------------------
# Appian expression-rule test integration
# ---------------------------------------------------------------------------


def _appian_native_tests_enabled() -> bool:
    return os.environ.get("APPIAN_NATIVE_TESTS_ENABLED", "true").lower() == "true"


def _appian_native_test_config(config: Mapping[str, Any]) -> Dict[str, Any]:
    configured = config.get("nativeTests") or {}
    if not isinstance(configured, dict):
        raise ValueError("Appian nativeTests secret property must be a JSON object")
    value = dict(configured)
    value.setdefault("startPath", "/suite/webapi/startRuleTestsApplications")
    value.setdefault("statusPath", "/suite/webapi/testRunStatusForId")
    value.setdefault("resultsPath", "/suite/webapi/testRunResultForId")
    value.setdefault("idQueryParameter", "id")
    value.setdefault("startMethod", "POST")
    value.setdefault("statusMethod", "GET")
    value.setdefault("resultsMethod", "GET")
    value.setdefault(
        "requestTimeoutSeconds",
        int(config.get("requestTimeoutSeconds", 180)),
    )
    return value


def _appian_site_root(config: Mapping[str, Any]) -> str:
    base = str(config["baseUrl"]).rstrip("/")
    return base[:-6] if base.lower().endswith("/suite") else base


def _appian_web_api_url(config: Mapping[str, Any], path: str) -> str:
    if str(path).lower().startswith(("http://", "https://")):
        return str(path)
    return _join(_appian_site_root(config), str(path))


def _plain_response_value(payload: bytes) -> Any:
    text = payload.decode("utf-8", errors="replace").strip()
    if not text:
        return ""
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return text.strip('"')


def _native_test_run_id(value: Any) -> str:
    if isinstance(value, dict):
        for key in ("testRunId", "id", "runId", "value"):
            if value.get(key) is not None:
                return str(value[key]).strip()
    text = str(value).strip()
    match = re.search(r"\b(\d+)\b", text)
    if not match:
        raise RuntimeError("Appian native-test start response did not contain testRunId")
    return match.group(1)


def _native_test_raw_status(value: Any) -> str:
    if isinstance(value, dict):
        for key in ("status", "state", "testRunStatus", "value"):
            if value.get(key) is not None:
                return str(value[key])
    return str(value)


def _native_test_state(raw_status: str) -> str:
    value = str(raw_status or "UNKNOWN").upper().strip().replace("_", " ")
    if value == "COMPLETE":
        return "SUCCEEDED"
    if value == "IN PROGRESS":
        return "RUNNING"
    if any(token in value for token in ("INVALID", "ERROR", "FAIL", "CANCEL")):
        return "FAILED"
    return "RUNNING"


def _xml_local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _xml_child_text(element: ET.Element, name: str, default: str = "") -> str:
    for child in list(element):
        if _xml_local_name(child.tag) == name:
            return (child.text or "").strip()
    return default


def _xml_children(element: ET.Element, name: str) -> Iterable[ET.Element]:
    for child in list(element):
        if _xml_local_name(child.tag) == name:
            yield child


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(str(value or default).strip())
    except (TypeError, ValueError):
        return default


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(str(value or default).strip())
    except (TypeError, ValueError):
        return default


def _appian_native_xml_to_junit(xml_text: str) -> Tuple[str, Dict[str, Any]]:
    try:
        appian_root = ET.fromstring(xml_text)
    except ET.ParseError as exc:
        raise RuntimeError(f"Appian native-test result XML is invalid: {exc}") from exc

    test_count = _safe_int(_xml_child_text(appian_root, "testCount"))
    failure_count = _safe_int(_xml_child_text(appian_root, "failureCount"))
    error_count = _safe_int(_xml_child_text(appian_root, "errorCount"))
    pass_count = _safe_int(_xml_child_text(appian_root, "passCount"))
    elapsed = _safe_float(_xml_child_text(appian_root, "totalElapsedTime"))
    raw_status = _xml_child_text(appian_root, "status", "UNKNOWN").upper()

    junit_root = ET.Element(
        "testsuites",
        {
            "name": _xml_child_text(appian_root, "type", "Appian Native Tests"),
            "tests": str(test_count),
            "failures": str(failure_count),
            "errors": str(error_count),
            "time": str(elapsed),
        },
    )
    failed_tests = []
    generated_cases = 0

    for application in _xml_children(appian_root, "applicationTestResults"):
        suite = ET.SubElement(
            junit_root,
            "testsuite",
            {
                "name": _xml_child_text(application, "name", "Appian Application"),
                "tests": _xml_child_text(application, "testCount", "0"),
                "failures": _xml_child_text(application, "failureCount", "0"),
                "errors": _xml_child_text(application, "errorCount", "0"),
                "time": _xml_child_text(application, "totalExecutionTime", "0"),
            },
        )
        app_error = _xml_child_text(application, "errorMessage")
        if app_error:
            ET.SubElement(suite, "system-err").text = app_error

        for object_group_name in ("problemObjectsTestResult", "passObjectsTestResult"):
            for rule_result in _xml_children(application, object_group_name):
                rule_name = _xml_child_text(rule_result, "name", "ExpressionRule")
                rule_url = _xml_child_text(rule_result, "url")
                for test_case in _xml_children(rule_result, "testCasesResult"):
                    case_name = _xml_child_text(test_case, "name", "NO_NAME")
                    status = _xml_child_text(test_case, "status", "UNKNOWN").upper()
                    case = ET.SubElement(
                        suite,
                        "testcase",
                        {
                            "classname": rule_name,
                            "name": case_name,
                            "time": _xml_child_text(test_case, "executionTime", "0"),
                            "status": status,
                        },
                    )
                    generated_cases += 1
                    if status in {"ERROR", "TIMEOUT"}:
                        message = _xml_child_text(
                            test_case,
                            "errorMessage",
                            "Appian expression-rule test error",
                        )
                        ET.SubElement(case, "error", {"message": message[:1000]}).text = (
                            message + (f"\nExpression Rule: {rule_url}" if rule_url else "")
                        )
                        failed_tests.append(
                            {
                                "application": _xml_child_text(application, "name"),
                                "rule": rule_name,
                                "test": case_name,
                                "status": status,
                                "message": message,
                                "url": rule_url,
                            }
                        )
                    elif status == "FAIL":
                        message = _xml_child_text(
                            test_case,
                            "failureMessage",
                            "Appian expression-rule assertion failed",
                        )
                        ET.SubElement(case, "failure", {"message": message[:1000]}).text = (
                            message + (f"\nExpression Rule: {rule_url}" if rule_url else "")
                        )
                        failed_tests.append(
                            {
                                "application": _xml_child_text(application, "name"),
                                "rule": rule_name,
                                "test": case_name,
                                "status": status,
                                "message": message,
                                "url": rule_url,
                            }
                        )

    # Some Appian versions/custom Web APIs may return only aggregate fields.
    # Preserve a valid and meaningful JUnit report in that case.
    if generated_cases == 0:
        suite = ET.SubElement(
            junit_root,
            "testsuite",
            {
                "name": "Appian Native Expression Rules",
                "tests": str(max(test_count, 1)),
                "failures": str(failure_count),
                "errors": str(error_count),
                "time": str(elapsed),
            },
        )
        case = ET.SubElement(
            suite,
            "testcase",
            {"classname": "Appian", "name": "ExpressionRuleBatch", "time": str(elapsed)},
        )
        if failure_count or error_count or raw_status in {"FAIL", "ERROR"}:
            message = "Appian returned aggregate native-test failures without case details"
            element_name = "error" if error_count or raw_status == "ERROR" else "failure"
            ET.SubElement(case, element_name, {"message": message}).text = message
            failed_tests.append(
                {
                    "application": "",
                    "rule": "",
                    "test": "ExpressionRuleBatch",
                    "status": raw_status,
                    "message": message,
                    "url": "",
                }
            )

    junit_xml = ET.tostring(junit_root, encoding="unicode", xml_declaration=True)
    failed = failure_count + error_count
    if test_count == 0 and generated_cases:
        test_count = generated_cases
    if pass_count == 0 and test_count >= failed:
        pass_count = test_count - failed
    summary = {
        "status": "PASSED" if raw_status == "PASS" and failed == 0 else "FAILED",
        "rawStatus": raw_status,
        "total": test_count,
        "passed": pass_count,
        "failed": failed,
        "failures": failure_count,
        "errors": error_count,
        "durationSeconds": elapsed,
        "failedTests": failed_tests[:50],
    }
    return junit_xml, summary


def _mock_appian_native_results(failed: bool) -> str:
    namespace = "http://www.appian.com/ae/types/2009"
    ET.register_namespace("a", namespace)

    def element(parent: ET.Element, name: str, value: Any = None) -> ET.Element:
        child = ET.SubElement(parent, f"{{{namespace}}}{name}")
        if value is not None:
            child.text = str(value)
        return child

    root = ET.Element(f"{{{namespace}}}TestRunResult")
    element(root, "id", 42)
    element(root, "type", "Application Test")
    element(root, "status", "FAIL" if failed else "PASS")
    element(root, "totalExecutionTime", "0.125")
    element(root, "totalElapsedTime", "0.480")
    element(root, "testCount", 6)
    element(root, "errorCount", 0)
    element(root, "failureCount", 1 if failed else 0)
    element(root, "passCount", 5 if failed else 6)
    element(root, "executedBy", "aws.appian.ci")
    application = element(root, "applicationTestResults")
    element(application, "name", "Customer Management")
    element(application, "status", "FAIL" if failed else "PASS")
    element(application, "totalExecutionTime", "0.125")
    element(application, "testCount", 6)
    element(application, "errorCount", 0)
    element(application, "failureCount", 1 if failed else 0)
    element(application, "passCount", 5 if failed else 6)

    group_name = "problemObjectsTestResult" if failed else "passObjectsTestResult"
    rule_result = element(application, group_name)
    element(rule_result, "name", "ACME_getCustomerStatus")
    element(
        rule_result,
        "url",
        "https://replace-me.appiancloud.com/suite/design/rule/ACME_getCustomerStatus",
    )
    for index in range(6):
        case = element(rule_result, "testCasesResult")
        element(case, "name", "Null customer status" if index == 0 else f"Rule case {index + 1}")
        case_failed = failed and index == 0
        element(case, "status", "FAIL" if case_failed else "PASS")
        element(case, "executionTime", "0.020")
        element(case, "failureMessage", "Expected UNKNOWN but expression evaluation failed" if case_failed else "")
        element(case, "errorMessage", "")

    return ET.tostring(root, encoding="unicode", xml_declaration=True)


# ---------------------------------------------------------------------------
# Tosca Execution API integration
# ---------------------------------------------------------------------------


def _tosca_config() -> Dict[str, Any]:
    config = _secret(os.environ["TOSCA_SECRET_ARN"])
    # Demo replaces only the endpoint; request/response/authentication behavior
    # remains identical to the production client contract.
    if os.environ.get("TOSCA_BASE_URL_OVERRIDE"):
        config["baseUrl"] = os.environ["TOSCA_BASE_URL_OVERRIDE"]
    if os.environ.get("TOSCA_EXECUTION_API_PATH_OVERRIDE"):
        config["executionApiPath"] = os.environ["TOSCA_EXECUTION_API_PATH_OVERRIDE"]
    return config


def _tosca_token(config: Mapping[str, Any]) -> str:
    token_url = _join(
        str(config["baseUrl"]),
        str(config.get("tokenPath", "/tua/connect/token")),
    )
    return _client_credentials(
        config,
        token_url,
        f"tosca:{token_url}:{config.get('clientId', '')}",
    )


def _tosca_headers(config: Mapping[str, Any]) -> Dict[str, str]:
    headers = {"Content-Type": "application/json", "X-Tricentis": "OK"}
    if str(config.get("authentication", "OAUTH2")).upper() != "NONE":
        headers["Authorization"] = f"Bearer {_tosca_token(config)}"
    return headers


def _tosca_base(config: Mapping[str, Any]) -> str:
    return _join(
        str(config["baseUrl"]),
        str(config.get("executionApiPath", "/api/Execution")),
    )


def _execution_id(response: Any) -> str:
    if isinstance(response, str):
        return response.strip('"')
    if isinstance(response, dict):
        for key in ("executionId", "ExecutionId", "id", "Id"):
            if response.get(key):
                return str(response[key])
    raise RuntimeError("Tosca enqueue response did not contain an execution ID")


def _tosca_raw_status(response: Any) -> str:
    if isinstance(response, str):
        return response.strip('"')
    if isinstance(response, dict):
        for key in ("status", "Status", "state", "State", "executionStatus"):
            if response.get(key) is not None:
                return str(response[key])
    return "UNKNOWN"


def _tosca_state(raw_status: str) -> str:
    value = str(raw_status or "UNKNOWN").upper().replace(" ", "_")
    if any(word in value for word in ("FAIL", "ERROR", "CANCEL", "TIMEOUT", "ABORT")):
        return "FAILED"
    if any(word in value for word in ("COMPLETE", "FINISHED", "SUCCESS", "PASSED")):
        return "SUCCEEDED"
    return "RUNNING"


def _junit_summary(xml_text: str) -> Dict[str, Any]:
    import xml.etree.ElementTree as ET

    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError as exc:
        return {
            "status": "ERROR",
            "total": 0,
            "passed": 0,
            "failed": 0,
            "skipped": 0,
            "parseError": str(exc),
        }

    suites = [root] if root.tag.endswith("testsuite") else list(root.findall(".//testsuite"))
    total = failures = errors = skipped = 0
    for suite in suites:
        total += int(float(suite.attrib.get("tests", 0) or 0))
        failures += int(float(suite.attrib.get("failures", 0) or 0))
        errors += int(float(suite.attrib.get("errors", 0) or 0))
        skipped += int(float(suite.attrib.get("skipped", 0) or 0))

    failed_tests = []
    for case in root.findall(".//testcase"):
        failure = case.find("failure")
        error = case.find("error")
        node = failure if failure is not None else error
        if node is not None:
            failed_tests.append(
                {
                    "classname": case.attrib.get("classname", ""),
                    "name": case.attrib.get("name", ""),
                    "message": node.attrib.get("message") or (node.text or "")[:1000],
                }
            )

    if total == 0:
        total = len(root.findall(".//testcase"))
        skipped = len(root.findall(".//skipped"))
    failed = failures + errors
    if failed == 0 and failed_tests:
        failed = len(failed_tests)
    passed = max(total - failed - skipped, 0)
    return {
        "status": "PASSED" if failed == 0 else "FAILED",
        "total": total,
        "passed": passed,
        "failed": failed,
        "skipped": skipped,
        "failedTests": failed_tests[:50],
    }


# ---------------------------------------------------------------------------
# Step Functions operations
# ---------------------------------------------------------------------------


def validate(ctx: Mapping[str, Any]) -> Dict[str, Any]:
    result = _clone(ctx)
    source_key = str(result["sourceKey"])
    if not source_key.lower().endswith(".zip"):
        raise ValueError("Source object must have a .zip extension")

    head = s3.head_object(**_object_args(result))
    max_bytes = int(os.environ.get("MAX_PACKAGE_SIZE_MB", "500")) * 1024 * 1024
    if int(head["ContentLength"]) > max_bytes:
        raise ValueError(
            f"Package is {head['ContentLength']} bytes; configured maximum is {max_bytes}"
        )

    filename, package = _download(result)
    if not zipfile.is_zipfile(io.BytesIO(package)):
        raise ValueError("Source object is not a valid ZIP archive")
    with zipfile.ZipFile(io.BytesIO(package), "r") as archive:
        names = archive.namelist()
        if not names:
            raise ValueError("ZIP archive is empty")
        for member in archive.infolist():
            path = PurePosixPath(member.filename)
            if path.is_absolute() or ".." in path.parts:
                raise ValueError(f"Unsafe ZIP entry: {member.filename}")
            if member.flag_bits & 0x1:
                raise ValueError(
                    f"Encrypted ZIP entry is not supported: {member.filename}"
                )
        corrupt_member = archive.testzip()
        if corrupt_member:
            raise ValueError(f"Corrupt ZIP entry: {corrupt_member}")

    digest = hashlib.sha256(package).hexdigest()
    execution_id = str(result.get("pipelineExecutionId") or uuid.uuid4())
    environment = str(result.get("environment", "TEST")).upper()
    release_id = str(
        result.get("releaseId")
        or f"{execution_id[:12]}-{digest[:12]}"
    )
    result.update(
        {
            "releaseId": release_id,
            "environment": environment,
            "evidencePrefix": f"releases/{release_id}/{environment.lower()}",
            "artifact": {
                "fileName": filename,
                "sizeBytes": len(package),
                "sha256": digest,
                "zipEntries": len(names),
                "s3Uri": f"s3://{result['sourceBucket']}/{source_key}",
                "versionId": result.get("sourceVersion"),
                "validatedAt": _now(),
            },
        }
    )

    scenario_parameter = os.environ.get("DEMO_SCENARIO_PARAMETER")
    if scenario_parameter:
        try:
            result["scenario"] = ssm.get_parameter(Name=scenario_parameter)["Parameter"]["Value"]
        except ClientError as exc:
            if exc.response.get("Error", {}).get("Code") != "ParameterNotFound":
                raise
    result.setdefault("scenario", "SUCCESS")

    # A unique S3 version is the immutable release identity. A Step Functions
    # retry in the same CodePipeline execution is allowed; a new execution must
    # upload a new S3 version to make replay explicit and auditable.
    identity = (
        f"{result['sourceBucket']}:{source_key}:"
        f"{result.get('sourceVersion')}:{environment}"
    )
    idempotency_key = hashlib.sha256(identity.encode("utf-8")).hexdigest()
    result["idempotencyKey"] = idempotency_key
    ledger = dynamodb.Table(os.environ["RELEASE_TABLE"])
    existing = ledger.get_item(Key={"idempotencyKey": idempotency_key}).get("Item")
    if existing and existing.get("pipelineExecutionId") != execution_id:
        raise ValueError(
            "This exact S3 object version has already been accepted for this "
            f"environment by pipeline execution {existing.get('pipelineExecutionId')}. "
            "Upload the package again to create a new immutable S3 version."
        )
    if not existing:
        ledger.put_item(
            Item={
                "idempotencyKey": idempotency_key,
                "pipelineExecutionId": execution_id,
                "releaseId": release_id,
                "environment": environment,
                "sourceVersion": str(result.get("sourceVersion") or ""),
                "status": "RECEIVED",
                "createdAt": _now(),
                "expiresAt": int(time.time())
                + int(os.environ.get("LEDGER_TTL_SECONDS", "31536000")),
            },
            ConditionExpression="attribute_not_exists(idempotencyKey)",
        )

    result["artifact"]["manifestKey"] = _put_json(
        result,
        "metadata/artifact-manifest.json",
        result["artifact"],
    )
    return result


def appian_inspection_start(ctx: Mapping[str, Any]) -> Dict[str, Any]:
    result = _clone(ctx)
    result.setdefault("appian", {})
    if os.environ.get("APPIAN_MODE", "REAL").upper() == "MOCK":
        response = {
            "uuid": str(uuid.uuid4()),
            "status": "IN_PROGRESS",
            "startedAt": time.time(),
        }
    else:
        response = _appian_post(result, "inspection")
    result["appian"]["inspection"] = {
        "id": response["uuid"],
        "rawStatus": response.get("status", "IN_PROGRESS"),
        "state": "RUNNING",
        "startedAt": response.get("startedAt", time.time()),
        "pollAttempts": 0,
    }
    return result


def appian_inspection_status(ctx: Mapping[str, Any]) -> Dict[str, Any]:
    result = _clone(ctx)
    operation = result["appian"]["inspection"]
    if os.environ.get("APPIAN_MODE", "REAL").upper() == "MOCK":
        scenario = str(result.get("scenario", "SUCCESS")).upper()
        if int(operation.get("pollAttempts", 0)) < 1:
            response = {"status": "IN_PROGRESS"}
        elif scenario == "APPIAN_INSPECTION_FAILURE":
            response = {
                "status": "COMPLETED",
                "summary": {
                    "objectsExpected": {
                        "total": 42,
                        "imported": 41,
                        "failed": 1,
                        "skipped": 0,
                    },
                    "problems": {
                        "totalErrors": 1,
                        "totalWarnings": 0,
                        "errors": [
                            {
                                "objectName": "ACME_Customer",
                                "errorMessage": "Required precedent is missing in the target environment.",
                            }
                        ],
                    },
                },
            }
        else:
            response = {
                "status": "COMPLETED",
                "summary": {
                    "objectsExpected": {
                        "total": 42,
                        "imported": 42,
                        "failed": 0,
                        "skipped": 0,
                    },
                    "problems": {
                        "totalErrors": 0,
                        "totalWarnings": 1,
                        "warnings": [
                            {"warningMessage": "Controlled demonstration warning."}
                        ],
                    },
                },
            }
    else:
        response = _appian_get(result, "inspection")

    operation["pollAttempts"] = int(operation.get("pollAttempts", 0)) + 1
    operation["rawStatus"] = (
        response.get("status", "UNKNOWN") if isinstance(response, dict) else "UNKNOWN"
    )
    operation["state"] = _appian_state(operation["rawStatus"])
    operation["response"] = response
    if operation["state"] == "SUCCEEDED" and isinstance(response, dict):
        problems = ((response.get("summary") or {}).get("problems") or {})
        if int(problems.get("totalErrors", 0) or 0) > 0:
            operation["state"] = "FAILED"
            operation["failureReason"] = "Inspection completed with one or more errors"
    if (
        operation["state"] == "RUNNING"
        and operation["pollAttempts"] >= int(os.environ.get("APPIAN_MAX_POLLS", "120"))
    ):
        operation.update(
            {
                "state": "FAILED",
                "rawStatus": "TIMED_OUT",
                "failureReason": "Appian inspection exceeded configured polling limit",
            }
        )
    return result


def appian_deployment_start(ctx: Mapping[str, Any]) -> Dict[str, Any]:
    result = _clone(ctx)
    result.setdefault("appian", {})
    if os.environ.get("APPIAN_MODE", "REAL").upper() == "MOCK":
        response = {
            "uuid": str(uuid.uuid4()),
            "status": "IN_PROGRESS",
            "startedAt": time.time(),
        }
    else:
        response = _appian_post(result, "deployment")
    result["appian"]["deployment"] = {
        "id": response["uuid"],
        "rawStatus": response.get("status", "IN_PROGRESS"),
        "state": "RUNNING",
        "startedAt": response.get("startedAt", time.time()),
        "pollAttempts": 0,
    }
    return result


def appian_deployment_status(ctx: Mapping[str, Any]) -> Dict[str, Any]:
    result = _clone(ctx)
    operation = result["appian"]["deployment"]
    if os.environ.get("APPIAN_MODE", "REAL").upper() == "MOCK":
        scenario = str(result.get("scenario", "SUCCESS")).upper()
        if int(operation.get("pollAttempts", 0)) < 1:
            response = {"status": "IN_PROGRESS"}
        elif scenario == "APPIAN_DEPLOYMENT_FAILURE":
            response = {
                "status": "FAILED",
                "summary": {
                    "objects": {"total": 42, "imported": 0, "failed": 42}
                },
            }
        else:
            response = {
                "status": "COMPLETED",
                "summary": {
                    "objects": {"total": 42, "imported": 42, "failed": 0}
                },
            }
    else:
        response = _appian_get(result, "deployment")

    operation["pollAttempts"] = int(operation.get("pollAttempts", 0)) + 1
    operation["rawStatus"] = (
        response.get("status", "UNKNOWN") if isinstance(response, dict) else "UNKNOWN"
    )
    operation["state"] = _appian_state(operation["rawStatus"])
    operation["response"] = response
    if (
        operation["state"] == "RUNNING"
        and operation["pollAttempts"] >= int(os.environ.get("APPIAN_MAX_POLLS", "120"))
    ):
        operation.update(
            {
                "state": "FAILED",
                "rawStatus": "TIMED_OUT",
                "failureReason": "Appian deployment exceeded configured polling limit",
            }
        )
    if (
        operation["state"] == "FAILED"
        and os.environ.get("APPIAN_MODE", "REAL").upper() != "MOCK"
    ):
        try:
            operation["log"] = _appian_get(
                result,
                "deployment",
                include_log=True,
            )
        except Exception as exc:  # Preserve the primary deployment failure.
            operation["logRetrievalError"] = str(exc)
    return result


def appian_native_tests_start(ctx: Mapping[str, Any]) -> Dict[str, Any]:
    result = _clone(ctx)
    result.setdefault("appian", {})
    if not _appian_native_tests_enabled():
        result["appian"]["nativeTests"] = {
            "state": "SKIPPED",
            "rawStatus": "DISABLED",
            "startedAt": _now(),
            "pollAttempts": 0,
            "reason": "EnableAppianNativeTests is false",
        }
        return result

    if os.environ.get("APPIAN_MODE", "REAL").upper() == "MOCK":
        run_id = str(int(time.time() * 1000) % 1_000_000_000)
    else:
        environment = str(result.get("environment", "TEST")).upper()
        config = _appian_config(environment)
        native = _appian_native_test_config(config)
        headers = _appian_headers(config)
        headers.update({"Accept": "application/json, text/plain, */*"})
        _, _, payload = _http(
            str(native["startMethod"]),
            _appian_web_api_url(config, str(native["startPath"])),
            headers=headers,
            timeout=int(native["requestTimeoutSeconds"]),
            ssl_config=config,
        )
        run_id = _native_test_run_id(_plain_response_value(payload))

    result["appian"]["nativeTests"] = {
        "id": run_id,
        "state": "RUNNING",
        "rawStatus": "IN PROGRESS",
        "startedAt": _now(),
        "pollAttempts": 0,
    }
    return result


def appian_native_tests_status(ctx: Mapping[str, Any]) -> Dict[str, Any]:
    result = _clone(ctx)
    operation = result.get("appian", {}).get("nativeTests")
    if not isinstance(operation, dict):
        raise ValueError("Appian native-test operation is missing")
    if operation.get("state") == "SKIPPED":
        return result

    if os.environ.get("APPIAN_MODE", "REAL").upper() == "MOCK":
        scenario = str(result.get("scenario", "SUCCESS")).upper()
        if scenario == "APPIAN_NATIVE_TEST_TIMEOUT":
            raw_status = "IN PROGRESS"
        elif int(operation.get("pollAttempts", 0)) < 1:
            raw_status = "IN PROGRESS"
        else:
            raw_status = "COMPLETE"
    else:
        environment = str(result.get("environment", "TEST")).upper()
        config = _appian_config(environment)
        native = _appian_native_test_config(config)
        query_name = str(native.get("idQueryParameter", "id"))
        query = urllib.parse.urlencode({query_name: str(operation["id"])})
        url = _appian_web_api_url(config, str(native["statusPath"]))
        url += ("&" if "?" in url else "?") + query
        _, _, payload = _http(
            str(native["statusMethod"]),
            url,
            headers={**_appian_headers(config), "Accept": "application/json, text/plain, */*"},
            timeout=int(native["requestTimeoutSeconds"]),
            ssl_config=config,
        )
        raw_status = _native_test_raw_status(_plain_response_value(payload))

    operation["pollAttempts"] = int(operation.get("pollAttempts", 0)) + 1
    operation["rawStatus"] = raw_status
    operation["state"] = _native_test_state(raw_status)
    if (
        operation["state"] == "RUNNING"
        and operation["pollAttempts"]
        >= int(os.environ.get("APPIAN_NATIVE_TEST_MAX_POLLS", "120"))
    ):
        operation.update(
            {
                "state": "FAILED",
                "rawStatus": "TIMED_OUT",
                "failureReason": "Appian native tests exceeded configured polling limit",
            }
        )
    return result


def appian_native_tests_results(ctx: Mapping[str, Any]) -> Dict[str, Any]:
    result = _clone(ctx)
    operation = result.get("appian", {}).get("nativeTests")
    if not isinstance(operation, dict) or not operation.get("id"):
        raise ValueError("Appian native-test run ID is missing")

    if os.environ.get("APPIAN_MODE", "REAL").upper() == "MOCK":
        failed = str(result.get("scenario", "SUCCESS")).upper() == "APPIAN_NATIVE_TEST_FAILURE"
        raw_xml = _mock_appian_native_results(failed)
    else:
        environment = str(result.get("environment", "TEST")).upper()
        config = _appian_config(environment)
        native = _appian_native_test_config(config)
        query_name = str(native.get("idQueryParameter", "id"))
        query = urllib.parse.urlencode({query_name: str(operation["id"])})
        url = _appian_web_api_url(config, str(native["resultsPath"]))
        url += ("&" if "?" in url else "?") + query
        _, _, payload = _http(
            str(native["resultsMethod"]),
            url,
            headers={**_appian_headers(config), "Accept": "application/xml, text/xml, text/plain, */*"},
            timeout=int(native["requestTimeoutSeconds"]),
            ssl_config=config,
        )
        raw_value = _plain_response_value(payload)
        raw_xml = raw_value if isinstance(raw_value, str) else str(raw_value)

    junit_xml, summary = _appian_native_xml_to_junit(raw_xml)
    raw_key = _put_text(
        result,
        "appian-native/raw-results.xml",
        raw_xml,
        "application/xml",
    )
    junit_key = _put_text(
        result,
        "test-results/appian-native.xml",
        junit_xml,
        "application/xml",
    )
    summary.update(
        {
            "testRunId": str(operation["id"]),
            "rawResultS3Key": raw_key,
            "junitS3Key": junit_key,
            "completedAt": _now(),
        }
    )
    summary["summaryS3Key"] = _put_json(
        result,
        "appian-native/summary.json",
        summary,
    )
    result.setdefault("testResults", {})["APPIAN_NATIVE"] = summary
    operation.update(
        {
            "state": "SUCCEEDED" if summary["status"] == "PASSED" else "FAILED",
            "rawStatus": summary["rawStatus"],
            "result": summary,
            "completedAt": summary["completedAt"],
        }
    )
    return result


def tosca_start(ctx: Mapping[str, Any], suite: str) -> Dict[str, Any]:
    result = _clone(ctx)
    suite = suite.upper()
    config = _tosca_config()
    event_id = (config.get("events") or {}).get(suite) or f"APPIAN_{suite}"
    parameters = dict(config.get("parameters") or {})
    parameters.update(
        {
            "Environment": result.get("environment", "TEST"),
            "ReleaseId": result["releaseId"],
            "Scenario": result.get("scenario", "SUCCESS"),
        }
    )
    payload = {
        "projectName": config.get("projectName", "AppianAutomation"),
        "executionEnvironment": config.get("executionEnvironment", "Dex"),
        "events": [
            {
                "eventId": event_id,
                "parameters": parameters,
                "characteristics": config.get("characteristics") or {},
            }
        ],
        "importResult": bool(config.get("importResult", True)),
        "creator": config.get("creator", "AWS-CodePipeline"),
    }
    _, _, response = _json_http(
        "POST",
        _join(_tosca_base(config), "Enqueue"),
        headers=_tosca_headers(config),
        body=json.dumps(payload).encode("utf-8"),
        timeout=int(config.get("requestTimeoutSeconds", 180)),
        ssl_config=config,
    )
    result.setdefault("tosca", {})[suite] = {
        "executionId": _execution_id(response),
        "eventId": event_id,
        "rawStatus": "QUEUED",
        "state": "RUNNING",
        "startedAt": _now(),
        "pollAttempts": 0,
    }
    return result


def tosca_status(ctx: Mapping[str, Any], suite: str) -> Dict[str, Any]:
    result = _clone(ctx)
    suite = suite.upper()
    config = _tosca_config()
    execution = result["tosca"][suite]
    _, _, response = _json_http(
        "GET",
        _join(_tosca_base(config), f"{execution['executionId']}/Status"),
        headers=_tosca_headers(config),
        timeout=int(config.get("requestTimeoutSeconds", 180)),
        ssl_config=config,
    )
    execution["pollAttempts"] = int(execution.get("pollAttempts", 0)) + 1
    execution["rawStatus"] = _tosca_raw_status(response)
    execution["state"] = _tosca_state(execution["rawStatus"])
    execution["statusResponse"] = response
    if (
        execution["state"] == "RUNNING"
        and execution["pollAttempts"] >= int(os.environ.get("TOSCA_MAX_POLLS", "240"))
    ):
        execution.update(
            {
                "state": "FAILED",
                "rawStatus": "TIMED_OUT",
                "failureReason": "Tosca execution exceeded configured polling limit",
            }
        )
    return result


def tosca_results(ctx: Mapping[str, Any], suite: str) -> Dict[str, Any]:
    result = _clone(ctx)
    suite = suite.upper()
    config = _tosca_config()
    execution = result["tosca"][suite]
    headers = _tosca_headers(config)
    _, _, payload = _http(
        "GET",
        _join(_tosca_base(config), f"{execution['executionId']}/Results"),
        headers=headers,
        timeout=int(config.get("requestTimeoutSeconds", 180)),
        ssl_config=config,
    )
    junit_xml = payload.decode("utf-8", errors="replace")
    _, _, raw_summary = _json_http(
        "GET",
        _join(
            _tosca_base(config),
            f"{execution['executionId']}/Results/Summary",
        ),
        headers=headers,
        timeout=int(config.get("requestTimeoutSeconds", 180)),
        ssl_config=config,
    )
    junit_key = f"{result['evidencePrefix']}/test-results/{suite.lower()}.xml"
    s3.put_object(
        Bucket=os.environ["RESULTS_BUCKET"],
        Key=junit_key,
        Body=junit_xml.encode("utf-8"),
        ContentType="application/xml",
        ServerSideEncryption="aws:kms",
        SSEKMSKeyId=os.environ["KMS_KEY_ARN"],
    )
    result.setdefault("testResults", {})[suite] = {
        **_junit_summary(junit_xml),
        "suite": suite,
        "eventId": execution["eventId"],
        "executionId": execution["executionId"],
        "rawExecutionStatus": execution.get("rawStatus"),
        "junitS3Key": junit_key,
        "toscaSummary": raw_summary,
        "completedAt": _now(),
    }
    return result


def merge_parallel(ctx: Mapping[str, Any]) -> Dict[str, Any]:
    branches = ctx.get("parallelResults")
    if not isinstance(branches, list) or not branches:
        raise ValueError("parallelResults is missing")
    result = _clone(branches[0])
    result.setdefault("testResults", {})
    result.setdefault("tosca", {})
    for branch in branches[1:]:
        result["testResults"].update(branch.get("testResults", {}))
        result["tosca"].update(branch.get("tosca", {}))
    return result


def mark_failure(ctx: Mapping[str, Any], category: str) -> Dict[str, Any]:
    result = _clone(ctx)
    category = category.upper()
    details: Any = {}
    if category == "APPIAN_INSPECTION":
        details = result.get("appian", {}).get("inspection", {})
    elif category == "APPIAN_DEPLOYMENT":
        details = result.get("appian", {}).get("deployment", {})
    elif category == "APPIAN_NATIVE_TEST":
        details = (
            result.get("testResults", {}).get("APPIAN_NATIVE")
            or result.get("appian", {}).get("nativeTests", {})
        )
    elif category.endswith("_TEST"):
        suite = category.removesuffix("_TEST")
        details = (
            result.get("testResults", {}).get(suite)
            or result.get("tosca", {}).get(suite)
            or {"status": "MISSING"}
        )
    result["qualityGate"] = {
        "status": "FAILED",
        "failures": [{"category": category, "details": details}],
        "evaluatedAt": _now(),
    }
    return result


def evaluate(ctx: Mapping[str, Any]) -> Dict[str, Any]:
    result = _clone(ctx)
    failures = []
    native_tests = result.get("appian", {}).get("nativeTests", {})
    if native_tests and native_tests.get("state") != "SKIPPED":
        native_result = result.get("testResults", {}).get("APPIAN_NATIVE")
        if not native_result or native_result.get("status") != "PASSED":
            failures.append(
                {
                    "category": "APPIAN_NATIVE_TEST",
                    "details": native_result or native_tests or {"status": "MISSING"},
                }
            )
    for suite in result.get("requiredSuites", ["SMOKE", "REGRESSION", "E2E"]):
        test_result = result.get("testResults", {}).get(suite)
        if not test_result or test_result.get("status") != "PASSED":
            failures.append(
                {
                    "category": f"{suite}_TEST",
                    "details": test_result or {"status": "MISSING"},
                }
            )
    result["qualityGate"] = {
        "status": "PASSED" if not failures else "FAILED",
        "failures": failures,
        "evaluatedAt": _now(),
    }
    return result


def capture_error(ctx: Mapping[str, Any]) -> Dict[str, Any]:
    result = _clone(ctx.get("original") or ctx)
    error = ctx.get("error", {})
    result["qualityGate"] = {
        "status": "FAILED",
        "failures": [
            {
                "category": "PIPELINE_OR_INTEGRATION",
                "error": (
                    error.get("Error", "UnknownError")
                    if isinstance(error, dict)
                    else "UnknownError"
                ),
                "cause": (
                    error.get("Cause", str(error))
                    if isinstance(error, dict)
                    else str(error)
                ),
            }
        ],
        "evaluatedAt": _now(),
    }
    return result


def _redact(value: Any) -> Any:
    text = json.dumps(value, default=str)
    pattern = re.compile(
        r'(?i)(client[_-]?secret|api[_-]?key|authorization|access[_-]?token|password)'
        r'\s*[":=]+\s*"?([^",}\]\s]+)'
    )
    text = pattern.sub(r'\1":"***REDACTED***', text)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return text


def _fallback_diagnostic(ctx: Mapping[str, Any], reason: str) -> Dict[str, Any]:
    failures = ctx.get("qualityGate", {}).get("failures", [])
    categories = [
        str(item.get("category", "UNKNOWN"))
        for item in failures
        if isinstance(item, dict)
    ]
    classification = "APPLICATION_TEST_FAILURE"
    if any("PIPELINE" in item or "INTEGRATION" in item for item in categories):
        classification = "PIPELINE_OR_INTEGRATION_FAILURE"
    elif "APPIAN_INSPECTION" in categories:
        classification = "APPIAN_PACKAGE_COMPATIBILITY_FAILURE"
    elif "APPIAN_DEPLOYMENT" in categories:
        classification = "APPIAN_DEPLOYMENT_FAILURE"
    elif "APPIAN_NATIVE_TEST" in categories:
        classification = "APPIAN_NATIVE_TEST_FAILURE"
    return {
        "classification": classification,
        "confidence": 0.55,
        "summary": (
            "A deterministic fallback diagnostic was generated because the "
            "foundation-model call was disabled or unavailable."
        ),
        "probableCause": ", ".join(categories) or "Unknown failure",
        "evidence": categories,
        "recommendedActions": [
            "Review the Appian deployment, native expression-rule test, Tosca, and AWS evidence artifacts linked to this release.",
            "Correct the package, target environment, Appian rule logic/test case, test automation, or integration issue indicated by the evidence.",
            "Export a new Appian package and rerun the pipeline; do not edit the internal XML/ZIP structure.",
        ],
        "recommendedRetest": ["APPIAN_NATIVE", "SMOKE", "REGRESSION", "E2E"],
        "promotionRecommendation": "DO_NOT_PROMOTE",
        "modelInvocationNote": reason[:1000],
        "humanValidationRequired": True,
    }


def diagnose(ctx: Mapping[str, Any]) -> Dict[str, Any]:
    result = _clone(ctx)
    evidence = {
        key: result.get(key)
        for key in (
            "releaseId",
            "environment",
            "artifact",
            "appian",
            "testResults",
            "tosca",
            "qualityGate",
        )
    }
    model_id = os.environ.get("BEDROCK_MODEL_ID", "amazon.nova-pro-v1:0")
    diagnostics_enabled = os.environ.get("AI_DIAGNOSTICS_ENABLED", "true").lower() == "true"
    prompt = (
        "Analyze this Appian release failure. Distinguish: Appian application regression; "
        "Appian package inspection or deployment failure; Appian native expression-rule "
        "test failure; Tosca test-design defect; Tosca "
        "execution infrastructure failure; and AWS pipeline or integration failure. Do not "
        "recommend editing the internal XML or ZIP structure of an Appian export. Return only "
        "valid JSON with keys classification, confidence, summary, probableCause, evidence "
        "(array), recommendedActions (array), recommendedRetest (array), "
        "promotionRecommendation, and humanValidationRequired.\n\nEVIDENCE:\n"
        + json.dumps(_redact(evidence), default=str)[:100000]
    )
    try:
        if not diagnostics_enabled:
            raise RuntimeError("AI diagnostics disabled by stack parameter")
        response = bedrock.converse(
            modelId=model_id,
            system=[
                {
                    "text": (
                        "You are an enterprise DevOps diagnostic assistant. Produce concise, "
                        "audit-ready diagnostics and output valid JSON only."
                    )
                }
            ],
            messages=[{"role": "user", "content": [{"text": prompt}]}],
            inferenceConfig={
                "maxTokens": 1800,
                "temperature": 0.1,
                "topP": 0.9,
            },
        )
        text = response["output"]["message"]["content"][0]["text"].strip()
        text = re.sub(
            r"^```(?:json)?\s*|\s*```$",
            "",
            text,
            flags=re.IGNORECASE | re.DOTALL,
        )
        diagnostic = json.loads(text)
        diagnostic["modelId"] = model_id
    except Exception as exc:
        diagnostic = _fallback_diagnostic(result, str(exc))

    diagnostic.update(
        {
            "releaseId": result.get("releaseId"),
            "pipelineExecutionId": result.get("pipelineExecutionId"),
            "generatedAt": _now(),
            "humanValidationRequired": True,
        }
    )
    diagnostic["s3Key"] = _put_json(
        result,
        "diagnostics/diagnostic.json",
        diagnostic,
    )
    result["diagnostic"] = diagnostic
    topic_arn = os.environ.get("NOTIFICATION_TOPIC_ARN")
    if topic_arn:
        try:
            sns.publish(
                TopicArn=topic_arn,
                Subject=f"Appian pipeline diagnostic: {result.get('releaseId', 'unknown')}"[:100],
                Message=json.dumps(diagnostic, indent=2, default=str)[:250000],
            )
        except Exception as exc:
            # Preserve the diagnostic and failure evidence even when notification delivery fails.
            result["diagnosticNotificationError"] = str(exc)[:1000]
    return result


def finalize(ctx: Mapping[str, Any]) -> Dict[str, Any]:
    result = _clone(ctx)
    result["completedAt"] = _now()
    result["executionSummaryKey"] = _put_json(
        result,
        "metadata/execution-summary.json",
        _redact(result),
    )
    if result.get("idempotencyKey"):
        dynamodb.Table(os.environ["RELEASE_TABLE"]).update_item(
            Key={"idempotencyKey": result["idempotencyKey"]},
            UpdateExpression=(
                "SET #status = :status, completedAt = :completed, "
                "executionSummaryKey = :summary"
            ),
            ExpressionAttributeNames={"#status": "status"},
            ExpressionAttributeValues={
                ":status": result.get("qualityGate", {}).get("status", "COMPLETED"),
                ":completed": result["completedAt"],
                ":summary": result["executionSummaryKey"],
            },
        )
    return result


OPERATIONS = {
    "validate": validate,
    "appian_inspection_start": appian_inspection_start,
    "appian_inspection_status": appian_inspection_status,
    "appian_deployment_start": appian_deployment_start,
    "appian_deployment_status": appian_deployment_status,
    "appian_native_tests_start": appian_native_tests_start,
    "appian_native_tests_status": appian_native_tests_status,
    "appian_native_tests_results": appian_native_tests_results,
    "merge_parallel": merge_parallel,
    "evaluate": evaluate,
    "capture_error": capture_error,
    "diagnose": diagnose,
    "finalize": finalize,
}


def handler(event: Mapping[str, Any], context: Any) -> Dict[str, Any]:
    operation = str(event.get("op", ""))
    payload = event.get("context", {})
    if operation == "tosca_start":
        return tosca_start(payload, str(event["suite"]))
    if operation == "tosca_status":
        return tosca_status(payload, str(event["suite"]))
    if operation == "tosca_results":
        return tosca_results(payload, str(event["suite"]))
    if operation == "mark_failure":
        return mark_failure(payload, str(event["category"]))
    if operation not in OPERATIONS:
        raise ValueError(f"Unknown operation: {operation}")
    return OPERATIONS[operation](payload)
