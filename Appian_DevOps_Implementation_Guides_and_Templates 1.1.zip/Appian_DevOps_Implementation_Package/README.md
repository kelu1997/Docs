# Appian DevOps on AWS — Implementation Package

Version 1.1 — 31 August 2026

This package contains two implementation paths for a tested Appian deployment ZIP after it leaves Appian:

1. **Client demo** — a self-contained AWS demonstration. The AWS pipeline, orchestration, security, reporting, evidence, manual gate, and diagnostics are real. Appian defaults to a deterministic adapter simulation, including the post-deployment native expression-rule test start/status/results loop, and Tosca is represented by a production-shaped HTTP API mock.
2. **Production reference** — real Appian TEST/PROD Deployment REST API connections, a pipeline-triggered Appian native expression-rule test gate in TEST, a real Tricentis Tosca Execution API connection, pre-production quality gates, an authorized production approval, production deployment/smoke, retained evidence, and optional AI-assisted diagnostics.

## Package layout

- `guides/` — comprehensive DOCX and PDF implementation guides.
- `cloudformation/` — complete demo and production CloudFormation templates.
- `source/` — the shared Appian/Tosca integration, evidence, quality-gate, and diagnostic Lambda source; plus the demo Tosca mock.
- `state-machines/` — readable Amazon States Language definitions embedded in the templates.
- `validation/` — local template/state-machine validation and regeneration tools.
- `diagrams/` — architecture and release-flow figures used in the guides.

## Demo quick start

1. Open **AWS CloudFormation → Stacks → Create stack → With new resources (standard)**.
2. Select **Upload a template file** and choose `cloudformation/appian-devops-demo.yaml`.
3. Keep `AppianIntegrationMode=MOCK` and `EnableAppianNativeTests=true` for a self-contained presentation that exercises the native-test orchestration contract. Select `EnableAiDiagnostics=true` only in a Region/account with the chosen Bedrock model enabled and approved.
4. Acknowledge IAM resource creation and create the stack.
5. Confirm any optional SNS email subscription.
6. From stack **Outputs**, record `SourceBucketName`, `SourceObjectKey`, `PipelineName`, `ResultsBucketName`, and `ScenarioParameterName`.
7. Upload a structurally representative Appian ZIP to the exact source bucket/key. Every overwrite creates a new S3 version and a new pipeline execution.
8. Run the three recommended scenarios by changing the SSM scenario parameter before uploading a new object version:
   - `SUCCESS`
   - `REGRESSION_FAILURE`
   - `TOSCA_TIMEOUT`
9. Review CodePipeline, the Step Functions execution graph, CodeBuild test reports, and the encrypted evidence prefix in the results bucket.

The demo guide contains the exact console paths, presentation narrative, failure scenarios, acceptance criteria, and cleanup sequence.

## Production prerequisites

Before creating the production stack, prepare three existing Secrets Manager secrets and supply their ARNs as stack parameters:

- Appian TEST connection JSON, including the native-test Web API paths
- Appian PROD connection JSON
- Tosca Execution API connection JSON

The guides define API-key and OAuth 2.0 Appian examples, the three Appian TEST native-test Web APIs, Tosca token/enqueue/status/result settings, network/TLS options, commissioning tests, ownership boundaries, and change-control decisions.

Production deployment must also confirm:

- the client-installed Appian Deployment REST API behavior and account permissions;
- the Appian TEST Web APIs that start application-scoped expression-rule tests, poll run status, and return TestRunResult XML, using the same CI identity with viewer rights to the selected applications and rules;
- the installed Tosca Server/AOS Swagger contract, authentication, event IDs, status values, result paths, and JUnit behavior;
- Region/model access and data-handling approval for Bedrock, or `EnableAiDiagnostics=false`;
- public egress or VPC/private connectivity from Lambda to Appian and Tosca;
- permissions boundary, KMS/IAM/SCP requirements, evidence retention, notification integration, approver identities, rollback/forward-fix process, and operational ownership.

## CloudFormation upload note

Both templates are larger than the 51,200-byte direct `TemplateBody` API limit. Use the CloudFormation console **Upload a template file** path, or an AWS CLI deployment path that uploads the template through S3. Do not paste the template into the console editor.

## Validation completed

The delivered artifacts passed local checks for:

- YAML parsing and resource/parameter sizing;
- intrinsic `Ref`, `Fn::GetAtt`, `Fn::Sub`, `Fn::If`, and `DependsOn` references;
- embedded Python syntax compilation;
- Step Functions state graph reachability and transition references;
- JUnit fallback generation and XML parsing, including Appian native TestRunResult XML conversion;
- representative pure helper behavior, including Appian native-test start/status/results evaluation and Appian `COMPLETED_AND_SYNCING` remaining non-terminal;
- DOCX rendering and page-by-page visual inspection;
- accessibility audit with zero high-severity findings.

A live CloudFormation `ValidateTemplate` call, change set, endpoint contract test, and stack deployment could not be executed without the client AWS account, Region, network, IAM boundaries, Appian endpoints, and Tosca installation. Those are explicit commissioning steps in the guides.

## Important operating boundaries

- Do not edit Appian-generated XML or the internal structure of an exported Appian ZIP as a remediation technique.
- AI output is advisory. It creates a structured diagnostic and recommended action; it does not modify Appian, Tosca, AWS infrastructure, or production systems.
- The same S3 object version is processed once per target environment through the release ledger.
- After Appian TEST deployment, the pipeline-triggered Appian native expression-rule test gate must pass before Tosca smoke starts.
- Smoke is blocking. In pre-production, regression and E2E run in parallel only after smoke passes.
- The production approval must be assigned to authorized personnel under the client change-control and segregation-of-duties process.
- A `COMPLETED_AND_SYNCING` Appian deployment status is polled until terminal `COMPLETED`; if post-deployment sync is used, record-sync success still requires the client monitoring/control defined in the guide.
