from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import yaml

ROOT = Path('/mnt/data/appian_devops_guides')
SRC = ROOT / 'src'


class Literal(str):
    """String that PyYAML emits using block scalar style."""


def _literal_representer(dumper: yaml.SafeDumper, data: Literal):
    return dumper.represent_scalar('tag:yaml.org,2002:str', data, style='|')


yaml.SafeDumper.add_representer(Literal, _literal_representer)


def Ref(name: str) -> Dict[str, Any]:
    return {'Ref': name}


def GetAtt(name: str, attribute: str) -> Dict[str, Any]:
    return {'Fn::GetAtt': [name, attribute]}


def Sub(value: str, mapping: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    if mapping:
        return {'Fn::Sub': [Literal(value), mapping]}
    return {'Fn::Sub': Literal(value)}


def If(condition: str, true_value: Any, false_value: Any) -> Dict[str, Any]:
    return {'Fn::If': [condition, true_value, false_value]}


def NoValue() -> Dict[str, Any]:
    return Ref('AWS::NoValue')


def tags(scope: str) -> List[Dict[str, Any]]:
    return [
        {'Key': 'Project', 'Value': Ref('ProjectName')},
        {'Key': 'ManagedBy', 'Value': 'CloudFormation'},
        {'Key': 'Workload', 'Value': 'AppianDevOps'},
        {'Key': 'Scope', 'Value': scope},
    ]


def tag_map(scope: str) -> Dict[str, Any]:
    return {item['Key']: item['Value'] for item in tags(scope)}


def policy_statement(
    actions: Any,
    resources: Any,
    *,
    effect: str = 'Allow',
    **extra: Any,
) -> Dict[str, Any]:
    item: Dict[str, Any] = {
        'Effect': effect,
        'Action': actions,
        'Resource': resources,
    }
    item.update(extra)
    return item


def iam_role(
    service: str,
    statements: Iterable[Dict[str, Any]],
    scope: str,
    *,
    permissions_boundary: bool = False,
) -> Dict[str, Any]:
    properties: Dict[str, Any] = {
        'AssumeRolePolicyDocument': {
            'Version': '2012-10-17',
            'Statement': [{
                'Effect': 'Allow',
                'Principal': {'Service': service},
                'Action': 'sts:AssumeRole',
            }],
        },
        'Policies': [{
            'PolicyName': 'workload-access',
            'PolicyDocument': {
                'Version': '2012-10-17',
                'Statement': list(statements),
            },
        }],
        'Tags': tags(scope),
    }
    if permissions_boundary:
        properties['PermissionsBoundary'] = If(
            'HasPermissionsBoundary',
            Ref('PermissionsBoundaryArn'),
            NoValue(),
        )
    return {'Type': 'AWS::IAM::Role', 'Properties': properties}


def encryption_key(scope: str, retain: bool) -> Dict[str, Any]:
    resource: Dict[str, Any] = {
        'Type': 'AWS::KMS::Key',
        'Properties': {
            'Description': Sub('${ProjectName} Appian DevOps encryption key'),
            'EnableKeyRotation': True,
            'KeyPolicy': {
                'Version': '2012-10-17',
                'Statement': [
                    {
                        'Sid': 'EnableAccountAdministrationAndIamDelegation',
                        'Effect': 'Allow',
                        'Principal': {
                            'AWS': Sub(
                                'arn:${AWS::Partition}:iam::${AWS::AccountId}:root'
                            )
                        },
                        'Action': 'kms:*',
                        'Resource': '*',
                    },
                    {
                        'Sid': 'AllowCloudWatchLogsEncryption',
                        'Effect': 'Allow',
                        'Principal': {
                            'Service': Sub(
                                'logs.${AWS::Region}.${AWS::URLSuffix}'
                            )
                        },
                        'Action': [
                            'kms:Encrypt*',
                            'kms:Decrypt*',
                            'kms:ReEncrypt*',
                            'kms:GenerateDataKey*',
                            'kms:Describe*',
                        ],
                        'Resource': '*',
                        'Condition': {
                            'ArnLike': {
                                'kms:EncryptionContext:aws:logs:arn': Sub(
                                    'arn:${AWS::Partition}:logs:${AWS::Region}:'
                                    '${AWS::AccountId}:log-group:/aws/*'
                                )
                            }
                        },
                    },
                ],
            },
            'Tags': tags(scope),
        },
    }
    if retain:
        resource['DeletionPolicy'] = 'Retain'
        resource['UpdateReplacePolicy'] = 'Retain'
    return resource


def log_group(
    name: Any,
    retention_days: int,
    scope: str,
    *,
    retain: bool = False,
) -> Dict[str, Any]:
    resource: Dict[str, Any] = {
        'Type': 'AWS::Logs::LogGroup',
        'Properties': {
            'LogGroupName': name,
            'RetentionInDays': retention_days,
            'KmsKeyId': GetAtt('EncryptionKey', 'Arn'),
            'Tags': tags(scope),
        },
    }
    if retain:
        resource['DeletionPolicy'] = 'Retain'
        resource['UpdateReplacePolicy'] = 'Retain'
    return resource


def s3_bucket(
    scope: str,
    *,
    eventbridge: bool = False,
    retain: bool = False,
    current_expiration_days: Any = None,
    noncurrent_expiration_days: Any = 30,
    archive_transitions: bool = False,
) -> Dict[str, Any]:
    lifecycle: Dict[str, Any] = {
        'Id': 'Lifecycle',
        'Status': 'Enabled',
        'NoncurrentVersionExpiration': {
            'NoncurrentDays': noncurrent_expiration_days,
        },
        'AbortIncompleteMultipartUpload': {'DaysAfterInitiation': 7},
    }
    if current_expiration_days is not None:
        lifecycle['ExpirationInDays'] = current_expiration_days
    if archive_transitions:
        lifecycle['Transitions'] = [
            {'StorageClass': 'STANDARD_IA', 'TransitionInDays': 30},
            {'StorageClass': 'GLACIER', 'TransitionInDays': 90},
        ]
        lifecycle['NoncurrentVersionTransitions'] = [
            {'StorageClass': 'STANDARD_IA', 'TransitionInDays': 30},
            {'StorageClass': 'GLACIER', 'TransitionInDays': 90},
        ]

    properties: Dict[str, Any] = {
        'VersioningConfiguration': {'Status': 'Enabled'},
        'OwnershipControls': {
            'Rules': [{'ObjectOwnership': 'BucketOwnerEnforced'}]
        },
        'BucketEncryption': {
            'ServerSideEncryptionConfiguration': [{
                'BucketKeyEnabled': True,
                'ServerSideEncryptionByDefault': {
                    'SSEAlgorithm': 'aws:kms',
                    'KMSMasterKeyID': GetAtt('EncryptionKey', 'Arn'),
                },
            }]
        },
        'PublicAccessBlockConfiguration': {
            'BlockPublicAcls': True,
            'IgnorePublicAcls': True,
            'BlockPublicPolicy': True,
            'RestrictPublicBuckets': True,
        },
        'LifecycleConfiguration': {'Rules': [lifecycle]},
        'Tags': tags(scope),
    }
    if eventbridge:
        properties['NotificationConfiguration'] = {
            'EventBridgeConfiguration': {'EventBridgeEnabled': True}
        }
    resource: Dict[str, Any] = {
        'Type': 'AWS::S3::Bucket',
        'Properties': properties,
    }
    if retain:
        resource['DeletionPolicy'] = 'Retain'
        resource['UpdateReplacePolicy'] = 'Retain'
    return resource


def s3_bucket_policy(bucket_logical_id: str, retain: bool) -> Dict[str, Any]:
    resource: Dict[str, Any] = {
        'Type': 'AWS::S3::BucketPolicy',
        'Properties': {
            'Bucket': Ref(bucket_logical_id),
            'PolicyDocument': {
                'Version': '2012-10-17',
                'Statement': [{
                    'Sid': 'DenyInsecureTransport',
                    'Effect': 'Deny',
                    'Principal': '*',
                    'Action': 's3:*',
                    'Resource': [
                        GetAtt(bucket_logical_id, 'Arn'),
                        Sub(
                            '${BucketArn}/*',
                            {'BucketArn': GetAtt(bucket_logical_id, 'Arn')},
                        ),
                    ],
                    'Condition': {
                        'Bool': {'aws:SecureTransport': 'false'}
                    },
                }],
            },
        },
    }
    if retain:
        resource['DeletionPolicy'] = 'Retain'
        resource['UpdateReplacePolicy'] = 'Retain'
    return resource


def common_parameters(production: bool) -> Dict[str, Any]:
    return {
        'ProjectName': {
            'Type': 'String',
            'Default': (
                'appian-devops-production'
                if production
                else 'appian-devops-demo'
            ),
            'AllowedPattern': '[a-zA-Z][a-zA-Z0-9-]{2,39}',
            'ConstraintDescription': (
                'Use 3-40 letters, digits, and hyphens; begin with a letter.'
            ),
        },
        'SourceObjectKey': {
            'Type': 'String',
            'Default': 'incoming/application.zip',
            'Description': (
                'Fixed, versioned S3 object key overwritten for each Appian export.'
            ),
        },
        'PollIntervalSeconds': {
            'Type': 'Number',
            'Default': 30 if production else 2,
            'MinValue': 1,
            'MaxValue': 300,
        },
        'MaxPackageSizeMB': {
            'Type': 'Number',
            'Default': 500,
            'MinValue': 1,
            'MaxValue': 900,
        },
        'EnableAiDiagnostics': {
            'Type': 'String',
            'Default': 'true',
            'AllowedValues': ['true', 'false'],
            'Description': (
                'When false, failure handling still writes a deterministic '
                'diagnostic without invoking a foundation model.'
            ),
        },
        'BedrockModelId': {
            'Type': 'String',
            'Default': 'amazon.nova-pro-v1:0',
            'Description': (
                'Bedrock model or inference-profile ID available in the Region.'
            ),
        },
        'NotificationEmail': {
            'Type': 'String',
            'Default': '',
            'Description': (
                'Optional email address for approval, alarm, and failure notifications.'
            ),
        },
    }


def common_resources(scope: str, production: bool) -> Dict[str, Any]:
    log_retention = 90 if production else 14
    evidence_retention: Any = (
        Ref('EvidenceRetentionDays') if production else 30
    )
    resources: Dict[str, Any] = {
        'EncryptionKey': encryption_key(scope, production),
        'EncryptionKeyAlias': {
            'Type': 'AWS::KMS::Alias',
            'Properties': {
                'AliasName': Sub('alias/${ProjectName}'),
                'TargetKeyId': Ref('EncryptionKey'),
            },
        },
        'SourceBucket': s3_bucket(
            scope,
            eventbridge=True,
            retain=production,
            current_expiration_days=None if production else 30,
            noncurrent_expiration_days=evidence_retention if production else 14,
            archive_transitions=production,
        ),
        'SourceBucketPolicy': s3_bucket_policy('SourceBucket', production),
        'ArtifactBucket': s3_bucket(
            scope,
            retain=production,
            current_expiration_days=90 if production else 14,
            noncurrent_expiration_days=90 if production else 14,
        ),
        'ArtifactBucketPolicy': s3_bucket_policy('ArtifactBucket', production),
        'ResultsBucket': s3_bucket(
            scope,
            retain=production,
            current_expiration_days=evidence_retention,
            noncurrent_expiration_days=evidence_retention,
            archive_transitions=production,
        ),
        'ResultsBucketPolicy': s3_bucket_policy('ResultsBucket', production),
        'NotificationTopic': {
            'Type': 'AWS::SNS::Topic',
            'Properties': {
                'TopicName': Sub('${ProjectName}-notifications'),
                # Diagnostic messages are explicitly redacted. The topic is
                # left without SSE in this reference template to avoid customer
                # key-policy incompatibilities across EventBridge, CloudWatch,
                # CodePipeline, and Lambda. Organizations can add their own SNS
                # key after validating those service-principal permissions.
                'Tags': tags(scope),
            },
        },
        'NotificationTopicPolicy': {
            'Type': 'AWS::SNS::TopicPolicy',
            'Properties': {
                'Topics': [Ref('NotificationTopic')],
                'PolicyDocument': {
                    'Version': '2012-10-17',
                    'Statement': [
                        {
                            'Sid': 'AllowAccountManagedPublishAndAdministration',
                            'Effect': 'Allow',
                            'Principal': {
                                'AWS': Sub(
                                    'arn:${AWS::Partition}:iam::${AWS::AccountId}:root'
                                )
                            },
                            'Action': 'sns:*',
                            'Resource': Ref('NotificationTopic'),
                            'Condition': {
                                'StringEquals': {
                                    'AWS:SourceOwner': Ref('AWS::AccountId')
                                }
                            },
                        },
                        {
                            'Sid': 'AllowEventBridgePublish',
                            'Effect': 'Allow',
                            'Principal': {'Service': 'events.amazonaws.com'},
                            'Action': 'sns:Publish',
                            'Resource': Ref('NotificationTopic'),
                            'Condition': {
                                'StringEquals': {
                                    'AWS:SourceAccount': Ref('AWS::AccountId')
                                }
                            },
                        },
                        {
                            'Sid': 'AllowCloudWatchAlarmPublish',
                            'Effect': 'Allow',
                            'Principal': {'Service': 'cloudwatch.amazonaws.com'},
                            'Action': 'sns:Publish',
                            'Resource': Ref('NotificationTopic'),
                            'Condition': {
                                'StringEquals': {
                                    'AWS:SourceAccount': Ref('AWS::AccountId')
                                }
                            },
                        },
                    ],
                },
            },
        },
        'EmailSubscription': {
            'Type': 'AWS::SNS::Subscription',
            'Condition': 'HasNotificationEmail',
            'Properties': {
                'Protocol': 'email',
                'Endpoint': Ref('NotificationEmail'),
                'TopicArn': Ref('NotificationTopic'),
            },
        },
        'ReleaseLedger': {
            'Type': 'AWS::DynamoDB::Table',
            'Properties': {
                'BillingMode': 'PAY_PER_REQUEST',
                'AttributeDefinitions': [
                    {'AttributeName': 'idempotencyKey', 'AttributeType': 'S'}
                ],
                'KeySchema': [
                    {'AttributeName': 'idempotencyKey', 'KeyType': 'HASH'}
                ],
                'SSESpecification': {'SSEEnabled': True},
                'TimeToLiveSpecification': {
                    'AttributeName': 'expiresAt',
                    'Enabled': True,
                },
                'PointInTimeRecoverySpecification': {
                    'PointInTimeRecoveryEnabled': production
                },
                'Tags': tags(scope),
            },
        },
        'OrchestratorLogGroup': log_group(
            Sub('/aws/lambda/${ProjectName}-orchestrator'),
            log_retention,
            scope,
            retain=production,
        ),
        'CodeBuildLogGroup': log_group(
            Sub('/aws/codebuild/${ProjectName}'),
            log_retention,
            scope,
            retain=production,
        ),
    }
    if production:
        resources['ReleaseLedger']['DeletionPolicy'] = 'Retain'
        resources['ReleaseLedger']['UpdateReplacePolicy'] = 'Retain'
    return resources


def report_resources(scope: str, production: bool) -> Dict[str, Any]:
    buildspec = Sub(
        r'''version: 0.2
phases:
  build:
    commands:
      - mkdir -p reports
      - aws s3 cp "s3://$RESULTS_BUCKET/$RESULT_PREFIX/" reports/ --recursive --exclude "*" --include "*.xml" || true
      - |
        if ! find reports -type f -name '*.xml' -print -quit | grep -q .; then
          printf '%s\n' \
            '<?xml version="1.0" encoding="UTF-8"?>' \
            '<testsuite name="ToscaResultAvailability" tests="1" failures="1">' \
            '  <testcase classname="Integration" name="JUnitResultsAvailable">' \
            '    <failure message="No JUnit XML was returned by the test provider">Review the Step Functions and S3 integration evidence.</failure>' \
            '  </testcase>' \
            '</testsuite>' > reports/no-results.xml
        fi
reports:
  "${ReportGroupArn}":
    files:
      - "**/*.xml"
    base-directory: reports
    file-format: JUNITXML
''',
        {'ReportGroupArn': GetAtt('TestReportGroup', 'Arn')},
    )
    report_group: Dict[str, Any] = {
        'Type': 'AWS::CodeBuild::ReportGroup',
        'Properties': {
            'Name': Sub('${ProjectName}-tosca-tests'),
            'Type': 'TEST',
            'ExportConfig': {'ExportConfigType': 'NO_EXPORT'},
            'DeleteReports': not production,
            'Tags': tags(scope),
        },
    }
    if production:
        report_group['DeletionPolicy'] = 'Retain'
        report_group['UpdateReplacePolicy'] = 'Retain'
    return {
        'TestReportGroup': report_group,
        'ReportPublisherProject': {
            'Type': 'AWS::CodeBuild::Project',
            'Properties': {
                'Name': Sub('${ProjectName}-report-publisher'),
                'Description': (
                    'Publishes Tosca JUnit XML stored in S3 into CodeBuild test reports.'
                ),
                'ServiceRole': GetAtt('CodeBuildRole', 'Arn'),
                'Artifacts': {'Type': 'NO_ARTIFACTS'},
                'Source': {
                    'Type': 'NO_SOURCE',
                    'BuildSpec': buildspec,
                },
                'Environment': {
                    'ComputeType': 'BUILD_GENERAL1_SMALL',
                    'Image': 'aws/codebuild/standard:7.0',
                    'Type': 'LINUX_CONTAINER',
                    'EnvironmentVariables': [],
                },
                'TimeoutInMinutes': 15,
                'ConcurrentBuildLimit': 2 if production else 1,
                'EncryptionKey': GetAtt('EncryptionKey', 'Arn'),
                'LogsConfig': {
                    'CloudWatchLogs': {
                        'Status': 'ENABLED',
                        'GroupName': Sub('/aws/codebuild/${ProjectName}'),
                    },
                    'S3Logs': {'Status': 'DISABLED'},
                },
                'Tags': tags(scope),
            },
        },
    }


def common_iam(
    scope: str,
    production: bool,
    appian_secret_arns: List[Any],
    tosca_secret_arn: Any,
    scenario_parameter_arn: Any = None,
) -> Dict[str, Any]:
    source_objects = Sub(
        '${BucketArn}/*',
        {'BucketArn': GetAtt('SourceBucket', 'Arn')},
    )
    results_objects = Sub(
        '${BucketArn}/*',
        {'BucketArn': GetAtt('ResultsBucket', 'Arn')},
    )
    artifact_objects = Sub(
        '${BucketArn}/*',
        {'BucketArn': GetAtt('ArtifactBucket', 'Arn')},
    )
    orchestrator_statements = [
        policy_statement(
            ['logs:CreateLogStream', 'logs:PutLogEvents'],
            Sub(
                'arn:${AWS::Partition}:logs:${AWS::Region}:${AWS::AccountId}:'
                'log-group:/aws/lambda/${ProjectName}-orchestrator:*'
            ),
        ),
        policy_statement(
            ['s3:GetObject', 's3:GetObjectVersion', 's3:GetObjectTagging'],
            source_objects,
        ),
        policy_statement(
            ['s3:ListBucket'],
            [GetAtt('SourceBucket', 'Arn'), GetAtt('ResultsBucket', 'Arn')],
        ),
        policy_statement(
            ['s3:GetObject', 's3:PutObject'],
            results_objects,
        ),
        policy_statement(
            ['kms:Decrypt', 'kms:Encrypt', 'kms:GenerateDataKey', 'kms:DescribeKey'],
            GetAtt('EncryptionKey', 'Arn'),
        ),
        policy_statement(
            ['secretsmanager:GetSecretValue'],
            appian_secret_arns + [tosca_secret_arn],
        ),
        policy_statement(
            ['dynamodb:GetItem', 'dynamodb:PutItem', 'dynamodb:UpdateItem'],
            GetAtt('ReleaseLedger', 'Arn'),
        ),
        policy_statement(['bedrock:InvokeModel'], '*'),
        policy_statement(['sns:Publish'], Ref('NotificationTopic')),
        policy_statement(
            ['xray:PutTraceSegments', 'xray:PutTelemetryRecords'],
            '*',
        ),
    ]
    if scenario_parameter_arn is not None:
        orchestrator_statements.append(
            policy_statement(['ssm:GetParameter'], scenario_parameter_arn)
        )
    if production:
        # Existing secrets may use keys other than this stack's CMK.
        orchestrator_statements.extend([
            policy_statement(
                ['kms:Decrypt'],
                '*',
                Condition={
                    'StringEquals': {
                        'kms:CallerAccount': Ref('AWS::AccountId')
                    },
                    'StringLike': {
                        'kms:ViaService': Sub(
                            'secretsmanager.${AWS::Region}.${AWS::URLSuffix}'
                        )
                    },
                },
            ),
            policy_statement(
                [
                    'ec2:CreateNetworkInterface',
                    'ec2:DescribeNetworkInterfaces',
                    'ec2:DeleteNetworkInterface',
                    'ec2:AssignPrivateIpAddresses',
                    'ec2:UnassignPrivateIpAddresses',
                ],
                '*',
            ),
        ])

    codebuild_statements = [
        policy_statement(
            ['logs:CreateLogStream', 'logs:PutLogEvents'],
            Sub(
                'arn:${AWS::Partition}:logs:${AWS::Region}:${AWS::AccountId}:'
                'log-group:/aws/codebuild/${ProjectName}:*'
            ),
        ),
        policy_statement(['s3:ListBucket'], GetAtt('ResultsBucket', 'Arn')),
        policy_statement(['s3:GetObject'], results_objects),
        policy_statement(
            ['kms:Decrypt', 'kms:Encrypt', 'kms:GenerateDataKey', 'kms:DescribeKey'],
            GetAtt('EncryptionKey', 'Arn'),
        ),
        policy_statement(
            [
                'codebuild:CreateReport',
                'codebuild:UpdateReport',
                'codebuild:BatchPutTestCases',
                'codebuild:BatchPutCodeCoverages',
            ],
            [
                GetAtt('TestReportGroup', 'Arn'),
                Sub(
                    '${ReportGroupArn}:*',
                    {'ReportGroupArn': GetAtt('TestReportGroup', 'Arn')},
                ),
            ],
        ),
    ]

    step_functions_statements = [
        policy_statement(
            ['lambda:InvokeFunction'],
            [
                GetAtt('OrchestratorFunction', 'Arn'),
                Sub(
                    '${FunctionArn}:*',
                    {'FunctionArn': GetAtt('OrchestratorFunction', 'Arn')},
                ),
            ],
        ),
        policy_statement(
            ['codebuild:StartBuild', 'codebuild:StopBuild', 'codebuild:BatchGetBuilds'],
            GetAtt('ReportPublisherProject', 'Arn'),
        ),
        policy_statement(
            ['events:PutTargets', 'events:PutRule', 'events:DescribeRule'],
            Sub(
                'arn:${AWS::Partition}:events:${AWS::Region}:${AWS::AccountId}:'
                'rule/StepFunctionsGetEventForCodeBuildStartBuildRule'
            ),
        ),
        policy_statement(
            [
                'logs:CreateLogDelivery',
                'logs:GetLogDelivery',
                'logs:UpdateLogDelivery',
                'logs:DeleteLogDelivery',
                'logs:ListLogDeliveries',
                'logs:PutResourcePolicy',
                'logs:DescribeResourcePolicies',
                'logs:DescribeLogGroups',
            ],
            '*',
        ),
        policy_statement(
            [
                'xray:PutTraceSegments',
                'xray:PutTelemetryRecords',
                'xray:GetSamplingRules',
                'xray:GetSamplingTargets',
            ],
            '*',
        ),
    ]

    pipeline_statements = [
        policy_statement(
            ['s3:GetBucketVersioning', 's3:GetBucketLocation', 's3:ListBucket'],
            [GetAtt('SourceBucket', 'Arn'), GetAtt('ArtifactBucket', 'Arn')],
        ),
        policy_statement(
            ['s3:GetObject', 's3:GetObjectVersion', 's3:GetObjectTagging'],
            source_objects,
        ),
        policy_statement(
            [
                's3:GetObject',
                's3:GetObjectVersion',
                's3:PutObject',
                's3:GetObjectTagging',
                's3:PutObjectTagging',
            ],
            artifact_objects,
        ),
        policy_statement(
            ['kms:Decrypt', 'kms:Encrypt', 'kms:GenerateDataKey', 'kms:DescribeKey'],
            GetAtt('EncryptionKey', 'Arn'),
        ),
        policy_statement(
            ['states:DescribeStateMachine', 'states:DescribeExecution', 'states:StartExecution'],
            '*',
        ),
        policy_statement(['sns:Publish'], Ref('NotificationTopic')),
    ]

    return {
        'OrchestratorRole': iam_role(
            'lambda.amazonaws.com',
            orchestrator_statements,
            scope,
            permissions_boundary=production,
        ),
        'CodeBuildRole': iam_role(
            'codebuild.amazonaws.com',
            codebuild_statements,
            scope,
            permissions_boundary=production,
        ),
        'StepFunctionsRole': iam_role(
            'states.amazonaws.com',
            step_functions_statements,
            scope,
            permissions_boundary=production,
        ),
        'CodePipelineRole': iam_role(
            'codepipeline.amazonaws.com',
            pipeline_statements,
            scope,
            permissions_boundary=production,
        ),
    }


def orchestrator_function(
    scope: str,
    production: bool,
    environment_variables: Dict[str, Any],
) -> Dict[str, Any]:
    properties: Dict[str, Any] = {
        'FunctionName': Sub('${ProjectName}-orchestrator'),
        'Description': (
            'Appian/Tosca integration client, quality gate evaluator, '
            'evidence collector, and Bedrock diagnostic invoker.'
        ),
        'Runtime': 'python3.12',
        'Handler': 'index.handler',
        'Role': GetAtt('OrchestratorRole', 'Arn'),
        'Code': {
            'ZipFile': Literal(
                (SRC / 'orchestrator.py').read_text(encoding='utf-8')
            )
        },
        'MemorySize': 2048,
        'Timeout': 900,
        'EphemeralStorage': {'Size': 1024},
        'ReservedConcurrentExecutions': 5 if production else 2,
        'Environment': {'Variables': environment_variables},
        'TracingConfig': {'Mode': 'Active'},
        'Tags': tags(scope),
    }
    if production:
        properties['VpcConfig'] = If(
            'UseVpc',
            {
                'SubnetIds': {
                    'Fn::Split': [',', Ref('LambdaSubnetIds')]
                },
                'SecurityGroupIds': {
                    'Fn::Split': [',', Ref('LambdaSecurityGroupIds')]
                },
            },
            NoValue(),
        )
    return {
        'Type': 'AWS::Lambda::Function',
        'DependsOn': ['OrchestratorLogGroup'],
        'Properties': properties,
    }


def state_machine(
    logical_id: str,
    asl_filename: str,
    name_suffix: str,
    scope: str,
) -> Dict[str, Any]:
    definition = (SRC / asl_filename).read_text(encoding='utf-8')
    return {
        'Type': 'AWS::StepFunctions::StateMachine',
        'Properties': {
            'StateMachineName': Sub('${ProjectName}-' + name_suffix),
            'StateMachineType': 'STANDARD',
            'RoleArn': GetAtt('StepFunctionsRole', 'Arn'),
            'DefinitionString': Sub(
                definition,
                {
                    'OrchestratorFunctionArn': GetAtt(
                        'OrchestratorFunction',
                        'Arn',
                    ),
                    'ReportPublisherProjectName': Ref(
                        'ReportPublisherProject'
                    ),
                    'ResultsBucketName': Ref('ResultsBucket'),
                },
            ),
            'LoggingConfiguration': {
                'Level': 'ALL',
                'IncludeExecutionData': False,
                'Destinations': [{
                    'CloudWatchLogsLogGroup': {
                        'LogGroupArn': GetAtt(
                            logical_id + 'LogGroup',
                            'Arn',
                        )
                    }
                }],
            },
            'TracingConfiguration': {'Enabled': True},
            'Tags': tags(scope),
        },
    }


def pipeline_arn() -> Dict[str, Any]:
    return Sub(
        'arn:${AWS::Partition}:codepipeline:${AWS::Region}:'
        '${AWS::AccountId}:${PipelineName}',
        {'PipelineName': Ref('Pipeline')},
    )


def eventbridge_resources(scope: str) -> Dict[str, Any]:
    return {
        'PipelineTriggerRole': iam_role(
            'events.amazonaws.com',
            [
                policy_statement(
                    ['codepipeline:StartPipelineExecution'],
                    pipeline_arn(),
                )
            ],
            scope,
            permissions_boundary=(scope == 'production'),
        ),
        'S3ObjectCreatedRule': {
            'Type': 'AWS::Events::Rule',
            'Properties': {
                'Description': (
                    'Starts CodePipeline for the exact Appian ZIP key and pins '
                    'the S3 object version as the source revision.'
                ),
                'EventPattern': {
                    'source': ['aws.s3'],
                    'detail-type': ['Object Created'],
                    'detail': {
                        'bucket': {'name': [Ref('SourceBucket')]},
                        'object': {'key': [Ref('SourceObjectKey')]},
                    },
                },
                'State': 'ENABLED',
                'Targets': [{
                    'Arn': pipeline_arn(),
                    'Id': 'StartPipeline',
                    'RoleArn': GetAtt('PipelineTriggerRole', 'Arn'),
                    'InputTransformer': {
                        'InputPathsMap': {
                            'versionId': '$.detail.object.version-id'
                        },
                        'InputTemplate': (
                            '{"sourceRevisions":[{"actionName":"Source",'
                            '"revisionType":"S3_OBJECT_VERSION_ID",'
                            '"revisionValue":"<versionId>"}]}'
                        ),
                    },
                }],
            },
        },
        'PipelineFailureRule': {
            'Type': 'AWS::Events::Rule',
            'Properties': {
                'Description': (
                    'Publishes a notification if the release pipeline fails, '
                    'is canceled, or is superseded.'
                ),
                'EventPattern': {
                    'source': ['aws.codepipeline'],
                    'detail-type': [
                        'CodePipeline Pipeline Execution State Change'
                    ],
                    'detail': {
                        'pipeline': [Ref('Pipeline')],
                        'state': ['FAILED', 'CANCELED', 'SUPERSEDED'],
                    },
                },
                'State': 'ENABLED',
                'Targets': [{
                    'Arn': Ref('NotificationTopic'),
                    'Id': 'NotifyPipelineFailure',
                }],
            },
        },
    }


def alarms(state_machine_ids: List[str]) -> Dict[str, Any]:
    resources: Dict[str, Any] = {
        'OrchestratorErrorAlarm': {
            'Type': 'AWS::CloudWatch::Alarm',
            'Properties': {
                'AlarmDescription': (
                    'One or more orchestrator Lambda invocations failed.'
                ),
                'Namespace': 'AWS/Lambda',
                'MetricName': 'Errors',
                'Dimensions': [{
                    'Name': 'FunctionName',
                    'Value': Ref('OrchestratorFunction'),
                }],
                'Statistic': 'Sum',
                'Period': 300,
                'EvaluationPeriods': 1,
                'Threshold': 1,
                'ComparisonOperator': 'GreaterThanOrEqualToThreshold',
                'TreatMissingData': 'notBreaching',
                'AlarmActions': [Ref('NotificationTopic')],
            },
        },
        'OrchestratorThrottleAlarm': {
            'Type': 'AWS::CloudWatch::Alarm',
            'Properties': {
                'AlarmDescription': 'The orchestrator Lambda was throttled.',
                'Namespace': 'AWS/Lambda',
                'MetricName': 'Throttles',
                'Dimensions': [{
                    'Name': 'FunctionName',
                    'Value': Ref('OrchestratorFunction'),
                }],
                'Statistic': 'Sum',
                'Period': 300,
                'EvaluationPeriods': 1,
                'Threshold': 1,
                'ComparisonOperator': 'GreaterThanOrEqualToThreshold',
                'TreatMissingData': 'notBreaching',
                'AlarmActions': [Ref('NotificationTopic')],
            },
        },
    }
    for index, state_machine_id in enumerate(state_machine_ids, start=1):
        resources[f'StateMachineFailureAlarm{index}'] = {
            'Type': 'AWS::CloudWatch::Alarm',
            'Properties': {
                'AlarmDescription': (
                    'One or more release state-machine executions failed.'
                ),
                'Namespace': 'AWS/States',
                'MetricName': 'ExecutionsFailed',
                'Dimensions': [{
                    'Name': 'StateMachineArn',
                    'Value': Ref(state_machine_id),
                }],
                'Statistic': 'Sum',
                'Period': 300,
                'EvaluationPeriods': 1,
                'Threshold': 1,
                'ComparisonOperator': 'GreaterThanOrEqualToThreshold',
                'TreatMissingData': 'notBreaching',
                'AlarmActions': [Ref('NotificationTopic')],
            },
        }
    return resources


def source_stage() -> Dict[str, Any]:
    return {
        'Name': 'Source',
        'Actions': [{
            'Name': 'Source',
            'Namespace': 'SourceVariables',
            'ActionTypeId': {
                'Category': 'Source',
                'Owner': 'AWS',
                'Provider': 'S3',
                'Version': '1',
            },
            'RunOrder': 1,
            'Configuration': {
                'S3Bucket': Ref('SourceBucket'),
                'S3ObjectKey': Ref('SourceObjectKey'),
                'PollForSourceChanges': 'false',
            },
            'OutputArtifacts': [{'Name': 'SourceArtifact'}],
        }],
    }


def step_functions_action(
    action_name: str,
    state_machine_id: str,
    environment: str,
    required_suites: List[str],
    execution_prefix: str,
) -> Dict[str, Any]:
    suites_json = json.dumps(required_suites, separators=(',', ':'))
    input_text = (
        '{'
        '"sourceBucket":"#{SourceVariables.BucketName}",'
        '"sourceKey":"#{SourceVariables.ObjectKey}",'
        '"sourceVersion":"#{SourceVariables.VersionId}",'
        '"pipelineExecutionId":"#{codepipeline.PipelineExecutionId}",'
        f'"environment":"{environment}",'
        f'"requiredSuites":{suites_json},'
        '"pollIntervalSeconds":${PollIntervalSeconds}'
        '}'
    )
    return {
        'Name': action_name,
        'ActionTypeId': {
            'Category': 'Invoke',
            'Owner': 'AWS',
            'Provider': 'StepFunctions',
            'Version': '1',
        },
        'RunOrder': 1,
        'Configuration': {
            'StateMachineArn': Ref(state_machine_id),
            'ExecutionNamePrefix': execution_prefix,
            'InputType': 'Literal',
            'Input': Sub(input_text),
        },
    }


def codepipeline(stages: List[Dict[str, Any]], scope: str) -> Dict[str, Any]:
    return {
        'Type': 'AWS::CodePipeline::Pipeline',
        'Properties': {
            'Name': Sub('${ProjectName}-pipeline'),
            'RoleArn': GetAtt('CodePipelineRole', 'Arn'),
            'PipelineType': 'V2',
            'ExecutionMode': 'QUEUED',
            'RestartExecutionOnUpdate': False,
            'ArtifactStore': {
                'Type': 'S3',
                'Location': Ref('ArtifactBucket'),
                'EncryptionKey': {
                    'Id': GetAtt('EncryptionKey', 'Arn'),
                    'Type': 'KMS',
                },
            },
            'Stages': stages,
            'Tags': tags(scope),
        },
    }


def demo_template() -> Dict[str, Any]:
    parameters = common_parameters(False)
    parameters.update({
        'DemoScenario': {
            'Type': 'String',
            'Default': 'SUCCESS',
            'AllowedValues': [
                'SUCCESS',
                'SMOKE_FAILURE',
                'REGRESSION_FAILURE',
                'E2E_FAILURE',
                'ALL_TESTS_FAILURE',
                'APPIAN_INSPECTION_FAILURE',
                'APPIAN_DEPLOYMENT_FAILURE',
                'TOSCA_AUTH_FAILURE',
                'TOSCA_SERVICE_FAILURE',
                'TOSCA_STATUS_ERROR',
                'TOSCA_TIMEOUT',
                'MALFORMED_RESULTS',
            ],
        },
        'AppianIntegrationMode': {
            'Type': 'String',
            'Default': 'MOCK',
            'AllowedValues': ['MOCK', 'REAL'],
            'Description': (
                'MOCK makes the demo self-contained. REAL calls the Appian '
                'TEST endpoint configured in the generated secret.'
            ),
        },
    })

    template: Dict[str, Any] = {
        'AWSTemplateFormatVersion': '2010-09-09',
        'Description': (
            'Client demonstration: production-shaped AWS-native Appian package '
            'release pipeline, Tosca Execution API mock, JUnit reporting, and '
            'AI-assisted diagnostics.'
        ),
        'Metadata': {
            'AWS::CloudFormation::Interface': {
                'ParameterGroups': [
                    {
                        'Label': {'default': 'Naming and source'},
                        'Parameters': ['ProjectName', 'SourceObjectKey'],
                    },
                    {
                        'Label': {'default': 'Demonstration behavior'},
                        'Parameters': [
                            'DemoScenario',
                            'AppianIntegrationMode',
                            'PollIntervalSeconds',
                            'MaxPackageSizeMB',
                        ],
                    },
                    {
                        'Label': {'default': 'Diagnostics and notifications'},
                        'Parameters': [
                            'EnableAiDiagnostics',
                            'BedrockModelId',
                            'NotificationEmail',
                        ],
                    },
                ]
            }
        },
        'Parameters': parameters,
        'Conditions': {
            'HasNotificationEmail': {
                'Fn::Not': [{'Fn::Equals': [Ref('NotificationEmail'), '']}]
            },
        },
        'Resources': {},
        'Outputs': {},
    }
    resources = template['Resources']
    resources.update(common_resources('demo', False))
    resources.update(report_resources('demo', False))

    resources['DemoScenarioParameter'] = {
        'Type': 'AWS::SSM::Parameter',
        'Properties': {
            'Name': Sub('/${ProjectName}/demo/scenario'),
            'Type': 'String',
            'Value': Ref('DemoScenario'),
            'Description': (
                'Deterministic fault/success scenario for upcoming demo executions.'
            ),
            'Tags': tag_map('demo'),
        },
    }
    resources['DemoAppianSecret'] = {
        'Type': 'AWS::SecretsManager::Secret',
        'Properties': {
            'Name': Sub('/${ProjectName}/appian/test'),
            'Description': (
                'Production-shaped Appian TEST connection configuration. '
                'Replace the generated values before REAL mode.'
            ),
            'KmsKeyId': GetAtt('EncryptionKey', 'Arn'),
            'GenerateSecretString': {
                'SecretStringTemplate': json.dumps({
                    'baseUrl': 'https://replace-me.appiancloud.com',
                    'deploymentApiVersion': 'v3',
                    'authType': 'API_KEY',
                    'requestTimeoutSeconds': 600,
                }),
                'GenerateStringKey': 'apiKey',
                'PasswordLength': 40,
                'ExcludePunctuation': True,
            },
            'Tags': tags('demo'),
        },
    }
    resources['DemoToscaSecret'] = {
        'Type': 'AWS::SecretsManager::Secret',
        'Properties': {
            'Name': Sub('/${ProjectName}/tosca'),
            'Description': (
                'Tosca Execution API configuration shared by the integration '
                'client and the mock implementation.'
            ),
            'KmsKeyId': GetAtt('EncryptionKey', 'Arn'),
            'GenerateSecretString': {
                'SecretStringTemplate': json.dumps({
                    'clientId': 'demo-client-id',
                    'tokenPath': '/tua/connect/token',
                    'executionApiPath': '/api/Execution',
                    'projectName': 'AppianAutomation',
                    'executionEnvironment': 'Dex',
                    'importResult': True,
                    'creator': 'AWS-CodePipeline',
                    'events': {
                        'SMOKE': 'APPIAN_SMOKE',
                        'REGRESSION': 'APPIAN_REGRESSION',
                        'E2E': 'APPIAN_E2E',
                    },
                    'parameters': {'Browser': 'Chrome'},
                    'requestTimeoutSeconds': 30,
                }),
                'GenerateStringKey': 'clientSecret',
                'PasswordLength': 40,
                'ExcludePunctuation': True,
            },
            'Tags': tags('demo'),
        },
    }
    resources['MockExecutionTable'] = {
        'Type': 'AWS::DynamoDB::Table',
        'Properties': {
            'BillingMode': 'PAY_PER_REQUEST',
            'AttributeDefinitions': [
                {'AttributeName': 'executionId', 'AttributeType': 'S'}
            ],
            'KeySchema': [
                {'AttributeName': 'executionId', 'KeyType': 'HASH'}
            ],
            'SSESpecification': {'SSEEnabled': True},
            'TimeToLiveSpecification': {
                'AttributeName': 'expiresAt',
                'Enabled': True,
            },
            'Tags': tags('demo'),
        },
    }
    resources['MockToscaLogGroup'] = log_group(
        Sub('/aws/lambda/${ProjectName}-mock-tosca'),
        14,
        'demo',
    )
    resources['MockToscaRole'] = iam_role(
        'lambda.amazonaws.com',
        [
            policy_statement(
                ['logs:CreateLogStream', 'logs:PutLogEvents'],
                Sub(
                    'arn:${AWS::Partition}:logs:${AWS::Region}:${AWS::AccountId}:'
                    'log-group:/aws/lambda/${ProjectName}-mock-tosca:*'
                ),
            ),
            policy_statement(
                ['dynamodb:GetItem', 'dynamodb:PutItem', 'dynamodb:UpdateItem'],
                GetAtt('MockExecutionTable', 'Arn'),
            ),
            policy_statement(
                ['secretsmanager:GetSecretValue'],
                Ref('DemoToscaSecret'),
            ),
            policy_statement(
                ['ssm:GetParameter'],
                Sub(
                    'arn:${AWS::Partition}:ssm:${AWS::Region}:${AWS::AccountId}:'
                    'parameter/${ProjectName}/demo/scenario'
                ),
            ),
            policy_statement(
                ['kms:Decrypt'],
                GetAtt('EncryptionKey', 'Arn'),
            ),
            policy_statement(
                ['xray:PutTraceSegments', 'xray:PutTelemetryRecords'],
                '*',
            ),
        ],
        'demo',
    )
    resources['MockToscaFunction'] = {
        'Type': 'AWS::Lambda::Function',
        'DependsOn': ['MockToscaLogGroup'],
        'Properties': {
            'FunctionName': Sub('${ProjectName}-mock-tosca'),
            'Description': (
                'Production-shaped token, enqueue, polling, result, and '
                'summary endpoints for the client demonstration.'
            ),
            'Runtime': 'python3.12',
            'Handler': 'index.handler',
            'Role': GetAtt('MockToscaRole', 'Arn'),
            'Code': {
                'ZipFile': Literal(
                    (SRC / 'mock_tosca.py').read_text(encoding='utf-8')
                )
            },
            'MemorySize': 512,
            'Timeout': 30,
            'ReservedConcurrentExecutions': 2,
            'Environment': {
                'Variables': {
                    'EXECUTION_TABLE': Ref('MockExecutionTable'),
                    'MOCK_SECRET_ARN': Ref('DemoToscaSecret'),
                    'SCENARIO_PARAMETER': Ref('DemoScenarioParameter'),
                }
            },
            'TracingConfig': {'Mode': 'Active'},
            'Tags': tags('demo'),
        },
    }
    resources['MockApiLogGroup'] = log_group(
        Sub('/aws/apigateway/${ProjectName}-mock-tosca'),
        14,
        'demo',
    )
    resources['MockApiLogResourcePolicy'] = {
        'Type': 'AWS::Logs::ResourcePolicy',
        'Properties': {
            'PolicyName': Sub('${ProjectName}-mock-api-log-delivery'),
            'PolicyDocument': Sub(
                '''{
  "Version": "2012-10-17",
  "Statement": [{
    "Sid": "ApiGatewayLogDelivery",
    "Effect": "Allow",
    "Principal": {"Service": ["apigateway.amazonaws.com", "delivery.logs.amazonaws.com"]},
    "Action": ["logs:CreateLogStream", "logs:PutLogEvents"],
    "Resource": "arn:${AWS::Partition}:logs:${AWS::Region}:${AWS::AccountId}:log-group:/aws/apigateway/${ProjectName}-mock-tosca:*"
  }]
}'''
            ),
        },
    }
    resources['MockHttpApi'] = {
        'Type': 'AWS::ApiGatewayV2::Api',
        'Properties': {
            'Name': Sub('${ProjectName}-mock-tosca'),
            'ProtocolType': 'HTTP',
            'Tags': tag_map('demo'),
        },
    }
    resources['MockApiIntegration'] = {
        'Type': 'AWS::ApiGatewayV2::Integration',
        'Properties': {
            'ApiId': Ref('MockHttpApi'),
            'IntegrationType': 'AWS_PROXY',
            'IntegrationUri': GetAtt('MockToscaFunction', 'Arn'),
            'PayloadFormatVersion': '2.0',
            'TimeoutInMillis': 29000,
        },
    }
    resources['MockApiRoute'] = {
        'Type': 'AWS::ApiGatewayV2::Route',
        'Properties': {
            'ApiId': Ref('MockHttpApi'),
            'RouteKey': '$default',
            'Target': Sub('integrations/${MockApiIntegration}'),
        },
    }
    resources['MockApiStage'] = {
        'Type': 'AWS::ApiGatewayV2::Stage',
        'DependsOn': ['MockApiLogResourcePolicy'],
        'Properties': {
            'ApiId': Ref('MockHttpApi'),
            'StageName': '$default',
            'AutoDeploy': True,
            'AccessLogSettings': {
                'DestinationArn': Sub(
                    'arn:${AWS::Partition}:logs:${AWS::Region}:${AWS::AccountId}:'
                    'log-group:/aws/apigateway/${ProjectName}-mock-tosca'
                ),
                'Format': (
                    '{"requestId":"$context.requestId",'
                    '"routeKey":"$context.routeKey",'
                    '"status":"$context.status",'
                    '"responseLength":"$context.responseLength"}'
                ),
            },
            'DefaultRouteSettings': {
                'ThrottlingBurstLimit': 20,
                'ThrottlingRateLimit': 10,
            },
            'Tags': tag_map('demo'),
        },
    }
    resources['MockApiInvokePermission'] = {
        'Type': 'AWS::Lambda::Permission',
        'Properties': {
            'Action': 'lambda:InvokeFunction',
            'FunctionName': Ref('MockToscaFunction'),
            'Principal': 'apigateway.amazonaws.com',
            'SourceArn': Sub(
                'arn:${AWS::Partition}:execute-api:${AWS::Region}:'
                '${AWS::AccountId}:${MockHttpApi}/*'
            ),
        },
    }

    scenario_arn = Sub(
        'arn:${AWS::Partition}:ssm:${AWS::Region}:${AWS::AccountId}:'
        'parameter/${ProjectName}/demo/scenario'
    )
    resources.update(
        common_iam(
            'demo',
            False,
            [Ref('DemoAppianSecret')],
            Ref('DemoToscaSecret'),
            scenario_arn,
        )
    )
    resources['OrchestratorFunction'] = orchestrator_function(
        'demo',
        False,
        {
            'RESULTS_BUCKET': Ref('ResultsBucket'),
            'KMS_KEY_ARN': GetAtt('EncryptionKey', 'Arn'),
            'RELEASE_TABLE': Ref('ReleaseLedger'),
            'APPIAN_MODE': Ref('AppianIntegrationMode'),
            'APPIAN_TEST_SECRET_ARN': Ref('DemoAppianSecret'),
            'APPIAN_PROD_SECRET_ARN': Ref('DemoAppianSecret'),
            'TOSCA_SECRET_ARN': Ref('DemoToscaSecret'),
            'TOSCA_BASE_URL_OVERRIDE': Sub(
                'https://${MockHttpApi}.execute-api.${AWS::Region}.${AWS::URLSuffix}'
            ),
            'TOSCA_EXECUTION_API_PATH_OVERRIDE': '/api/Execution',
            'DEMO_SCENARIO_PARAMETER': Ref('DemoScenarioParameter'),
            'AI_DIAGNOSTICS_ENABLED': Ref('EnableAiDiagnostics'),
            'BEDROCK_MODEL_ID': Ref('BedrockModelId'),
            'NOTIFICATION_TOPIC_ARN': Ref('NotificationTopic'),
            'MAX_PACKAGE_SIZE_MB': Sub('${MaxPackageSizeMB}'),
            'TOSCA_MAX_POLLS': '6',
            'APPIAN_MAX_POLLS': '6',
            'LEDGER_TTL_SECONDS': '2592000',
        },
    )
    resources['ReleaseStateMachineLogGroup'] = log_group(
        Sub('/aws/vendedlogs/states/${ProjectName}-release'),
        14,
        'demo',
    )
    resources['ReleaseStateMachine'] = state_machine(
        'ReleaseStateMachine',
        'demo_release.asl.json',
        'release',
        'demo',
    )
    resources['Pipeline'] = codepipeline(
        [
            source_stage(),
            {
                'Name': 'ValidateDeployAndTest',
                'Actions': [
                    step_functions_action(
                        'OrchestrateRelease',
                        'ReleaseStateMachine',
                        'TEST',
                        ['SMOKE', 'REGRESSION', 'E2E'],
                        'demo',
                    )
                ],
            },
            {
                'Name': 'ClientApproval',
                'Actions': [{
                    'Name': 'ApproveProposition',
                    'ActionTypeId': {
                        'Category': 'Approval',
                        'Owner': 'AWS',
                        'Provider': 'Manual',
                        'Version': '1',
                    },
                    'RunOrder': 1,
                    'Configuration': {
                        'NotificationArn': Ref('NotificationTopic'),
                        'CustomData': (
                            'The demo quality gates passed. Review CodeBuild '
                            'test reports and encrypted S3 evidence, then approve '
                            'to complete the demonstration.'
                        ),
                    },
                }],
            },
        ],
        'demo',
    )
    resources.update(eventbridge_resources('demo'))
    resources.update(alarms(['ReleaseStateMachine']))

    template['Outputs'] = {
        'PipelineName': {'Value': Ref('Pipeline')},
        'SourceBucketName': {'Value': Ref('SourceBucket')},
        'SourceObjectKey': {'Value': Ref('SourceObjectKey')},
        'ResultsBucketName': {'Value': Ref('ResultsBucket')},
        'MockToscaBaseUrl': {
            'Value': Sub(
                'https://${MockHttpApi}.execute-api.${AWS::Region}.${AWS::URLSuffix}'
            )
        },
        'ScenarioParameterName': {'Value': Ref('DemoScenarioParameter')},
        'AppianSecretArn': {'Value': Ref('DemoAppianSecret')},
        'ToscaSecretArn': {'Value': Ref('DemoToscaSecret')},
        'UploadCommand': {
            'Value': Sub(
                'aws s3 cp application.zip s3://${SourceBucket}/${SourceObjectKey}'
            )
        },
        'SetRegressionFailureCommand': {
            'Value': Sub(
                'aws ssm put-parameter --name ${DemoScenarioParameter} '
                '--type String --overwrite --value REGRESSION_FAILURE'
            )
        },
    }
    return template


def production_template() -> Dict[str, Any]:
    parameters = common_parameters(True)
    parameters.update({
        'EvidenceRetentionDays': {
            'Type': 'Number',
            'Default': 2555,
            'MinValue': 365,
            'MaxValue': 3650,
            'Description': (
                'Retention for current and noncurrent release evidence. '
                'The default is approximately seven years.'
            ),
        },
        'TestAppianSecretArn': {
            'Type': 'String',
            'AllowedPattern': 'arn:.*:secretsmanager:.*',
            'Description': (
                'Existing Secrets Manager ARN for Appian TEST connection JSON.'
            ),
        },
        'ProdAppianSecretArn': {
            'Type': 'String',
            'AllowedPattern': 'arn:.*:secretsmanager:.*',
            'Description': (
                'Existing Secrets Manager ARN for Appian PROD connection JSON.'
            ),
        },
        'ToscaSecretArn': {
            'Type': 'String',
            'AllowedPattern': 'arn:.*:secretsmanager:.*',
            'Description': (
                'Existing Secrets Manager ARN for the real Tosca Execution API.'
            ),
        },
        'EnableVpc': {
            'Type': 'String',
            'Default': 'false',
            'AllowedValues': ['true', 'false'],
            'Description': (
                'Attach the orchestrator Lambda to client-provided subnets and '
                'security groups.'
            ),
        },
        'LambdaSubnetIds': {
            'Type': 'String',
            'Default': '',
            'Description': (
                'Comma-separated private subnet IDs; required when EnableVpc=true.'
            ),
        },
        'LambdaSecurityGroupIds': {
            'Type': 'String',
            'Default': '',
            'Description': (
                'Comma-separated security group IDs; required when EnableVpc=true.'
            ),
        },
        'PermissionsBoundaryArn': {
            'Type': 'String',
            'Default': '',
            'Description': (
                'Optional IAM permissions-boundary ARN applied to created roles.'
            ),
        },
    })

    template: Dict[str, Any] = {
        'AWSTemplateFormatVersion': '2010-09-09',
        'Description': (
            'Production reference: Appian TEST and PROD inspection/deployment, '
            'real Tosca smoke/regression/end-to-end quality gates, manual '
            'production approval, retained audit evidence, and AI diagnostics.'
        ),
        'Metadata': {
            'AWS::CloudFormation::Interface': {
                'ParameterGroups': [
                    {
                        'Label': {'default': 'Naming, source, and retention'},
                        'Parameters': [
                            'ProjectName',
                            'SourceObjectKey',
                            'EvidenceRetentionDays',
                        ],
                    },
                    {
                        'Label': {'default': 'External integrations'},
                        'Parameters': [
                            'TestAppianSecretArn',
                            'ProdAppianSecretArn',
                            'ToscaSecretArn',
                        ],
                    },
                    {
                        'Label': {'default': 'Networking'},
                        'Parameters': [
                            'EnableVpc',
                            'LambdaSubnetIds',
                            'LambdaSecurityGroupIds',
                        ],
                    },
                    {
                        'Label': {'default': 'Security and governance'},
                        'Parameters': [
                            'PermissionsBoundaryArn',
                            'NotificationEmail',
                        ],
                    },
                    {
                        'Label': {'default': 'Runtime and AI diagnostics'},
                        'Parameters': [
                            'PollIntervalSeconds',
                            'MaxPackageSizeMB',
                            'EnableAiDiagnostics',
                            'BedrockModelId',
                        ],
                    },
                ]
            }
        },
        'Parameters': parameters,
        'Rules': {
            'VpcSettingsRequiredWhenEnabled': {
                'RuleCondition': {
                    'Fn::Equals': [Ref('EnableVpc'), 'true']
                },
                'Assertions': [
                    {
                        'Assert': {
                            'Fn::Not': [{
                                'Fn::Equals': [Ref('LambdaSubnetIds'), '']
                            }]
                        },
                        'AssertDescription': (
                            'LambdaSubnetIds is required when EnableVpc=true.'
                        ),
                    },
                    {
                        'Assert': {
                            'Fn::Not': [{
                                'Fn::Equals': [
                                    Ref('LambdaSecurityGroupIds'),
                                    '',
                                ]
                            }]
                        },
                        'AssertDescription': (
                            'LambdaSecurityGroupIds is required when EnableVpc=true.'
                        ),
                    },
                ],
            }
        },
        'Conditions': {
            'HasNotificationEmail': {
                'Fn::Not': [{'Fn::Equals': [Ref('NotificationEmail'), '']}]
            },
            'UseVpc': {'Fn::Equals': [Ref('EnableVpc'), 'true']},
            'HasPermissionsBoundary': {
                'Fn::Not': [{
                    'Fn::Equals': [Ref('PermissionsBoundaryArn'), '']
                }]
            },
        },
        'Resources': {},
        'Outputs': {},
    }
    resources = template['Resources']
    resources.update(common_resources('production', True))
    resources.update(report_resources('production', True))
    resources.update(
        common_iam(
            'production',
            True,
            [Ref('TestAppianSecretArn'), Ref('ProdAppianSecretArn')],
            Ref('ToscaSecretArn'),
        )
    )
    resources['OrchestratorFunction'] = orchestrator_function(
        'production',
        True,
        {
            'RESULTS_BUCKET': Ref('ResultsBucket'),
            'KMS_KEY_ARN': GetAtt('EncryptionKey', 'Arn'),
            'RELEASE_TABLE': Ref('ReleaseLedger'),
            'APPIAN_MODE': 'REAL',
            'APPIAN_TEST_SECRET_ARN': Ref('TestAppianSecretArn'),
            'APPIAN_PROD_SECRET_ARN': Ref('ProdAppianSecretArn'),
            'TOSCA_SECRET_ARN': Ref('ToscaSecretArn'),
            'AI_DIAGNOSTICS_ENABLED': Ref('EnableAiDiagnostics'),
            'BEDROCK_MODEL_ID': Ref('BedrockModelId'),
            'NOTIFICATION_TOPIC_ARN': Ref('NotificationTopic'),
            'MAX_PACKAGE_SIZE_MB': Sub('${MaxPackageSizeMB}'),
            'TOSCA_MAX_POLLS': '240',
            'APPIAN_MAX_POLLS': '120',
            'LEDGER_TTL_SECONDS': '315360000',
        },
    )
    resources['PreProdStateMachineLogGroup'] = log_group(
        Sub('/aws/vendedlogs/states/${ProjectName}-preprod'),
        90,
        'production',
        retain=True,
    )
    resources['ProdStateMachineLogGroup'] = log_group(
        Sub('/aws/vendedlogs/states/${ProjectName}-production'),
        90,
        'production',
        retain=True,
    )
    resources['PreProdStateMachine'] = state_machine(
        'PreProdStateMachine',
        'production_preprod.asl.json',
        'preprod',
        'production',
    )
    resources['ProdStateMachine'] = state_machine(
        'ProdStateMachine',
        'production_prod.asl.json',
        'production',
        'production',
    )
    resources['Pipeline'] = codepipeline(
        [
            source_stage(),
            {
                'Name': 'PreProduction',
                'Actions': [
                    step_functions_action(
                        'InspectDeployAndTest',
                        'PreProdStateMachine',
                        'TEST',
                        ['SMOKE', 'REGRESSION', 'E2E'],
                        'preprod',
                    )
                ],
            },
            {
                'Name': 'ProductionApproval',
                'Actions': [{
                    'Name': 'ChangeApproval',
                    'ActionTypeId': {
                        'Category': 'Approval',
                        'Owner': 'AWS',
                        'Provider': 'Manual',
                        'Version': '1',
                    },
                    'RunOrder': 1,
                    'Configuration': {
                        'NotificationArn': Ref('NotificationTopic'),
                        'CustomData': (
                            'Review Appian inspection/import evidence, CodeBuild '
                            'JUnit reports, change record, rollback readiness, and '
                            'segregation-of-duties approval before production.'
                        ),
                    },
                }],
            },
            {
                'Name': 'Production',
                'Actions': [
                    step_functions_action(
                        'InspectDeployAndSmoke',
                        'ProdStateMachine',
                        'PROD',
                        ['SMOKE'],
                        'prod',
                    )
                ],
            },
        ],
        'production',
    )
    resources.update(eventbridge_resources('production'))
    resources.update(
        alarms(['PreProdStateMachine', 'ProdStateMachine'])
    )

    template['Outputs'] = {
        'PipelineName': {'Value': Ref('Pipeline')},
        'SourceBucketName': {'Value': Ref('SourceBucket')},
        'SourceObjectKey': {'Value': Ref('SourceObjectKey')},
        'ArtifactBucketName': {'Value': Ref('ArtifactBucket')},
        'ResultsBucketName': {'Value': Ref('ResultsBucket')},
        'PreProdStateMachineArn': {'Value': Ref('PreProdStateMachine')},
        'ProdStateMachineArn': {'Value': Ref('ProdStateMachine')},
        'NotificationTopicArn': {'Value': Ref('NotificationTopic')},
        'UploadCommand': {
            'Value': Sub(
                'aws s3 cp application.zip s3://${SourceBucket}/${SourceObjectKey}'
            )
        },
    }
    return template


def write_template(template: Dict[str, Any], path: Path) -> None:
    rendered = yaml.safe_dump(
        template,
        sort_keys=False,
        width=160,
        default_flow_style=False,
        allow_unicode=True,
    )
    path.write_text(rendered, encoding='utf-8')
    print(
        path.name,
        len(rendered),
        'bytes,',
        len(template['Resources']),
        'resources,',
        len(template['Parameters']),
        'parameters',
    )


if __name__ == '__main__':
    write_template(demo_template(), ROOT / 'appian-devops-demo.yaml')
    write_template(production_template(), ROOT / 'appian-devops-production.yaml')
