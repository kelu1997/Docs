from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, Set

import yaml

ROOT = Path('/mnt/data/appian_devops_guides')
PSEUDO = {
    'AWS::AccountId', 'AWS::NotificationARNs', 'AWS::NoValue', 'AWS::Partition',
    'AWS::Region', 'AWS::StackId', 'AWS::StackName', 'AWS::URLSuffix', 'AWS::Tenant',
}


def walk(value: Any) -> Iterable[Any]:
    yield value
    if isinstance(value, dict):
        for child in value.values():
            yield from walk(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk(child)


def validate_template(path: Path) -> None:
    template = yaml.safe_load(path.read_text(encoding='utf-8'))
    resources = set(template.get('Resources', {}))
    parameters = set(template.get('Parameters', {}))
    conditions = set(template.get('Conditions', {}))
    known = resources | parameters | PSEUDO
    errors = []

    if len(path.read_bytes()) > 1_000_000:
        errors.append('template exceeds 1 MB S3 template quota')
    if len(resources) > 500:
        errors.append('template exceeds 500-resource quota')
    if len(parameters) > 200:
        errors.append('template exceeds 200-parameter quota')

    for node in walk(template):
        if not isinstance(node, dict):
            continue
        if set(node) == {'Ref'}:
            target = node['Ref']
            if target not in known:
                errors.append(f'unresolved Ref: {target}')
        if set(node) == {'Fn::GetAtt'}:
            target = node['Fn::GetAtt'][0]
            if target not in resources:
                errors.append(f'unresolved GetAtt resource: {target}')
        if 'Condition' in node and len(node) >= 1 and isinstance(node['Condition'], str):
            # Resource-level/Output-level condition. Ignore IAM policy Condition objects.
            if node.get('Type', '').startswith('AWS::') or 'Value' in node:
                if node['Condition'] not in conditions:
                    errors.append(f'unresolved Condition: {node["Condition"]}')
        if 'DependsOn' in node and node.get('Type', '').startswith('AWS::'):
            values = node['DependsOn'] if isinstance(node['DependsOn'], list) else [node['DependsOn']]
            for target in values:
                if target not in resources:
                    errors.append(f'unresolved DependsOn: {target}')
        if set(node) == {'Fn::If'}:
            condition = node['Fn::If'][0]
            if condition not in conditions:
                errors.append(f'unresolved Fn::If condition: {condition}')
        if set(node) == {'Fn::Sub'}:
            sub = node['Fn::Sub']
            if isinstance(sub, list):
                text, mapping = sub
                mapped = set(mapping)
            else:
                text, mapped = sub, set()
            for variable in re.findall(r'\$\{([^}]+)\}', str(text)):
                logical = variable.split('.')[0]
                if logical not in known and variable not in mapped and logical not in mapped:
                    errors.append(f'unresolved Fn::Sub variable: {variable}')

    # Inline Lambda code compile check.
    for logical_id, resource in template['Resources'].items():
        if resource.get('Type') == 'AWS::Lambda::Function':
            code = resource.get('Properties', {}).get('Code', {}).get('ZipFile')
            if isinstance(code, str):
                try:
                    compile(code, f'{path.name}:{logical_id}', 'exec')
                except SyntaxError as exc:
                    errors.append(f'{logical_id} inline Python syntax: {exc}')

    if errors:
        print(f'{path.name}: FAILED')
        for error in sorted(set(errors)):
            print('  -', error)
        raise SystemExit(1)
    print(f'{path.name}: structural validation passed ({len(resources)} resources, {path.stat().st_size} bytes)')


def state_targets(state: Dict[str, Any]) -> Set[str]:
    targets: Set[str] = set()
    if 'Next' in state:
        targets.add(state['Next'])
    for catcher in state.get('Catch', []):
        targets.add(catcher['Next'])
    if state.get('Type') == 'Choice':
        for choice in state.get('Choices', []):
            targets.add(choice['Next'])
        if state.get('Default'):
            targets.add(state['Default'])
    return targets


def validate_machine(machine: Dict[str, Any], label: str) -> None:
    states = machine.get('States', {})
    errors = []
    if machine.get('StartAt') not in states:
        errors.append(f'StartAt {machine.get("StartAt")} is missing')
    for name, state in states.items():
        for target in state_targets(state):
            if target not in states:
                errors.append(f'{name} targets missing state {target}')
        if state.get('Type') == 'Parallel':
            for index, branch in enumerate(state.get('Branches', [])):
                try:
                    validate_machine(branch, f'{label}:{name}:branch{index}')
                except AssertionError as exc:
                    errors.append(str(exc))
        terminal = state.get('End') or state.get('Type') in {'Succeed', 'Fail'}
        has_transition = bool(state_targets(state)) or state.get('Type') == 'Choice'
        if not terminal and not has_transition and state.get('Type') != 'Parallel':
            errors.append(f'{name} has no terminal marker or transition')
    if errors:
        raise AssertionError(label + ': ' + '; '.join(errors))


def validate_asl(path: Path) -> None:
    machine = json.loads(path.read_text(encoding='utf-8'))
    validate_machine(machine, path.name)
    print(f'{path.name}: ASL graph validation passed ({len(machine["States"])} top-level states)')


for template_path in [
    ROOT / 'appian-devops-demo.yaml',
    ROOT / 'appian-devops-production.yaml',
]:
    validate_template(template_path)

for asl_path in sorted((ROOT / 'src').glob('*.asl.json')):
    validate_asl(asl_path)

print('All local structural, reference, inline-Python, and ASL checks passed.')
