import importlib.util
import os
import sys
from unittest.mock import MagicMock

os.environ.update({
    "TABLE_NAME": "t",
    "PIPELINE_NAME": "DemoPipeline",
    "ROUTING_PARAMETER_NAME": "/routing",
})

fake_boto3 = MagicMock()
fake_boto3.resource.return_value.Table.return_value = MagicMock()
sys.modules["boto3"] = fake_boto3

spec = importlib.util.spec_from_file_location(
    "router", os.path.join(os.path.dirname(__file__), "..", "integration-router", "lambda_function.py")
)
router = importlib.util.module_from_spec(spec)
spec.loader.exec_module(router)


def test_normalize_stage_event():
    event = {
        "id": "evt-1",
        "time": "2026-09-03T12:00:00Z",
        "detail-type": "CodePipeline Stage Execution State Change",
        "detail": {
            "pipeline": "DemoPipeline",
            "execution-id": "exec-1",
            "stage": "SAST",
            "state": "SUCCEEDED",
        },
    }
    item = router.normalize_event(event)
    assert item["level"] == "STAGE"
    assert item["stageName"] == "SAST"
    assert item["state"] == "SUCCEEDED"


def test_rule_matching_wildcard_stage():
    item = {
        "level": "STAGE",
        "state": "FAILED",
        "stageName": "CentralQualityGate",
        "actionName": None,
    }
    rule = {
        "levels": ["STAGE"],
        "states": ["SUCCEEDED", "FAILED"],
        "stages": ["*"],
        "actions": ["*"],
    }
    assert router.rule_matches(rule, item)
