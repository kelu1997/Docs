import importlib.util
import os
import sys
from unittest.mock import MagicMock

os.environ.update({
    "TABLE_NAME": "t",
    "PIPELINE_NAME": "DemoPipeline",
    "ALLOWED_ORIGIN": "*",
})

fake_boto3 = MagicMock()
fake_boto3.resource.return_value.Table.return_value = MagicMock()
sys.modules["boto3"] = fake_boto3

conditions = MagicMock()
conditions.Key = MagicMock()
sys.modules["boto3.dynamodb"] = MagicMock()
sys.modules["boto3.dynamodb.conditions"] = conditions

spec = importlib.util.spec_from_file_location(
    "dashboard", os.path.join(os.path.dirname(__file__), "..", "dashboard-api", "lambda_function.py")
)
dashboard = importlib.util.module_from_spec(spec)
spec.loader.exec_module(dashboard)


def test_derive_stage_status():
    assert dashboard.derive_stage_status([]) == "NOT_STARTED"
    assert dashboard.derive_stage_status([{"status": "SUCCEEDED"}]) == "SUCCEEDED"
    assert dashboard.derive_stage_status([{"status": "FAILED"}]) == "FAILED"
    assert dashboard.derive_stage_status(
        [{"status": "SUCCEEDED"}, {"status": "IN_PROGRESS"}]
    ) == "IN_PROGRESS"
