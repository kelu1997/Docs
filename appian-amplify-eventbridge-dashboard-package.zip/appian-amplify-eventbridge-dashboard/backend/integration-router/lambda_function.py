import base64
import json
import logging
import os
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from decimal import Decimal

import boto3
from botocore.exceptions import ClientError

LOG = logging.getLogger()
LOG.setLevel(os.getenv("LOG_LEVEL", "INFO").upper())

TABLE_NAME = os.environ["TABLE_NAME"]
PIPELINE_NAME = os.environ["PIPELINE_NAME"]
ROUTING_PARAMETER_NAME = os.environ["ROUTING_PARAMETER_NAME"]
SERVICENOW_SECRET_ARN = os.getenv("SERVICENOW_SECRET_ARN", "")
JIRA_SECRET_ARN = os.getenv("JIRA_SECRET_ARN", "")
HTTP_TIMEOUT_SECONDS = int(os.getenv("HTTP_TIMEOUT_SECONDS", "10"))
EVENT_TTL_DAYS = int(os.getenv("EVENT_TTL_DAYS", "30"))

ddb = boto3.resource("dynamodb")
table = ddb.Table(TABLE_NAME)
ssm = boto3.client("ssm")
secrets = boto3.client("secretsmanager")

_ROUTING_CACHE = {"expires": 0, "value": None}
_SECRET_CACHE = {}


def utc_epoch() -> int:
    return int(time.time())


def ttl_epoch() -> int:
    return utc_epoch() + EVENT_TTL_DAYS * 86400


def json_default(value):
    if isinstance(value, Decimal):
        return int(value) if value % 1 == 0 else float(value)
    if isinstance(value, (datetime,)):
        return value.isoformat()
    raise TypeError(f"Unsupported type: {type(value).__name__}")


def load_routing_config():
    now = utc_epoch()
    if _ROUTING_CACHE["value"] is not None and _ROUTING_CACHE["expires"] > now:
        return _ROUTING_CACHE["value"]

    response = ssm.get_parameter(Name=ROUTING_PARAMETER_NAME)
    config = json.loads(response["Parameter"]["Value"])
    _ROUTING_CACHE["value"] = config
    _ROUTING_CACHE["expires"] = now + 60
    return config


def load_secret(arn):
    if not arn:
        raise ValueError("Secret ARN is not configured.")
    if arn in _SECRET_CACHE:
        return _SECRET_CACHE[arn]
    response = secrets.get_secret_value(SecretId=arn)
    secret = json.loads(response["SecretString"])
    _SECRET_CACHE[arn] = secret
    return secret


def normalized_level(detail_type: str) -> str:
    if "Action Execution" in detail_type:
        return "ACTION"
    if "Stage Execution" in detail_type:
        return "STAGE"
    return "PIPELINE"


def normalize_event(event):
    detail = event.get("detail") or {}
    detail_type = event.get("detail-type", "Unknown")
    level = normalized_level(detail_type)

    return {
        "eventId": event.get("id", "unknown"),
        "eventTime": event.get("time", datetime.now(timezone.utc).isoformat()),
        "detailType": detail_type,
        "pipelineName": detail.get("pipeline", PIPELINE_NAME),
        "executionId": detail.get("execution-id", "unknown"),
        "state": str(detail.get("state", "UNKNOWN")).upper(),
        "level": level,
        "stageName": detail.get("stage"),
        "actionName": detail.get("action"),
        "region": event.get("region"),
        "account": event.get("account"),
    }


def store_pipeline_event(item):
    table.put_item(
        Item={
            "executionId": item["executionId"],
            "eventKey": f"EVENT#{item['eventTime']}#{item['eventId']}",
            "itemType": "PIPELINE_EVENT",
            **item,
            "ttl": ttl_epoch(),
        }
    )


def wildcard_matches(value, allowed):
    if not allowed or "*" in allowed:
        return True
    return value in allowed


def rule_matches(rule, item):
    levels = [str(x).upper() for x in rule.get("levels", ["*"])]
    states = [str(x).upper() for x in rule.get("states", ["*"])]
    stages = rule.get("stages", ["*"])
    actions = rule.get("actions", ["*"])

    return (
        wildcard_matches(item["level"], levels)
        and wildcard_matches(item["state"], states)
        and wildcard_matches(item.get("stageName"), stages)
        and wildcard_matches(item.get("actionName"), actions)
    )


def should_route(integration_cfg, item):
    if not integration_cfg.get("enabled", False):
        return False
    return any(rule_matches(rule, item) for rule in integration_cfg.get("rules", []))


def integration_key(name, event_id):
    return f"INTEGRATION#{name.upper()}#{event_id}"


def existing_success(execution_id, key):
    response = table.get_item(
        Key={"executionId": execution_id, "eventKey": key},
        ConsistentRead=True,
    )
    return (response.get("Item") or {}).get("integrationStatus") == "SUCCEEDED"


def write_integration_result(item, integration, status, detail, external_ref=None):
    key = integration_key(integration, item["eventId"])
    table.put_item(
        Item={
            "executionId": item["executionId"],
            "eventKey": key,
            "itemType": "INTEGRATION_RESULT",
            "pipelineName": item["pipelineName"],
            "eventId": item["eventId"],
            "eventTime": item["eventTime"],
            "detailType": item["detailType"],
            "level": item["level"],
            "stageName": item.get("stageName"),
            "actionName": item.get("actionName"),
            "pipelineState": item["state"],
            "integration": integration,
            "integrationStatus": status,
            "detail": detail[:2000],
            "externalReference": external_ref or "",
            "updatedAt": datetime.now(timezone.utc).isoformat(),
            "ttl": ttl_epoch(),
        }
    )


def message_for(item):
    subject = item["pipelineName"]
    if item["level"] == "STAGE":
        subject += f" / {item.get('stageName') or 'unknown-stage'}"
    elif item["level"] == "ACTION":
        subject += (
            f" / {item.get('stageName') or 'unknown-stage'}"
            f" / {item.get('actionName') or 'unknown-action'}"
        )
    return (
        f"{subject} is {item['state']} "
        f"(execution {item['executionId']}, event {item['eventId']})."
    )


def http_json(url, method="POST", headers=None, body=None):
    data = None if body is None else json.dumps(body).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json", **(headers or {})},
        method=method,
    )
    try:
        with urllib.request.urlopen(request, timeout=HTTP_TIMEOUT_SECONDS) as response:
            raw = response.read().decode("utf-8", errors="replace")
            parsed = json.loads(raw) if raw.strip() else {}
            return response.status, parsed
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code}: {raw[:1000]}") from exc


def call_servicenow(item, cfg):
    mode = str(cfg.get("mode", "MOCK")).upper()
    if mode == "MOCK":
        return f"MOCK-SNOW-{item['eventId'][:8]}", "Mock ServiceNow update recorded."

    secret = load_secret(SERVICENOW_SECRET_ARN)
    base_url = secret["baseUrl"].rstrip("/")
    table_name = secret.get("table", "change_request")
    record_sys_id = secret["recordSysId"]
    message_field = secret.get("messageField", "work_notes")
    username = secret["username"]
    password = secret["password"]
    auth = base64.b64encode(f"{username}:{password}".encode()).decode()

    status, body = http_json(
        f"{base_url}/api/now/table/{table_name}/{record_sys_id}",
        method="PATCH",
        headers={
            "Authorization": f"Basic {auth}",
            "Accept": "application/json",
        },
        body={message_field: message_for(item)},
    )
    result = body.get("result", {}) if isinstance(body, dict) else {}
    return str(result.get("sys_id", record_sys_id)), f"ServiceNow HTTP {status}"


def jira_doc(text):
    return {
        "body": {
            "type": "doc",
            "version": 1,
            "content": [
                {
                    "type": "paragraph",
                    "content": [{"type": "text", "text": text}],
                }
            ],
        }
    }


def call_jira(item, cfg):
    mode = str(cfg.get("mode", "MOCK")).upper()
    if mode == "MOCK":
        return f"MOCK-JIRA-{item['eventId'][:8]}", "Mock Jira update recorded."

    secret = load_secret(JIRA_SECRET_ARN)
    base_url = secret["baseUrl"].rstrip("/")
    issue_key = secret["issueKey"]
    email = secret["email"]
    api_token = secret["apiToken"]
    auth = base64.b64encode(f"{email}:{api_token}".encode()).decode()

    status, body = http_json(
        f"{base_url}/rest/api/3/issue/{issue_key}/comment",
        method="POST",
        headers={
            "Authorization": f"Basic {auth}",
            "Accept": "application/json",
        },
        body=jira_doc(message_for(item)),
    )
    external_ref = str(body.get("id", issue_key)) if isinstance(body, dict) else issue_key
    return external_ref, f"Jira HTTP {status}"


def invoke_integration(name, item, cfg):
    key = integration_key(name, item["eventId"])
    if existing_success(item["executionId"], key):
        LOG.info("Skipping duplicate successful %s update for event %s", name, item["eventId"])
        return

    try:
        if name == "serviceNow":
            external_ref, detail = call_servicenow(item, cfg)
        elif name == "jira":
            external_ref, detail = call_jira(item, cfg)
        else:
            raise ValueError(f"Unsupported integration: {name}")

        write_integration_result(item, name, "SUCCEEDED", detail, external_ref)
    except Exception as exc:
        write_integration_result(item, name, "FAILED", str(exc))
        raise


def lambda_handler(event, context):
    item = normalize_event(event)

    # Ignore events for other pipelines even if the EventBridge rule is later broadened.
    if item["pipelineName"] != PIPELINE_NAME:
        return {"ignored": True, "reason": "different-pipeline"}

    store_pipeline_event(item)
    config = load_routing_config()

    routed = []
    errors = []

    for integration_name in ("serviceNow", "jira"):
        cfg = config.get(integration_name, {})
        if not should_route(cfg, item):
            continue

        try:
            invoke_integration(integration_name, item, cfg)
            routed.append(integration_name)
        except Exception as exc:
            errors.append(f"{integration_name}: {exc}")

    if errors:
        # Raising causes EventBridge to retry the invocation. Successful integrations are
        # idempotently skipped on retries because their SUCCEEDED record already exists.
        raise RuntimeError("; ".join(errors))

    return {
        "processed": True,
        "executionId": item["executionId"],
        "eventId": item["eventId"],
        "routedIntegrations": routed,
    }
