import json
import os
from datetime import datetime
from decimal import Decimal

import boto3
from boto3.dynamodb.conditions import Key

PIPELINE_NAME = os.environ["PIPELINE_NAME"]
TABLE_NAME = os.environ["TABLE_NAME"]
ALLOWED_ORIGIN = os.getenv("ALLOWED_ORIGIN", "*")

codepipeline = boto3.client("codepipeline")
ddb = boto3.resource("dynamodb")
table = ddb.Table(TABLE_NAME)


def json_default(value):
    if isinstance(value, Decimal):
        return int(value) if value % 1 == 0 else float(value)
    if isinstance(value, datetime):
        return value.isoformat()
    raise TypeError(f"Unsupported JSON type: {type(value).__name__}")


def response(status_code, body):
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
            "Cache-Control": "no-store",
        },
        "body": json.dumps(body, default=json_default),
    }


def list_all_action_executions(execution_id):
    items = []
    kwargs = {
        "pipelineName": PIPELINE_NAME,
        "filter": {"pipelineExecutionId": execution_id},
        "maxResults": 100,
    }
    while True:
        result = codepipeline.list_action_executions(**kwargs)
        items.extend(result.get("actionExecutionDetails", []))
        token = result.get("nextToken")
        if not token:
            break
        kwargs["nextToken"] = token
    return items


def pipeline_definition():
    result = codepipeline.get_pipeline(name=PIPELINE_NAME)
    pipeline = result["pipeline"]
    stages = []
    for stage_index, stage in enumerate(pipeline.get("stages", [])):
        actions = []
        for action in sorted(
            stage.get("actions", []),
            key=lambda a: (a.get("runOrder", 1), a.get("name", "")),
        ):
            type_id = action.get("actionTypeId", {})
            actions.append(
                {
                    "name": action["name"],
                    "runOrder": action.get("runOrder", 1),
                    "category": type_id.get("category", "Unknown"),
                    "provider": type_id.get("provider", "Unknown"),
                    "namespace": action.get("namespace"),
                    "region": action.get("region"),
                }
            )
        stages.append({"name": stage["name"], "order": stage_index + 1, "actions": actions})
    return {"name": pipeline["name"], "version": pipeline.get("version"), "stages": stages}


def action_status(raw):
    status = raw or "NOT_STARTED"
    mapping = {
        "InProgress": "IN_PROGRESS",
        "Succeeded": "SUCCEEDED",
        "Failed": "FAILED",
        "Abandoned": "ABANDONED",
    }
    return mapping.get(status, str(status).upper())


def derive_stage_status(actions):
    statuses = [action["status"] for action in actions]
    if not statuses or all(s == "NOT_STARTED" for s in statuses):
        return "NOT_STARTED"
    if any(s in {"FAILED", "ABANDONED"} for s in statuses):
        return "FAILED"
    if any(s == "IN_PROGRESS" for s in statuses):
        return "IN_PROGRESS"
    if all(s == "SUCCEEDED" for s in statuses):
        return "SUCCEEDED"
    if any(s == "SUCCEEDED" for s in statuses):
        return "IN_PROGRESS"
    return "NOT_STARTED"


def execution_integrations(execution_id):
    result = table.query(
        KeyConditionExpression=Key("executionId").eq(execution_id)
    )
    items = result.get("Items", [])
    integrations = [
        item
        for item in items
        if item.get("itemType") == "INTEGRATION_RESULT"
    ]
    events = [
        item
        for item in items
        if item.get("itemType") == "PIPELINE_EVENT"
    ]
    integrations.sort(key=lambda x: x.get("updatedAt", x.get("eventTime", "")), reverse=True)
    events.sort(key=lambda x: x.get("eventTime", ""), reverse=True)
    return integrations, events


def build_execution_detail(execution_id):
    definition = pipeline_definition()
    execution_result = codepipeline.get_pipeline_execution(
        pipelineName=PIPELINE_NAME,
        pipelineExecutionId=execution_id,
    )["pipelineExecution"]

    raw_actions = list_all_action_executions(execution_id)
    by_key = {
        (item.get("stageName"), item.get("actionName")): item
        for item in raw_actions
    }

    stages = []
    for stage in definition["stages"]:
        actions = []
        for declared in stage["actions"]:
            raw = by_key.get((stage["name"], declared["name"]), {})
            output = raw.get("output", {}) or {}
            execution_result_detail = output.get("executionResult", {}) or {}
            error = execution_result_detail.get("errorDetails", {}) or {}
            actions.append(
                {
                    **declared,
                    "status": action_status(raw.get("status")),
                    "startTime": raw.get("startTime"),
                    "lastUpdateTime": raw.get("lastUpdateTime"),
                    "outputVariables": output.get("outputVariables", {}) or {},
                    "externalExecutionUrl": execution_result_detail.get("externalExecutionUrl"),
                    "externalExecutionSummary": execution_result_detail.get("externalExecutionSummary"),
                    "errorCode": error.get("code"),
                    "errorMessage": error.get("message"),
                }
            )

        stages.append(
            {
                "name": stage["name"],
                "order": stage["order"],
                "status": derive_stage_status(actions),
                "actions": actions,
            }
        )

    integrations, events = execution_integrations(execution_id)

    source_revisions = execution_result.get("artifactRevisions", []) or []
    trigger = execution_result.get("trigger", {}) or {}

    return {
        "pipeline": {
            "name": definition["name"],
            "version": execution_result.get("pipelineVersion", definition.get("version")),
        },
        "execution": {
            "id": execution_id,
            "status": str(execution_result.get("status", "UNKNOWN")).upper(),
            "startTime": execution_result.get("startTime"),
            "lastUpdateTime": execution_result.get("lastUpdateTime"),
            "trigger": trigger,
            "sourceRevisions": source_revisions,
        },
        "stages": stages,
        "integrations": integrations,
        "events": events[:100],
    }


def list_executions(limit):
    limit = max(1, min(int(limit or 10), 50))
    result = codepipeline.list_pipeline_executions(
        pipelineName=PIPELINE_NAME,
        maxResults=limit,
    )
    items = []
    for item in result.get("pipelineExecutionSummaries", []):
        items.append(
            {
                "id": item.get("pipelineExecutionId"),
                "status": str(item.get("status", "UNKNOWN")).upper(),
                "startTime": item.get("startTime"),
                "lastUpdateTime": item.get("lastUpdateTime"),
                "trigger": item.get("trigger", {}),
                "sourceRevisions": item.get("sourceRevisions", []),
            }
        )
    return {"pipelineName": PIPELINE_NAME, "executions": items}


def lambda_handler(event, context):
    request_context = event.get("requestContext", {})
    http = request_context.get("http", {})
    method = http.get("method", "GET").upper()
    path = http.get("path") or event.get("rawPath", "/")

    if method == "OPTIONS":
        return response(204, {})

    if method != "GET":
        return response(405, {"message": "Method not allowed"})

    if path == "/health":
        return response(
            200,
            {
                "status": "ok",
                "pipelineName": PIPELINE_NAME,
                "tableName": TABLE_NAME,
            },
        )

    if path == "/executions":
        params = event.get("queryStringParameters") or {}
        try:
            return response(200, list_executions(params.get("limit", 10)))
        except Exception as exc:
            return response(500, {"message": str(exc)})

    prefix = "/executions/"
    if path.startswith(prefix):
        execution_id = path[len(prefix):].strip("/")
        if not execution_id:
            return response(400, {"message": "Execution id is required"})
        try:
            return response(200, build_execution_detail(execution_id))
        except codepipeline.exceptions.PipelineExecutionNotFoundException:
            return response(404, {"message": "Pipeline execution not found"})
        except Exception as exc:
            return response(500, {"message": str(exc)})

    return response(404, {"message": "Not found"})
