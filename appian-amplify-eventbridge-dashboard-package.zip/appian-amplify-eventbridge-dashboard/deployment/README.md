# Deployment artifacts

Run:

```bash
../scripts/zip_lambdas.sh
```

to create:
- `integration-router.zip`
- `dashboard-api.zip`

Run:

```bash
../scripts/build_frontend.sh https://YOUR_API_URL
```

to create:
- `amplify-dashboard.zip`
