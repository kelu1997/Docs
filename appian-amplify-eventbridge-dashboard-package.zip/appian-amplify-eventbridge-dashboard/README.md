# Appian DevOps Event-Driven Dashboard Package

This package adds a **non-blocking integration and visibility layer** around the existing CodePipeline:

```text
Source -> SAST -> ValidateAndTest -> CentralQualityGate -> future stages...
   |         |             |                 |
   +---------+-------------+-----------------+---- CodePipeline state-change events
                                                   |
                                              EventBridge
                                                   |
                                       Integration Router Lambda
                                          |                  |
                                    ServiceNow           Jira
                                    (MOCK now)         (MOCK now)
                                          \                  /
                                           \                /
                                            DynamoDB events
                                                  |
                                      Dashboard API Lambda
                                                  |
                                             API Gateway
                                                  |
                                    Amplify Hosting + Cloudscape
```

## Design principles

- **Non-blocking by default.** ServiceNow/Jira synchronization does not sit in the CodePipeline critical path.
- **Adaptive.** The dashboard queries the live CodePipeline definition and action history; new stages/actions appear automatically.
- **Event-driven.** EventBridge sees pipeline, stage, and action state changes.
- **Mock-safe.** ServiceNow and Jira default to MOCK mode. No external credentials are required.
- **Replaceable.** Routing rules live in Systems Manager Parameter Store, so you can later choose stage-level, action-level, or pipeline-level updates without changing the dashboard.
- **Observable.** Integration attempts are recorded in DynamoDB and surfaced in the dashboard.
- **Resilient.** EventBridge delivery failures go to one SQS DLQ; Lambda asynchronous processing retries function errors and sends exhausted failures to a second SQS queue.

## Start here

1. Read `docs/01_ARCHITECTURE.md`.
2. Follow `docs/02_CONSOLE_IMPLEMENTATION.md` for your existing console-built pipeline.
3. Run the scenarios in `docs/03_DEMO_RUNBOOK.md`.
4. Use `docs/04_ROUTING_AND_NEW_STAGES.md` when adding SNOW/Jira updates or new pipeline stages.
5. Use `docs/05_REAL_INTEGRATIONS_LATER.md` when credentials/endpoints become available.

## Main deliverables

- `backend/integration-router/lambda_function.py`
- `backend/dashboard-api/lambda_function.py`
- `backend/routing-config.example.json`
- `frontend/` — React + Vite + Cloudscape dashboard
- `infrastructure/template.yaml` — optional AWS SAM deployment
- `infrastructure/event-pattern.json`
- `deployment/integration-router.zip`
- `deployment/dashboard-api.zip`
- `deployment/amplify-dashboard.zip` — generated after building the frontend
- `docs/architecture-concept.png`

The package deliberately does **not** modify the existing Source/SAST/ValidateAndTest/CentralQualityGate stages.
