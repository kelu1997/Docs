import { sampleDetail, sampleExecutions } from "./sampleData";

let runtimeConfig;

export async function loadRuntimeConfig() {
  if (runtimeConfig) return runtimeConfig;
  try {
    const response = await fetch("/runtime-config.json", { cache: "no-store" });
    if (!response.ok) throw new Error(`Runtime config HTTP ${response.status}`);
    runtimeConfig = await response.json();
  } catch {
    runtimeConfig = {
      apiBaseUrl: "",
      refreshSeconds: 15,
      demoModeWhenApiMissing: true,
      title: "Appian DevOps Pipeline"
    };
  }
  return runtimeConfig;
}

function apiUrl(config, path) {
  const base = (config.apiBaseUrl || "").replace(/\/$/, "");
  return `${base}${path}`;
}

async function fetchJson(url) {
  const response = await fetch(url, { cache: "no-store" });
  if (!response.ok) {
    let message = `HTTP ${response.status}`;
    try {
      const body = await response.json();
      message = body.message || message;
    } catch {
      // keep default
    }
    throw new Error(message);
  }
  return response.json();
}

export async function listExecutions(config) {
  if (!config.apiBaseUrl && config.demoModeWhenApiMissing) {
    return structuredClone(sampleExecutions);
  }
  return fetchJson(apiUrl(config, "/executions?limit=20"));
}

export async function getExecution(config, executionId) {
  if (!config.apiBaseUrl && config.demoModeWhenApiMissing) {
    const cloned = structuredClone(sampleDetail);
    cloned.execution.id = executionId || cloned.execution.id;
    return cloned;
  }
  return fetchJson(apiUrl(config, `/executions/${encodeURIComponent(executionId)}`));
}
