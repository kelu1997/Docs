import { useCallback, useEffect, useMemo, useState } from "react";
import AppLayout from "@cloudscape-design/components/app-layout";
import Alert from "@cloudscape-design/components/alert";
import Box from "@cloudscape-design/components/box";
import Button from "@cloudscape-design/components/button";
import ColumnLayout from "@cloudscape-design/components/column-layout";
import Container from "@cloudscape-design/components/container";
import Header from "@cloudscape-design/components/header";
import Select from "@cloudscape-design/components/select";
import SpaceBetween from "@cloudscape-design/components/space-between";
import Spinner from "@cloudscape-design/components/spinner";
import TopNavigation from "@cloudscape-design/components/top-navigation";

import { getExecution, listExecutions, loadRuntimeConfig } from "./api";
import ActionTable from "./components/ActionTable";
import IntegrationTable from "./components/IntegrationTable";
import StageRail from "./components/StageRail";
import Status from "./components/Status";

function formatTime(value) {
  if (!value) return "—";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleString();
}

function duration(start, end) {
  if (!start) return "—";
  const startMs = new Date(start).getTime();
  const endMs = end ? new Date(end).getTime() : Date.now();
  if (!Number.isFinite(startMs) || !Number.isFinite(endMs)) return "—";
  const seconds = Math.max(0, Math.round((endMs - startMs) / 1000));
  if (seconds < 60) return `${seconds}s`;
  const minutes = Math.floor(seconds / 60);
  const remaining = seconds % 60;
  return `${minutes}m ${remaining}s`;
}

function executionLabel(execution) {
  const shortId = execution.id?.slice(0, 8) || "unknown";
  return `${shortId} · ${execution.status} · ${formatTime(execution.startTime)}`;
}

export default function App() {
  const [config, setConfig] = useState(null);
  const [executions, setExecutions] = useState([]);
  const [selectedExecutionId, setSelectedExecutionId] = useState("");
  const [detail, setDetail] = useState(null);
  const [selectedStage, setSelectedStage] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [lastRefresh, setLastRefresh] = useState(null);

  const load = useCallback(async (preferredExecutionId) => {
    try {
      setError("");
      const loadedConfig = config || (await loadRuntimeConfig());
      if (!config) setConfig(loadedConfig);

      const executionList = await listExecutions(loadedConfig);
      const list = executionList.executions || [];
      setExecutions(list);

      const targetId =
        preferredExecutionId ||
        selectedExecutionId ||
        list[0]?.id ||
        "";

      if (targetId) {
        const executionDetail = await getExecution(loadedConfig, targetId);
        setSelectedExecutionId(targetId);
        setDetail(executionDetail);
        setSelectedStage(current =>
          executionDetail.stages.some(stage => stage.name === current)
            ? current
            : executionDetail.stages[0]?.name || ""
        );
      }
      setLastRefresh(new Date());
    } catch (err) {
      setError(err.message || String(err));
    } finally {
      setLoading(false);
    }
  }, [config, selectedExecutionId]);

  useEffect(() => {
    load();
  }, []); // initial load only

  useEffect(() => {
    if (!config) return undefined;
    const seconds = Math.max(5, Number(config.refreshSeconds || 15));
    const timer = window.setInterval(() => load(selectedExecutionId), seconds * 1000);
    return () => window.clearInterval(timer);
  }, [config, load, selectedExecutionId]);

  const selectedStageData = useMemo(
    () => detail?.stages?.find(stage => stage.name === selectedStage),
    [detail, selectedStage]
  );

  const summary = useMemo(() => {
    const stages = detail?.stages || [];
    return {
      total: stages.length,
      succeeded: stages.filter(stage => stage.status === "SUCCEEDED").length,
      failed: stages.filter(stage => stage.status === "FAILED").length,
      integrations: detail?.integrations?.length || 0
    };
  }, [detail]);

  const executionOptions = executions.map(item => ({
    value: item.id,
    label: executionLabel(item)
  }));

  return (
    <>
      <TopNavigation
        identity={{
          href: "#",
          title: config?.title || "Appian DevOps Pipeline",
          logo: { src: "/pipeline-mark.svg", alt: "Pipeline dashboard" }
        }}
        utilities={[
          {
            type: "button",
            text: lastRefresh ? `Updated ${lastRefresh.toLocaleTimeString()}` : "Not refreshed",
            iconName: "refresh",
            onClick: () => load(selectedExecutionId)
          }
        ]}
      />
      <AppLayout
        navigationHide
        toolsHide
        content={
          <SpaceBetween size="l">
            <Header
              variant="h1"
              description="Adaptive CodePipeline status, quality signals, and non-blocking ServiceNow/Jira synchronization."
              actions={
                <Button iconName="refresh" onClick={() => load(selectedExecutionId)}>
                  Refresh
                </Button>
              }
            >
              Delivery overview
            </Header>

            {error && (
              <Alert type="error" header="Dashboard data could not be refreshed">
                {error}
              </Alert>
            )}

            <Container>
              <SpaceBetween size="m">
                <div className="execution-row">
                  <div>
                    <Box variant="awsui-key-label">Pipeline execution</Box>
                    <Select
                      selectedOption={
                        executionOptions.find(option => option.value === selectedExecutionId) || null
                      }
                      onChange={({ detail: change }) => {
                        const id = change.selectedOption?.value || "";
                        setSelectedExecutionId(id);
                        setLoading(true);
                        load(id);
                      }}
                      options={executionOptions}
                      placeholder="Choose an execution"
                      empty="No pipeline executions found"
                    />
                  </div>
                  <div className="execution-meta">
                    <Box variant="awsui-key-label">Overall</Box>
                    {loading && !detail ? <Spinner /> : <Status value={detail?.execution?.status} />}
                  </div>
                  <div className="execution-meta">
                    <Box variant="awsui-key-label">Started</Box>
                    <Box>{formatTime(detail?.execution?.startTime)}</Box>
                  </div>
                  <div className="execution-meta">
                    <Box variant="awsui-key-label">Duration</Box>
                    <Box>{duration(detail?.execution?.startTime, detail?.execution?.lastUpdateTime)}</Box>
                  </div>
                </div>
              </SpaceBetween>
            </Container>

            <ColumnLayout columns={4} variant="text-grid">
              <div>
                <Box variant="awsui-key-label">Stages</Box>
                <Box fontSize="display-l" fontWeight="bold">{summary.total}</Box>
              </div>
              <div>
                <Box variant="awsui-key-label">Succeeded</Box>
                <Box fontSize="display-l" fontWeight="bold">{summary.succeeded}</Box>
              </div>
              <div>
                <Box variant="awsui-key-label">Failed</Box>
                <Box fontSize="display-l" fontWeight="bold">{summary.failed}</Box>
              </div>
              <div>
                <Box variant="awsui-key-label">External updates</Box>
                <Box fontSize="display-l" fontWeight="bold">{summary.integrations}</Box>
              </div>
            </ColumnLayout>

            <Container
              header={
                <Header
                  variant="h2"
                  description="Generated from the current CodePipeline definition and execution data."
                >
                  Pipeline stages
                </Header>
              }
            >
              {loading && !detail ? (
                <Box textAlign="center" padding="xl"><Spinner size="large" /></Box>
              ) : (
                <StageRail
                  stages={detail?.stages || []}
                  selectedStage={selectedStage}
                  onSelectStage={setSelectedStage}
                />
              )}
            </Container>

            <Container
              header={
                <Header
                  variant="h2"
                  description={selectedStageData ? `Actions inside ${selectedStageData.name}` : undefined}
                >
                  Stage detail
                </Header>
              }
            >
              <ActionTable stage={selectedStageData} />
            </Container>

            <Container
              header={
                <Header
                  variant="h2"
                  description="Asynchronous EventBridge-driven updates; failures here do not block CodePipeline."
                >
                  ServiceNow / Jira activity
                </Header>
              }
            >
              <IntegrationTable integrations={detail?.integrations || []} />
            </Container>

            <div className="footer-note">
              <Box color="text-body-secondary" fontSize="body-s">
                The dashboard discovers pipeline stages/actions from CodePipeline. Adding deployment,
                approval, ServiceNow, Jira, UiPath, or other stages does not require a frontend schema change.
              </Box>
            </div>
          </SpaceBetween>
        }
      />
    </>
  );
}
