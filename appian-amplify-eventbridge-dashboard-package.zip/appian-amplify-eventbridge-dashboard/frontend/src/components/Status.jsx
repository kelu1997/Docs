import StatusIndicator from "@cloudscape-design/components/status-indicator";

export function normalizeStatus(status) {
  return String(status || "UNKNOWN").toUpperCase();
}

export default function Status({ value }) {
  const status = normalizeStatus(value);
  const type =
    status === "SUCCEEDED" || status === "PASSED"
      ? "success"
      : status === "FAILED"
      ? "error"
      : status === "IN_PROGRESS" || status === "STARTED"
      ? "in-progress"
      : status === "STOPPED" || status === "ABANDONED"
      ? "stopped"
      : "pending";

  return <StatusIndicator type={type}>{status.replaceAll("_", " ")}</StatusIndicator>;
}
