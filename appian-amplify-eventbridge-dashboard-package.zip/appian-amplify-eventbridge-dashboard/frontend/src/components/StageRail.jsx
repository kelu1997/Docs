import Box from "@cloudscape-design/components/box";
import SpaceBetween from "@cloudscape-design/components/space-between";
import Status from "./Status";

export default function StageRail({ stages, selectedStage, onSelectStage }) {
  return (
    <div className="stage-rail" aria-label="Pipeline stages">
      {stages.map((stage, index) => (
        <div className="stage-rail-slot" key={stage.name}>
          <button
            type="button"
            className={`stage-node ${selectedStage === stage.name ? "selected" : ""}`}
            onClick={() => onSelectStage(stage.name)}
          >
            <SpaceBetween size="xxs">
              <Box variant="awsui-key-label">Stage {index + 1}</Box>
              <Box fontWeight="bold">{stage.name}</Box>
              <Status value={stage.status} />
              <Box color="text-body-secondary" fontSize="body-s">
                {stage.actions.length} action{stage.actions.length === 1 ? "" : "s"}
              </Box>
            </SpaceBetween>
          </button>
          {index < stages.length - 1 && <div className="stage-connector" aria-hidden="true" />}
        </div>
      ))}
    </div>
  );
}
