import Box from "@cloudscape-design/components/box";
import Table from "@cloudscape-design/components/table";
import Status from "./Status";

function outputSummary(outputVariables) {
  const entries = Object.entries(outputVariables || {});
  if (!entries.length) return "—";
  return entries
    .slice(0, 4)
    .map(([key, value]) => `${key}=${value}`)
    .join(" · ");
}

export default function ActionTable({ stage }) {
  if (!stage) {
    return <Box color="text-body-secondary">Select a stage to inspect its actions.</Box>;
  }

  return (
    <Table
      variant="embedded"
      trackBy="name"
      items={stage.actions}
      columnDefinitions={[
        {
          id: "action",
          header: "Action",
          cell: item => <Box fontWeight="bold">{item.name}</Box>
        },
        {
          id: "provider",
          header: "Provider",
          cell: item => `${item.category} / ${item.provider}`
        },
        {
          id: "runOrder",
          header: "Run order",
          cell: item => item.runOrder
        },
        {
          id: "status",
          header: "Status",
          cell: item => <Status value={item.status} />
        },
        {
          id: "output",
          header: "Output",
          cell: item => (
            <span className="mono-small" title={outputSummary(item.outputVariables)}>
              {outputSummary(item.outputVariables)}
            </span>
          )
        }
      ]}
      empty={<Box color="text-body-secondary">No actions found for this stage.</Box>}
    />
  );
}
