import Box from "@cloudscape-design/components/box";
import Table from "@cloudscape-design/components/table";
import Status from "./Status";

export default function IntegrationTable({ integrations }) {
  return (
    <Table
      variant="embedded"
      trackBy="eventKey"
      items={integrations || []}
      columnDefinitions={[
        {
          id: "time",
          header: "Time",
          cell: item => item.updatedAt || item.eventTime || "—"
        },
        {
          id: "system",
          header: "Integration",
          cell: item => (
            <Box fontWeight="bold">
              {item.integration === "serviceNow" ? "ServiceNow" : item.integration}
            </Box>
          )
        },
        {
          id: "subject",
          header: "Pipeline event",
          cell: item =>
            item.level === "ACTION"
              ? `${item.stageName || "—"} / ${item.actionName || "—"}`
              : item.stageName || item.level
        },
        {
          id: "state",
          header: "Pipeline state",
          cell: item => <Status value={item.pipelineState} />
        },
        {
          id: "status",
          header: "Update",
          cell: item => <Status value={item.integrationStatus} />
        },
        {
          id: "reference",
          header: "External reference",
          cell: item => item.externalReference || "—"
        }
      ]}
      empty={
        <Box color="text-body-secondary">
          No ServiceNow/Jira update events have been recorded for this execution.
        </Box>
      }
    />
  );
}
