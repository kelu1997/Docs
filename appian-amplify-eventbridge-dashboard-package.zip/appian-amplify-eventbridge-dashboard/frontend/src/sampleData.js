export const sampleExecutions = {
  pipelineName: "AppianDevOpsDemo",
  executions: [
    {
      id: "7b1d9af0-demo-4e08-b6c3-001",
      status: "SUCCEEDED",
      startTime: "2026-09-03T17:12:04Z",
      lastUpdateTime: "2026-09-03T17:14:42Z"
    },
    {
      id: "6a87a9af-demo-4e08-b6c3-002",
      status: "FAILED",
      startTime: "2026-09-03T16:42:11Z",
      lastUpdateTime: "2026-09-03T16:45:05Z"
    }
  ]
};

export const sampleDetail = {
  pipeline: { name: "AppianDevOpsDemo", version: 12 },
  execution: {
    id: "7b1d9af0-demo-4e08-b6c3-001",
    status: "SUCCEEDED",
    startTime: "2026-09-03T17:12:04Z",
    lastUpdateTime: "2026-09-03T17:14:42Z"
  },
  stages: [
    {
      name: "Source",
      order: 1,
      status: "SUCCEEDED",
      actions: [
        {
          name: "SourceArtifact",
          runOrder: 1,
          category: "Source",
          provider: "S3",
          status: "SUCCEEDED",
          outputVariables: { VersionId: "demo-version-1" }
        }
      ]
    },
    {
      name: "SAST",
      order: 2,
      status: "SUCCEEDED",
      actions: [
        {
          name: "RunSast",
          runOrder: 1,
          category: "Build",
          provider: "CodeBuild",
          status: "SUCCEEDED",
          outputVariables: {
            SAST_STATUS: "PASSED",
            SAST_MODE_USED: "MOCK_PASS",
            SAST_DETAIL: "MOCK_QUALITY_GATE_OK"
          }
        }
      ]
    },
    {
      name: "ValidateAndTest",
      order: 3,
      status: "SUCCEEDED",
      actions: [
        {
          name: "RunValidationAndTests",
          runOrder: 1,
          category: "Invoke",
          provider: "StepFunctions",
          status: "SUCCEEDED",
          outputVariables: {
            ExecutionArn: "arn:aws:states:us-east-1:123456789012:execution:demo:1"
          }
        }
      ]
    },
    {
      name: "CentralQualityGate",
      order: 4,
      status: "SUCCEEDED",
      actions: [
        {
          name: "EvaluateQualityGate",
          runOrder: 1,
          category: "Invoke",
          provider: "Lambda",
          status: "SUCCEEDED",
          outputVariables: {
            CENTRAL_GATE_STATUS: "PASSED",
            SAST_STATUS: "PASSED",
            TOSCA_STATUS: "PASSED",
            TOSCA_TEST_SET: "REGRESSION_1"
          }
        }
      ]
    }
  ],
  integrations: [
    {
      eventKey: "INTEGRATION#SERVICENOW#1",
      eventTime: "2026-09-03T17:12:30Z",
      level: "STAGE",
      stageName: "Source",
      pipelineState: "SUCCEEDED",
      integration: "serviceNow",
      integrationStatus: "SUCCEEDED",
      externalReference: "MOCK-SNOW-a83d",
      detail: "Mock ServiceNow update recorded."
    },
    {
      eventKey: "INTEGRATION#JIRA#2",
      eventTime: "2026-09-03T17:13:01Z",
      level: "STAGE",
      stageName: "SAST",
      pipelineState: "SUCCEEDED",
      integration: "jira",
      integrationStatus: "SUCCEEDED",
      externalReference: "MOCK-JIRA-f18e",
      detail: "Mock Jira update recorded."
    },
    {
      eventKey: "INTEGRATION#SERVICENOW#3",
      eventTime: "2026-09-03T17:14:42Z",
      level: "STAGE",
      stageName: "CentralQualityGate",
      pipelineState: "SUCCEEDED",
      integration: "serviceNow",
      integrationStatus: "SUCCEEDED",
      externalReference: "MOCK-SNOW-c914",
      detail: "Mock ServiceNow update recorded."
    }
  ],
  events: []
};
