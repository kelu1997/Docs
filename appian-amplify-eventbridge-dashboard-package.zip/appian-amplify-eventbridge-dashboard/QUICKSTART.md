# QUICKSTART — Existing Pipeline

You already have:

```text
Source -> SAST -> ValidateAndTest -> CentralQualityGate
```

Do these in order:

1. **DynamoDB**
   - Create `appian-demo-integration-events`
   - PK `executionId` (String)
   - SK `eventKey` (String)
   - On-demand
   - TTL attribute `ttl`

2. **SSM Parameter Store**
   - Create `/appian-demo/integrations/routing`
   - Paste `backend/routing-config.example.json`

3. **SQS**
   - Create `appian-demo-eventbridge-delivery-dlq`
   - Create `appian-demo-integration-processing-failures`

4. **Lambda — Integration Router**
   - Create `appian-demo-integration-router`
   - Python 3.14
   - Upload/paste `backend/integration-router/lambda_function.py`
   - Add environment variables from `docs/02_CONSOLE_IMPLEMENTATION.md`
   - Add DynamoDB/SSM/SQS IAM permissions
   - Configure asynchronous retries = 2 and on-failure SQS destination

5. **EventBridge**
   - Create rule for your existing pipeline
   - Match pipeline + stage + action state-change events
   - Target the Integration Router Lambda
   - Configure EventBridge delivery DLQ

6. **Test observer path**
   - Run CodePipeline
   - Verify DynamoDB contains `PIPELINE_EVENT` and mock `INTEGRATION_RESULT` items

7. **Lambda — Dashboard API**
   - Create `appian-demo-dashboard-api`
   - Python 3.14
   - Use `backend/dashboard-api/lambda_function.py`
   - Grant read-only CodePipeline API + DynamoDB Query

8. **API Gateway HTTP API**
   - Routes:
     - `GET /health`
     - `GET /executions`
     - `GET /executions/{id}`
   - Copy invoke URL

9. **Cloudscape frontend**
   - Recommended: push `frontend/` to Git and connect Amplify
   - Set `frontend/public/runtime-config.json` API URL before build
   - Or build locally and use Amplify `Deploy without Git`

10. **Demo**
    - Run a pipeline
    - Dashboard automatically shows its current stage/action structure
    - ServiceNow/Jira mock entries appear asynchronously
    - Add a new stage later: dashboard/routing do not need code changes when wildcard routing is used

For exact console clicks and IAM JSON, use `docs/02_CONSOLE_IMPLEMENTATION.md`.
