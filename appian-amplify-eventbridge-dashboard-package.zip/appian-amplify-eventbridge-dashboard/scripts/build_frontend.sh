#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FRONTEND_DIR="$ROOT_DIR/frontend"
OUTPUT_ZIP="$ROOT_DIR/deployment/amplify-dashboard.zip"

if [ "${1:-}" != "" ]; then
  python3 - "$FRONTEND_DIR/public/runtime-config.json" "$1" <<'PY'
import json, sys
path, url = sys.argv[1], sys.argv[2].rstrip("/")
data = json.load(open(path))
data["apiBaseUrl"] = url
with open(path, "w") as f:
    json.dump(data, f, indent=2)
    f.write("\n")
PY
fi

cd "$FRONTEND_DIR"
npm install
npm run build
cd dist
zip -qr "$OUTPUT_ZIP" .
echo "Created $OUTPUT_ZIP"
