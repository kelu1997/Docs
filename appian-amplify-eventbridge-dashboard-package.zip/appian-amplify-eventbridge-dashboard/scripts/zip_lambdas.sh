#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mkdir -p "$ROOT_DIR/deployment"

for fn in integration-router dashboard-api; do
  (
    cd "$ROOT_DIR/backend/$fn"
    zip -qj "$ROOT_DIR/deployment/${fn}.zip" lambda_function.py
  )
done

echo "Created Lambda deployment ZIPs in $ROOT_DIR/deployment"
