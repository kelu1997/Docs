# 03 — Demo Runbook

## Scenario 1 — Happy path

Run the existing pipeline with:

```text
SAST = mock pass
Tosca = mock pass
```

Expected:
- CodePipeline: green through CentralQualityGate.
- Dashboard: all current stages green.
- ServiceNow activity: one mock success after each terminal stage.
- Jira activity: one mock success after each terminal stage.
- Pipeline remains unaffected by those updates.

## Scenario 2 — SAST quality failure

Configure the existing SAST mock to report failure while allowing CodeBuild itself to complete.

Expected:
- SAST CodeBuild action: succeeds as an execution mechanism.
- CentralQualityGate: fails because `SAST_STATUS=FAILED`.
- EventBridge captures both the SAST stage terminal event and the quality gate failure.
- Mock ServiceNow/Jira entries appear for both.
- Dashboard shows the failed quality gate and the external notification attempts.

## Scenario 3 — Tosca quality failure

Configure the existing mock Tosca result to FAILED.

Expected:
- ValidateAndTest workflow successfully reports a Tosca failure result.
- CentralQualityGate fails.
- Dashboard exposes the relevant action status/output where CodePipeline reports it.
- ServiceNow/Jira observer updates occur without changing pipeline behavior.

## Scenario 4 — Add a future pipeline stage

Add any harmless temporary stage/action after the CentralQualityGate, for example a Lambda or approval stage.

Expected after a fresh execution:
- No dashboard source-code change.
- The new stage appears in the stage rail automatically because the API reads `GetPipeline`.
- Its action appears in Stage detail automatically.
- If the stage reaches SUCCEEDED/FAILED, the existing EventBridge rule routes mock ServiceNow/Jira updates automatically because routing uses `stages=["*"]`.

## Scenario 5 — Simulate integration-router processing failure

Temporarily make the routing parameter invalid JSON.

Expected:
- CodePipeline continues normally.
- EventBridge successfully delivers the event to Lambda.
- Lambda's asynchronous invocation queue retries the router function twice.
- After retry exhaustion, an invocation record lands in `appian-demo-integration-processing-failures`.
- CloudWatch Lambda error and SQS depth monitoring shows the integration issue.

Restore the routing JSON immediately after the test.

To test the *EventBridge delivery* DLQ separately, temporarily break the EventBridge-to-Lambda invoke permission, then restore it after observing the failed-delivery behavior.

## Suggested sales-demo narrative

1. Show the native CodePipeline once.
2. Open the Cloudscape dashboard.
3. Explain that the stage rail is read from CodePipeline rather than coded manually.
4. Trigger a new execution.
5. Show stage/action status updating.
6. Point out ServiceNow/Jira update records arriving asynchronously.
7. Explain that those integrations can fail without stopping delivery.
8. Switch a quality result to failure and show the **Central Quality Gate**—not the notification integration—blocking the pipeline.
