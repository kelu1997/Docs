# Optional SAM deployment

The console guide is the primary path because the existing pipeline was built manually.

If AWS SAM CLI is available, the backend can instead be created from `infrastructure/template.yaml`.

From the package root:

```bash
sam build --template-file infrastructure/template.yaml

sam deploy --guided \
  --stack-name appian-demo-observability \
  --parameter-overrides PipelineName=YOUR_PIPELINE_NAME
```

After deployment, copy the `DashboardApiUrl` stack output into:

`frontend/public/runtime-config.json`

Then build/deploy the frontend.

The SAM template creates:
- DynamoDB integration-event table
- SSM routing parameter in MOCK mode
- EventBridge rule
- Integration Router Lambda
- EventBridge delivery SQS DLQ
- Lambda processing-failure SQS destination
- Dashboard API Lambda
- API Gateway HTTP API
- CloudWatch log retention
- basic CloudWatch alarms

It does not create or modify the existing CodePipeline.
