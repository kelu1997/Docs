# 05 — Turning the Mock Integrations Real Later

The dashboard and EventBridge design do not need to change.

## ServiceNow

1. Create a Secrets Manager secret containing, for example:

```json
{
  "baseUrl": "https://INSTANCE.service-now.com",
  "username": "pipeline.integration",
  "password": "REDACTED",
  "table": "change_request",
  "recordSysId": "REPLACE",
  "messageField": "work_notes"
}
```

2. Add `secretsmanager:GetSecretValue` for that exact ARN to the Integration Router role.
3. Set Lambda environment variable:
   `SERVICENOW_SECRET_ARN=<secret arn>`
4. Change the SSM routing config:
   `"serviceNow": { "mode": "REAL", ... }`

The included adapter patches the configured ServiceNow table record and writes the pipeline message into `messageField`.

For a real implementation, the record ID will usually be dynamic rather than one fixed secret value. The natural extension is to derive it from a pipeline variable, source metadata, or a lookup table keyed by release/execution.

## Jira Cloud

1. Create a Secrets Manager secret:

```json
{
  "baseUrl": "https://YOURDOMAIN.atlassian.net",
  "email": "integration-account@example.com",
  "apiToken": "REDACTED",
  "issueKey": "PROJ-123"
}
```

2. Grant the Integration Router access to that secret.
3. Set:
   `JIRA_SECRET_ARN=<secret arn>`
4. Change Jira routing mode to `REAL`.

The included adapter posts a comment to the configured issue using Jira REST API v3.

As with ServiceNow, production will commonly resolve the issue key dynamically.

## Appian / Tosca / SonarQube

Those are independent of this package:
- SonarQube continues to report through the SAST action.
- Appian/Tosca remain inside ValidateAndTest.
- The dashboard reads whichever output variables CodePipeline makes available.
- EventBridge observer integrations react to stage/action states without needing to understand the internal implementation.

## Production hardening recommendations

Before production:
- Put an auth layer in front of the dashboard API.
- Restrict API CORS to the Amplify domain.
- Prefer OAuth/service credentials appropriate to the enterprise ServiceNow/Jira configuration.
- Add provider-specific idempotency/correlation IDs.
- Add alarms/notifications on DLQ depth and integration failures.
- Consider separate routing rules/functions per security boundary if ServiceNow and Jira are owned by different teams.
- Replace fixed issue/change IDs with a release metadata lookup.
