# 04 — Routing and Adding New Stages

## Add ServiceNow/Jira updates after every stage

The default package already does this for terminal stage states:

```json
{
  "levels": ["STAGE"],
  "states": ["SUCCEEDED", "FAILED"],
  "stages": ["*"],
  "actions": ["*"]
}
```

No CodePipeline stage/action needs to be inserted.

## Add updates after every action

Change the corresponding rule to:

```json
{
  "levels": ["ACTION"],
  "states": ["SUCCEEDED", "FAILED"],
  "stages": ["*"],
  "actions": ["*"]
}
```

## Only notify on selected stages

Example:

```json
{
  "levels": ["STAGE"],
  "states": ["SUCCEEDED", "FAILED"],
  "stages": ["SAST", "ValidateAndTest", "CentralQualityGate"],
  "actions": ["*"]
}
```

## Notify Jira on actions, ServiceNow only on stages

Use separate configs:

```json
{
  "serviceNow": {
    "enabled": true,
    "mode": "MOCK",
    "rules": [
      {
        "levels": ["STAGE"],
        "states": ["SUCCEEDED", "FAILED"],
        "stages": ["*"],
        "actions": ["*"]
      }
    ]
  },
  "jira": {
    "enabled": true,
    "mode": "MOCK",
    "rules": [
      {
        "levels": ["ACTION"],
        "states": ["SUCCEEDED", "FAILED"],
        "stages": ["*"],
        "actions": ["*"]
      }
    ]
  }
}
```

Update the SSM parameter. The router caches it for approximately 60 seconds.

## Adding new CodePipeline stages

No EventBridge rule change is required while the rule uses:

```json
"detail": {
  "pipeline": ["YOUR_PIPELINE_NAME"]
}
```

and routing uses wildcard stages.

No dashboard source-code change is required. The API requests the current pipeline definition and returns the new stage/actions generically.

## When to use a blocking pipeline action instead

Use the non-blocking EventBridge route for:
- status comments,
- audit trail updates,
- progress synchronization,
- attaching pass/fail summaries,
- notifying ServiceNow/Jira that a stage completed.

Use a real pipeline gate for:
- mandatory change-ticket existence,
- CAB approval,
- production deployment authorization,
- compliance approval that legally must stop delivery when unavailable/denied.
