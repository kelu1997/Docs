# AWS / Cloudscape reference sources

Checked September 2026.

- AWS CodePipeline events in EventBridge:
  https://docs.aws.amazon.com/eventbridge/latest/ref/events-ref-codepipeline.html
- Monitoring CodePipeline state changes / execution-id event field:
  https://docs.aws.amazon.com/codepipeline/latest/userguide/detect-state-changes-cloudwatch-events.html
- CodePipeline action execution output variables:
  https://docs.aws.amazon.com/codepipeline/latest/APIReference/API_ActionExecutionOutput.html
- EventBridge target retry policy:
  https://docs.aws.amazon.com/eventbridge/latest/userguide/eb-rule-retry-policy.html
- EventBridge dead-letter queues:
  https://docs.aws.amazon.com/eventbridge/latest/userguide/eb-rule-dlq.html
- Lambda asynchronous error/retry behavior:
  https://docs.aws.amazon.com/lambda/latest/dg/invocation-async-error-handling.html
- Lambda asynchronous invocation configuration:
  https://docs.aws.amazon.com/lambda/latest/dg/invocation-async-configuring.html
- Amplify manual deployments:
  https://docs.aws.amazon.com/amplify/latest/userguide/manual-deploys.html
- Cloudscape component installation:
  https://cloudscape.design/get-started/for-developers/using-cloudscape-components/
