# 02 — Console Implementation Guide

These steps assume the existing pipeline is already:

```text
Source -> SAST -> ValidateAndTest -> CentralQualityGate
```

Nothing in this guide requires changing those stages.

---

## A. Create the DynamoDB integration-event table

1. Open **DynamoDB → Tables → Create table**.
2. Table name: `appian-demo-integration-events`.
3. Partition key: `executionId` (String).
4. Sort key: `eventKey` (String).
5. Capacity mode: **On-demand**.
6. Create the table.
7. Open the table → **Additional settings / Time to Live (TTL)**.
8. Enable TTL with attribute name: `ttl`.

The router writes both raw CodePipeline events and ServiceNow/Jira result records here.

---

## B. Create the routing configuration in Parameter Store

1. Open **Systems Manager → Parameter Store → Create parameter**.
2. Name: `/appian-demo/integrations/routing`
3. Tier: Standard.
4. Type: String.
5. Data type: text.
6. Paste the contents of `backend/routing-config.example.json`.
7. Create the parameter.

The default is intentionally:

- ServiceNow: enabled, MOCK
- Jira: enabled, MOCK
- Route terminal **stage** events (`SUCCEEDED` / `FAILED`)
- Match every stage

No ServiceNow/Jira credentials are needed.

---

## C. Create the two failure queues

Create two **Standard** SQS queues.

### Queue 1 — EventBridge delivery failures

1. Open **Amazon SQS → Create queue**.
2. Type: Standard.
3. Name: `appian-demo-eventbridge-delivery-dlq`.
4. Keep server-side encryption enabled.
5. Set message retention to 14 days.
6. Create the queue.

This queue is only for cases where EventBridge cannot deliver the event to the router Lambda.

### Queue 2 — Integration processing failures

1. Create another Standard queue.
2. Name: `appian-demo-integration-processing-failures`.
3. Keep encryption enabled.
4. Set message retention to 14 days.
5. Create it.

This queue receives Lambda asynchronous invocation records after the router itself fails all configured retries, for example because ServiceNow/Jira remains unavailable.

Keep both queue ARNs handy.

---

## D. Create the Integration Router Lambda

1. Open **Lambda → Create function**.
2. Choose **Author from scratch**.
3. Name: `appian-demo-integration-router`.
4. Runtime: Python 3.14.
5. Architecture: x86_64.
6. Create a new basic Lambda execution role.
7. Create the function.
8. Open the **Code** tab.
9. Replace `lambda_function.py` with `backend/integration-router/lambda_function.py`.
10. Deploy.
11. Under **Configuration → Environment variables**, add:

```text
TABLE_NAME=appian-demo-integration-events
PIPELINE_NAME=<YOUR_EXISTING_CODEPIPELINE_NAME>
ROUTING_PARAMETER_NAME=/appian-demo/integrations/routing
SERVICENOW_SECRET_ARN=
JIRA_SECRET_ARN=
HTTP_TIMEOUT_SECONDS=10
EVENT_TTL_DAYS=30
LOG_LEVEL=INFO
```

12. Set timeout to 20 seconds and memory to 256 MB.
13. Open **Configuration → Asynchronous invocation → Edit**.
14. Set:
    - Maximum age of event: 1 hour
    - Retry attempts: 2
15. Under **On-failure destination**, choose **SQS queue** and select:
    `appian-demo-integration-processing-failures`
16. Save.

This is separate from the EventBridge target retry policy: EventBridge handles failure to *deliver* the invocation, while Lambda asynchronous invocation settings handle errors *inside* the router function.

### IAM permissions for this Lambda

Open the Lambda execution role in IAM and add an inline policy. Replace region/account/table/parameter values:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "IntegrationEventTable",
      "Effect": "Allow",
      "Action": [
        "dynamodb:GetItem",
        "dynamodb:PutItem",
        "dynamodb:UpdateItem"
      ],
      "Resource": "arn:aws:dynamodb:REGION:ACCOUNT_ID:table/appian-demo-integration-events"
    },
    {
      "Sid": "RoutingParameter",
      "Effect": "Allow",
      "Action": "ssm:GetParameter",
      "Resource": "arn:aws:ssm:REGION:ACCOUNT_ID:parameter/appian-demo/integrations/routing"
    },
    {
      "Sid": "SendFailedInvocationRecord",
      "Effect": "Allow",
      "Action": "sqs:SendMessage",
      "Resource": "arn:aws:sqs:REGION:ACCOUNT_ID:appian-demo-integration-processing-failures"
    }
  ]
}
```

Do **not** add Secrets Manager permissions yet because both integrations are MOCK.

---

## E. Create the EventBridge rule

1. Open **Amazon EventBridge → Rules → Create rule**.
2. Name: `appian-demo-codepipeline-events`.
3. Event bus: `default`.
4. Rule type: **Rule with an event pattern**.
5. Event source: **AWS events or EventBridge partner events**.
6. Creation method: **Custom pattern (JSON editor)**.
7. Paste:

```json
{
  "source": ["aws.codepipeline"],
  "detail-type": [
    "CodePipeline Pipeline Execution State Change",
    "CodePipeline Stage Execution State Change",
    "CodePipeline Action Execution State Change"
  ],
  "detail": {
    "pipeline": ["YOUR_PIPELINE_NAME"]
  }
}
```

8. Target: **AWS service → Lambda function**.
9. Select `appian-demo-integration-router`.
10. Configure retry policy:
    - Maximum age: 1 hour
    - Retry attempts: 10
11. Dead-letter queue: select `appian-demo-eventbridge-delivery-dlq`.
12. Create the rule.

When configured in the console, AWS normally adds the Lambda invoke permission and same-account DLQ resource policy for you. Verify the rule target shows both the retry policy and DLQ.

---

## F. Run one pipeline execution and verify the event layer

1. Start your existing CodePipeline with mock SAST/Tosca passing.
2. Wait for the pipeline to complete.
3. Open **DynamoDB → appian-demo-integration-events → Explore table items**.
4. You should see records with:
   - `itemType = PIPELINE_EVENT`
   - `itemType = INTEGRATION_RESULT`
5. For each terminal stage, the default config should create both:
   - `integration = serviceNow`
   - `integration = jira`
6. The integration results should say `SUCCEEDED` and have `MOCK-*` external references.

If no records appear:
- Confirm the EventBridge rule pipeline name exactly matches CodePipeline.
- Open the Integration Router CloudWatch logs.
- Check the EventBridge rule monitoring metrics.
- Check both SQS failure queues.

---

## G. Create the Dashboard API Lambda

1. Open **Lambda → Create function**.
2. Name: `appian-demo-dashboard-api`.
3. Runtime: Python 3.14.
4. Architecture: x86_64.
5. Create a new basic Lambda execution role.
6. Replace `lambda_function.py` with `backend/dashboard-api/lambda_function.py`.
7. Deploy.
8. Add environment variables:

```text
TABLE_NAME=appian-demo-integration-events
PIPELINE_NAME=<YOUR_EXISTING_CODEPIPELINE_NAME>
ALLOWED_ORIGIN=*
```

9. Set timeout to 20 seconds and memory to 256 MB.

### IAM permissions

Add:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "ReadIntegrationEvents",
      "Effect": "Allow",
      "Action": [
        "dynamodb:Query"
      ],
      "Resource": "arn:aws:dynamodb:REGION:ACCOUNT_ID:table/appian-demo-integration-events"
    },
    {
      "Sid": "ReadPipeline",
      "Effect": "Allow",
      "Action": [
        "codepipeline:GetPipeline",
        "codepipeline:GetPipelineExecution",
        "codepipeline:ListPipelineExecutions",
        "codepipeline:ListActionExecutions"
      ],
      "Resource": "*"
    }
  ]
}
```

The CodePipeline list APIs do not support the same useful per-pipeline resource scoping as every read operation, so the demo policy uses `Resource: "*"`. Keep the allowed actions narrow.

---

## H. Create the API Gateway HTTP API

1. Open **API Gateway → Create API**.
2. Under **HTTP API**, choose **Build**.
3. Add integration: Lambda → `appian-demo-dashboard-api`.
4. API name: `appian-demo-dashboard-api`.
5. Add these routes:
   - `GET /health`
   - `GET /executions`
   - `GET /executions/{id}`
6. Use the `$default` stage with auto-deploy enabled.
7. Configure CORS:
   - Allowed origins: `*` for the first demo
   - Allowed methods: `GET`, `OPTIONS`
   - Allowed headers: `Content-Type`
8. Create/deploy the API.
9. Copy the **Invoke URL**, e.g.:
   `https://abc123.execute-api.us-east-1.amazonaws.com`

Test in a browser:

```text
<INVOKE_URL>/health
<INVOKE_URL>/executions
```

You should receive JSON.

---

## I. Deploy/build the Cloudscape frontend

You have two paths.

### Option 1 — Recommended when you do not want to build locally: Git-connected Amplify

1. Put the contents of `frontend/` in a Git repository.
2. Open **AWS Amplify → Create new app**.
3. Choose your Git provider and select that repository/branch.
4. Amplify should detect the included `amplify.yml`.
5. Before the first build, edit `frontend/public/runtime-config.json` in the repo and set:

```json
{
  "apiBaseUrl": "https://YOUR_API_ID.execute-api.YOUR_REGION.amazonaws.com",
  "refreshSeconds": 15,
  "demoModeWhenApiMissing": true,
  "title": "Appian DevOps Pipeline"
}
```

6. Commit/push the change.
7. Amplify installs Node 22, installs the pinned React/Cloudscape dependencies, runs the Vite build, and hosts `dist/`.

### Option 2 — Local build + manual Amplify deployment

On a workstation with Node.js:

```bash
cd frontend
npm install
npm run build
```

Before building for the live API, edit:

`frontend/public/runtime-config.json`

and set `apiBaseUrl` to the API Gateway invoke URL.

The build output is `frontend/dist/`.

### Convenience script

From the package root:

```bash
./scripts/build_frontend.sh https://YOUR_API_ID.execute-api.YOUR_REGION.amazonaws.com
```

It updates the runtime API URL, builds the app, and creates:

`deployment/amplify-dashboard.zip`

## J. Deploy the frontend to Amplify Hosting without Git

This is the fastest sales-demo path.

1. Open **AWS Amplify → Create new app**.
2. Choose **Deploy without Git**.
3. App name: `appian-devops-dashboard`.
4. Branch name: `demo`.
5. Method: **Drag and drop**.
6. Upload `deployment/amplify-dashboard.zip`.
7. Save and deploy.
8. Open the generated Amplify URL.

The dashboard should show:
- recent CodePipeline executions,
- current pipeline status,
- a dynamic stage rail,
- each stage's actions/providers/status,
- action output variables (including SAST and central-gate values when present),
- ServiceNow/Jira mock update activity.

---

## K. Tighten CORS after Amplify has a URL

Once the Amplify domain is known:

1. Edit API Gateway CORS allowed origin from `*` to:
   `https://<your-amplify-domain>`
2. Change the Dashboard API Lambda `ALLOWED_ORIGIN` to the same value.
3. Redeploy if necessary.

For a sales demo, public read-only API access may be acceptable if the data is non-sensitive. For production, add authentication/authorization rather than leaving the API public.

---

## L. Add log retention

For both Lambda log groups:

- `/aws/lambda/appian-demo-integration-router`
- `/aws/lambda/appian-demo-dashboard-api`

Set retention to 14 days.

Also create a CloudWatch alarm for:
- Integration Router Lambda `Errors >= 1`
- EventBridge delivery DLQ `ApproximateNumberOfMessagesVisible >= 1`
- Integration processing failure queue `ApproximateNumberOfMessagesVisible >= 1`

The optional SAM template creates these automatically.
