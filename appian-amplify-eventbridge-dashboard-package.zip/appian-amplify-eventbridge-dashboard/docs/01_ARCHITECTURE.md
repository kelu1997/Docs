# 01 — Architecture

## Recommended pattern

The external ticket/update systems are **observers**, not gates:

```text
CodePipeline
  Source
    ↓
  SAST
    ↓
  ValidateAndTest
    ↓
  CentralQualityGate
    ↓
  future stages...
       │
       └── emits state-change events continuously
                    ↓
               EventBridge
                    ↓
        Integration Router Lambda
          ├── ServiceNow
          └── Jira
                    ↓
        Integration event history
               DynamoDB
                    ↓
         Dashboard API Lambda
                    ↓
        API Gateway HTTP API
                    ↓
       Amplify + Cloudscape UI
```

## Why the dashboard remains adaptive

The dashboard does **not** have fields such as `SourceStatus`, `SastStatus`, or `QualityGateStatus`.

On each execution-detail request, the backend:

1. Calls `GetPipeline` to read the current ordered stage/action definition.
2. Calls `GetPipelineExecution` for the selected execution.
3. Calls `ListActionExecutions` filtered to that execution.
4. Groups action execution results beneath whatever stages currently exist.
5. Queries DynamoDB for matching ServiceNow/Jira integration records.
6. Returns a generic `stages[] -> actions[]` model.

Therefore, adding:

```text
CentralQualityGate
  ↓
Deploy
  ↓
PostDeploySmoke
  ↓
Approval
```

requires no frontend schema change. Those stages appear when CodePipeline reports them.

## Source-of-truth split

The dashboard intentionally does not depend on EventBridge to reconstruct pipeline status. It reads the pipeline definition and execution/action history directly from CodePipeline.

EventBridge is used for the **observer/integration side effects**. This separation is useful because CodePipeline service events are not the authoritative dashboard data store. For production where every external update must be reconciled, add a periodic reconciliation job that compares CodePipeline action history with integration records and replays any missing update.

## Routing model

The Integration Router reads JSON from Systems Manager Parameter Store. The default routes every terminal **stage** result to both mock ServiceNow and mock Jira.

Example:

```json
{
  "serviceNow": {
    "enabled": true,
    "mode": "MOCK",
    "rules": [
      {
        "levels": ["STAGE"],
        "states": ["SUCCEEDED", "FAILED"],
        "stages": ["*"],
        "actions": ["*"]
      }
    ]
  }
}
```

To update Jira after every action instead, use:

```json
{
  "levels": ["ACTION"],
  "states": ["SUCCEEDED", "FAILED"],
  "stages": ["*"],
  "actions": ["*"]
}
```

You can combine multiple rules.

## Reliability boundary

CodePipeline continues regardless of ServiceNow/Jira API availability.

There are two separate failure boundaries:

1. **EventBridge delivery failure** — EventBridge cannot deliver the event to Lambda at all (for example, missing invoke permission). The EventBridge target retry policy applies, then the event is sent to the EventBridge delivery DLQ.
2. **Lambda processing failure** — EventBridge successfully hands the event to Lambda, but the router code or external API fails. Lambda asynchronous invocation retry behavior applies. This package configures two retries and an on-failure SQS destination.

The router also stores successful integration results by EventBridge event ID and skips already-successful repeats, reducing duplicate external updates during retries.

This is intentionally different from a mandatory change-control check. If ServiceNow approval becomes a release prerequisite later, that one interaction should be implemented as a blocking pipeline gate rather than through this observer path.
