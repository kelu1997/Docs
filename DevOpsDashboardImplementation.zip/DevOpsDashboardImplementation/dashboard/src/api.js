export async function loadConfig() {
  const response = await fetch('/config.json', { cache: 'no-store' });
  if (!response.ok) throw new Error(`config.json returned HTTP ${response.status}`);
  return response.json();
}

export async function loadDashboard(dataUrl) {
  const response = await fetch(dataUrl, { cache: 'no-store' });
  if (!response.ok) throw new Error(`dashboard data returned HTTP ${response.status}`);
  return response.json();
}
