import React, { useEffect, useMemo, useState } from 'react';
import {
  Alert,
  AppLayout,
  Badge,
  Box,
  Button,
  ColumnLayout,
  Container,
  ContentLayout,
  Header,
  ProgressBar,
  SpaceBetween,
  StatusIndicator,
  Table
} from '@cloudscape-design/components';
import { loadConfig, loadDashboard } from './api';

const DEFAULT_CONFIG = {
  title: 'Application Delivery Control Center',
  subtitle: 'AWS-native delivery pipeline observability',
  environment: 'Sales Demo',
  refreshSeconds: 5,
  dataUrl: '/data/dashboard.json'
};

const EMPTY = {
  generatedAt: null,
  pipeline: { name: 'Waiting for telemetry', status: 'WAITING' },
  stages: [],
  quality: {},
  integrations: [],
  bedrock: { status: 'STANDBY' },
  history: [],
  timeline: [],
  kpis: {}
};

function statusType(status) {
  switch ((status || '').toUpperCase()) {
    case 'SUCCEEDED': return 'success';
    case 'FAILED': return 'error';
    case 'IN_PROGRESS': return 'in-progress';
    case 'AWAITING_ANALYSIS': return 'in-progress';
    case 'STOPPED': return 'stopped';
    case 'STOPPING': return 'in-progress';
    case 'ABANDONED': return 'error';
    case 'CANCELED': return 'stopped';
    case 'SUPERSEDED': return 'stopped';
    case 'WAITING':
    case 'PENDING': return 'pending';
    default: return 'info';
  }
}

function labelStatus(status) {
  const s = status || 'PENDING';
  return s.replaceAll('_', ' ').toLowerCase().replace(/\b\w/g, c => c.toUpperCase());
}

function fmtDuration(seconds) {
  if (seconds === null || seconds === undefined) return '—';
  const total = Math.max(0, Math.round(seconds));
  const m = Math.floor(total / 60);
  const s = total % 60;
  return m ? `${m}m ${s}s` : `${s}s`;
}

function fmtTime(value) {
  if (!value) return '—';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return value;
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function shortId(value, length = 8) {
  if (!value) return '—';
  return String(value).length > length ? String(value).slice(0, length) : String(value);
}

function safeExternalUrl(value) {
  if (!value) return null;
  try {
    const parsed = new URL(value);
    return ['https:', 'http:'].includes(parsed.protocol) ? parsed.href : null;
  } catch {
    return null;
  }
}

function MetricCard({ label, value, detail, status }) {
  return (
    <div className="metric-card">
      <div className="metric-label">{label}</div>
      <div className="metric-value">{value}</div>
      <div className="metric-detail">
        {status ? <StatusIndicator type={statusType(status)}>{detail || labelStatus(status)}</StatusIndicator> : (detail || ' ')}
      </div>
    </div>
  );
}

function PipelineProgress({ stages }) {
  if (!stages?.length) {
    return <Alert type="info">Waiting for the first telemetry snapshot. Seed the telemetry Lambda or start the pipeline.</Alert>;
  }
  return (
    <div className="pipeline-strip" aria-label="Live pipeline stages">
      {stages.map((stage, index) => (
        <React.Fragment key={stage.name}>
          <div className={`stage-card stage-${(stage.status || 'PENDING').toLowerCase()}`}>
            <div className="stage-order">{String(index + 1).padStart(2, '0')}</div>
            <div className="stage-name">{stage.name}</div>
            <StatusIndicator type={statusType(stage.status)}>{labelStatus(stage.status)}</StatusIndicator>
            <div className="stage-duration">{fmtDuration(stage.durationSeconds)}</div>
            {stage.summary && <div className="stage-summary" title={stage.summary}>{stage.summary}</div>}
          </div>
          {index < stages.length - 1 && <div className={`stage-connector connector-${stage.status?.toLowerCase() || 'pending'}`} />}
        </React.Fragment>
      ))}
    </div>
  );
}

function QualityCard({ title, data, children }) {
  const status = data?.status || 'WAITING';
  return (
    <div className="quality-card">
      <div className="quality-card-header">
        <strong>{title}</strong>
        <StatusIndicator type={statusType(status)}>{labelStatus(status)}</StatusIndicator>
      </div>
      <div className="quality-body">{children}</div>
    </div>
  );
}

function QualitySignals({ quality = {} }) {
  const sast = quality.sast || {};
  const tests = quality.tests || {};
  const gate = quality.qualityGate || {};
  const totalTests = Number(tests.total ?? ((tests.passed || 0) + (tests.failed || 0) + (tests.skipped || 0))) || 0;
  const passPct = totalTests ? Math.round(((Number(tests.passed) || 0) / totalTests) * 100) : 0;
  return (
    <div className="quality-grid">
      <QualityCard title="SAST" data={sast}>
        <div className="signal-numbers">
          <span><b>{sast.critical ?? '—'}</b> Critical</span>
          <span><b>{sast.high ?? '—'}</b> High</span>
          <span><b>{sast.medium ?? '—'}</b> Medium</span>
          <span><b>{sast.low ?? '—'}</b> Low</span>
        </div>
        {sast.tool && <div className="subtle">Scanner: {sast.tool}</div>}
      </QualityCard>
      <QualityCard title="Automated tests" data={tests}>
        <div className="signal-numbers">
          <span><b>{tests.passed ?? '—'}</b> Passed</span>
          <span><b>{tests.failed ?? '—'}</b> Failed</span>
          <span><b>{tests.skipped ?? '—'}</b> Skipped</span>
        </div>
        <ProgressBar value={passPct} label="Pass rate" description={totalTests ? `${passPct}% of ${totalTests} tests` : 'Waiting for test results'} />
      </QualityCard>
      <QualityCard title="Central quality gate" data={gate}>
        <div className="gate-decision">{gate.decision || labelStatus(gate.status || 'WAITING')}</div>
        <div className="subtle">{gate.reason || 'Central policy evaluation will appear here.'}</div>
      </QualityCard>
    </div>
  );
}

function IntegrationFeed({ items = [] }) {
  if (!items.length) {
    return <Box color="text-body-secondary">No outbound status events for this execution yet.</Box>;
  }
  return (
    <div className="integration-feed">
      {items.slice(0, 10).map((item, idx) => {
        const externalUrl = safeExternalUrl(item.externalUrl);
        return (
        <div className="integration-row" key={item.id || `${item.integration}-${item.timestamp}-${idx}`}>
          <div className="integration-icon">{(item.integration || '?').slice(0, 2).toUpperCase()}</div>
          <div className="integration-main">
            <div className="integration-title">
              <strong>{item.integration || 'Integration'}</strong>
              <span>{item.operation || 'Status update'}</span>
            </div>
            <div className="integration-meta">
              {item.stage && <Badge color="blue">{item.stage}</Badge>}
              {item.externalId && <span>{item.externalId}</span>}
              <span>{fmtTime(item.timestamp)}</span>
            </div>
            {item.message && <div className="integration-message">{item.message}</div>}
          </div>
          <div className="integration-status">
            <StatusIndicator type={statusType(item.status)}>{labelStatus(item.status)}</StatusIndicator>
            {externalUrl && <a href={externalUrl} target="_blank" rel="noreferrer">Open record</a>}
          </div>
        </div>
        );
      })}
    </div>
  );
}

function BedrockPanel({ data = {}, failedStage }) {
  const status = data.status || 'STANDBY';
  return (
    <div className={`bedrock-panel bedrock-${status.toLowerCase()}`}>
      <div className="bedrock-heading">
        <div>
          <div className="eyebrow">GENERATIVE AI FAILURE ASSIST</div>
          <h3>Amazon Bedrock analysis</h3>
        </div>
        <StatusIndicator type={statusType(status)}>{labelStatus(status)}</StatusIndicator>
      </div>
      <div className="bedrock-summary">{data.summary || 'AI failure analysis is standing by.'}</div>
      {(data.rootCause || failedStage) && (
        <div className="bedrock-section">
          <div className="bedrock-label">Likely root cause</div>
          <div>{data.rootCause || `Failure detected in ${failedStage}. Waiting for the analyzer response.`}</div>
        </div>
      )}
      {!!data.recommendedActions?.length && (
        <div className="bedrock-section">
          <div className="bedrock-label">Recommended actions</div>
          <ol>
            {data.recommendedActions.map((action, index) => <li key={index}>{action}</li>)}
          </ol>
        </div>
      )}
      <div className="bedrock-footer">
        {data.sourceStage && <span>Source: {data.sourceStage}</span>}
        {data.modelId && <span>Model: {data.modelId}</span>}
        {data.timestamp && <span>Analyzed: {fmtTime(data.timestamp)}</span>}
      </div>
    </div>
  );
}

function Timeline({ items = [] }) {
  if (!items.length) return <Box color="text-body-secondary">The execution activity stream will appear here.</Box>;
  return (
    <div className="timeline">
      {items.slice(0, 12).map((item, index) => (
        <div className="timeline-item" key={item.id || `${item.timestamp}-${index}`}>
          <div className={`timeline-dot dot-${statusType(item.status)}`} />
          <div className="timeline-content">
            <div className="timeline-title">
              <strong>{item.title || item.service || 'Event'}</strong>
              <span>{fmtTime(item.timestamp)}</span>
            </div>
            <div className="timeline-meta">
              {item.service && <Badge>{item.service}</Badge>}
              {item.stage && <Badge color="blue">{item.stage}</Badge>}
              <StatusIndicator type={statusType(item.status)}>{labelStatus(item.status)}</StatusIndicator>
            </div>
            {item.message && <div className="timeline-message">{item.message}</div>}
          </div>
        </div>
      ))}
    </div>
  );
}

function HistoryTable({ history = [] }) {
  return (
    <Table
      variant="embedded"
      items={history}
      empty={<Box textAlign="center" color="inherit">No pipeline history returned yet.</Box>}
      columnDefinitions={[
        { id: 'execution', header: 'Execution', cell: i => shortId(i.executionId, 10) },
        { id: 'status', header: 'Status', cell: i => <StatusIndicator type={statusType(i.status)}>{labelStatus(i.status)}</StatusIndicator> },
        { id: 'started', header: 'Started', cell: i => fmtTime(i.startTime) },
        { id: 'duration', header: 'Duration', cell: i => fmtDuration(i.durationSeconds) },
        { id: 'commit', header: 'Revision', cell: i => { const url = safeExternalUrl(i.revisionUrl); return url ? <a href={url} target="_blank" rel="noreferrer">{shortId(i.commitId, 9)}</a> : shortId(i.commitId, 9); } },
        { id: 'message', header: 'Change', cell: i => <span className="truncate-cell" title={i.commitMessage || ''}>{i.commitMessage || '—'}</span> }
      ]}
      header={<Header variant="h2" description="Recent CodePipeline executions used for the demo-level reliability KPIs.">Recent executions</Header>}
    />
  );
}

export default function App() {
  const [config, setConfig] = useState(DEFAULT_CONFIG);
  const [data, setData] = useState(EMPTY);
  const [error, setError] = useState(null);
  const [now, setNow] = useState(Date.now());
  const [manualRefresh, setManualRefresh] = useState(0);

  useEffect(() => {
    loadConfig().then(setConfig).catch(() => setConfig(DEFAULT_CONFIG));
  }, []);

  useEffect(() => {
    let cancelled = false;
    async function refresh() {
      try {
        const payload = await loadDashboard(config.dataUrl);
        if (!cancelled) {
          setData(payload);
          setError(null);
        }
      } catch (err) {
        if (!cancelled) setError(err.message);
      }
    }
    refresh();
    const timer = setInterval(refresh, Math.max(2, Number(config.refreshSeconds) || 5) * 1000);
    return () => { cancelled = true; clearInterval(timer); };
  }, [config.dataUrl, config.refreshSeconds, manualRefresh]);

  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const ageSeconds = data.generatedAt ? Math.max(0, Math.floor((now - new Date(data.generatedAt).getTime()) / 1000)) : null;
  const runningStage = data.stages?.find(stage => stage.status === 'IN_PROGRESS');
  const failedStage = data.stages?.find(stage => stage.status === 'FAILED');
  const pipeline = data.pipeline || EMPTY.pipeline;
  const successRate = data.kpis?.successRatePct;
  const completed = data.kpis?.completedExecutions || 0;

  const header = useMemo(() => (
    <div className="hero">
      <div className="hero-topline">
        <div>
          <div className="eyebrow">AWS DEVOPS DEMONSTRATION</div>
          <h1>{config.title}</h1>
          <p>{config.subtitle}</p>
        </div>
        <div className="hero-actions">
          <Badge color="blue">{config.environment}</Badge>
          <div className="live-pill"><span className="live-dot" /> LIVE</div>
          <Button iconName="refresh" onClick={() => setManualRefresh(v => v + 1)}>Refresh</Button>
        </div>
      </div>
      <div className="hero-meta">
        <span><b>Pipeline</b> {pipeline.name || '—'}</span>
        <span><b>Execution</b> {shortId(pipeline.executionId, 12)}</span>
        <span><b>Branch</b> {pipeline.branch || '—'}</span>
        <span><b>Commit</b> {shortId(pipeline.commitId, 10)}</span>
        <span><b>Telemetry age</b> {ageSeconds === null ? 'waiting' : `${ageSeconds}s`}</span>
      </div>
    </div>
  ), [config, pipeline, ageSeconds]);

  return (
    <AppLayout
      navigationHide
      toolsHide
      contentType="dashboard"
      content={
        <ContentLayout header={header}>
          <SpaceBetween size="l">
            {error && <Alert type="warning" header="Live telemetry temporarily unavailable">{error}. The last successful snapshot remains on screen.</Alert>}

            <ColumnLayout columns={5} variant="text-grid">
              <MetricCard label="Pipeline" value={labelStatus(pipeline.status)} detail={runningStage ? `Running: ${runningStage.name}` : failedStage ? `Failed: ${failedStage.name}` : 'Current execution'} status={pipeline.status} />
              <MetricCard label="Execution time" value={fmtDuration(pipeline.durationSeconds)} detail={pipeline.startTime ? `Started ${fmtTime(pipeline.startTime)}` : 'Waiting for execution'} />
              <MetricCard label="Success rate" value={successRate === null || successRate === undefined ? '—' : `${successRate}%`} detail={completed ? `Last ${completed} completed runs` : 'Waiting for history'} />
              <MetricCard label="Quality gate" value={data.quality?.qualityGate?.decision || labelStatus(data.quality?.qualityGate?.status || 'WAITING')} detail={data.quality?.qualityGate?.reason || 'Central policy'} status={data.quality?.qualityGate?.status} />
              <MetricCard label="Automation" value={data.integrations?.filter(i => i.status === 'SUCCEEDED').length || 0} detail={`${data.integrations?.length || 0} outbound updates this run`} />
            </ColumnLayout>

            <Container header={<Header variant="h2" description="Pipeline stage state is refreshed from CodePipeline execution APIs after each state-change event.">Live pipeline progress</Header>}>
              <PipelineProgress stages={data.stages} />
            </Container>

            <Container header={<Header variant="h2" description="Custom signals from SAST, automated testing and the central quality gate.">Quality signals</Header>}>
              <QualitySignals quality={data.quality} />
            </Container>

            <ColumnLayout columns={2} variant="text-grid">
              <Container header={<Header variant="h2" description="Every outbound sidecar update can publish a success/failure event for the current execution.">ServiceNow / Jira / external updates</Header>}>
                <IntegrationFeed items={data.integrations} />
              </Container>
              <Container>
                <BedrockPanel data={data.bedrock} failedStage={failedStage?.name} />
              </Container>
            </ColumnLayout>

            <ColumnLayout columns={2} variant="text-grid">
              <Container header={<Header variant="h2" description="A single audit-style stream combining pipeline state, quality signals and external automation.">Execution activity</Header>}>
                <Timeline items={data.timeline} />
              </Container>
              <Container>
                <HistoryTable history={data.history || []} />
              </Container>
            </ColumnLayout>

            <Box textAlign="center" color="text-body-secondary" padding={{ bottom: 'l' }}>
              Static Cloudscape UI served from private S3 through CloudFront OAC. Viewer access is restricted by AWS WAF IP allowlist. No AWS credentials are stored in the browser.
            </Box>
          </SpaceBetween>
        </ContentLayout>
      }
    />
  );
}
