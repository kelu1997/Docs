# DevOps Sales Dashboard Implementation Package

This package implements a polished live dashboard using **private S3 + CloudFront OAC + AWS WAF IP allowlist + React/Cloudscape + EventBridge/Lambda telemetry**.

Start with **`IMPLEMENTATION_GUIDE.md`** (or the included Word guide) and deploy in this order:

1. `cloudformation/01-edge-stack-us-east-1.yaml` in **us-east-1**
2. Build and upload `dashboard/`
3. `cloudformation/02-telemetry-stack-pipeline-region.yaml` in the **CodePipeline Region**
4. Invoke the telemetry Lambda once with `{}` to seed data
5. Add the small EventBridge publisher calls to existing ServiceNow/Jira/quality/Bedrock sidecars
6. Run the acceptance checklist and demo runbook

The design intentionally makes no VPC/network-topology changes and does not put the dashboard into the pipeline execution path.
