#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT/dashboard"
npm install
npm run build
printf '\nBuilt dashboard at %s/dashboard/dist\n' "$ROOT"
