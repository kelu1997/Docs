#!/usr/bin/env bash
set -euo pipefail
STACK="${1:-DevOpsSalesDashboard-Edge}"
aws cloudformation describe-stacks --region us-east-1 --stack-name "$STACK" \
  --query 'Stacks[0].Outputs[*].[OutputKey,OutputValue]' --output table
