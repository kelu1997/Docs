# Dashboard Custom Event Contract

All custom sidecar signals are sent to the default EventBridge bus in the **pipeline Region**.

- `Source`: `devops.pipeline.dashboard`
- `DetailType`: `DevOps Dashboard Signal`
- `detail.pipeline`: exact CodePipeline name
- `detail.executionId`: `#{codepipeline.PipelineExecutionId}` propagated into the sidecar
- `detail.kind`: `integration`, `quality`, `bedrock`, or `note`

## Integration event

```json
{
  "pipeline": "ApplicationDeliveryPipeline",
  "executionId": "8abc75f0-fbf8-4f4c-bf00-example",
  "kind": "integration",
  "integration": "ServiceNow",
  "operation": "Change record status update",
  "stage": "SAST",
  "status": "SUCCEEDED",
  "externalId": "CHG003142",
  "externalUrl": "https://example.service-now.com/...",
  "message": "ServiceNow accepted the pipeline status update.",
  "timestamp": "2026-09-04T15:01:22Z"
}
```

Use the same shape for Jira, Teams/Slack, email/SNS, deployment orchestration, or later sidecars. The dashboard is deliberately integration-name agnostic.

## SAST quality event

```json
{
  "pipeline": "ApplicationDeliveryPipeline",
  "executionId": "8abc75f0-fbf8-4f4c-bf00-example",
  "kind": "quality",
  "category": "sast",
  "stage": "SAST",
  "status": "SUCCEEDED",
  "title": "SAST scan completed",
  "metrics": {
    "critical": 0,
    "high": 1,
    "medium": 4,
    "low": 8,
    "tool": "Your scanner"
  }
}
```

## Automated test event

```json
{
  "pipeline": "ApplicationDeliveryPipeline",
  "executionId": "8abc75f0-fbf8-4f4c-bf00-example",
  "kind": "quality",
  "category": "tests",
  "stage": "ValidateAndTest",
  "status": "FAILED",
  "metrics": {
    "passed": 142,
    "failed": 2,
    "skipped": 1,
    "total": 145,
    "framework": "Tosca / UiPath adapter"
  }
}
```

## Central quality gate event

```json
{
  "pipeline": "ApplicationDeliveryPipeline",
  "executionId": "8abc75f0-fbf8-4f4c-bf00-example",
  "kind": "quality",
  "category": "qualityGate",
  "stage": "CentralQualityGate",
  "status": "SUCCEEDED",
  "metrics": {
    "decision": "PASS",
    "reason": "All required SAST and test thresholds were satisfied."
  }
}
```

## Bedrock analysis event

```json
{
  "pipeline": "ApplicationDeliveryPipeline",
  "executionId": "8abc75f0-fbf8-4f4c-bf00-example",
  "kind": "bedrock",
  "stage": "ValidateAndTest",
  "status": "SUCCEEDED",
  "summary": "Two automated tests failed after an application response contract changed.",
  "rootCause": "The test fixture expects the previous field name.",
  "recommendedActions": [
    "Confirm the schema change is intentional.",
    "Update the fixture and rerun the failed tests.",
    "Revert the application contract if the change is unintended."
  ],
  "modelId": "YOUR_BEDROCK_MODEL_OR_PROFILE",
  "analysisId": "optional-correlation-id"
}
```

**Do not publish raw failure logs, credentials, prompts, request headers, secrets, or full ServiceNow/Jira payloads to the dashboard.** Publish only the summarized fields that are safe for the intended viewers.
