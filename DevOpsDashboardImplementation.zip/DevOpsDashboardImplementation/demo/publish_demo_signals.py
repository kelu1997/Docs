#!/usr/bin/env python3
"""Rehearsal/UI wiring helper.

This publishes dashboard-only custom events. It does NOT call ServiceNow, Jira, or Bedrock.
Use it only to validate the dashboard layout or rehearse the presentation; do not present
these events as evidence that an external system was actually updated.
"""

import argparse
import json
import time
from datetime import datetime, timezone

import boto3


def ts():
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--region', required=True)
    p.add_argument('--pipeline', required=True)
    p.add_argument('--execution-id', required=True)
    p.add_argument('--source', default='devops.pipeline.dashboard')
    args = p.parse_args()

    eb = boto3.client('events', region_name=args.region)

    def send(detail):
        detail = {'pipeline': args.pipeline, 'executionId': args.execution_id, 'timestamp': ts(), **detail}
        resp = eb.put_events(Entries=[{
            'Source': args.source,
            'DetailType': 'DevOps Dashboard Signal',
            'Detail': json.dumps(detail),
            'EventBusName': 'default'
        }])
        print(json.dumps({'failed': resp.get('FailedEntryCount'), 'detail': detail}, indent=2))
        time.sleep(1)

    send({'kind': 'quality', 'category': 'sast', 'stage': 'SAST', 'status': 'SUCCEEDED',
          'title': 'SAST scan completed',
          'metrics': {'critical': 0, 'high': 1, 'medium': 3, 'low': 7, 'tool': 'Demo SAST scanner'}})
    send({'kind': 'integration', 'integration': 'ServiceNow', 'operation': 'SAST status update',
          'stage': 'SAST', 'status': 'SUCCEEDED', 'externalId': 'CHG-DEMO-1042',
          'message': 'Rehearsal event: dashboard wiring only; no external API call was made.'})
    send({'kind': 'quality', 'category': 'tests', 'stage': 'ValidateAndTest', 'status': 'FAILED',
          'title': 'Automated test results available',
          'metrics': {'passed': 142, 'failed': 2, 'skipped': 1, 'total': 145, 'framework': 'Tosca / UiPath adapter'}})
    send({'kind': 'integration', 'integration': 'Jira', 'operation': 'Test failure status update',
          'stage': 'ValidateAndTest', 'status': 'SUCCEEDED', 'externalId': 'DEMO-142',
          'message': 'Rehearsal event: dashboard wiring only; no external API call was made.'})
    send({'kind': 'bedrock', 'stage': 'ValidateAndTest', 'status': 'SUCCEEDED',
          'modelId': 'demo-model',
          'summary': 'Two automated tests failed after a validation rule changed the expected response contract.',
          'rootCause': 'The test fixture still expects the previous field name while the application returns the revised schema.',
          'recommendedActions': [
              'Confirm the schema change is intentional and update the test fixture.',
              'Rerun the failed tests before allowing the quality gate to pass.',
              'If the schema change is not intentional, revert the application contract change.'
          ]})


if __name__ == '__main__':
    main()
