# Insert immediately after the existing ServiceNow API response is validated.
from dashboard_events import integration_status


def publish_servicenow_dashboard_status(execution_id, stage, change_number, change_url, api_response):
    integration_status(
        execution_id=execution_id,
        integration="ServiceNow",
        operation="Change record status update",
        status="SUCCEEDED",
        stage=stage,
        external_id=change_number,
        external_url=change_url,
        message=f"ServiceNow accepted the pipeline status update (HTTP {api_response.status_code}).",
    )
