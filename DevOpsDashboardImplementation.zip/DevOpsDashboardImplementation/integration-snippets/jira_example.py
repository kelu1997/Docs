# Insert immediately after the existing Jira API response is validated.
from dashboard_events import integration_status


def publish_jira_dashboard_status(execution_id, stage, issue_key, issue_url):
    integration_status(
        execution_id=execution_id,
        integration="Jira",
        operation="Issue / deployment status update",
        status="SUCCEEDED",
        stage=stage,
        external_id=issue_key,
        external_url=issue_url,
        message="Jira status and pipeline execution reference were updated successfully.",
    )
