"""Small helper to publish sanitized sidecar status to the dashboard through EventBridge.

Copy this module into existing ServiceNow/Jira/quality/Bedrock Lambdas. The calling
Lambda role needs events:PutEvents on the default event bus in the pipeline Region.
"""

import json
import os
from datetime import datetime, timezone
from typing import Iterable, Optional

import boto3

EVENT_SOURCE = os.environ.get("DASHBOARD_EVENT_SOURCE", "devops.pipeline.dashboard")
EVENT_REGION = os.environ.get("DASHBOARD_EVENT_REGION") or os.environ.get("AWS_REGION")
EVENT_BUS = os.environ.get("DASHBOARD_EVENT_BUS", "default")
PIPELINE_NAME = os.environ.get("PIPELINE_NAME")

events = boto3.client("events", region_name=EVENT_REGION)


def _now():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def publish(detail: dict, detail_type: str = "DevOps Dashboard Signal"):
    payload = {
        "pipeline": detail.get("pipeline") or PIPELINE_NAME,
        "timestamp": detail.get("timestamp") or _now(),
        **detail,
    }
    if not payload.get("pipeline"):
        raise ValueError("pipeline is required; set PIPELINE_NAME or pass detail['pipeline']")

    response = events.put_events(
        Entries=[
            {
                "Source": EVENT_SOURCE,
                "DetailType": detail_type,
                "Detail": json.dumps(payload),
                "EventBusName": EVENT_BUS,
            }
        ]
    )
    if response.get("FailedEntryCount", 0):
        raise RuntimeError(f"EventBridge PutEvents failed: {response.get('Entries')}")
    return response


def integration_status(*, execution_id: str, integration: str, operation: str, status: str,
                       stage: Optional[str] = None, external_id: Optional[str] = None,
                       external_url: Optional[str] = None, message: Optional[str] = None):
    return publish({
        "kind": "integration",
        "executionId": execution_id,
        "integration": integration,
        "operation": operation,
        "status": status,
        "stage": stage,
        "externalId": external_id,
        "externalUrl": external_url,
        "message": message,
    })


def quality_signal(*, execution_id: str, category: str, status: str, metrics: dict,
                   stage: Optional[str] = None, title: Optional[str] = None,
                   message: Optional[str] = None):
    return publish({
        "kind": "quality",
        "executionId": execution_id,
        "category": category,
        "status": status,
        "stage": stage,
        "metrics": metrics,
        "title": title,
        "message": message,
    })


def bedrock_analysis(*, execution_id: str, status: str, summary: str,
                     root_cause: Optional[str] = None,
                     recommended_actions: Optional[Iterable[str]] = None,
                     stage: Optional[str] = None, model_id: Optional[str] = None,
                     analysis_id: Optional[str] = None):
    # Publish only summarized/sanitized fields. Do not send raw logs or prompts to the dashboard.
    return publish({
        "kind": "bedrock",
        "executionId": execution_id,
        "status": status,
        "stage": stage,
        "summary": summary,
        "rootCause": root_cause,
        "recommendedActions": list(recommended_actions or []),
        "modelId": model_id,
        "analysisId": analysis_id,
    })
