from dashboard_events import quality_signal


def publish_sast(execution_id, stage, critical, high, medium, low, tool="SAST scanner"):
    quality_signal(
        execution_id=execution_id,
        category="sast",
        status="SUCCEEDED" if critical == 0 else "FAILED",
        stage=stage,
        title="SAST scan completed",
        metrics={
            "critical": critical,
            "high": high,
            "medium": medium,
            "low": low,
            "tool": tool,
        },
    )


def publish_tests(execution_id, stage, passed, failed, skipped=0, framework="Automated test adapter"):
    total = passed + failed + skipped
    quality_signal(
        execution_id=execution_id,
        category="tests",
        status="SUCCEEDED" if failed == 0 else "FAILED",
        stage=stage,
        title="Automated test results available",
        metrics={
            "passed": passed,
            "failed": failed,
            "skipped": skipped,
            "total": total,
            "framework": framework,
        },
    )


def publish_quality_gate(execution_id, stage, passed, reason):
    quality_signal(
        execution_id=execution_id,
        category="qualityGate",
        status="SUCCEEDED" if passed else "FAILED",
        stage=stage,
        title="Central quality gate evaluated",
        message=reason,
        metrics={
            "decision": "PASS" if passed else "FAIL",
            "reason": reason,
        },
    )
