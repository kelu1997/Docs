# Insert after your existing Bedrock failure analyzer has produced its final, sanitized response.
from dashboard_events import bedrock_analysis


def publish_bedrock_dashboard_response(execution_id, failed_stage, model_id, result):
    # result is expected to be the structured output from your existing failure-analysis sidecar.
    bedrock_analysis(
        execution_id=execution_id,
        status="SUCCEEDED",
        stage=failed_stage,
        summary=result["summary"],
        root_cause=result.get("rootCause"),
        recommended_actions=result.get("recommendedActions", []),
        model_id=model_id,
        analysis_id=result.get("analysisId"),
    )
