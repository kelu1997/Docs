# Private S3 + CloudFront OAC + WAF DevOps Sales Dashboard
## Implementation Package and Console-First Guide

**Target architecture:** private S3 origin, CloudFront Origin Access Control (OAC), AWS WAF default-block IP allowlist, static React + Cloudscape UI, EventBridge + Lambda telemetry, and lightweight custom events from ServiceNow/Jira/quality/Bedrock sidecars.

**Design objective:** produce a polished, live sales-demo dashboard while changing as little as possible in a shared AWS environment. The dashboard introduces **no VPC, subnet, route-table, NAT, internet-gateway, VPN, ALB, ECS, EC2, API Gateway, or Cognito dependency**.

---

# 1. What this package builds

The package creates two intentionally separated stacks.

## Edge stack - deploy in `us-east-1`

- Private Amazon S3 dashboard bucket
- S3 Block Public Access enabled
- CloudFront Origin Access Control (OAC), SigV4 signing always enabled
- CloudFront distribution using the normal S3 bucket origin (not S3 Website Hosting)
- AWS WAF Web ACL with **default BLOCK**
- WAF IPv4 IP set containing only approved presenter/corporate public CIDRs
- CloudFront IPv6 disabled so only the IPv4 allowlist must be managed
- `data/*` CloudFront cache behavior with caching disabled
- security response headers
- CloudFront default HTTPS certificate and hostname
- S3 lifecycle rules that expire noncurrent object versions and abandoned multipart uploads, so the versioned bucket does not grow indefinitely as the telemetry Lambda rewrites its snapshot

## Telemetry stack - deploy in the CodePipeline Region

- One Python Lambda telemetry adapter
- IAM role with read-only access to the selected pipeline and read/write access only to `s3://<dashboard-bucket>/data/*`
- EventBridge rule for CodePipeline pipeline/stage/action state changes
- EventBridge rule for custom dashboard events from ServiceNow, Jira, SAST, testing, the quality gate, Bedrock, and future sidecars
- One-minute reconciliation rule so a missed best-effort CodePipeline event cannot leave the display stale indefinitely, switchable with the `HeartbeatState` parameter so it can be turned off between demos
- Lambda reserved concurrency of 1 so S3 can safely serve as the lightweight state store for this demo

## Static UI

- React
- AWS Cloudscape Design System
- live five-second polling by default
- responsive stage progress ribbon
- current execution / branch / commit metadata
- execution duration
- recent success-rate KPI
- SAST severity metrics
- automated test counts and pass rate
- central quality-gate result
- ServiceNow/Jira/external update feed with record links
- Bedrock failure-analysis panel
- unified activity timeline
- recent pipeline execution history

---

# 2. Architecture

```text
APPROVED PRESENTER / CORPORATE NETWORK
                 |
              HTTPS 443
                 |
                 v
       +--------------------+
       | AWS WAF Web ACL    |
       | Default: BLOCK     |
       | Allow: approved IP |
       +---------+----------+
                 |
                 v
       +--------------------+
       | Amazon CloudFront  |
       | GET / HEAD only    |
       | IPv6 disabled      |
       +---------+----------+
                 |
              OAC / SigV4
                 |
                 v
       +--------------------+
       | PRIVATE S3 BUCKET  |
       | index.html         |
       | assets/*           |
       | config.json        |
       | data/dashboard.json|<----------------------+
       +--------------------+                       |
                                                    |
                                         PutObject  |
                                                    |
                               +--------------------+----------------+
                               | Dashboard Telemetry Lambda          |
                               | CodePipeline APIs + event merge     |
                               +--------------------+----------------+
                                                    ^
                                                    |
                              +---------------------+--------------------+
                              |                                          |
                    CodePipeline state events                  Custom dashboard events
                              |                                          |
                        EventBridge                               EventBridge default bus
                              |                                          ^
                              |                                          |
                  Existing CodePipeline                 ServiceNow / Jira / SAST / Tests /
                                                        Quality Gate / Bedrock / future sidecars
```

The dashboard is **not** in the pipeline execution path. If CloudFront, WAF, the UI, or the telemetry Lambda is unavailable, the actual CI/CD pipeline can continue independently.

---

# 3. Files in the package

```text
DevOpsDashboardImplementation/
├── IMPLEMENTATION_GUIDE.md
├── CONSOLE_MANUAL_SETUP.md
├── README.md
├── cloudformation/
│   ├── 01-edge-stack-us-east-1.yaml
│   └── 02-telemetry-stack-pipeline-region.yaml
├── dashboard/
│   ├── package.json
│   ├── vite.config.js
│   ├── index.html
│   ├── public/config.json
│   └── src/
│       ├── main.jsx
│       ├── App.jsx
│       ├── api.js
│       └── styles.css
├── telemetry/
│   ├── handler.py
│   └── EVENT_CONTRACT.md
├── integration-snippets/
│   ├── dashboard_events.py
│   ├── service_now_example.py
│   ├── jira_example.py
│   ├── quality_examples.py
│   ├── bedrock_example.py
│   └── sidecar-putevents-policy.json
├── scripts/
│   ├── build-dashboard.sh
│   ├── deploy-dashboard.sh
│   ├── upload-dashboard.sh
│   └── get-edge-outputs.sh
└── demo/
    ├── DEMO_RUNBOOK.md
    └── publish_demo_signals.py
```

---

# 4. Pre-implementation decisions

Collect these values before starting.

| Value | Example | Notes |
|---|---|---|
| Pipeline Region | `us-east-2` | The Region containing your existing CodePipeline |
| Pipeline name | `ApplicationDeliveryPipeline` | Exact CodePipeline name |
| Presenter public IPv4 CIDR | `198.51.100.24/32` | Use the public IP seen from the presenter browser/network |
| Optional corporate CIDR | `198.51.100.0/24` | Only if your security/network team confirms it |
| Edge stack Region | `us-east-1` | Required by CloudFront-scoped WAF resources |
| Custom event source | `devops.pipeline.dashboard` | Keep the package default unless you have a naming standard |
| Noncurrent version retention | `7` days | Lifecycle expiry for old `dashboard.json` snapshot versions in the versioned bucket |
| Heartbeat state | `ENABLED` | Leave enabled while demoing; set `DISABLED` between demos to stop continuous background refresh |

### Determine the presenter public IP

From the **same laptop and network/VPN that will open the dashboard**, open `https://checkip.amazonaws.com` in the browser. If it returns an IPv4 address such as `198.51.100.24`, use `198.51.100.24/32` in the WAF IP set.

Do **not** use the public IP of AWS CloudShell; that is not the source address of the presenter browser.

### Security meaning of the WAF approach

This design is network-restricted, not identity-authenticated. Anyone who can originate traffic from an allowed NAT/VPN/public CIDR and knows the CloudFront URL can load the page. That is usually appropriate for a controlled sales demo, but it is not equivalent to per-user SSO. The S3 bucket itself remains private.

---

# 5. Deploy the edge stack - console steps

> Deploying without CloudFormation? Use `CONSOLE_MANUAL_SETUP.md` instead of this section and
> section 7. It creates the same resources by hand and includes a parameter-to-console mapping table
> so the two approaches can be compared. Sections 6 and 8 onward apply either way.

## 5.1 Switch to the required Region

1. Sign in to the AWS Management Console.
2. In the Region selector, choose **US East (N. Virginia) - `us-east-1`**.
3. Open **CloudFormation**.

CloudFront is global, but CloudFront-scoped AWS WAF API operations are managed through `us-east-1`; keeping the entire edge stack in that Region makes deployment and lifecycle management simple.

## 5.2 Create the stack

1. Choose **Create stack** > **With new resources (standard)**.
2. Under **Specify template**, choose **Upload a template file**.
3. Upload:
   `cloudformation/01-edge-stack-us-east-1.yaml`
4. Choose **Next**.
5. Stack name:
   `DevOpsSalesDashboard-Edge`
6. Set **ProjectName** to something short, for example:
   `DevOpsSalesDashboard`
7. Set **AllowedIPv4Cidrs** to the approved presenter address, for example:
   `198.51.100.24/32`
8. To allow more than one source, enter comma-separated CIDRs, for example:
   `198.51.100.24/32,203.0.113.0/24`
9. Leave **EnvironmentLabel** as `SalesDemo` or rename it for the client/demo. The value must match `^[A-Za-z0-9_-]{2,30}$`, so use `AcmeDemo` rather than `Acme Demo`.
10. Leave **NoncurrentVersionRetentionDays** at `7` unless your account has a different retention standard. The bucket is versioned and the telemetry Lambda rewrites `data/dashboard.json` on every event, so this lifecycle rule is what stops old snapshot versions accumulating indefinitely.
11. Choose **Next**.
12. Leave stack options at their normal defaults unless the account requires standard tags/notifications.
13. Choose **Next**.
14. Review the template and choose **Submit**.
15. Wait until the stack reaches **CREATE_COMPLETE**.

## 5.3 Capture the outputs

Open the stack and select **Outputs**. Record:

- `DashboardBucketName`
- `DashboardDistributionId`
- `DashboardDistributionDomain`
- `DashboardUrl`
- `AllowedViewerIPv4SetArn`

At this point the CloudFront URL can return an error because the UI files have not been uploaded yet. That is expected.

## 5.4 Verify the security configuration in the console

### S3

1. Open **S3**.
2. Open the new dashboard bucket.
3. **Permissions** > **Block public access** should show all four settings enabled.
4. **Permissions** > **Bucket policy** should contain:
   - CloudFront service principal `cloudfront.amazonaws.com`
   - `s3:GetObject`
   - condition limiting access to the specific CloudFront distribution ARN
   - deny for insecure transport
5. **Management** > **Lifecycle rules** should show `ExpireNoncurrentDashboardVersions` and `AbortIncompleteMultipartUploads` enabled.
6. Do **not** enable S3 static website hosting.

### CloudFront

1. Open **CloudFront** > **Distributions**.
2. Select the new distribution.
3. On **Origins**, confirm the S3 origin uses **Origin access control settings**.
4. On **Behaviors**, confirm:
   - default `/*` behavior uses normal static caching
   - `data/*` behavior uses **CachingDisabled**
   - Viewer protocol policy redirects to HTTPS
   - allowed methods are only `GET, HEAD`
5. Confirm **IPv6** is disabled.
6. On **Security**, confirm the expected WAF Web ACL is attached.

### WAF

1. Open **WAF & Shield** while still in `us-east-1`.
2. Open the new Web ACL.
3. Confirm the **Default action** is **Block**.
4. Confirm the first rule allows only the approved IPv4 IP set.

---

# 6. Configure and build the Cloudscape UI

You can build locally or in AWS CloudShell. CloudShell is convenient because the AWS CLI is already authenticated, but the package build itself does not require access to your VPC.

## 6.1 Optional: customize the dashboard labels

Edit:

`dashboard/public/config.json`

Example:

```json
{
  "title": "Client Application Delivery Control Center",
  "subtitle": "Secure automated delivery and quality orchestration",
  "environment": "Client Sales Demo",
  "eyebrow": "ACCENTURE | AWS DEVOPS DEMONSTRATION",
  "logoUrl": "/brand-logo.svg",
  "logoAlt": "Accenture",
  "refreshSeconds": 5,
  "dataUrl": "/data/dashboard.json"
}
```

`eyebrow`, `logoUrl`, and `logoAlt` are optional. Omit `logoUrl` to hide the brand mark entirely.
Any key you leave out falls back to the defaults in `App.jsx`. `title` also sets the browser tab
label at runtime, so `index.html` does not need editing.

`logoUrl` must resolve to a same-origin path. The distribution's Content-Security-Policy sets
`img-src 'self' data:`, so a logo referenced from an external CDN or marketing site will be blocked by
the browser. Put the file in `dashboard/public/` and it is served from the distribution root.

Do not put secrets, account numbers, internal hostnames, ServiceNow credentials, Jira credentials, or
Bedrock prompts into this file. It is delivered to the viewer browser.

## 6.2 CloudShell method

1. Open **AWS CloudShell** from the console.
2. Use **Actions** > **Upload file** and upload the implementation package ZIP.
3. In CloudShell:

```bash
unzip DevOpsDashboardImplementation.zip
cd DevOpsDashboardImplementation
chmod +x scripts/*.sh
./scripts/build-dashboard.sh
```

The `chmod` line matters if the archive was repacked on Windows at any point. PowerShell's
`Compress-Archive` does not record Unix permission bits, so the scripts extract as mode `644` and
`./scripts/build-dashboard.sh` returns `permission denied`. Running `chmod +x` first is harmless when
the bit is already present. `bash scripts/build-dashboard.sh` also works and ignores the bit entirely.

The build script runs `npm install` and `npm run build`. Cloudscape is a React design system and the package imports both `@cloudscape-design/components` and `@cloudscape-design/global-styles`.

## 6.3 Upload the UI to the private S3 bucket

Deployment is always two steps, because `dashboard/dist/` is generated output and is not shipped in the
archive. Either run them in order:

```bash
bash scripts/build-dashboard.sh
bash scripts/upload-dashboard.sh \
  YOUR_DASHBOARD_BUCKET_NAME \
  YOUR_CLOUDFRONT_DISTRIBUTION_ID
```

or use the single-step wrapper, which does the same thing and cannot be run out of order:

```bash
bash scripts/deploy-dashboard.sh \
  YOUR_DASHBOARD_BUCKET_NAME \
  YOUR_CLOUDFRONT_DISTRIBUTION_ID
```

Running the upload on its own before a build fails with `Dashboard dist/ not found`. That is the guard
working, not a packaging problem.

The upload script deliberately excludes `data/*` from `--delete`, so a later UI deployment cannot erase the live telemetry snapshots generated by Lambda.

The script also creates a CloudFront invalidation so the new UI shell is loaded on the next refresh.

## 6.4 Initial browser test

1. From a source IP that is in the WAF IP set, open the `DashboardUrl` output.
2. The UI should load.
3. Before the telemetry stack is seeded, it may display a warning that `/data/dashboard.json` is unavailable. That is expected.
4. The page should still render the polished dashboard shell.

---

# 7. Deploy the telemetry stack - console steps

## 7.1 Change to the CodePipeline Region

Use the Region selector to choose the Region containing the existing pipeline, for example `us-east-2`.

This keeps the CodePipeline EventBridge rule and telemetry Lambda local to the pipeline and avoids creating a cross-Region EventBridge bus route.

## 7.2 Create the telemetry stack

1. Open **CloudFormation** in the pipeline Region.
2. Choose **Create stack** > **With new resources (standard)**.
3. Choose **Upload a template file**.
4. Upload:
   `cloudformation/02-telemetry-stack-pipeline-region.yaml`
5. Choose **Next**.
6. Stack name:
   `DevOpsSalesDashboard-Telemetry`
7. Parameters:
   - **PipelineName**: exact existing CodePipeline name
   - **DashboardBucketName**: `DashboardBucketName` from the edge stack
   - **DashboardBucketRegion**: `us-east-1`
   - **DashboardEventSource**: keep `devops.pipeline.dashboard`
   - **HistoryLimit**: `12` is a good sales-demo default
   - **HeartbeatState**: keep `ENABLED` for deployment and rehearsal. See section 21 for when to set it to `DISABLED`.
   - **WriteExecutionSnapshots**: keep `DISABLED`. The UI does not read per-execution snapshot files, and leaving this off halves the S3 writes made by the reconciliation refresh.
8. Choose **Next**.
9. Continue through stack options.
10. On the final page acknowledge that CloudFormation will create IAM resources.
11. Choose **Submit**.
12. Wait for **CREATE_COMPLETE**.

## 7.3 Seed the first dashboard snapshot

1. Open the telemetry stack **Outputs**.
2. Copy `DashboardTelemetryFunctionName`.
3. Open **Lambda** in the same Region.
4. Open that function.
5. Choose the **Test** tab.
6. Create a new test event named `SeedDashboard` with:

```json
{}
```

7. Choose **Test**.
8. Expected result contains values similar to:

```json
{
  "ok": true,
  "bucket": "...",
  "key": "data/dashboard.json",
  "executionId": "...",
  "status": "SUCCEEDED"
}
```

9. Open **S3** in `us-east-1` and verify `data/dashboard.json` now exists.
10. Refresh the CloudFront dashboard. It should populate with the actual pipeline structure, latest execution, stage/action status, revision metadata, and recent history.

---

# 8. How live pipeline progress works

CodePipeline emits pipeline, stage, and action state-change events to EventBridge. The telemetry Lambda uses those events as a fast trigger, then reads the authoritative execution state from CodePipeline APIs.

For the current execution it uses:

- `GetPipeline` to establish stage/action structure and stage ordering
- `GetPipelineExecution` for execution status, revision metadata, trigger, and execution ID
- `ListActionExecutions` filtered to the latest action executions within the current pipeline execution for action status, start/update times, execution summaries, errors, and external execution URLs
- `ListPipelineExecutions` for recent history and the success-rate / average-duration KPIs

The browser does **not** call CodePipeline APIs and contains **no AWS credentials**. It only fetches the sanitized JSON snapshot through the same CloudFront hostname.

The UI polls `/data/dashboard.json` every five seconds by default. The CloudFront `data/*` behavior uses AWS's managed `CachingDisabled` policy, so CloudFront does not serve a cached telemetry snapshot.

---

# 9. Instrument ServiceNow, Jira, quality, and Bedrock sidecars

The most useful demo information is not always present in CodePipeline itself. CodePipeline can show that an integration action succeeded, but it cannot automatically tell the dashboard that ServiceNow updated `CHG003142` or that Jira updated `DEMO-142` unless your integration publishes that result.

This package therefore adds a very small generic event publisher.

## 9.1 Add EventBridge publish permission to existing sidecar roles

Open the telemetry stack output `DefaultEventBusArn`, which looks like:

```text
arn:aws:events:PIPELINE_REGION:ACCOUNT_ID:event-bus/default
```

For every existing Lambda/adapter that will send a dashboard signal:

1. Open **IAM** > **Roles**.
2. Open the role used by that integration Lambda.
3. Choose **Add permissions** > **Create inline policy**.
4. Use the JSON editor.
5. Copy `integration-snippets/sidecar-putevents-policy.json`.
6. Replace `PIPELINE_REGION` and `ACCOUNT_ID`.
7. Save the policy as `PublishDevOpsDashboardSignals`.

The permission grants only `events:PutEvents` to the default event bus in the pipeline Region.

## 9.2 Copy the helper into each integration package

Copy:

`integration-snippets/dashboard_events.py`

into the existing Lambda package (or a shared Lambda layer if your sidecar package already uses one).

Recommended environment variables on the sidecar Lambda:

```text
DASHBOARD_EVENT_SOURCE=devops.pipeline.dashboard
DASHBOARD_EVENT_REGION=<pipeline-region>
DASHBOARD_EVENT_BUS=default
PIPELINE_NAME=<exact-pipeline-name>
```

If a sidecar Lambda is in another Region, explicitly set `DASHBOARD_EVENT_REGION` to the CodePipeline Region so its EventBridge client sends the custom event to the bus that contains the telemetry rule.

---

# 10. Propagate the CodePipeline execution ID

Every custom event should carry the real pipeline execution ID. CodePipeline exposes the implicit variable:

```text
#{codepipeline.PipelineExecutionId}
```

Use it wherever the pipeline passes execution context into the sidecar.

### Example - CodeBuild environment variable

```text
Name: PIPELINE_EXECUTION_ID
Value: #{codepipeline.PipelineExecutionId}
Type: Plaintext
```

### Example - Lambda action UserParameters

Use a JSON string such as:

```json
{
  "pipelineExecutionId": "#{codepipeline.PipelineExecutionId}"
}
```

### Example - Step Functions wrapper

If an existing Lambda invokes your Step Functions sidecar, add the field to the Step Functions input:

```json
{
  "pipelineExecutionId": "<resolved CodePipeline execution ID>",
  "stage": "SAST",
  "status": "SUCCEEDED"
}
```

Your existing sidecar architecture can remain adaptive. The dashboard does not require fixed stage-to-ServiceNow/Jira mappings; it simply correlates events by execution ID.

If the ID is wrong or missing, the event is correlated against whatever execution the dashboard is
currently tracking. A mismatched ID means the event is dropped from the current-run cards and shown
only in the timeline as historical; it cannot pull the display back to an older execution. That makes
a propagation mistake a visible gap rather than a corrupted dashboard, but it is still a gap, so
verify the ID reaches every sidecar during rehearsal.

---

# 11. ServiceNow status events

Immediately after the existing ServiceNow API response is validated, publish a dashboard event.

Example:

```python
from dashboard_events import integration_status

integration_status(
    execution_id=pipeline_execution_id,
    integration="ServiceNow",
    operation="Change record status update",
    status="SUCCEEDED",
    stage=current_stage,
    external_id=change_number,
    external_url=change_url,
    message="ServiceNow accepted the pipeline status update.",
)
```

On a real ServiceNow failure, publish `FAILED` **before re-raising the error**:

```python
try:
    response = call_servicenow(...)
    response.raise_for_status()
    integration_status(..., status="SUCCEEDED", message="ServiceNow update accepted")
except Exception as exc:
    integration_status(
        execution_id=pipeline_execution_id,
        integration="ServiceNow",
        operation="Change record status update",
        status="FAILED",
        stage=current_stage,
        message="ServiceNow update failed. See integration logs for operational detail."
    )
    raise
```

Do not put credentials, headers, complete request bodies, or raw response bodies into the dashboard message.

For a demo with ServiceNow updates after multiple stages, publish one event after each update. The UI feed deliberately retains multiple ServiceNow rows for the same execution.

---

# 12. Jira status events

The Jira pattern is identical:

```python
from dashboard_events import integration_status

integration_status(
    execution_id=pipeline_execution_id,
    integration="Jira",
    operation="Test / deployment status update",
    status="SUCCEEDED",
    stage=current_stage,
    external_id=issue_key,
    external_url=issue_url,
    message="Jira issue status and pipeline reference updated successfully.",
)
```

The dashboard is generic: future outbound systems can use `integration="Teams"`, `integration="Slack"`, `integration="Email"`, `integration="Change Manager"`, or any other display name without a dashboard code change.

---

# 13. SAST metrics

At the end of the SAST adapter, publish only the summary counts needed by the dashboard.

```python
from dashboard_events import quality_signal

quality_signal(
    execution_id=pipeline_execution_id,
    category="sast",
    status="SUCCEEDED",
    stage="SAST",
    title="SAST scan completed",
    metrics={
        "critical": 0,
        "high": 1,
        "medium": 4,
        "low": 8,
        "tool": "Your SAST product"
    }
)
```

If the SAST policy fails the stage, use `status="FAILED"`. The dashboard can then show both the CodePipeline stage failure and the actual severity counts.

---

# 14. Tosca / UiPath / automated test metrics

The test adapter should publish a normalized summary after it has parsed the external test product response.

```python
quality_signal(
    execution_id=pipeline_execution_id,
    category="tests",
    status="FAILED" if failed_count else "SUCCEEDED",
    stage="ValidateAndTest",
    title="Automated test results available",
    metrics={
        "passed": 142,
        "failed": 2,
        "skipped": 1,
        "total": 145,
        "framework": "Tosca"
    }
)
```

The same event shape works for UiPath; only the `framework` label changes. This intentionally preserves your ability to swap or combine test adapters without changing the UI contract.

---

# 15. Central quality gate

When the central gate evaluates all required evidence, publish:

```python
quality_signal(
    execution_id=pipeline_execution_id,
    category="qualityGate",
    status="SUCCEEDED" if gate_passed else "FAILED",
    stage="CentralQualityGate",
    title="Central quality gate evaluated",
    message=reason,
    metrics={
        "decision": "PASS" if gate_passed else "FAIL",
        "reason": reason
    }
)
```

For the sales demo this creates a very clear story:

```text
SAST evidence + automated test evidence
              |
              v
       CENTRAL QUALITY GATE
              |
       PASS / FAIL decision
              |
              v
  ServiceNow / Jira status updates
```

---

# 16. Bedrock failure-analysis response

Your existing Bedrock sidecar remains responsible for gathering the appropriate failure context and invoking the chosen Bedrock model. The dashboard package should **not invoke Bedrock a second time**.

After your existing analyzer has produced its final structured response, publish only sanitized summary fields:

```python
from dashboard_events import bedrock_analysis

bedrock_analysis(
    execution_id=pipeline_execution_id,
    status="SUCCEEDED",
    stage=failed_stage,
    summary=result["summary"],
    root_cause=result.get("rootCause"),
    recommended_actions=result.get("recommendedActions", []),
    model_id=model_id,
    analysis_id=result.get("analysisId")
)
```

The dashboard behavior is deliberately staged:

1. CodePipeline failure is detected.
2. Failed stage turns red immediately.
3. Bedrock panel changes to **Awaiting Analysis**.
4. Existing failure-analysis sidecar invokes Bedrock.
5. Sidecar publishes the custom Bedrock event.
6. Bedrock panel changes to complete and displays:
   - concise failure summary
   - likely root cause
   - recommended actions
   - source stage
   - model/profile identifier
   - analysis time

The telemetry Lambda contains defensive redaction/truncation, but that is not a substitute for correct data handling. **Do not publish raw logs, raw prompts, credentials, tokens, headers, secrets, or confidential payloads to the dashboard.**

---

# 17. Screen layout

The UI is a shell plus six switchable screens. The shell is always on screen; only the main area
changes.

## Persistent shell

- **Hero** — brand mark, eyebrow, title, subtitle, live indicator, manual refresh, and a metadata strip
  showing pipeline, status, elapsed time, branch, commit and telemetry age.
- **Left navigation** — the six screens, each with a live status marker: red `Failed` on Pipeline when a
  stage fails, red `Blocked` on Quality when the gate fails, an update count on Governance, and
  `Analysing` / `Ready` on AI failure assist.
- **Pinned stage rail** — below the navigation, a vertical list of every stage with status and duration,
  discovered live from the pipeline definition. This is the reason the layout works for a demo: pipeline
  progress never leaves the screen, whichever drill-down you are on.

## Navigation and deep links

Screens are addressed by URL fragment: `#/overview`, `#/pipeline`, `#/quality`, `#/governance`, `#/ai`,
`#/trends`. Fragments are deliberate rather than paths. The distribution serves a private S3 origin with
no custom error responses, so a path such as `/quality` would ask S3 for an object that does not exist
and OAC would return 403, breaking refresh and any bookmarked link. Fragments keep deep links and the
browser back button working with no CloudFront change.

A single five-second poll of `data/dashboard.json` feeds every screen. Switching screens re-renders the
same in-memory snapshot, so there is no extra request, no per-screen loading state, and no lag when
navigating live.

## The six screens

**Overview** — five headline metrics (pipeline state, elapsed, gate decision, test pass rate, success
rate), a stage time-distribution bar with per-stage share, queue and transition overhead, slowest stage
and action, condensed quality and governance summaries, latest activity, and recent performance. Each
panel links through to its drill-down.

**Pipeline detail** — wall clock versus summed stage execution time, queue overhead as a percentage,
progress, action counts. A stage table comparing this run against the pipeline's own average, median and
fastest/slowest, with a delta column. A full action table with start, update, duration, error code,
summary and external execution links. Revision metadata.

**Quality evidence** — gate decision, blocking findings, weighted risk score, pass rate, load p95.
Static analysis severity breakdown with total findings and a 10/5/2/1 weighted risk score. Test
breakdown with pass rate of all tests, pass rate of executed tests, fail rate and skip coverage. Load
result, p95 latency and error rate. The gate verdict with its reasoning split into individual blocking
reasons.

**Governance** — updates sent, delivery rate, distinct records touched, and average, fastest and slowest
latency from stage completion to record update. A per-system table with delivery rate and record ids,
then the full update feed with external record links.

**AI failure assist** — analysis state, source stage, response time from failure to published analysis,
and recommended action count. The analysis panel with summary, likely root cause and numbered
remediation steps. While no failure has occurred it explains what will happen instead of showing an
empty panel.

**Trends and history** — success rate, average, median and 90th percentile duration, a consistency
figure derived from duration spread, throughput in runs per day, fastest and slowest runs, success
streak and time since last failure. A duration sparkline across the window. **Average time per stage**,
which is what answers questions like average time to reach the test environment. Execution history with
a per-run delta against the average. Telemetry health showing snapshot, last event and reconciliation
ages.

## Where the numbers come from

Almost every figure is derived in the browser from the single snapshot by `dashboard/src/stats.js`, so
adding or changing a metric needs no telemetry change.

The exception is `kpis.stageAverages`. CodePipeline's `ListPipelineExecutions` returns only
whole-execution durations, so per-stage history for *past* executions does not exist in the API. The
telemetry Lambda therefore accumulates it in a `stageStats` object keyed by execution id, pruned to the
executions still present in `history` so it stays bounded by `HistoryLimit` with no separate retention
rule. Only completed executions contribute to an average; an in-progress run's stage durations are still
growing and would drag every figure down.

Consequences worth knowing:

- Stage averages are empty until the first execution completes after deploying this version. They fill
  in as runs finish.
- `stageStats` survives the run-scoped reset that clears the quality, integration and AI cards, because
  it spans executions.
- Raising `HistoryLimit` widens both the trend window and the stage-average sample count.

The included React app implements the following hierarchy.

## Hero area

- client/application delivery title
- environment label
- animated `LIVE` indicator
- pipeline name
- execution ID
- branch
- commit ID
- telemetry freshness age

## KPI strip

- current pipeline status and active/failed stage
- execution duration
- recent success rate
- central quality-gate result
- count of successful outbound automation updates

## Live pipeline ribbon

Every CodePipeline stage is discovered dynamically from `GetPipeline`, so adding a future stage does not require hard-coding it into the UI. Each stage shows:

- stage order
- stage name
- pending / running / passed / failed state
- duration
- failure summary when available

The active stage receives a visual highlight and the page's live indicator continues to pulse.

## Quality signals

Three high-value sales-demo cards:

- SAST critical/high/medium/low counts
- automated test passed/failed/skipped counts and pass rate
- central quality gate PASS/FAIL and reason

## External automation feed

Rows for every status event, for example:

```text
ServiceNow | SAST status update                 | SUCCEEDED | CHG003142
Jira       | SAST evidence attached             | SUCCEEDED | DEMO-142
ServiceNow | Automated test status update       | SUCCEEDED | CHG003142
Jira       | Central quality gate result        | SUCCEEDED | DEMO-142
```

If an external record URL is safe to expose to the audience, the dashboard displays an **Open record** link.

## Bedrock failure-assist panel

Designed as a visually differentiated dark panel so the AI-assisted operational story is obvious without dominating successful executions.

## Unified execution timeline

Combines:

- CodePipeline state changes
- SAST/test/quality signals
- ServiceNow/Jira updates
- Bedrock analysis completion

This is useful in a sales presentation because it visually demonstrates that the pipeline orchestrates more than build/test/deploy stages.

## Recent execution table

Shows recent status, start time, duration, revision, and commit summary. The KPI strip uses the same history to compute success rate and average runtime.

---

# 18. Verify WAF behavior

## Approved network

From the presenter network included in the IP set:

1. Open the CloudFront URL.
2. Confirm the dashboard loads normally.
3. Browser developer tools > **Network** should show successful requests to:
   - `/index.html`
   - `/assets/...`
   - `/config.json`
   - `/data/dashboard.json`

## Direct S3 access must fail

Try the bucket object URL pattern:

```text
https://BUCKET_NAME.s3.us-east-1.amazonaws.com/index.html
```

Direct public read should fail because Block Public Access is enabled and the bucket policy grants read only to the specific CloudFront distribution.

## Non-approved network test

If convenient, test from a separate network whose public IPv4 address is not in the WAF IP set. WAF should block the request.

Do not permanently add broad ranges such as `0.0.0.0/0` just to simplify the demonstration.

---

# 19. Changing the presenter IP later

This does not require a CloudFormation update.

1. Open **WAF & Shield** in `us-east-1`.
2. Open **IP sets**.
3. Open the IP set named similar to `DevOpsSalesDashboard-ApprovedIPv4`.
4. Choose **Edit**.
5. Add the new public IPv4 CIDR.
6. Remove obsolete CIDRs when no longer needed.
7. Save.

The Web ACL rule references the IP set, so it automatically uses the updated addresses.

---

# 20. Dashboard refresh and caching behavior

Static application assets use CloudFront's managed **CachingOptimized** policy.

Dashboard data uses **CachingDisabled**:

```text
/data/* -> min TTL 0 / default TTL 0 / max TTL 0
```

The telemetry Lambda also writes JSON objects with:

```text
Cache-Control: no-store, max-age=0
Content-Type: application/json
```

The React app fetches with browser cache disabled.

Therefore a typical update path is:

```text
CodePipeline / sidecar event
          |
          v
EventBridge -> Telemetry Lambda -> S3 data/dashboard.json
                                      |
                                      v
                              CloudFront data/*
                                      |
                               browser polls
                                      |
                                      v
                                  UI redraw
```

This is near-live visualization, not a hard real-time SLA.

---

# 21. Event reliability model

CodePipeline service event delivery to EventBridge is documented as best effort. The package therefore does not treat the event payload itself as the only source of truth.

Every state-change trigger causes the Lambda to re-read CodePipeline's current execution APIs. In addition, a one-minute EventBridge schedule performs the same reconciliation. The result is:

- fast update when events arrive normally
- eventual correction if a state-change event is missed
- no database required for the demo

The custom ServiceNow/Jira/Bedrock events are accepted directly and merged into the S3 state document.

## Which events may change the displayed execution

Only CodePipeline's own state-change events and the reconciliation refresh decide which execution the
dashboard is showing. Custom sidecar events are correlated against that execution but never move it.

This matters because every sidecar event also carries an `executionId`. If a sidecar retries slowly,
or `#{codepipeline.PipelineExecutionId}` was not propagated correctly and it sends a stale value, the
dashboard drops that event from the current-run cards instead of switching the display back to the
older execution and clearing the quality, integration, and Bedrock panels for the run in progress.
The event still appears in the unified timeline, flagged as historical.

## Turning the reconciliation refresh off between demos

The heartbeat rule runs continuously once deployed. Left enabled it is roughly 43,000 Lambda
invocations, 170,000 CodePipeline read API calls, and 43,000 S3 writes per month regardless of
whether anyone is presenting. The cost is negligible, but in a shared account it is constant
CloudTrail and CloudWatch noise.

Two ways to stop it:

- **Console, no stack update.** Take the `HeartbeatRuleName` output from the telemetry stack, open
  **EventBridge** > **Rules** in the pipeline Region, select that rule, and choose **Disable**.
- **Stack update.** Set the `HeartbeatState` parameter to `DISABLED`.

With the heartbeat off, the dashboard still updates on every CodePipeline and sidecar event. What you
lose is the automatic correction if a best-effort event is never delivered. Re-enable it before any
rehearsal or live demo.

---

# 22. IAM permissions created by the telemetry stack

The telemetry Lambda is granted only:

```text
codepipeline:GetPipeline
codepipeline:GetPipelineExecution
codepipeline:GetPipelineState
codepipeline:ListActionExecutions
codepipeline:ListPipelineExecutions
```

for the selected pipeline ARN, plus:

```text
s3:GetObject
s3:PutObject
```

for:

```text
arn:aws:s3:::DASHBOARD_BUCKET/data/*
```

and the standard permissions needed to write its own CloudWatch Logs.

The static browser gets none of these permissions.

---

# 23. Rehearsal-only synthetic signals

For UI development or a rehearsal when ServiceNow/Jira/Bedrock are not available, the package includes:

`demo/publish_demo_signals.py`

Example:

```bash
python demo/publish_demo_signals.py \
  --region PIPELINE_REGION \
  --pipeline PIPELINE_NAME \
  --execution-id CURRENT_EXECUTION_ID
```

It creates realistic-looking dashboard events but **does not call the external systems**. Its console output explicitly labels them as rehearsal events.

Use this to validate:

- EventBridge custom event rule
- Lambda event merging
- ServiceNow/Jira feed layout
- SAST/test cards
- Bedrock panel

Do not use synthetic events as evidence that the client integration was executed.

---

# 24. Recommended live sales-demo sequence

## Demo 1 - successful flow

1. Open the dashboard on the approved presenter network.
2. Start the known-good pipeline execution.
3. Show the live stage ribbon move through Source, SAST, Validate/Test, Central Quality Gate, and later integration/deployment stages.
4. When the SAST adapter publishes results, highlight severity counts.
5. When test results arrive, highlight pass rate and tool label.
6. When the quality gate passes, highlight the decision card.
7. As ServiceNow/Jira sidecars run, show the outbound update feed populate with external IDs.
8. At completion, show success status, total duration, and the updated recent-history table.

## Demo 2 - controlled failure + Bedrock

1. Use a deterministic, safe failure scenario in the demo branch/environment.
2. Prefer a known validation or automated-test failure over a random network outage.
3. Show the failed stage immediately turn red.
4. Point out that the Bedrock panel switches to **Awaiting Analysis** before the AI response exists.
5. When the existing Bedrock sidecar completes, show:
   - summary
   - root cause
   - recommended remediation
6. Show ServiceNow/Jira failure/status updates in the same unified execution activity stream.

This sequence communicates an enterprise DevOps proposition much more effectively than a conventional graph-only dashboard because it shows **workflow orchestration, governance, integrations, and AI-assisted operations** in one place.

---

# 25. Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| CloudFront returns 403 from your laptop | WAF IP allowlist does not include the laptop's current public egress IP | Update the WAF IP set in `us-east-1` |
| Dashboard page loads but data warning remains | `data/dashboard.json` has not been created | Invoke telemetry Lambda once with `{}` |
| S3 direct URL works publicly | Bucket policy/public access configuration is wrong | Re-enable all Block Public Access settings and review OAC bucket policy |
| CloudFront returns S3 AccessDenied | OAC or bucket policy mismatch | Confirm distribution uses the created OAC and bucket policy `AWS:SourceArn` points to that distribution |
| Pipeline state does not change | EventBridge rule is in wrong Region or pattern/pipeline name mismatches | Deploy telemetry stack in the actual pipeline Region; verify `detail.pipeline` exact name |
| Pipeline catches up only on the minute | EventBridge fast rule is not invoking Lambda but heartbeat is | Check rule metrics, Lambda resource permission, and Lambda logs |
| ServiceNow/Jira feed is empty | Sidecars are not publishing custom events | Add `events:PutEvents`, helper call, and execution ID propagation |
| Custom event appears in timeline but not current cards | Event carries a different execution ID, so it is correlated as historical | Pass `#{codepipeline.PipelineExecutionId}` to the sidecar |
| Stage state only catches up when a new event arrives | Heartbeat rule is disabled | Enable the rule named in the `HeartbeatRuleName` output, or set `HeartbeatState` to `ENABLED` |
| `data/executions/<id>.json` files are missing | `WriteExecutionSnapshots` is `DISABLED`, which is the default | Nothing to fix; the UI does not read them. Set the parameter to `ENABLED` only if you want retained per-execution copies |
| Bucket accumulates many object versions | Lifecycle rule was removed or retention set very high | Confirm `ExpireNoncurrentDashboardVersions` is enabled and `NoncurrentVersionRetentionDays` is sensible |
| Bedrock panel stays Awaiting Analysis | Existing Bedrock sidecar did not publish its completed response | Add `bedrock_analysis(...)` after final structured model response |
| Browser JSON request returns stale content | Wrong CloudFront behavior matched | Confirm `data/*` uses managed `CachingDisabled` policy |
| UI deployment erased data | Upload command did not exclude `data/*` | Use the included `upload-dashboard.sh` script |
| ServiceNow/Jira link should not be visible to client | External URL is too sensitive | Omit `externalUrl` from published event |
| Bedrock output contains sensitive text | Sidecar published raw/unsafe content | Publish only sanitized summary/root-cause/recommendations; rotate any exposed secret if necessary |

---

# 26. Acceptance test checklist

## Security

- [ ] Edge stack is in `us-east-1`
- [ ] S3 bucket has Block Public Access fully enabled
- [ ] S3 Website Hosting is disabled/not used
- [ ] CloudFront origin uses OAC with signed requests
- [ ] S3 bucket policy restricts reads to the exact CloudFront distribution
- [ ] WAF default action is BLOCK
- [ ] only approved IPv4 CIDRs are in the IP set
- [ ] CloudFront IPv6 is disabled
- [ ] CloudFront only allows GET/HEAD
- [ ] no AWS credentials or secrets exist in frontend files
- [ ] direct S3 object URL is denied
- [ ] bucket lifecycle rules for noncurrent versions and incomplete multipart uploads are enabled

## Live pipeline

- [ ] Lambda manual seed creates `data/dashboard.json`
- [ ] stage structure matches the current CodePipeline automatically
- [ ] active stage changes during a run
- [ ] execution duration increases while running
- [ ] final pipeline status is correct
- [ ] branch/commit/revision metadata appears when source provider exposes it
- [ ] recent executions populate
- [ ] all five KPI cards render on a single row at the presentation screen resolution
- [ ] a sidecar event published with a deliberately wrong execution ID does not clear the current run's cards

## Quality

- [ ] SAST severity counts publish
- [ ] automated test pass/fail counts publish
- [ ] quality gate PASS/FAIL publishes

## Integrations

- [ ] ServiceNow success event appears
- [ ] ServiceNow failure event can appear when appropriate
- [ ] Jira success/failure status appears
- [ ] external ID links work only where safe
- [ ] multiple integration updates for one execution are retained

## Bedrock

- [ ] pipeline failure changes Bedrock panel to Awaiting Analysis
- [ ] completed analyzer response populates summary/root cause/recommendations
- [ ] raw logs/prompts are not exposed

## Sales-demo readiness

- [ ] tested from the exact presentation VPN/network
- [ ] one known-good run rehearsed
- [ ] one controlled failure run rehearsed
- [ ] presenter WAF IP verified on demo day
- [ ] CloudFront URL bookmarked
- [ ] external records contain client-safe demo content
- [ ] `HeartbeatState` is `ENABLED` for the demo window

---

# 27. Updating the UI later

Change any React/CSS file under `dashboard/`, then:

```bash
bash scripts/deploy-dashboard.sh BUCKET_NAME DISTRIBUTION_ID
```

That builds and uploads in one step. The two underlying scripts remain available separately:

```bash
bash scripts/build-dashboard.sh
bash scripts/upload-dashboard.sh BUCKET_NAME DISTRIBUTION_ID
```

The upload script does not modify `data/*`.

Adding a new pipeline stage needs **no UI code change** because the stage ribbon is generated from the live pipeline structure.

## Rebranding

The shipped theme uses the Accenture palette: purple `#A100FF` and black `#000000`.

Colour lives in one place. `dashboard/src/styles.css` opens with a `:root` block of 45 design tokens,
and the rest of the file contains no colour literals apart from three `rgba()` values inside the
`live-pulse` keyframe, which are commented where they appear. To change the whole palette, edit only
the tokens.

The block is grouped so you can tell what is safe to change:

- **Official brand palette** — `--brand-purple`, `--brand-black`. Replace these first.
- **Derived tints and shades** — computed for legibility, not official brand colours. `--brand-purple-soft`
  exists because `#A100FF` on black measures about 3.97:1 contrast, which fails WCAG AA for the small
  uppercase accent labels; the lighter tint measures about 7.8:1. Keep that distinction if you
  substitute another brand colour.
- **Semantic status colours** — pass, fail, and live. Leave these conventional. The stage ribbon and
  timeline depend on green and red being read instantly, so do not tint them to match a brand. Only
  in-progress is deliberately brand-coloured.

The brand mark is `dashboard/public/brand-logo.svg`, rendered top left of the hero at 30px tall. The
file shipped in this package is a **placeholder**, not an official logo; replace it with the approved
reversed (white-on-dark) SVG from your brand portal, keeping the filename. `dashboard/public/favicon.svg`
is the tab icon.

Both must stay under `dashboard/public/` so they are served same-origin. The distribution's
Content-Security-Policy sets `img-src 'self' data:`, which blocks logos loaded from an external CDN.

Cloudscape's own components — `Container`, `Header`, `Table`, `StatusIndicator`, `Badge`,
`ProgressBar`, `Button`, `Alert` — are not affected by these tokens and keep their default AWS styling.
`StatusIndicator` is the most visible of these because it supplies the status glyphs inside the custom
cards. Restyling them requires the Cloudscape themeable build (`@cloudscape-design/components-themeable`
plus `@cloudscape-design/theming-build`), which is a larger change than a palette swap. A cheaper option
if your brand is dark is `applyMode(Mode.Dark)` from `@cloudscape-design/global-styles`, one line in
`main.jsx`, though the light surface tokens then need inverting to match.

Adding a new outbound integration generally needs only:

```python
integration_status(
    execution_id=...,
    integration="New System",
    operation="...",
    status="SUCCEEDED",
    stage="..."
)
```

---

# 28. Cleanup / rollback

Because this is a shared environment, cleanup is split intentionally.

## Telemetry

1. Switch to the pipeline Region.
2. Open CloudFormation.
3. Delete `DevOpsSalesDashboard-Telemetry`.

This removes the Lambda, rules, permissions, and telemetry IAM role. It does not alter the pipeline itself.

## Edge resources

1. Switch to `us-east-1`.
2. Delete `DevOpsSalesDashboard-Edge`.
3. The S3 bucket is configured with a **Retain** deletion policy so a stack deletion does not unexpectedly erase dashboard files/history.
4. If you want it completely removed afterward:
   - empty all current and versioned objects from the bucket
   - delete the retained bucket manually

The lifecycle rule keeps noncurrent versions bounded while the stack is running, but it does not empty
the bucket. A retained bucket still needs the manual step above if the dashboard is being retired.

If you are only pausing between demos rather than tearing down, disable the heartbeat rule instead of
deleting the telemetry stack. That stops the continuous background refresh while leaving the wiring,
IAM permissions, and seeded data in place.

## Existing sidecars

If the dashboard is permanently retired, remove:

- `events:PutEvents` inline permission added for dashboard events
- `dashboard_events.py` calls and environment variables

They are not required for the original external integration to function.

---

# 29. Production hardening path if this stops being only a demo

This package deliberately optimizes for minimal shared-environment change. If the dashboard becomes a persistent production service, reassess:

- replace network-only viewer restriction with user identity/SSO
- define retention and data-classification policy for telemetry JSON
- use a dedicated event bus if organization standards require one
- add WAF/access logging and formal alerting
- consider a stronger state store if concurrent pipelines or high event volume require transactional semantics
- add automated frontend deployment instead of manual upload
- define custom domain/certificate only if required
- review Bedrock output handling and external-record links under the client's data-classification policy

None of those are necessary to demonstrate the current proposition.

---

# 30. AWS / Cloudscape references used for this implementation

- CloudFront OAC and private S3 origin: https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/private-content-restricting-access-to-s3.html
- CloudFront managed cache policies: https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/using-managed-cache-policies.html
- AWS WAF IP sets: https://docs.aws.amazon.com/waf/latest/APIReference/API_CreateIPSet.html
- AWS WAF Web ACL behavior: https://docs.aws.amazon.com/waf/latest/APIReference/API_WebACL.html
- CloudFront response header policies: https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/creating-response-headers-policies.html
- CodePipeline events in EventBridge: https://docs.aws.amazon.com/eventbridge/latest/ref/events-ref-codepipeline.html
- CodePipeline state-change event examples: https://docs.aws.amazon.com/codepipeline/latest/userguide/detect-state-changes-cloudwatch-events.html
- CodePipeline GetPipelineExecution: https://docs.aws.amazon.com/codepipeline/latest/APIReference/API_GetPipelineExecution.html
- CodePipeline ListActionExecutions: https://docs.aws.amazon.com/codepipeline/latest/APIReference/API_ListActionExecutions.html
- CodePipeline ListPipelineExecutions: https://docs.aws.amazon.com/codepipeline/latest/APIReference/API_ListPipelineExecutions.html
- CodePipeline variables / PipelineExecutionId: https://docs.aws.amazon.com/codepipeline/latest/userguide/reference-variables.html
- EventBridge PutEvents: https://docs.aws.amazon.com/eventbridge/latest/APIReference/API_PutEvents.html
- Cloudscape component installation: https://cloudscape.design/get-started/for-developers/using-cloudscape-components/
