import json
import os
import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import boto3
from botocore.exceptions import ClientError

PIPELINE_NAME = os.environ["PIPELINE_NAME"]
DASHBOARD_BUCKET = os.environ["DASHBOARD_BUCKET"]
DASHBOARD_BUCKET_REGION = os.environ.get("DASHBOARD_BUCKET_REGION", "us-east-1")
DASHBOARD_EVENT_SOURCE = os.environ.get("DASHBOARD_EVENT_SOURCE", "devops.pipeline.dashboard")
HISTORY_LIMIT = int(os.environ.get("HISTORY_LIMIT", "12"))
TIMELINE_LIMIT = int(os.environ.get("TIMELINE_LIMIT", "60"))
DATA_KEY = os.environ.get("DATA_KEY", "data/dashboard.json")
WRITE_EXECUTION_SNAPSHOTS = os.environ.get("WRITE_EXECUTION_SNAPSHOTS", "DISABLED").upper() == "ENABLED"

codepipeline = boto3.client("codepipeline")
s3 = boto3.client("s3", region_name=DASHBOARD_BUCKET_REGION)

SECRET_PATTERNS = [
    re.compile(r"AKIA[0-9A-Z]{16}"),
    re.compile(r"(?i)(password|passwd|token|secret|api[_-]?key)\s*[:=]\s*[^\s,;]+"),
    re.compile(r"(?i)authorization:\s*bearer\s+[^\s]+"),
]


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def iso(value: Any) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
    return str(value)


def epoch_seconds(value: Any) -> Optional[float]:
    if value is None:
        return None
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.timestamp()
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def clean_text(value: Any, max_len: int = 1200) -> Optional[str]:
    if value is None:
        return None
    text = str(value).replace("\x00", " ").strip()
    for pattern in SECRET_PATTERNS:
        text = pattern.sub("[REDACTED]", text)
    if len(text) > max_len:
        text = text[: max_len - 1] + "…"
    return text


def normalize_status(value: Any) -> str:
    if not value:
        return "PENDING"
    raw = str(value).replace("-", "_").replace(" ", "_").upper()
    mapping = {
        "INPROGRESS": "IN_PROGRESS",
        "IN_PROGRESS": "IN_PROGRESS",
        "STARTED": "IN_PROGRESS",
        "SUCCEEDED": "SUCCEEDED",
        "SUCCESS": "SUCCEEDED",
        "FAILED": "FAILED",
        "FAILURE": "FAILED",
        "ABANDONED": "ABANDONED",
        "STOPPED": "STOPPED",
        "STOPPING": "STOPPING",
        "SUPERSEDED": "SUPERSEDED",
        "CANCELED": "CANCELED",
        "CANCELLED": "CANCELED",
        "RESUMED": "IN_PROGRESS",
        "WAITING": "PENDING",
        "NOT_STARTED": "PENDING",
        "PENDING": "PENDING",
    }
    return mapping.get(raw, raw)


def empty_bedrock() -> Dict[str, Any]:
    return {
        "status": "STANDBY",
        "executionId": None,
        "sourceStage": None,
        "summary": "AI failure analysis is standing by and will populate automatically when a failure is analyzed.",
        "rootCause": None,
        "recommendedActions": [],
        "modelId": None,
        "analysisId": None,
        "timestamp": None,
    }


def empty_quality() -> Dict[str, Any]:
    return {
        "sast": {"status": "WAITING"},
        "unitTests": {"status": "WAITING"},
        "tests": {"status": "WAITING"},
        "load": {"status": "WAITING"},
        "qualityGate": {"status": "WAITING"},
    }


def initial_state() -> Dict[str, Any]:
    return {
        "schemaVersion": "1.0",
        "generatedAt": now_iso(),
        "pipeline": {
            "name": PIPELINE_NAME,
            "region": os.environ.get("AWS_REGION"),
            "executionId": None,
            "status": "WAITING",
            "startTime": None,
            "durationSeconds": None,
            "trigger": None,
            "branch": None,
            "repository": None,
            "commitId": None,
            "commitMessage": None,
            "revisionUrl": None,
        },
        "stages": [],
        "quality": empty_quality(),
        "integrations": [],
        "bedrock": empty_bedrock(),
        "timeline": [],
        "history": [],
        # Per-execution stage durations, keyed by execution id. Deliberately outside the
        # run-scoped reset: this is the only cross-execution data the Lambda keeps, and
        # it is what makes per-stage averages possible.
        "stageStats": {},
        "kpis": {
            "successRatePct": None,
            "averageDurationSeconds": None,
            "medianDurationSeconds": None,
            "p90DurationSeconds": None,
            "fastestDurationSeconds": None,
            "slowestDurationSeconds": None,
            "completedExecutions": 0,
            "succeededExecutions": 0,
            "failedExecutions": 0,
            "currentSuccessStreak": 0,
            "secondsSinceLastFailure": None,
            "executionsPerDay": None,
            "observedWindowHours": None,
            "stageAverages": {},
        },
        "telemetry": {
            "lastEventId": None,
            "lastEventType": None,
            "lastEventAt": None,
            "heartbeat": None,
        },
    }


def load_state() -> Dict[str, Any]:
    try:
        obj = s3.get_object(Bucket=DASHBOARD_BUCKET, Key=DATA_KEY)
        return json.loads(obj["Body"].read().decode("utf-8"))
    except ClientError as exc:
        code = exc.response.get("Error", {}).get("Code")
        if code in {"NoSuchKey", "404", "AccessDenied"}:
            return initial_state()
        raise
    except (json.JSONDecodeError, UnicodeDecodeError):
        return initial_state()


def put_json(key: str, payload: Dict[str, Any]) -> None:
    s3.put_object(
        Bucket=DASHBOARD_BUCKET,
        Key=key,
        Body=json.dumps(payload, default=iso, separators=(",", ":")).encode("utf-8"),
        ContentType="application/json",
        CacheControl="no-store, max-age=0",
        ServerSideEncryption="AES256",
    )


def reset_run_scoped(state: Dict[str, Any], execution_id: str) -> None:
    """Clear the cards that belong to a single execution.

    stageStats and history are intentionally untouched: they span executions and are
    what the trend and stage-timing screens are built from.
    """
    state["quality"] = empty_quality()
    state["integrations"] = []
    state["bedrock"] = empty_bedrock()
    state["timeline"] = []
    state["pipeline"]["executionId"] = execution_id


def get_execution_id(event: Dict[str, Any], history: List[Dict[str, Any]]) -> Optional[str]:
    # Only CodePipeline's own state-change events are allowed to move the current-execution
    # pointer. Custom sidecar events also carry an executionId, and a stale or mis-propagated
    # value there would otherwise drag the display back to an older execution and make
    # reset_run_scoped() wipe the quality/integration/Bedrock cards for the run on screen.
    # Custom events are correlated against this pointer in custom_event_is_current() instead.
    if event.get("source") == "aws.codepipeline":
        detail = event.get("detail") or {}
        event_id = detail.get("execution-id") or detail.get("executionId")
        if event_id:
            return str(event_id)
    if history:
        return history[0].get("pipelineExecutionId")
    return None


def source_metadata(action_details: List[Dict[str, Any]], execution: Dict[str, Any], event: Dict[str, Any]) -> Dict[str, Any]:
    result = {
        "branch": None,
        "repository": None,
        "commitId": None,
        "commitMessage": None,
        "revisionUrl": None,
    }

    additional = event.get("additionalAttributes") or {}
    source_actions = additional.get("sourceActions") or []
    if source_actions:
        vars_ = source_actions[0].get("sourceActionVariables") or {}
        result["branch"] = vars_.get("BranchName")
        result["repository"] = vars_.get("FullRepositoryName") or vars_.get("RepositoryName")
        result["commitId"] = vars_.get("CommitId")
        result["commitMessage"] = vars_.get("CommitMessage")

    for action in action_details:
        output_vars = (action.get("output") or {}).get("outputVariables") or {}
        lower = {str(k).lower(): v for k, v in output_vars.items()}
        result["branch"] = result["branch"] or lower.get("branchname") or lower.get("branch")
        result["repository"] = result["repository"] or lower.get("fullrepositoryname") or lower.get("repositoryname")
        result["commitId"] = result["commitId"] or lower.get("commitid") or lower.get("commitsha")
        result["commitMessage"] = result["commitMessage"] or lower.get("commitmessage")

    revisions = execution.get("artifactRevisions") or []
    if revisions:
        revision = revisions[0]
        result["commitId"] = result["commitId"] or revision.get("revisionId")
        result["commitMessage"] = result["commitMessage"] or revision.get("revisionSummary")
        result["revisionUrl"] = revision.get("revisionUrl")

    for key in list(result.keys()):
        result[key] = clean_text(result[key], 500)
    return result


def action_summary(action: Dict[str, Any]) -> Dict[str, Any]:
    output = action.get("output") or {}
    exec_result = output.get("executionResult") or {}
    error = exec_result.get("errorDetails") or {}
    start = epoch_seconds(action.get("startTime"))
    end = epoch_seconds(action.get("lastUpdateTime"))
    duration = None
    if start:
        effective_end = end or datetime.now(timezone.utc).timestamp()
        duration = max(0, round(effective_end - start))
    return {
        "name": action.get("actionName"),
        "status": normalize_status(action.get("status")),
        "startTime": iso(action.get("startTime")),
        "lastUpdateTime": iso(action.get("lastUpdateTime")),
        "durationSeconds": duration,
        "summary": clean_text(exec_result.get("externalExecutionSummary") or error.get("message"), 600),
        "externalUrl": clean_text(exec_result.get("externalExecutionUrl"), 1200),
        "errorCode": clean_text(error.get("code"), 120),
    }


def stage_status(actions: List[Dict[str, Any]]) -> str:
    if not actions:
        return "PENDING"
    statuses = [a["status"] for a in actions]
    for terminal in ["FAILED", "ABANDONED", "STOPPED", "CANCELED"]:
        if terminal in statuses:
            return terminal
    if "IN_PROGRESS" in statuses or "STOPPING" in statuses:
        return "IN_PROGRESS"
    if statuses and all(s == "SUCCEEDED" for s in statuses):
        return "SUCCEEDED"
    if "SUCCEEDED" in statuses:
        return "IN_PROGRESS"
    return "PENDING"


def build_stages(pipeline_def: Dict[str, Any], action_details: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    by_stage: Dict[str, List[Dict[str, Any]]] = {}
    for action in action_details:
        by_stage.setdefault(action.get("stageName") or "Unknown", []).append(action_summary(action))

    stages: List[Dict[str, Any]] = []
    for stage_def in pipeline_def.get("stages") or []:
        name = stage_def.get("name")
        actions = by_stage.get(name, [])
        actions.sort(key=lambda x: x.get("startTime") or "")
        starts = [epoch_seconds(a.get("startTime")) for a in action_details if a.get("stageName") == name]
        ends = [epoch_seconds(a.get("lastUpdateTime")) for a in action_details if a.get("stageName") == name]
        starts = [x for x in starts if x is not None]
        ends = [x for x in ends if x is not None]
        status = stage_status(actions)
        duration = None
        if starts:
            start = min(starts)
            end = max(ends) if ends else datetime.now(timezone.utc).timestamp()
            duration = max(0, round(end - start))
        failure = next((a for a in actions if a["status"] in {"FAILED", "ABANDONED", "STOPPED", "CANCELED"}), None)
        stages.append(
            {
                "name": name,
                "status": status,
                "durationSeconds": duration,
                "summary": (failure or {}).get("summary"),
                "externalUrl": (failure or {}).get("externalUrl"),
                "actions": actions,
            }
        )
    return stages


def history_payload(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    result = []
    for item in items[:HISTORY_LIMIT]:
        start = epoch_seconds(item.get("startTime"))
        end = epoch_seconds(item.get("lastUpdateTime"))
        duration = round(max(0, end - start)) if start and end else None
        revisions = item.get("sourceRevisions") or []
        revision = revisions[0] if revisions else {}
        result.append(
            {
                "executionId": item.get("pipelineExecutionId"),
                "status": normalize_status(item.get("status")),
                "startTime": iso(item.get("startTime")),
                "lastUpdateTime": iso(item.get("lastUpdateTime")),
                "durationSeconds": duration,
                "commitId": clean_text(revision.get("revisionId"), 200),
                "commitMessage": clean_text(revision.get("revisionSummary"), 300),
                "revisionUrl": clean_text(revision.get("revisionUrl"), 1200),
            }
        )
    return result


def epoch_seconds_from_iso(value: Any) -> Optional[float]:
    """Parse an ISO timestamp that this module previously serialised.

    State is round-tripped through JSON, so timestamps come back as strings rather
    than datetimes and cannot go through epoch_seconds().
    """
    if not value:
        return None
    if isinstance(value, datetime):
        return epoch_seconds(value)
    try:
        text = str(value).replace("Z", "+00:00")
        parsed = datetime.fromisoformat(text)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.timestamp()
    except ValueError:
        return None


def percentile(sorted_values: List[float], pct: int) -> Optional[int]:
    """Nearest-rank percentile over an already-sorted list."""
    if not sorted_values:
        return None
    if len(sorted_values) == 1:
        return round(sorted_values[0])
    rank = (pct / 100.0) * (len(sorted_values) - 1)
    low = int(rank)
    high = min(low + 1, len(sorted_values) - 1)
    weight = rank - low
    return round(sorted_values[low] * (1 - weight) + sorted_values[high] * weight)


def record_stage_stats(
    state: Dict[str, Any],
    execution_id: Optional[str],
    stages: List[Dict[str, Any]],
    status: str,
    history: List[Dict[str, Any]],
) -> None:
    """Accumulate per-stage durations across executions.

    ListPipelineExecutions returns only whole-execution durations, so per-stage history
    has to be built up here if the UI is to show things like average time to reach the
    test environment. Entries are pruned to the executions still present in history, so
    this stays bounded by HISTORY_LIMIT without a separate retention rule.
    """
    store = state.setdefault("stageStats", {})
    if execution_id:
        durations = {
            stage["name"]: stage["durationSeconds"]
            for stage in stages
            if stage.get("name") and isinstance(stage.get("durationSeconds"), (int, float))
        }
        if durations:
            store[execution_id] = {
                "status": status,
                "durations": durations,
                "updatedAt": now_iso(),
            }

    keep = {h.get("executionId") for h in history if h.get("executionId")}
    if execution_id:
        keep.add(execution_id)
    for stale in [key for key in store if key not in keep]:
        del store[stale]


def stage_averages(stage_stats: Dict[str, Any]) -> Dict[str, Any]:
    """Per-stage timing across completed executions only.

    In-progress runs are excluded: their stage durations are still growing and would
    drag every average down.
    """
    terminal = {"SUCCEEDED", "FAILED", "STOPPED", "CANCELED", "SUPERSEDED"}
    buckets: Dict[str, List[float]] = {}
    for entry in (stage_stats or {}).values():
        if not isinstance(entry, dict) or entry.get("status") not in terminal:
            continue
        for name, seconds in (entry.get("durations") or {}).items():
            if isinstance(seconds, (int, float)):
                buckets.setdefault(str(name), []).append(float(seconds))

    result: Dict[str, Any] = {}
    for name, values in buckets.items():
        values.sort()
        result[name] = {
            "averageSeconds": round(sum(values) / len(values)),
            "medianSeconds": percentile(values, 50),
            "fastestSeconds": round(values[0]),
            "slowestSeconds": round(values[-1]),
            "samples": len(values),
        }
    return result


def calculate_kpis(history: List[Dict[str, Any]], stage_stats: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    terminal = {"SUCCEEDED", "FAILED", "STOPPED", "CANCELED", "SUPERSEDED"}
    completed = [h for h in history if h.get("status") in terminal]
    succeeded = [h for h in completed if h.get("status") == "SUCCEEDED"]
    failed = [h for h in completed if h.get("status") == "FAILED"]
    durations = sorted(h["durationSeconds"] for h in completed if h.get("durationSeconds") is not None)

    # history is newest-first, so the streak counts forward from the most recent run.
    streak = 0
    for item in completed:
        if item.get("status") != "SUCCEEDED":
            break
        streak += 1

    last_failure = next((h for h in completed if h.get("status") == "FAILED"), None)
    seconds_since_failure = None
    if last_failure and last_failure.get("lastUpdateTime"):
        end = epoch_seconds_from_iso(last_failure["lastUpdateTime"])
        if end:
            seconds_since_failure = max(0, round(datetime.now(timezone.utc).timestamp() - end))

    # Throughput over the observed window rather than a fixed period: the window is
    # however far back HISTORY_LIMIT executions reach.
    starts = [epoch_seconds_from_iso(h.get("startTime")) for h in completed]
    starts = sorted(x for x in starts if x is not None)
    per_day = None
    window_hours = None
    if len(starts) >= 2:
        span = starts[-1] - starts[0]
        window_hours = round(span / 3600.0, 1)
        if span > 0:
            per_day = round(len(starts) / (span / 86400.0), 1)

    return {
        "successRatePct": round((len(succeeded) / len(completed)) * 100, 1) if completed else None,
        "averageDurationSeconds": round(sum(durations) / len(durations)) if durations else None,
        "medianDurationSeconds": percentile(durations, 50),
        "p90DurationSeconds": percentile(durations, 90),
        "fastestDurationSeconds": durations[0] if durations else None,
        "slowestDurationSeconds": durations[-1] if durations else None,
        "completedExecutions": len(completed),
        "succeededExecutions": len(succeeded),
        "failedExecutions": len(failed),
        "currentSuccessStreak": streak,
        "secondsSinceLastFailure": seconds_since_failure,
        "executionsPerDay": per_day,
        "observedWindowHours": window_hours,
        "stageAverages": stage_averages(stage_stats or {}),
    }


def refresh_pipeline(state: Dict[str, Any], event: Dict[str, Any]) -> Dict[str, Any]:
    list_resp = codepipeline.list_pipeline_executions(pipelineName=PIPELINE_NAME, maxResults=HISTORY_LIMIT)
    raw_history = list_resp.get("pipelineExecutionSummaries") or []
    execution_id = get_execution_id(event, raw_history)

    if not execution_id:
        state["pipeline"].update({"name": PIPELINE_NAME, "status": "WAITING", "executionId": None})
        state["history"] = []
        state["kpis"] = calculate_kpis([], state.get("stageStats"))
        return state

    if state.get("pipeline", {}).get("executionId") != execution_id:
        reset_run_scoped(state, execution_id)

    execution = codepipeline.get_pipeline_execution(
        pipelineName=PIPELINE_NAME,
        pipelineExecutionId=execution_id,
    ).get("pipelineExecution") or {}
    pipeline_def = codepipeline.get_pipeline(name=PIPELINE_NAME).get("pipeline") or {}
    actions_resp = codepipeline.list_action_executions(
        pipelineName=PIPELINE_NAME,
        filter={
            "latestInPipelineExecution": {
                "pipelineExecutionId": execution_id,
                "startTimeRange": "Latest",
            }
        },
        maxResults=100,
    )
    action_details = actions_resp.get("actionExecutionDetails") or []

    history = history_payload(raw_history)
    current_hist = next((h for h in history if h.get("executionId") == execution_id), {})
    meta = source_metadata(action_details, execution, event)
    status = normalize_status(execution.get("status"))
    start_epoch = epoch_seconds(current_hist.get("startTime"))
    duration = None
    if start_epoch:
        if status in {"SUCCEEDED", "FAILED", "STOPPED", "CANCELED", "SUPERSEDED"}:
            end_epoch = epoch_seconds(current_hist.get("lastUpdateTime")) or datetime.now(timezone.utc).timestamp()
        else:
            end_epoch = datetime.now(timezone.utc).timestamp()
        duration = max(0, round(end_epoch - start_epoch))

    trigger = execution.get("trigger") or {}
    state["pipeline"] = {
        "name": PIPELINE_NAME,
        "region": os.environ.get("AWS_REGION"),
        "executionId": execution_id,
        "status": status,
        "startTime": current_hist.get("startTime"),
        "durationSeconds": duration,
        "trigger": clean_text(trigger.get("triggerType") or trigger.get("triggerDetail"), 300),
        **meta,
    }
    state["stages"] = build_stages(pipeline_def, action_details)
    state["history"] = history
    record_stage_stats(state, execution_id, state["stages"], status, history)
    state["kpis"] = calculate_kpis(history, state.get("stageStats"))

    if status == "FAILED" and state.get("bedrock", {}).get("status") == "STANDBY":
        failed_stage = next((s for s in state["stages"] if s["status"] == "FAILED"), None)
        state["bedrock"] = {
            **empty_bedrock(),
            "status": "AWAITING_ANALYSIS",
            "executionId": execution_id,
            "sourceStage": (failed_stage or {}).get("name"),
            "summary": "Pipeline failure detected. Waiting for the Bedrock failure-analysis sidecar to publish its response.",
            "timestamp": now_iso(),
        }
    return state


def append_timeline(state: Dict[str, Any], item: Dict[str, Any]) -> None:
    event_id = item.get("id")
    if event_id and any(existing.get("id") == event_id for existing in state.get("timeline", [])):
        return
    state.setdefault("timeline", []).insert(0, item)
    state["timeline"] = state["timeline"][:TIMELINE_LIMIT]


def apply_pipeline_event(state: Dict[str, Any], event: Dict[str, Any]) -> None:
    detail = event.get("detail") or {}
    dtype = event.get("detail-type") or "CodePipeline event"
    stage = detail.get("stage")
    action = detail.get("action")
    state_value = normalize_status(detail.get("state"))
    subject = action or stage or detail.get("pipeline") or PIPELINE_NAME
    append_timeline(
        state,
        {
            "id": event.get("id"),
            "timestamp": event.get("time") or now_iso(),
            "type": "PIPELINE",
            "service": "CodePipeline",
            "stage": stage,
            "status": state_value,
            "title": clean_text(f"{subject} {state_value.replace('_', ' ').title()}", 180),
            "message": clean_text(((detail.get("execution-result") or {}).get("external-execution-summary")), 600),
            "externalUrl": clean_text(((detail.get("execution-result") or {}).get("external-execution-url")), 1200),
            "detailType": dtype,
        },
    )


def custom_event_is_current(state: Dict[str, Any], detail: Dict[str, Any]) -> bool:
    event_exec = detail.get("executionId") or detail.get("execution-id")
    current = state.get("pipeline", {}).get("executionId")
    return not event_exec or not current or str(event_exec) == str(current)


def apply_custom_event(state: Dict[str, Any], event: Dict[str, Any]) -> None:
    detail = event.get("detail") or {}
    kind = str(detail.get("kind") or "note").lower()
    execution_id = detail.get("executionId") or detail.get("execution-id")
    current = custom_event_is_current(state, detail)
    timestamp = detail.get("timestamp") or event.get("time") or now_iso()

    if kind == "integration":
        entry = {
            "id": event.get("id"),
            "executionId": execution_id,
            "timestamp": timestamp,
            "integration": clean_text(detail.get("integration"), 100),
            "operation": clean_text(detail.get("operation"), 180),
            "stage": clean_text(detail.get("stage"), 120),
            "status": normalize_status(detail.get("status")),
            "externalId": clean_text(detail.get("externalId"), 200),
            "externalUrl": clean_text(detail.get("externalUrl"), 1200),
            "message": clean_text(detail.get("message"), 700),
        }
        if current:
            state.setdefault("integrations", []).insert(0, entry)
            state["integrations"] = state["integrations"][:30]
        append_timeline(
            state,
            {
                "id": event.get("id"),
                "timestamp": timestamp,
                "type": "INTEGRATION",
                "service": entry["integration"],
                "stage": entry["stage"],
                "status": entry["status"],
                "title": clean_text(f"{entry['integration'] or 'Integration'}: {entry['operation'] or 'update'}", 220),
                "message": entry["message"],
                "externalUrl": entry["externalUrl"],
                "historical": not current,
            },
        )

    elif kind == "quality" and current:
        category = str(detail.get("category") or "").strip()
        if category in {"sast", "unitTests", "tests", "load", "qualityGate"}:
            metrics = detail.get("metrics") if isinstance(detail.get("metrics"), dict) else {}
            safe_metrics = {}
            for key, value in metrics.items():
                safe_metrics[clean_text(key, 80)] = clean_text(value, 300) if isinstance(value, str) else value
            # Merge rather than replace. Two publishers can legitimately report the same
            # card at different points in one execution: the SAST stage publishes severity
            # counts as soon as the scan finishes, and the central quality gate republishes
            # a verdict later, built from action variables that may not carry those counts.
            # Replacing wholesale blanked the counters the scan had already reported, so
            # keys the newer event does not mention are preserved. Status and timestamp
            # always take the newer value, because the later publisher is authoritative
            # about the verdict. reset_run_scoped clears the whole card on a new execution,
            # so nothing carries across runs.
            existing = (state.get("quality") or {}).get(category)
            merged = {} if not isinstance(existing, dict) else {
                key: value for key, value in existing.items() if key not in {"status", "timestamp"}
            }
            merged.update(safe_metrics)
            state.setdefault("quality", {})[category] = {
                "status": normalize_status(detail.get("status")),
                "timestamp": timestamp,
                **merged,
            }
            append_timeline(
                state,
                {
                    "id": event.get("id"),
                    "timestamp": timestamp,
                    "type": "QUALITY",
                    "service": "Quality Signals",
                    "stage": clean_text(detail.get("stage"), 120),
                    "status": normalize_status(detail.get("status")),
                    "title": clean_text(detail.get("title") or f"{category} metrics updated", 220),
                    "message": clean_text(detail.get("message"), 600),
                },
            )

    elif kind == "bedrock" and current:
        recommendations = detail.get("recommendedActions") or []
        if not isinstance(recommendations, list):
            recommendations = [recommendations]
        state["bedrock"] = {
            "status": normalize_status(detail.get("status") or "SUCCEEDED"),
            "executionId": execution_id,
            "sourceStage": clean_text(detail.get("stage") or detail.get("sourceStage"), 120),
            "summary": clean_text(detail.get("summary"), 1800),
            "rootCause": clean_text(detail.get("rootCause"), 1800),
            "recommendedActions": [clean_text(x, 600) for x in recommendations[:6] if clean_text(x, 600)],
            "modelId": clean_text(detail.get("modelId"), 300),
            "analysisId": clean_text(detail.get("analysisId"), 200),
            "timestamp": timestamp,
        }
        append_timeline(
            state,
            {
                "id": event.get("id"),
                "timestamp": timestamp,
                "type": "AI",
                "service": "Amazon Bedrock",
                "stage": state["bedrock"]["sourceStage"],
                "status": state["bedrock"]["status"],
                "title": "Bedrock failure analysis available",
                "message": state["bedrock"]["summary"],
            },
        )

    else:
        append_timeline(
            state,
            {
                "id": event.get("id"),
                "timestamp": timestamp,
                "type": "NOTE",
                "service": clean_text(detail.get("service") or "Dashboard", 100),
                "stage": clean_text(detail.get("stage"), 120),
                "status": normalize_status(detail.get("status") or "SUCCEEDED"),
                "title": clean_text(detail.get("title") or "Dashboard event", 220),
                "message": clean_text(detail.get("message"), 700),
                "historical": not current,
            },
        )


def handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    event = event or {}
    state = load_state()

    try:
        state = refresh_pipeline(state, event)
    except ClientError as exc:
        append_timeline(
            state,
            {
                "id": event.get("id") or f"refresh-{now_iso()}",
                "timestamp": now_iso(),
                "type": "SYSTEM",
                "service": "Dashboard Telemetry",
                "status": "FAILED",
                "title": "Pipeline refresh failed",
                "message": clean_text(exc.response.get("Error", {}).get("Message"), 700),
            },
        )

    source = event.get("source")
    if source == "aws.codepipeline":
        apply_pipeline_event(state, event)
    elif source == DASHBOARD_EVENT_SOURCE:
        apply_custom_event(state, event)
    elif source == "aws.events":
        state.setdefault("telemetry", {})["heartbeat"] = now_iso()

    state["generatedAt"] = now_iso()
    state.setdefault("telemetry", {})["lastEventId"] = event.get("id")
    state["telemetry"]["lastEventType"] = event.get("detail-type")
    state["telemetry"]["lastEventAt"] = event.get("time") or now_iso()

    put_json(DATA_KEY, state)
    execution_id = state.get("pipeline", {}).get("executionId")
    # Per-execution snapshots are not read by the UI, so they are off by default to halve
    # the S3 writes made by the one-minute reconciliation. Set WRITE_EXECUTION_SNAPSHOTS
    # to ENABLED if you want a retained per-execution copy for post-demo review.
    if execution_id and WRITE_EXECUTION_SNAPSHOTS:
        put_json(f"data/executions/{execution_id}.json", state)

    return {
        "ok": True,
        "bucket": DASHBOARD_BUCKET,
        "key": DATA_KEY,
        "executionId": execution_id,
        "status": state.get("pipeline", {}).get("status"),
    }
