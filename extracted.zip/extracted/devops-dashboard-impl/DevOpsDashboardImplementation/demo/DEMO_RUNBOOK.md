# Sales Demo Runbook

## Recommended live sequence

1. Open the dashboard from an approved network and keep CodePipeline in a second browser tab.
2. Start a known-good pipeline execution. Highlight the live stage ribbon, execution duration, revision metadata, SAST metrics, automated test results, central quality gate, and ServiceNow/Jira outbound status feed as each sidecar publishes.
3. Show the recent-executions table and success-rate KPI after the successful execution finishes.
4. Start a controlled known-failure execution in the demo branch/environment. Prefer a deterministic validation/test failure rather than a networking failure.
5. When the pipeline fails, point out that the dashboard immediately identifies the failed stage and changes the Bedrock panel to **Awaiting analysis**.
6. When the existing Bedrock failure-analysis sidecar completes, show the generated summary, likely root cause, and recommended remediation actions.
7. Close by showing the architecture/security footer: static UI, private S3 origin, CloudFront OAC, WAF allowlist, no AWS credentials in the browser, and no VPC changes.

## Rehearsal-only signal generator

`publish_demo_signals.py` can validate the UI and EventBridge wiring when external integrations are unavailable. It does **not** call ServiceNow, Jira, or Bedrock. Never describe its events as proof that those external systems were updated.

Example:

```bash
python demo/publish_demo_signals.py \
  --region us-east-2 \
  --pipeline YOUR_PIPELINE \
  --execution-id YOUR_CURRENT_EXECUTION_ID
```

## Demo resilience checklist

- Verify the current presenter public IPv4 address is in the WAF IP set before the meeting.
- Confirm the heartbeat reconciliation rule is enabled (telemetry stack output `HeartbeatRuleName`). If it was disabled between demos, re-enable it before rehearsing.
- Run one successful and one controlled-failure rehearsal on the same day.
- Verify ServiceNow/Jira links are safe to show to the client and do not expose confidential records.
- Verify the Bedrock publisher sends only summarized/sanitized output, never raw logs or prompts.
- Keep the CloudFront dashboard URL bookmarked and test it from the exact network/VPN used for the presentation.
- Keep the latest known-good dashboard build available locally so it can be re-uploaded without rebuilding dependencies.
