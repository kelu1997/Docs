/* Small presentational primitives shared by the drill-down views. */

import React from 'react';
import { Box, Header, StatusIndicator } from '@cloudscape-design/components';
import { fmtDuration } from './stats';

export function statusType(status) {
  switch (String(status || '').toUpperCase()) {
    case 'SUCCEEDED': case 'PASSED': case 'PASS': return 'success';
    case 'FAILED': case 'FAIL': case 'ABANDONED': return 'error';
    case 'IN_PROGRESS': case 'AWAITING_ANALYSIS': case 'STOPPING': case 'RUNNING': return 'in-progress';
    case 'STOPPED': case 'CANCELED': case 'SUPERSEDED': return 'stopped';
    case 'WAITING': case 'PENDING': case 'STANDBY': case 'SKIPPED': return 'pending';
    default: return 'info';
  }
}

export function labelStatus(status) {
  return String(status || 'PENDING').replaceAll('_', ' ').toLowerCase().replace(/\b\w/g, c => c.toUpperCase());
}

export function Status({ status, children }) {
  return <StatusIndicator type={statusType(status)}>{children || labelStatus(status)}</StatusIndicator>;
}

/** Headline number. `tone` tints the value for verdicts. */
export function Stat({ label, value, detail, status, tone, size }) {
  return (
    <div className={`stat${size === 'lg' ? ' stat-lg' : ''}`}>
      <div className="stat-label">{label}</div>
      <div className={`stat-value${tone ? ` tone-${tone}` : ''}`}>{value}</div>
      {(detail || status) && (
        <div className="stat-detail">
          {status ? <Status status={status}>{detail || labelStatus(status)}</Status> : detail}
        </div>
      )}
    </div>
  );
}

/** Dense label/value list. Rows with a null value are dropped, not shown as em dashes. */
export function Facts({ rows }) {
  const visible = rows.filter(r => r && r.value !== null && r.value !== undefined && r.value !== '' && r.value !== '—');
  if (!visible.length) return <Box color="text-body-secondary">No data yet.</Box>;
  return (
    <dl className="facts">
      {visible.map((r, i) => (
        <div className="fact" key={r.label + i}>
          <dt>{r.label}</dt>
          <dd>{r.value}{r.hint ? <span className="fact-hint">{r.hint}</span> : null}</dd>
        </div>
      ))}
    </dl>
  );
}

export function Bar({ value, tone = 'pass', label }) {
  const w = Math.max(0, Math.min(100, Number(value) || 0));
  return (
    <div className="mbar-wrap">
      {label ? <div className="mbar-label"><span>{label}</span><span>{w.toFixed(1)}%</span></div> : null}
      <div className="mbar"><i className={`tone-${tone}`} style={{ width: `${w}%` }} /></div>
    </div>
  );
}

/** Horizontal proportion bar for stage share of total time. */
export function ShareBar({ segments }) {
  const total = segments.reduce((a, s) => a + (s.value || 0), 0) || 1;
  return (
    <div className="sharebar">
      {segments.map((s, i) => (
        <span
          key={s.label + i}
          className={`share share-${statusType(s.status)}`}
          style={{ width: `${((s.value || 0) / total) * 100}%` }}
          title={`${s.label} · ${fmtDuration(s.value)}`}
        />
      ))}
    </div>
  );
}

/** Duration trend, oldest to newest. Colour marks failed runs. */
export function Sparkline({ points, height = 46 }) {
  if (!points?.length) return <Box color="text-body-secondary">Not enough history yet.</Box>;
  const vals = points.map(p => p.seconds).filter(v => typeof v === 'number');
  if (!vals.length) return <Box color="text-body-secondary">No durations recorded yet.</Box>;
  const max = Math.max(...vals);
  return (
    <div className="spark" style={{ height }}>
      {points.map((p, i) => (
        <span
          key={p.executionId || i}
          className={`spark-bar spark-${statusType(p.status)}`}
          style={{ height: `${max ? ((p.seconds || 0) / max) * 100 : 0}%` }}
          title={`${p.status} · ${fmtDuration(p.seconds)}`}
        />
      ))}
    </div>
  );
}

/** Delta against a historical average: negative is faster and reads as good. */
export function Delta({ seconds, pct }) {
  if (seconds === null || seconds === undefined) return <span className="delta-flat">no baseline</span>;
  const rounded = Math.round(seconds);
  if (rounded === 0) return <span className="delta-flat">on average</span>;
  const faster = rounded < 0;
  return (
    <span className={faster ? 'delta-good' : 'delta-bad'}>
      {faster ? '▼' : '▲'} {fmtDuration(Math.abs(rounded))} {faster ? 'faster' : 'slower'}
      {pct !== null && pct !== undefined && Number.isFinite(pct) ? ` (${Math.abs(pct).toFixed(0)}%)` : ''}
    </span>
  );
}

export function ViewHeader({ title, description, counter }) {
  return <Header variant="h1" counter={counter} description={description}>{title}</Header>;
}

export function StatGrid({ columns = 4, children }) {
  return <div className="stat-grid" style={{ '--cols': columns }}>{children}</div>;
}
