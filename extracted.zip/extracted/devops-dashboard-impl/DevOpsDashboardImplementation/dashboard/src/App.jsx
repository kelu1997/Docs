import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert, AppLayout, Badge, Button, ContentLayout, SideNavigation
} from '@cloudscape-design/components';
import { loadConfig, loadDashboard } from './api';
import { Status, statusType } from './ui';
import { currentRunStats, navSignals, telemetryStats, fmtDuration } from './stats';
import Overview from './views/Overview';
import Pipeline from './views/Pipeline';
import Quality from './views/Quality';
import Governance from './views/Governance';
import AiAssist from './views/AiAssist';
import Trends from './views/Trends';

const DEFAULT_CONFIG = {
  title: 'Application Delivery Control Center',
  subtitle: 'AWS-native delivery pipeline observability',
  environment: '',
  eyebrow: 'AUTOMATED AWS DEVOPS',
  logoUrl: '/brand-logo.svg',
  logoAlt: '',
  refreshSeconds: 5,
  dataUrl: '/data/dashboard.json'
};

const EMPTY = {
  generatedAt: null,
  pipeline: { name: 'Waiting for telemetry', status: 'WAITING' },
  stages: [], quality: {}, integrations: [], bedrock: { status: 'STANDBY' },
  history: [], timeline: [], kpis: {}, telemetry: {}
};

const VIEWS = [
  { id: 'overview', label: 'Overview', Component: Overview },
  { id: 'pipeline', label: 'Pipeline detail', Component: Pipeline },
  { id: 'quality', label: 'Quality evidence', Component: Quality },
  { id: 'governance', label: 'Governance', Component: Governance },
  { id: 'ai', label: 'AI failure assist', Component: AiAssist },
  { id: 'trends', label: 'Trends & history', Component: Trends }
];

/* Hash routing rather than paths. The distribution serves a private S3 origin with no
   custom error responses, so a path like /quality would ask S3 for an object that does
   not exist and OAC returns 403. Hash routes keep deep links and the back button working
   with no CloudFront change. */
function readHash() {
  const id = (window.location.hash || '').replace(/^#\/?/, '').trim();
  return VIEWS.some(v => v.id === id) ? id : 'overview';
}

function StageRail({ stages }) {
  if (!stages?.length) {
    return <div className="rail-empty">Stages appear once the first execution is observed.</div>;
  }
  return (
    <div className="rail">
      {stages.map((stage, i) => {
        const tone = statusType(stage.status);
        return (
          <div className="rail-item" key={stage.name}>
            <div className="rail-gut">
              <span className={`rail-dot rail-${tone}`} />
              {i < stages.length - 1 && <span className={`rail-line rail-line-${tone}`} />}
            </div>
            <div className="rail-body">
              <div className="rail-nm">{stage.name}</div>
              <div className="rail-sub">
                <Status status={stage.status} />
              </div>
              <div className="rail-sub rail-dur">{fmtDuration(stage.durationSeconds)}</div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

export default function App() {
  const [config, setConfig] = useState(DEFAULT_CONFIG);
  const [data, setData] = useState(EMPTY);
  const [error, setError] = useState(null);
  const [nowMs, setNowMs] = useState(Date.now());
  const [manualRefresh, setManualRefresh] = useState(0);
  const [view, setView] = useState(readHash);

  useEffect(() => {
    loadConfig()
      .then(loaded => setConfig({ ...DEFAULT_CONFIG, ...loaded }))
      .catch(() => setConfig(DEFAULT_CONFIG));
  }, []);

  useEffect(() => {
    if (config.title) document.title = config.title;
  }, [config.title]);

  useEffect(() => {
    const onHash = () => setView(readHash());
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

  // One poll feeds every view. Switching views is instant because it is the same
  // in-memory snapshot rendered differently, with no extra request.
  useEffect(() => {
    let cancelled = false;
    async function refresh() {
      try {
        const payload = await loadDashboard(config.dataUrl);
        if (!cancelled) { setData(payload); setError(null); }
      } catch (err) {
        if (!cancelled) setError(err.message);
      }
    }
    refresh();
    const timer = setInterval(refresh, Math.max(2, Number(config.refreshSeconds) || 5) * 1000);
    return () => { cancelled = true; clearInterval(timer); };
  }, [config.dataUrl, config.refreshSeconds, manualRefresh]);

  useEffect(() => {
    const timer = setInterval(() => setNowMs(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const go = useCallback(id => event => {
    if (event) event.preventDefault();
    window.location.hash = `#/${id}`;
    setView(id);
  }, []);

  const pipeline = data.pipeline || EMPTY.pipeline;
  const run = currentRunStats(data);
  const sig = navSignals(data);
  const tel = telemetryStats(data, nowMs);
  const active = VIEWS.find(v => v.id === view) || VIEWS[0];
  const ActiveView = active.Component;

  const navItems = useMemo(() => ([
    { type: 'link', text: 'Overview', href: '#/overview' },
    {
      type: 'link', text: 'Pipeline detail', href: '#/pipeline',
      info: sig.pipelineAlert ? <Badge color="red">Failed</Badge>
        : run.runningStage ? <Badge color="blue">Running</Badge> : null
    },
    {
      type: 'link', text: 'Quality evidence', href: '#/quality',
      info: sig.qualityAlert ? <Badge color="red">Blocked</Badge> : null
    },
    {
      type: 'link', text: 'Governance', href: '#/governance',
      info: sig.governanceAlert ? <Badge color="red">{String(sig.governanceCount)}</Badge>
        : sig.governanceCount ? <Badge color="grey">{String(sig.governanceCount)}</Badge> : null
    },
    {
      type: 'link', text: 'AI failure assist', href: '#/ai',
      info: sig.aiPending ? <Badge color="blue">Analysing</Badge>
        : sig.aiActive ? <Badge color="green">Ready</Badge> : null
    },
    { type: 'link', text: 'Trends & history', href: '#/trends' },
    { type: 'divider' },
    { type: 'link', text: 'Live pipeline', href: '#/pipeline' }
  ]), [sig, run.runningStage]);

  const navigation = (
    <div className="nav-shell">
      <SideNavigation
        activeHref={`#/${view}`}
        header={{ text: 'Delivery views', href: '#/overview' }}
        items={navItems}
        onFollow={event => {
          if (event.detail.external) return;
          event.preventDefault();
          const id = (event.detail.href || '').replace(/^#\/?/, '');
          window.location.hash = `#/${id}`;
          setView(id);
        }}
      />
      <div className="nav-rail">
        <div className="nav-rail-title">Current execution</div>
        <StageRail stages={data.stages} />
      </div>
    </div>
  );

  const header = (
    <div className="hero">
      <div className="hero-topline">
        <div className="hero-identity">
          {config.logoUrl && <img className="brand-logo" src={config.logoUrl} alt={config.logoAlt || ''} />}
          <div className="eyebrow">{config.eyebrow}</div>
          <h1>{config.title}</h1>
          <p>{config.subtitle}</p>
        </div>
        <div className="hero-actions">
          {config.environment ? <Badge color="blue">{config.environment}</Badge> : null}
          <div className="live-pill"><span className="live-dot" /> LIVE</div>
          <Button iconName="refresh" onClick={() => setManualRefresh(v => v + 1)}>Refresh</Button>
        </div>
      </div>
      <div className="hero-meta">
        <span><b>Pipeline</b> {pipeline.name || '—'}</span>
        <span><b>Status</b> {pipeline.status ? pipeline.status.replaceAll('_', ' ') : '—'}</span>
        <span><b>Elapsed</b> {fmtDuration(pipeline.durationSeconds)}</span>
        <span><b>Branch</b> {pipeline.branch || '—'}</span>
        <span><b>Commit</b> {String(pipeline.commitId || '—').slice(0, 10)}</span>
        <span><b>Telemetry age</b> {tel.snapshotAgeSeconds === null ? 'waiting' : `${tel.snapshotAgeSeconds}s`}</span>
      </div>
    </div>
  );

  return (
    <AppLayout
      toolsHide
      contentType="dashboard"
      navigationWidth={300}
      navigation={navigation}
      content={
        <ContentLayout header={header}>
          {error && (
            <div style={{ marginBottom: 16 }}>
              <Alert type="warning" header="Live telemetry temporarily unavailable">
                {error}. The last successful snapshot remains on screen.
              </Alert>
            </div>
          )}
          {tel.stale && !error && (
            <div style={{ marginBottom: 16 }}>
              <Alert type="warning" header="Snapshot is not refreshing">
                The data on screen is {tel.snapshotAgeSeconds}s old. Check that the reconciliation
                schedule is enabled and the telemetry function is not failing.
              </Alert>
            </div>
          )}
          <ActiveView data={data} nowMs={nowMs} go={go} />
        </ContentLayout>
      }
    />
  );
}
