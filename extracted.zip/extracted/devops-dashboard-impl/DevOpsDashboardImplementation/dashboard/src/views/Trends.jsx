import React from 'react';
import { Box, Container, Header, SpaceBetween, Table } from '@cloudscape-design/components';
import { Stat, StatGrid, Status, Facts, Sparkline, Bar, ViewHeader } from '../ui';
import { trendStats, telemetryStats, fmtDuration, fmtDateTime, fmtAgo, pct, num } from '../stats';

export default function Trends({ data, nowMs }) {
  const t = trendStats(data);
  const tel = telemetryStats(data, nowMs);

  return (
    <SpaceBetween size="l">
      <ViewHeader
        title="Delivery trends"
        counter={`(${t.completedExecutions} runs)`}
        description="Performance and reliability across the retained execution window."
      />

      <StatGrid columns={5}>
        <Stat label="Success rate" value={pct(t.successRatePct)}
          detail={`${t.succeededExecutions} of ${t.completedExecutions} completed`}
          tone={t.successRatePct === 100 ? 'pass' : t.failedExecutions ? 'warn' : null} size="lg" />
        <Stat label="Average duration" value={fmtDuration(t.averageDurationSeconds)}
          detail={t.medianDurationSeconds !== null ? `median ${fmtDuration(t.medianDurationSeconds)}` : null} />
        <Stat label="90th percentile" value={fmtDuration(t.p90DurationSeconds)} detail="9 in 10 finish within" />
        <Stat label="Consistency" value={t.consistencyPct !== null ? pct(t.consistencyPct, 0) : '—'}
          detail={t.durationSpreadSeconds !== null ? `±${fmtDuration(t.durationSpreadSeconds)} spread` : 'needs more runs'} />
        <Stat label="Throughput" value={t.executionsPerDay !== null ? `${t.executionsPerDay}` : '—'}
          detail={t.observedWindowHours !== null ? `runs/day over ${t.observedWindowHours}h` : 'runs per day'} />
      </StatGrid>

      <StatGrid columns={4}>
        <Stat label="Fastest run" value={fmtDuration(t.fastestDurationSeconds)} tone="pass" />
        <Stat label="Slowest run" value={fmtDuration(t.slowestDurationSeconds)} />
        <Stat label="Success streak" value={t.currentSuccessStreak ? num(t.currentSuccessStreak) : '—'}
          detail="consecutive passing runs" />
        <Stat label="Since last failure" value={t.secondsSinceLastFailure !== null ? fmtAgo(t.secondsSinceLastFailure) : 'no failures'}
          detail={t.failedExecutions ? `${t.failedExecutions} in window` : 'in retained window'} />
      </StatGrid>

      <Container header={<Header variant="h2"
        description="Execution duration, oldest on the left. Red bars are failed runs, which usually finish early because they stop at the failing stage.">
        Duration trend
      </Header>}>
        <Sparkline points={t.sparkline} height={64} />
      </Container>

      <Container header={<Header variant="h2"
        description="Averaged across completed executions in the window. This is what answers questions like average time to reach the test environment.">
        Average time per stage
      </Header>}>
        <Table
          variant="embedded"
          items={t.stageAverages}
          empty={<Box textAlign="center" color="inherit">
            Stage averages build up as executions complete. The first completed run seeds them.
          </Box>}
          columnDefinitions={[
            { id: 'stage', header: 'Stage', cell: s => <strong>{s.name}</strong> },
            { id: 'avg', header: 'Average', cell: s => fmtDuration(s.averageSeconds) },
            { id: 'median', header: 'Median', cell: s => fmtDuration(s.medianSeconds) },
            { id: 'fast', header: 'Fastest', cell: s => fmtDuration(s.fastestSeconds) },
            { id: 'slow', header: 'Slowest', cell: s => fmtDuration(s.slowestSeconds) },
            { id: 'share', header: 'Share of average run',
              cell: s => (t.averageDurationSeconds ? pct((s.averageSeconds / t.averageDurationSeconds) * 100, 0) : '—') },
            { id: 'bar', header: '',
              cell: s => <Bar value={t.slowestStageAvg ? (s.averageSeconds / t.slowestStageAvg.averageSeconds) * 100 : 0} tone="progress" /> },
            { id: 'samples', header: 'Runs', cell: s => num(s.samples) }
          ]}
        />
      </Container>

      <Container header={<Header variant="h2" counter={`(${t.history.length})`}
        description="Completed executions in the retained window.">
        Execution history
      </Header>}>
        <Table
          variant="embedded"
          items={t.history}
          empty={<Box textAlign="center" color="inherit">No completed executions yet.</Box>}
          columnDefinitions={[
            { id: 'exec', header: 'Execution', cell: h => String(h.executionId || '').slice(0, 10) },
            { id: 'status', header: 'Status', cell: h => <Status status={h.status} /> },
            { id: 'started', header: 'Started', cell: h => fmtDateTime(h.startTime) },
            { id: 'dur', header: 'Duration', cell: h => fmtDuration(h.durationSeconds) },
            { id: 'vs', header: 'vs average',
              cell: h => {
                if (typeof h.durationSeconds !== 'number' || !t.averageDurationSeconds) return '—';
                const d = h.durationSeconds - t.averageDurationSeconds;
                return <span className={d <= 0 ? 'delta-good' : 'delta-bad'}>{d <= 0 ? '▼' : '▲'} {fmtDuration(Math.abs(d))}</span>;
              } },
            { id: 'commit', header: 'Revision',
              cell: h => (h.revisionUrl
                ? <a href={h.revisionUrl} target="_blank" rel="noreferrer">{String(h.commitId || '').slice(0, 9)}</a>
                : String(h.commitId || '—').slice(0, 9)) },
            { id: 'msg', header: 'Change',
              cell: h => <span className="truncate-cell" title={h.commitMessage || ''}>{h.commitMessage || '—'}</span> }
          ]}
        />
      </Container>

      <Container header={<Header variant="h2"
        description="Freshness of the data on screen. The reconciliation schedule refreshes every minute even when no pipeline event arrives.">
        Telemetry health
      </Header>}>
        <StatGrid columns={4}>
          <Stat label="Snapshot age" value={tel.snapshotAgeSeconds !== null ? `${tel.snapshotAgeSeconds}s` : '—'}
            tone={tel.stale ? 'fail' : 'pass'} detail={tel.stale ? 'stale, check the telemetry rules' : 'current'} />
          <Stat label="Last event" value={tel.lastEventAgeSeconds !== null ? fmtAgo(tel.lastEventAgeSeconds) : '—'}
            detail={tel.lastEventType || 'no event type recorded'} />
          <Stat label="Reconciliation" value={tel.heartbeatAgeSeconds !== null ? fmtAgo(tel.heartbeatAgeSeconds) : '—'}
            detail={tel.heartbeat ? 'schedule is running' : 'schedule may be disabled'} />
          <Stat label="Window" value={t.observedWindowHours !== null ? `${t.observedWindowHours}h` : '—'}
            detail={`${t.completedExecutions} completed runs retained`} />
        </StatGrid>
      </Container>
    </SpaceBetween>
  );
}
