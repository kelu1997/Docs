import React from 'react';
import { Badge, Box, Container, Header, SpaceBetween, Table } from '@cloudscape-design/components';
import { Stat, StatGrid, Status, Facts, ViewHeader } from '../ui';
import { governanceStats, fmtDuration, fmtTime, pct, num } from '../stats';

function safeUrl(value) {
  if (!value) return null;
  try {
    const u = new URL(value);
    return ['http:', 'https:'].includes(u.protocol) ? u.href : null;
  } catch { return null; }
}

export default function Governance({ data }) {
  const g = governanceStats(data);
  const items = data.integrations || [];

  return (
    <SpaceBetween size="l">
      <ViewHeader
        title="Governance automation"
        counter={`(${g.total})`}
        description="Outbound record updates raised by the pipeline for this execution. These systems observe the pipeline; they do not gate it."
      />

      <StatGrid columns={5}>
        <Stat label="Updates sent" value={num(g.total)} detail={`${g.systemCount} target system${g.systemCount === 1 ? '' : 's'}`} />
        <Stat label="Delivered" value={pct(g.successRatePct, 0)}
          detail={g.failed ? `${g.failed} failed` : 'no delivery failures'}
          tone={g.failed ? 'fail' : 'pass'} />
        <Stat label="Records touched" value={num(g.uniqueRecords)} detail="distinct external ids" />
        <Stat label="Avg latency" value={g.avgLatencySeconds !== null ? fmtDuration(g.avgLatencySeconds) : '—'}
          detail={g.latencySamples ? `${g.latencySamples} measured` : 'stage end to record update'} />
        <Stat label="Latency range" value={g.fastestLatencySeconds !== null
            ? `${fmtDuration(g.fastestLatencySeconds)} – ${fmtDuration(g.slowestLatencySeconds)}` : '—'}
          detail="fastest to slowest" />
      </StatGrid>

      <Container header={<Header variant="h2"
        description="One row per target system. Adding a new outbound integration needs no dashboard change.">
        By target system
      </Header>}>
        <Table
          variant="embedded"
          items={g.systems}
          empty={<Box textAlign="center" color="inherit">No outbound updates for this execution yet.</Box>}
          columnDefinitions={[
            { id: 'system', header: 'System', cell: s => <strong>{s.name}</strong> },
            { id: 'sent', header: 'Updates', cell: s => num(s.total) },
            { id: 'ok', header: 'Delivered', cell: s => num(s.succeeded) },
            { id: 'failed', header: 'Failed', cell: s => (s.failed ? <span className="tone-fail">{s.failed}</span> : '0') },
            { id: 'rate', header: 'Delivery rate', cell: s => pct(s.total ? (s.succeeded / s.total) * 100 : null, 0) },
            { id: 'records', header: 'Records', cell: s => (s.records.length ? s.records.join(', ') : '—') },
            { id: 'last', header: 'Last update', cell: s => fmtTime(s.last) }
          ]}
        />
      </Container>

      <Container header={<Header variant="h2" counter={`(${items.length})`}
        description="Full feed for this execution, newest first. Multiple updates to the same record are retained deliberately.">
        Update feed
      </Header>}>
        {items.length ? (
          <div className="feed">
            {items.map((item, i) => {
              const url = safeUrl(item.externalUrl);
              return (
                <div className="feed-row" key={item.id || i}>
                  <div className="ico">{(item.integration || '?').slice(0, 2).toUpperCase()}</div>
                  <div>
                    <div className="feed-t">
                      <strong>{item.integration || 'Integration'}</strong>
                      <span>{item.operation || 'Status update'}</span>
                    </div>
                    <div className="feed-m">
                      {item.stage ? <Badge color="blue">{item.stage}</Badge> : null}
                      {item.externalId ? <span>{item.externalId}</span> : null}
                      <span>{fmtTime(item.timestamp)}</span>
                    </div>
                    {item.message ? <div className="feed-msg">{item.message}</div> : null}
                  </div>
                  <div className="feed-r">
                    <Status status={item.status} />
                    {url ? <a href={url} target="_blank" rel="noreferrer">Open record</a> : null}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <Box color="text-body-secondary">
            No outbound status events for this execution yet. Each integration publishes a success or
            failure event as it completes.
          </Box>
        )}
      </Container>

      <Container header={<Header variant="h2" description="How latency is derived.">Notes</Header>}>
        <Facts rows={[
          { label: 'Latency basis', value: 'Time from the last action in a stage reaching a terminal state to the outbound record update being published.' },
          { label: 'Measured samples', value: g.latencySamples ? `${g.latencySamples} of ${g.total} updates` : 'none yet' },
          { label: 'Accuracy', value: 'Indicative. The two timestamps come from different producers, so treat small values as approximate.' }
        ]} />
      </Container>
    </SpaceBetween>
  );
}
