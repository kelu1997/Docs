import React from 'react';
import { Box, Container, Header, SpaceBetween } from '@cloudscape-design/components';
import { Stat, StatGrid, Status, Facts, ViewHeader } from '../ui';
import { aiStats, currentRunStats, fmtDuration, fmtTime, num } from '../stats';

export default function AiAssist({ data }) {
  const ai = aiStats(data);
  const run = currentRunStats(data);

  return (
    <SpaceBetween size="l">
      <ViewHeader
        title="AI failure assist"
        description="Generative failure analysis. Dormant while the pipeline is healthy, and populated automatically when a stage fails."
      />

      <StatGrid columns={4}>
        <Stat label="Analysis state" value={ai.status ? ai.status.replaceAll('_', ' ') : 'Standby'} status={ai.status} />
        <Stat label="Source stage" value={ai.sourceStage || run.failedStage?.name || '—'}
          detail={run.failedStage ? 'failure detected' : 'no failure this run'} />
        <Stat label="Response time" value={ai.responseSeconds !== null ? fmtDuration(ai.responseSeconds) : '—'}
          detail="failure to analysis published" />
        <Stat label="Recommended actions" value={ai.actionCount ? num(ai.actionCount) : '—'}
          detail={ai.summaryWords ? `${ai.summaryWords} word summary` : 'awaiting analysis'} />
      </StatGrid>

      <div className="ai-panel">
        <div className="ai-head">
          <div>
            <div className="ai-eyebrow">GENERATIVE AI FAILURE ASSIST</div>
            <h3>Automated failure analysis</h3>
          </div>
          <Status status={ai.status} />
        </div>

        <div className="ai-summary">
          {ai.summary || 'Failure analysis is standing by and will populate automatically when a stage reports a failure.'}
        </div>

        {ai.rootCause ? (
          <div className="ai-section">
            <div className="ai-label">Likely root cause</div>
            <div>{ai.rootCause}</div>
          </div>
        ) : null}

        {ai.recommendedActions.length ? (
          <div className="ai-section">
            <div className="ai-label">Recommended actions</div>
            <ol>{ai.recommendedActions.map((a, i) => <li key={i}>{a}</li>)}</ol>
          </div>
        ) : null}

        {!ai.triggered ? (
          <div className="ai-section">
            <div className="ai-label">What happens on failure</div>
            <ol>
              <li>The failed stage turns red immediately.</li>
              <li>This panel switches to awaiting analysis before any AI response exists.</li>
              <li>Failure evidence is collected within bounds and redacted.</li>
              <li>The analysis is published and appears here with a root cause and remediation steps.</li>
            </ol>
          </div>
        ) : null}

        <div className="ai-footer">
          {ai.sourceStage ? <span>Source: {ai.sourceStage}</span> : null}
          {ai.modelId ? <span>Provenance: {ai.modelId}</span> : null}
          {ai.analysisId ? <span>Correlation: {ai.analysisId}</span> : null}
          {ai.timestamp ? <span>Analysed: {fmtTime(ai.timestamp)}</span> : null}
          {!ai.triggered ? <span>Awaiting trigger</span> : null}
        </div>
      </div>

      <Container header={<Header variant="h2" description="Metadata for this analysis.">Analysis detail</Header>}>
        <Facts rows={[
          { label: 'State', value: ai.status ? <Status status={ai.status} /> : null },
          { label: 'Correlated execution', value: ai.executionId },
          { label: 'Source stage', value: ai.sourceStage },
          { label: 'Provenance', value: ai.modelId },
          { label: 'Correlation id', value: ai.analysisId },
          { label: 'Published', value: ai.timestamp ? fmtTime(ai.timestamp) : null },
          { label: 'Response time', value: ai.responseSeconds !== null ? fmtDuration(ai.responseSeconds) : null },
          { label: 'Recommended actions', value: ai.actionCount ? num(ai.actionCount) : null }
        ]} />
        {!ai.triggered ? (
          <Box color="text-body-secondary" padding={{ top: 'm' }}>
            Only summarised, redacted fields reach this panel. Raw logs, prompts and evidence bodies stay
            in the evidence archive and are never sent to the browser.
          </Box>
        ) : null}
      </Container>
    </SpaceBetween>
  );
}
