import React from 'react';
import { Box, Container, Header, SpaceBetween } from '@cloudscape-design/components';
import { Stat, StatGrid, Status, Facts, Bar, ViewHeader } from '../ui';
import {
  currentRunStats, qualityStats, governanceStats, aiStats, trendStats,
  fmtDuration, fmtTime, fmtAgo, pct, num
} from '../stats';

export default function Overview({ data, go }) {
  const run = currentRunStats(data);
  const q = qualityStats(data);
  const g = governanceStats(data);
  const ai = aiStats(data);
  const t = trendStats(data);
  const p = data.pipeline || {};

  return (
    <SpaceBetween size="l">
      <ViewHeader
        title="Delivery overview"
        description="Headline state of the current execution and recent delivery performance."
      />

      <StatGrid columns={5}>
        <Stat label="Pipeline" value={run.failedStage ? 'Failed' : run.runningStage ? 'Running' : 'Succeeded'}
          status={p.status}
          detail={run.runningStage ? run.runningStage.name : run.failedStage ? run.failedStage.name : 'Current execution'} />
        <Stat label="Elapsed" value={fmtDuration(p.durationSeconds)}
          detail={t.averageDurationSeconds ? `avg ${fmtDuration(t.averageDurationSeconds)}` : 'no baseline yet'} />
        <Stat label="Quality gate" value={q.gate.decision || '—'} status={q.gate.status}
          tone={q.gate.decision === 'PASS' ? 'pass' : q.gate.decision === 'FAIL' ? 'fail' : null}
          detail={q.gate.blockingChecks ? `${q.gate.blockingChecks} blocking` : 'central decision'} />
        <Stat label="Test pass rate" value={pct(q.tests.passRatePct)}
          detail={q.tests.total ? `${q.tests.passed} of ${q.tests.total}` : 'awaiting results'} />
        <Stat label="Success rate" value={pct(t.successRatePct)}
          detail={t.completedExecutions ? `last ${t.completedExecutions} runs` : 'no history'} />
      </StatGrid>

      <div className="two-col">
        <Container header={<Header variant="h2" description="Evidence feeding the gate decision."
          actions={<a className="drill" href="#/quality" onClick={go('quality')}>Quality detail →</a>}>
          Quality signals
        </Header>}>
          <StatGrid columns={3}>
            <Stat label="Static analysis" value={q.sast.hasSeverities ? num(q.sast.findings) : '—'}
              status={q.sast.status}
              detail={q.sast.hasSeverities ? `${q.sast.blocking} critical or high` : 'awaiting scan'} />
            <Stat label="Tests passed" value={q.tests.total ? `${q.tests.passed}/${q.tests.total}` : '—'}
              status={q.tests.status} detail={q.tests.framework || 'awaiting results'} />
            <Stat label="Load p95" value={q.load.p95Ms !== null ? `${num(q.load.p95Ms)} ms` : '—'}
              detail={q.load.errorRatePct !== null ? `${q.load.errorRatePct}% errors` : 'no load run'} />
          </StatGrid>
          <div style={{ marginTop: 14 }}>
            <Bar value={q.tests.passRatePct || 0} label="Test pass rate" />
          </div>
        </Container>

        <Container header={<Header variant="h2" description="Outbound records updated by the pipeline."
          actions={<a className="drill" href="#/governance" onClick={go('governance')}>Governance detail →</a>}>
          Governance automation
        </Header>}>
          <StatGrid columns={3}>
            <Stat label="Updates sent" value={num(g.total)} detail={`${g.systemCount} systems`} />
            <Stat label="Delivered" value={pct(g.successRatePct, 0)} detail={g.failed ? `${g.failed} failed` : 'no failures'} />
            <Stat label="Avg latency" value={g.avgLatencySeconds !== null ? fmtDuration(g.avgLatencySeconds) : '—'}
              detail={g.latencySamples ? `${g.latencySamples} samples` : 'stage to record'} />
          </StatGrid>
          {g.systems.length ? (
            <div className="chips" style={{ marginTop: 14 }}>
              {g.systems.map(s => (
                <span className="chip-stat" key={s.name}>
                  <b>{s.name}</b> {s.succeeded}/{s.total}
                  {s.recordCount ? <span> · {s.recordCount} record{s.recordCount === 1 ? '' : 's'}</span> : null}
                </span>
              ))}
            </div>
          ) : <Box color="text-body-secondary" padding={{ top: 's' }}>No outbound updates for this execution yet.</Box>}
        </Container>
      </div>

      <div className="two-col">
        <Container header={<Header variant="h2" description="Most recent events across pipeline, quality and governance.">
          Latest activity
        </Header>}>
          <div className="tl">
            {(data.timeline || []).slice(0, 7).map((item, i) => (
              <div className="tl-item" key={item.id || i}>
                <span className={`tl-dot dot-${item.status?.toLowerCase()}`} />
                <div>
                  <div className="tl-t"><strong>{item.title || item.service}</strong><span>{fmtTime(item.timestamp)}</span></div>
                  {item.message ? <div className="tl-m">{item.message}</div> : null}
                </div>
              </div>
            ))}
            {!(data.timeline || []).length ? <Box color="text-body-secondary">Activity will appear here.</Box> : null}
          </div>
        </Container>

        <Container header={<Header variant="h2" description="Delivery performance over the observed window."
          actions={<a className="drill" href="#/trends" onClick={go('trends')}>Trends →</a>}>
          Recent performance
        </Header>}>
          <Facts rows={[
            { label: 'Average duration', value: fmtDuration(t.averageDurationSeconds) },
            { label: 'Median duration', value: fmtDuration(t.medianDurationSeconds) },
            { label: 'Fastest / slowest', value: t.fastestDurationSeconds !== null ? `${fmtDuration(t.fastestDurationSeconds)} / ${fmtDuration(t.slowestDurationSeconds)}` : null },
            { label: 'Consecutive successes', value: t.currentSuccessStreak ? num(t.currentSuccessStreak) : null },
            { label: 'Time since last failure', value: t.secondsSinceLastFailure !== null ? fmtAgo(t.secondsSinceLastFailure) : null },
            { label: 'Throughput', value: t.executionsPerDay !== null ? `${t.executionsPerDay} runs/day` : null },
            { label: 'AI failure assist', value: ai.status ? <Status status={ai.status} /> : null }
          ]} />
        </Container>
      </div>
    </SpaceBetween>
  );
}
