import React from 'react';
import { Box, Container, Header, SpaceBetween, Table } from '@cloudscape-design/components';
import { Stat, StatGrid, Status, Facts, ShareBar, Delta, ViewHeader } from '../ui';
import { currentRunStats, stageBreakdown, fmtDuration, fmtTime, pct, num } from '../stats';

export default function Pipeline({ data }) {
  const run = currentRunStats(data);
  const stages = stageBreakdown(data);
  const p = data.pipeline || {};
  const allActions = stages.flatMap(s => s.actions.map(a => ({ ...a, stageName: s.name })));

  return (
    <SpaceBetween size="l">
      <ViewHeader
        title="Pipeline detail"
        counter={`(${run.stageCount} stages)`}
        description="Per-stage and per-action timing for the current execution, compared with this pipeline's own history."
      />

      <StatGrid columns={5}>
        <Stat label="Wall clock" value={fmtDuration(p.durationSeconds)} detail={p.startTime ? `started ${fmtTime(p.startTime)}` : null} />
        <Stat label="Stage execution" value={fmtDuration(run.totalStageSeconds)}
          detail={run.stageCount ? `across ${run.stageCount} stages` : null} />
        <Stat label="Queue overhead" value={run.overheadSeconds !== null ? fmtDuration(run.overheadSeconds) : '—'}
          detail={run.overheadPct !== null ? `${run.overheadPct.toFixed(0)}% of wall clock` : 'transitions and waits'} />
        <Stat label="Progress" value={run.progressPct !== null ? pct(run.progressPct, 0) : '—'}
          detail={`${run.completedStages} succeeded, ${run.pendingStages} pending`} />
        <Stat label="Actions" value={run.actionCount ? `${run.succeededActions}/${run.actionCount}` : '—'}
          detail={run.slowestAction ? `slowest ${run.slowestAction.name}` : null} />
      </StatGrid>

      <Container header={<Header variant="h2" description="Proportion of stage time consumed by each stage.">
        Time distribution
      </Header>}>
        <ShareBar segments={stages.map(s => ({ label: s.name, value: s.durationSeconds, status: s.status }))} />
        <div className="legend" style={{ marginTop: 12 }}>
          {stages.map(s => (
            <span className="legend-item" key={s.name}>
              <i className={`swatch swatch-${s.status?.toLowerCase()}`} />
              <b>{s.name}</b><span>{fmtDuration(s.durationSeconds)}</span>
              {s.sharePct !== null ? <span className="legend-pct">{s.sharePct.toFixed(0)}%</span> : null}
            </span>
          ))}
        </div>
      </Container>

      <Container header={<Header variant="h2"
        description="Averages are computed from completed executions in the retained window. A stage needs at least one completed run before a baseline appears.">
        Stage timing against baseline
      </Header>}>
        <Table
          variant="embedded"
          items={stages}
          empty={<Box textAlign="center" color="inherit">Waiting for the first execution.</Box>}
          columnDefinitions={[
            { id: 'order', header: '#', cell: s => String(s.order).padStart(2, '0'), width: 60 },
            { id: 'stage', header: 'Stage', cell: s => <strong>{s.name}</strong> },
            { id: 'status', header: 'Status', cell: s => <Status status={s.status} /> },
            { id: 'this', header: 'This run', cell: s => fmtDuration(s.durationSeconds) },
            { id: 'avg', header: 'Average', cell: s => fmtDuration(s.averageSeconds) },
            { id: 'median', header: 'Median', cell: s => fmtDuration(s.medianSeconds) },
            { id: 'range', header: 'Fastest / slowest',
              cell: s => (s.fastestSeconds !== null ? `${fmtDuration(s.fastestSeconds)} / ${fmtDuration(s.slowestSeconds)}` : '—') },
            { id: 'delta', header: 'vs average', cell: s => <Delta seconds={s.deltaSeconds} pct={s.deltaPct} /> },
            { id: 'samples', header: 'Runs', cell: s => (s.samples ? num(s.samples) : '—') }
          ]}
        />
      </Container>

      <Container header={<Header variant="h2" counter={`(${allActions.length})`}
        description="Individual action executions, newest stage last. External links open the underlying build or job where the provider exposes one.">
        Action execution detail
      </Header>}>
        <Table
          variant="embedded"
          items={allActions}
          empty={<Box textAlign="center" color="inherit">No action detail reported yet.</Box>}
          columnDefinitions={[
            { id: 'stage', header: 'Stage', cell: a => a.stageName },
            { id: 'action', header: 'Action', cell: a => <strong>{a.name}</strong> },
            { id: 'status', header: 'Status', cell: a => <Status status={a.status} /> },
            { id: 'start', header: 'Started', cell: a => fmtTime(a.startTime) },
            { id: 'updated', header: 'Updated', cell: a => fmtTime(a.lastUpdateTime) },
            { id: 'dur', header: 'Duration', cell: a => fmtDuration(a.durationSeconds) },
            { id: 'code', header: 'Error code', cell: a => a.errorCode || '—' },
            { id: 'summary', header: 'Summary',
              cell: a => <span className="truncate-cell" title={a.summary || ''}>{a.summary || '—'}</span> },
            { id: 'link', header: '', cell: a => (a.externalUrl ? <a href={a.externalUrl} target="_blank" rel="noreferrer">Open</a> : null) }
          ]}
        />
      </Container>

      <Container header={<Header variant="h2" description="Source revision that produced this execution.">
        Revision
      </Header>}>
        <Facts rows={[
          { label: 'Pipeline', value: p.name },
          { label: 'Region', value: p.region },
          { label: 'Execution id', value: p.executionId },
          { label: 'Trigger', value: p.trigger },
          { label: 'Repository', value: p.repository },
          { label: 'Branch', value: p.branch },
          { label: 'Commit', value: p.revisionUrl
              ? <a href={p.revisionUrl} target="_blank" rel="noreferrer">{p.commitId}</a>
              : p.commitId },
          { label: 'Change', value: p.commitMessage }
        ]} />
      </Container>
    </SpaceBetween>
  );
}
