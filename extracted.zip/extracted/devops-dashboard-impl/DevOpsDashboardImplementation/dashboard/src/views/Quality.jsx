import React from 'react';
import { Alert, Box, Container, Header, SpaceBetween } from '@cloudscape-design/components';
import { Stat, StatGrid, Status, Facts, Bar, ViewHeader } from '../ui';
import { qualityStats, fmtDuration, fmtTime, pct, num } from '../stats';

export default function Quality({ data }) {
  const q = qualityStats(data);

  return (
    <SpaceBetween size="l">
      <ViewHeader
        title="Quality evidence"
        description="Static analysis, automated testing and load results, and the central gate decision they feed."
      />

      <StatGrid columns={5}>
        <Stat label="Gate decision" value={q.gate.decision || '—'} status={q.gate.status}
          tone={q.gate.decision === 'PASS' ? 'pass' : q.gate.decision === 'FAIL' ? 'fail' : null}
          detail={q.gate.timestamp ? `evaluated ${fmtTime(q.gate.timestamp)}` : 'awaiting evaluation'} size="lg" />
        <Stat label="Unit and smoke" value={q.unit.total ? `${q.unit.passed}/${q.unit.total}` : '—'}
          status={q.unit.status}
          detail={q.unit.present ? `${q.unit.failed} failed` : 'not configured'} />
        <Stat label="Blocking findings" value={q.sast.hasSeverities ? num(q.sast.blocking) : '—'}
          detail="critical + high" />
        <Stat label="Test pass rate" value={pct(q.tests.passRatePct)}
          detail={q.tests.total ? `${q.tests.executed} of ${q.tests.total} executed` : 'awaiting results'} />
        <Stat label="Load p95" value={q.load.p95Ms !== null ? `${num(q.load.p95Ms)} ms` : '—'}
          detail={q.load.status ? `profile ${q.load.profile || 'default'}` : 'no load run recorded'} />
      </StatGrid>

      {q.gate.decision === 'FAIL' && q.gate.reasons.length ? (
        <Alert type="error" header="Central quality gate blocked this release">
          <ul className="reasons">{q.gate.reasons.map((r, i) => <li key={i}>{r}</li>)}</ul>
        </Alert>
      ) : null}

      <div className="two-col">
        <Container header={<Header variant="h2"
          description={q.sast.tool ? `Scanner: ${q.sast.tool}` : 'Severity counts published by the static analysis stage.'}
          actions={<Status status={q.sast.status} />}>
          Static analysis
        </Header>}>
          {q.sast.hasSeverities ? (
            <SpaceBetween size="m">
              <StatGrid columns={4}>
                <Stat label="Critical" value={num(q.sast.critical)} tone={q.sast.critical ? 'fail' : 'pass'} />
                <Stat label="High" value={num(q.sast.high)} tone={q.sast.high ? 'warn' : 'pass'} />
                <Stat label="Medium" value={num(q.sast.medium)} />
                <Stat label="Low" value={num(q.sast.low)} />
              </StatGrid>
              <Facts rows={[
                { label: 'Total findings', value: num(q.sast.findings) },
                { label: 'Blocking (critical + high)', value: num(q.sast.blocking) },
                { label: 'Weighted risk score', value: num(q.sast.riskScore) },
                { label: 'Scanner', value: q.sast.tool },
                { label: 'Result', value: q.sast.detail },
                { label: 'Published', value: q.sast.timestamp ? fmtTime(q.sast.timestamp) : null }
              ]} />
            </SpaceBetween>
          ) : (
            <Box color="text-body-secondary">
              Severity counts are not published by the current scan configuration. Status and result are
              reported, but per-severity numbers need the scan stage to export them.
              {q.sast.detail ? <div style={{ marginTop: 8 }}>Result: {q.sast.detail}</div> : null}
            </Box>
          )}
        </Container>

        <Container header={<Header variant="h2"
          description={q.unit.suite ? `Suite: ${q.unit.suite}` : 'Fast unit and smoke tests, run immediately after Source.'}
          actions={<Status status={q.unit.status} />}>
          Unit and smoke tests
        </Header>}>
          {q.unit.present ? (
            <SpaceBetween size="m">
              <StatGrid columns={4}>
                <Stat label="Passed" value={num(q.unit.passed)} tone="pass" />
                <Stat label="Failed" value={num(q.unit.failed)} tone={q.unit.failed ? 'fail' : null} />
                <Stat label="Skipped" value={num(q.unit.skipped)} />
                <Stat label="Total" value={num(q.unit.total)} />
              </StatGrid>
              <Bar value={q.unit.passRatePct || 0} label="Pass rate" />
              <Facts rows={[
                { label: 'Pass rate', value: pct(q.unit.passRatePct) },
                { label: 'Suite', value: q.unit.suite },
                { label: 'Run time', value: q.unit.durationSeconds !== null ? fmtDuration(q.unit.durationSeconds) : null },
                { label: 'Published', value: q.unit.timestamp ? fmtTime(q.unit.timestamp) : null }
              ]} />
            </SpaceBetween>
          ) : (
            <Box color="text-body-secondary">
              No unit or smoke test result for this execution. This stage runs before anything is
              deployed, so it is the first quality signal to appear when configured.
            </Box>
          )}
        </Container>
      </div>

      <div className="two-col">
        <Container header={<Header variant="h2"
          description={q.tests.framework ? `Suites: ${q.tests.framework}` : 'Automated test results.'}
          actions={<Status status={q.tests.status} />}>
          Automated tests
        </Header>}>
          <SpaceBetween size="m">
            <StatGrid columns={4}>
              <Stat label="Passed" value={num(q.tests.passed)} tone="pass" />
              <Stat label="Failed" value={num(q.tests.failed)} tone={q.tests.failed ? 'fail' : null} />
              <Stat label="Skipped" value={num(q.tests.skipped)} />
              <Stat label="Total" value={num(q.tests.total)} />
            </StatGrid>
            <Bar value={q.tests.passRatePct || 0} label="Pass rate of all tests" />
            <Bar value={q.tests.coveragePct || 0} tone="progress" label="Executed (not skipped)" />
            <Facts rows={[
              { label: 'Pass rate of executed', value: pct(q.tests.passRateOfExecutedPct) },
              { label: 'Fail rate', value: pct(q.tests.failRatePct) },
              { label: 'Suites', value: q.tests.framework },
              { label: 'Test set', value: q.tests.toscaTestSet },
              { label: 'Published', value: q.tests.timestamp ? fmtTime(q.tests.timestamp) : null }
            ]} />
          </SpaceBetween>
        </Container>

        <Container header={<Header variant="h2"
          description="Latency, throughput and error rate observed by the load profile, evaluated against its configured thresholds."
          actions={q.load.status ? <Status status={q.load.status} /> : null}>
          Load and performance
        </Header>}>
          {q.load.present ? (
            <SpaceBetween size="m">
              <StatGrid columns={4}>
                <Stat label="Result" value={q.load.status} status={q.load.status} />
                <Stat label="p95 latency" value={q.load.p95Ms !== null ? `${num(q.load.p95Ms)} ms` : '—'}
                  tone={q.load.p95UsedPct > 100 ? 'fail' : q.load.p95UsedPct > 80 ? 'warn' : 'pass'}
                  detail={q.load.p95ThresholdMs ? `threshold ${num(q.load.p95ThresholdMs)} ms` : null} />
                <Stat label="Error rate" value={q.load.errorRatePct !== null ? pct(q.load.errorRatePct, 2) : '—'}
                  tone={q.load.errorUsedPct > 100 ? 'fail' : q.load.errorUsedPct > 80 ? 'warn' : 'pass'}
                  detail={q.load.errorRateThresholdPct ? `threshold ${q.load.errorRateThresholdPct}%` : null} />
                <Stat label="Throughput" value={q.load.throughputRps !== null ? `${num(q.load.throughputRps)} rps` : '—'}
                  detail={q.load.virtualUsers ? `${num(q.load.virtualUsers)} virtual users` : null} />
              </StatGrid>

              {q.load.p95UsedPct !== null ? (
                <Bar value={Math.min(100, q.load.p95UsedPct)}
                  tone={q.load.p95UsedPct > 100 ? 'fail' : 'progress'}
                  label="p95 latency against threshold" />
              ) : null}
              {q.load.errorUsedPct !== null ? (
                <Bar value={Math.min(100, q.load.errorUsedPct)}
                  tone={q.load.errorUsedPct > 100 ? 'fail' : 'progress'}
                  label="Error rate against threshold" />
              ) : null}

              {q.load.breaches.length ? (
                <Alert type="error" header="Threshold breaches">
                  <ul className="reasons">{q.load.breaches.map((b, i) => <li key={i}>{b}</li>)}</ul>
                </Alert>
              ) : null}

              <Facts rows={[
                { label: 'Profile', value: q.load.profile,
                  hint: q.load.requestedProfile && q.load.requestedProfile !== q.load.profile
                    ? ` (requested ${q.load.requestedProfile})` : '' },
                { label: 'Scenario', value: q.load.scenarioKey },
                { label: 'Virtual users', value: q.load.virtualUsers !== null ? num(q.load.virtualUsers) : null },
                { label: 'Duration', value: q.load.durationSeconds !== null ? `${num(q.load.durationSeconds)}s` : null },
                { label: 'Average latency', value: q.load.avgMs !== null ? `${num(q.load.avgMs)} ms` : null },
                { label: 'p95 latency headroom', value: q.load.p95HeadroomPct !== null ? pct(q.load.p95HeadroomPct, 0) : null },
                { label: 'Error-rate headroom', value: q.load.errorHeadroomPct !== null ? pct(q.load.errorHeadroomPct, 0) : null },
                { label: 'Requests', value: q.load.totalRequests !== null
                    ? `${num(q.load.totalRequests)} total, ${num(q.load.failedRequests)} failed` : null },
                { label: 'Published', value: q.load.timestamp ? fmtTime(q.load.timestamp) : null }
              ]} />
            </SpaceBetween>
          ) : (
            <Box color="text-body-secondary">
              No load-test result for this execution yet. When the load stage completes, its
              profile, latency, throughput, error rate and threshold headroom appear here.
            </Box>
          )}
        </Container>
      </div>

      <Container header={<Header variant="h2"
          description="The single authoritative release decision. Individual checks report to the gate rather than failing their own stage."
          actions={<Status status={q.gate.status} />}>
          Central quality gate
        </Header>}>
          <SpaceBetween size="m">
            <div className={`verdict-block verdict-${(q.gate.decision || 'wait').toLowerCase()}`}>
              <div className="verdict-lab">Decision</div>
              <div className="verdict-big">{q.gate.decision || 'AWAITING'}</div>
            </div>
            <Facts rows={[
              { label: 'Blocking checks', value: q.gate.blockingChecks !== null ? num(q.gate.blockingChecks) : null },
              { label: 'Evaluated', value: q.gate.timestamp ? fmtTime(q.gate.timestamp) : null },
              { label: 'Reasoning', value: q.gate.reason }
            ]} />
          </SpaceBetween>
        </Container>
    </SpaceBetween>
  );
}
