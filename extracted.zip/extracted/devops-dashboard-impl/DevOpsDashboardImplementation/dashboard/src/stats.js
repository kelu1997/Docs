/*
 * Derived metrics.
 *
 * Everything here is computed in the browser from the single dashboard.json snapshot.
 * No extra requests, and nothing here requires a telemetry or pipeline change, with one
 * exception: kpis.stageAverages is produced by the telemetry Lambda, because per-stage
 * durations for *past* executions are not available from CodePipeline's
 * ListPipelineExecutions and have to be accumulated server side.
 *
 * Pure functions only, so they can be exercised without a browser.
 */

const TERMINAL = new Set(['SUCCEEDED', 'FAILED', 'STOPPED', 'CANCELED', 'SUPERSEDED']);

export function fmtDuration(seconds) {
  if (seconds === null || seconds === undefined || Number.isNaN(Number(seconds))) return '—';
  const total = Math.max(0, Math.round(Number(seconds)));
  if (total < 60) return `${total}s`;
  const m = Math.floor(total / 60);
  const s = total % 60;
  if (m < 60) return s ? `${m}m ${s}s` : `${m}m`;
  const h = Math.floor(m / 60);
  return `${h}h ${m % 60}m`;
}

export function fmtAgo(seconds) {
  if (seconds === null || seconds === undefined) return '—';
  const total = Math.max(0, Math.round(Number(seconds)));
  if (total < 90) return `${total}s ago`;
  if (total < 5400) return `${Math.round(total / 60)}m ago`;
  if (total < 172800) return `${Math.round(total / 3600)}h ago`;
  return `${Math.round(total / 86400)}d ago`;
}

export function fmtTime(value) {
  if (!value) return '—';
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? String(value) : d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

export function fmtDateTime(value) {
  if (!value) return '—';
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? String(value) : d.toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

export function pct(value, digits = 1) {
  if (value === null || value === undefined || Number.isNaN(Number(value))) return '—';
  return `${Number(value).toFixed(digits)}%`;
}

export function num(value) {
  if (value === null || value === undefined || value === '') return '—';
  return typeof value === 'number' ? value.toLocaleString() : String(value);
}

const epoch = value => {
  if (!value) return null;
  const t = new Date(value).getTime();
  return Number.isNaN(t) ? null : t / 1000;
};

/* ---------------------------------------------------------------- current run */

export function currentRunStats(data) {
  const stages = data.stages || [];
  const timed = stages.filter(s => typeof s.durationSeconds === 'number');
  const totalStageSeconds = timed.reduce((a, s) => a + s.durationSeconds, 0);
  const slowest = timed.reduce((best, s) => (!best || s.durationSeconds > best.durationSeconds ? s : best), null);

  const allActions = stages.flatMap(s => (s.actions || []).map(a => ({ ...a, stageName: s.name })));
  const timedActions = allActions.filter(a => typeof a.durationSeconds === 'number');
  const slowestAction = timedActions.reduce((best, a) => (!best || a.durationSeconds > best.durationSeconds ? a : best), null);

  // Wall-clock time not accounted for by stage execution: queueing, transitions and
  // approval waits. Useful because it is usually invisible and often significant.
  const wall = data.pipeline?.durationSeconds;
  const overhead = typeof wall === 'number' && totalStageSeconds ? Math.max(0, wall - totalStageSeconds) : null;

  return {
    stageCount: stages.length,
    completedStages: stages.filter(s => s.status === 'SUCCEEDED').length,
    failedStages: stages.filter(s => s.status === 'FAILED').length,
    pendingStages: stages.filter(s => s.status === 'PENDING' || s.status === 'WAITING').length,
    runningStage: stages.find(s => s.status === 'IN_PROGRESS') || null,
    failedStage: stages.find(s => s.status === 'FAILED') || null,
    totalStageSeconds: totalStageSeconds || null,
    overheadSeconds: overhead,
    overheadPct: overhead !== null && wall ? (overhead / wall) * 100 : null,
    slowestStage: slowest,
    actionCount: allActions.length,
    succeededActions: allActions.filter(a => a.status === 'SUCCEEDED').length,
    slowestAction,
    progressPct: stages.length
      ? (stages.filter(s => TERMINAL.has(s.status)).length / stages.length) * 100
      : null
  };
}

/** Each stage's share of total stage time, plus current vs historical average. */
export function stageBreakdown(data) {
  const averages = data.kpis?.stageAverages || {};
  const stages = data.stages || [];
  const total = stages.reduce((a, s) => a + (typeof s.durationSeconds === 'number' ? s.durationSeconds : 0), 0);
  return stages.map((s, i) => {
    const avg = averages[s.name] || {};
    const cur = typeof s.durationSeconds === 'number' ? s.durationSeconds : null;
    const delta = cur !== null && typeof avg.averageSeconds === 'number' ? cur - avg.averageSeconds : null;
    return {
      order: i + 1,
      name: s.name,
      status: s.status,
      summary: s.summary,
      externalUrl: s.externalUrl,
      actions: s.actions || [],
      durationSeconds: cur,
      sharePct: cur !== null && total ? (cur / total) * 100 : null,
      averageSeconds: avg.averageSeconds ?? null,
      medianSeconds: avg.medianSeconds ?? null,
      fastestSeconds: avg.fastestSeconds ?? null,
      slowestSeconds: avg.slowestSeconds ?? null,
      samples: avg.samples ?? 0,
      deltaSeconds: delta,
      deltaPct: delta !== null && avg.averageSeconds ? (delta / avg.averageSeconds) * 100 : null
    };
  });
}

/* ------------------------------------------------------------------- quality */

export function qualityStats(data) {
  const sast = data.quality?.sast || {};
  const tests = data.quality?.tests || {};
  const gate = data.quality?.qualityGate || {};
  const unit = data.quality?.unitTests || {};
  // Load has its own card. Older publishers put a few load keys on the tests card
  // instead, so fall back to those so a new UI against an older gate still shows
  // something rather than an empty panel.
  const loadCard = data.quality?.load || {};
  const load = {
    status: loadCard.status ?? tests.loadTestStatus ?? null,
    profile: loadCard.profile ?? tests.loadTestProfile ?? null,
    requestedProfile: loadCard.requestedProfile ?? null,
    scenarioKey: loadCard.scenarioKey ?? null,
    virtualUsers: loadCard.virtualUsers ?? null,
    durationSeconds: loadCard.durationSeconds ?? null,
    p95Ms: loadCard.p95Ms ?? tests.loadP95Ms ?? null,
    avgMs: loadCard.avgMs ?? null,
    errorRatePct: loadCard.errorRatePct ?? tests.loadErrorRatePct ?? null,
    throughputRps: loadCard.throughputRps ?? null,
    totalRequests: loadCard.totalRequests ?? null,
    failedRequests: loadCard.failedRequests ?? null,
    p95ThresholdMs: loadCard.p95ThresholdMs ?? null,
    errorRateThresholdPct: loadCard.errorRateThresholdPct ?? null,
    timestamp: loadCard.timestamp ?? null,
    breaches: loadCard.breaches ? String(loadCard.breaches).split('; ').filter(Boolean) : []
  };
  // Headroom against the threshold is the number worth showing: it says how much
  // capacity is left, not just that the run passed.
  load.p95HeadroomPct =
    load.p95Ms !== null && load.p95ThresholdMs
      ? ((load.p95ThresholdMs - load.p95Ms) / load.p95ThresholdMs) * 100
      : null;
  load.errorHeadroomPct =
    load.errorRatePct !== null && load.errorRateThresholdPct
      ? ((load.errorRateThresholdPct - load.errorRatePct) / load.errorRateThresholdPct) * 100
      : null;
  load.p95UsedPct =
    load.p95Ms !== null && load.p95ThresholdMs ? (load.p95Ms / load.p95ThresholdMs) * 100 : null;
  load.errorUsedPct =
    load.errorRatePct !== null && load.errorRateThresholdPct
      ? (load.errorRatePct / load.errorRateThresholdPct) * 100
      : null;
  load.present = load.status !== null && load.status !== undefined && load.status !== 'WAITING';

  const sev = n => (typeof sast[n] === 'number' ? sast[n] : null);
  const critical = sev('critical');
  const high = sev('high');
  const medium = sev('medium');
  const low = sev('low');
  const hasSeverities = [critical, high, medium, low].some(v => v !== null);
  const findings = hasSeverities ? (critical || 0) + (high || 0) + (medium || 0) + (low || 0) : null;
  // Conventional 10/5/2/1 weighting. Gives a single comparable number where four
  // separate counts are hard to read at a glance.
  const riskScore = hasSeverities
    ? (critical || 0) * 10 + (high || 0) * 5 + (medium || 0) * 2 + (low || 0)
    : null;

  const passed = Number(tests.passed) || 0;
  const failed = Number(tests.failed) || 0;
  const skipped = Number(tests.skipped) || 0;
  const total = Number(tests.total) || passed + failed + skipped;
  const executed = passed + failed;

  return {
    sast: {
      ...sast,
      critical, high, medium, low,
      findings,
      riskScore,
      blocking: (critical || 0) + (high || 0),
      hasSeverities
    },
    tests: {
      ...tests,
      passed, failed, skipped, total, executed,
      passRatePct: total ? (passed / total) * 100 : null,
      passRateOfExecutedPct: executed ? (passed / executed) * 100 : null,
      failRatePct: total ? (failed / total) * 100 : null,
      coveragePct: total ? (executed / total) * 100 : null
    },
    load,
    unit: {
      ...unit,
      total: Number(unit.total) || 0,
      passed: Number(unit.passed) || 0,
      failed: Number(unit.failed) || 0,
      skipped: Number(unit.skipped) || 0,
      passRatePct: Number(unit.total) ? (Number(unit.passed) / Number(unit.total)) * 100 : null,
      durationSeconds: unit.durationMs !== undefined && unit.durationMs !== null
        ? Number(unit.durationMs) / 1000 : null,
      present: unit.status !== undefined && unit.status !== null && unit.status !== 'WAITING'
    },
    gate: {
      ...gate,
      blockingChecks: gate.blockingChecks ?? null,
      reasons: gate.reason ? String(gate.reason).split('; ').filter(Boolean) : []
    }
  };
}

/* ---------------------------------------------------------------- governance */

export function governanceStats(data) {
  const items = data.integrations || [];
  const bySystem = {};
  for (const item of items) {
    const key = item.integration || 'Unknown';
    const b = (bySystem[key] = bySystem[key] || { name: key, total: 0, succeeded: 0, failed: 0, last: null, records: new Set() });
    b.total += 1;
    if (item.status === 'SUCCEEDED') b.succeeded += 1;
    if (item.status === 'FAILED') b.failed += 1;
    if (item.externalId) b.records.add(item.externalId);
    if (!b.last || String(item.timestamp || '') > String(b.last)) b.last = item.timestamp;
  }

  // Time from a stage reaching a terminal state to the outbound record being updated.
  // Approximate: both timestamps come from different producers, so treat as indicative.
  const stageEnd = {};
  for (const s of data.stages || []) {
    const last = (s.actions || []).map(a => epoch(a.lastUpdateTime)).filter(Boolean);
    if (last.length) stageEnd[s.name] = Math.max(...last);
  }
  const latencies = [];
  for (const item of items) {
    const end = stageEnd[item.stage];
    const at = epoch(item.timestamp);
    if (end && at && at >= end) latencies.push(at - end);
  }

  const succeeded = items.filter(i => i.status === 'SUCCEEDED').length;
  const failed = items.filter(i => i.status === 'FAILED').length;

  return {
    total: items.length,
    succeeded,
    failed,
    successRatePct: items.length ? (succeeded / items.length) * 100 : null,
    systems: Object.values(bySystem)
      .map(b => ({ ...b, recordCount: b.records.size, records: [...b.records] }))
      .sort((a, b) => b.total - a.total),
    systemCount: Object.keys(bySystem).length,
    uniqueRecords: new Set(items.map(i => i.externalId).filter(Boolean)).size,
    avgLatencySeconds: latencies.length ? Math.round(latencies.reduce((a, b) => a + b, 0) / latencies.length) : null,
    fastestLatencySeconds: latencies.length ? Math.round(Math.min(...latencies)) : null,
    slowestLatencySeconds: latencies.length ? Math.round(Math.max(...latencies)) : null,
    latencySamples: latencies.length
  };
}

/* ------------------------------------------------------------------ ai assist */

export function aiStats(data) {
  const b = data.bedrock || {};
  const failedStage = (data.stages || []).find(s => s.status === 'FAILED');
  // Time from the failing stage finishing to the analysis being published.
  let responseSeconds = null;
  if (failedStage && b.timestamp) {
    const ends = (failedStage.actions || []).map(a => epoch(a.lastUpdateTime)).filter(Boolean);
    const at = epoch(b.timestamp);
    if (ends.length && at) responseSeconds = Math.max(0, Math.round(at - Math.max(...ends)));
  }
  return {
    ...b,
    recommendedActions: b.recommendedActions || [],
    actionCount: (b.recommendedActions || []).length,
    responseSeconds,
    triggered: b.status === 'AWAITING_ANALYSIS' || b.status === 'SUCCEEDED',
    summaryWords: b.summary ? String(b.summary).trim().split(/\s+/).length : 0
  };
}

/* --------------------------------------------------------------------- trends */

export function trendStats(data) {
  const k = data.kpis || {};
  const history = data.history || [];
  const completed = history.filter(h => TERMINAL.has(h.status));
  const durations = completed.map(h => h.durationSeconds).filter(v => typeof v === 'number');

  // Spread matters more than the average for a delivery pitch: a tight band is the
  // claim, not just a low mean.
  const avg = k.averageDurationSeconds ?? null;
  const spread =
    durations.length > 1 && avg
      ? Math.round(Math.sqrt(durations.reduce((a, d) => a + (d - avg) ** 2, 0) / durations.length))
      : null;

  const stageAverages = Object.entries(k.stageAverages || {}).map(([name, v]) => ({ name, ...v }));
  const slowestStageAvg = stageAverages.reduce((best, s) => (!best || s.averageSeconds > best.averageSeconds ? s : best), null);

  return {
    ...k,
    history: completed,
    durationSpreadSeconds: spread,
    consistencyPct: avg && spread !== null ? Math.max(0, (1 - spread / avg) * 100) : null,
    stageAverages: stageAverages.sort((a, b) => b.averageSeconds - a.averageSeconds),
    slowestStageAvg,
    sparkline: [...completed].reverse().map(h => ({
      executionId: h.executionId,
      seconds: h.durationSeconds,
      status: h.status
    }))
  };
}

/* ---------------------------------------------------------------- telemetry */

export function telemetryStats(data, nowMs) {
  const t = data.telemetry || {};
  const age = v => {
    const e = epoch(v);
    return e ? Math.max(0, Math.round(nowMs / 1000 - e)) : null;
  };
  return {
    ...t,
    snapshotAgeSeconds: age(data.generatedAt),
    lastEventAgeSeconds: age(t.lastEventAt),
    heartbeatAgeSeconds: age(t.heartbeat),
    // The reconciliation rule runs every minute, so anything past ~150s means events
    // and the heartbeat have both stopped arriving.
    stale: (() => {
      const a = age(data.generatedAt);
      return a !== null && a > 150;
    })()
  };
}

/** Badge counts and alert markers for the side navigation. */
export function navSignals(data) {
  const q = data.quality || {};
  const failedStage = (data.stages || []).some(s => s.status === 'FAILED');
  return {
    pipelineAlert: failedStage,
    qualityAlert: q.qualityGate?.decision === 'FAIL' || q.sast?.status === 'FAILED' || q.tests?.status === 'FAILED',
    governanceCount: (data.integrations || []).length,
    governanceAlert: (data.integrations || []).some(i => i.status === 'FAILED'),
    aiActive: data.bedrock?.status === 'AWAITING_ANALYSIS' || data.bedrock?.status === 'SUCCEEDED',
    aiPending: data.bedrock?.status === 'AWAITING_ANALYSIS'
  };
}
