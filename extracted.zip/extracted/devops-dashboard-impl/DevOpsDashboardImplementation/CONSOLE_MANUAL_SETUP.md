# Console-Only Manual Setup (No CloudFormation)

This procedure builds exactly the same architecture as the two CloudFormation templates, created by
hand in the AWS Management Console. Use it when stack creation is restricted in the account, when you
need to attach the dashboard to resources you do not own, or when a reviewer wants to see each
resource created and explained individually.

`IMPLEMENTATION_GUIDE.md` remains the reference for how the dashboard *works*, how to instrument
sidecars, the demo runbook, and troubleshooting. This file replaces only sections 5 and 7 of that
guide (the two stack deployments).

**Read this before starting.** Without a stack there is no automatic rollback and no dependency
ordering. The order of steps below matters, particularly steps A6 → A7 (the CloudFront/S3 policy
handshake) and C1 → C3 (the role must exist before the function). Work through them in sequence.

---

## 0. Worksheet

Fill this in before you begin. Every placeholder below appears verbatim in the JSON you will paste.

| Placeholder | Where it comes from | Your value |
|---|---|---|
| `ACCOUNT_ID` | Console top-right account menu | |
| `PIPELINE_REGION` | Region containing your existing CodePipeline, e.g. `us-east-2` | |
| `PIPELINE_NAME` | Exact CodePipeline name | |
| `PRESENTER_CIDR` | Open `https://checkip.amazonaws.com` **from the presenting laptop on the presenting network**, then append `/32` | |
| `DASHBOARD_BUCKET` | You choose in A1. Must be globally unique | |
| `DISTRIBUTION_ID` | Output of A6, looks like `E1A2B3C4D5E6F7` | |
| `DISTRIBUTION_DOMAIN` | Output of A6, looks like `d111abcdef8.cloudfront.net` | |

Naming used throughout (change if your account has a convention, but stay consistent):

| Resource | Name |
|---|---|
| S3 bucket | `DASHBOARD_BUCKET` |
| WAF IP set | `DevOpsSalesDashboard-ApprovedIPv4` |
| WAF Web ACL | `DevOpsSalesDashboard-WebACL` |
| Response headers policy | `DevOpsSalesDashboard-SecurityHeaders` |
| Origin access control | `DevOpsSalesDashboard-OAC` |
| IAM policy | `DevOpsSalesDashboard-TelemetryPolicy` |
| IAM role | `DevOpsSalesDashboard-TelemetryRole` |
| Lambda function | `DevOpsSalesDashboardTelemetry` |
| EventBridge rules | `DevOpsSalesDashboard-PipelineEvents`, `-CustomEvents`, `-Heartbeat` |

Do not use the public IP of AWS CloudShell for `PRESENTER_CIDR`. That is not the address your browser
presents to CloudFront.

---

# Part A — Edge resources in us-east-1

Everything in Part A is created in **US East (N. Virginia) `us-east-1`**. CloudFront itself is global,
but CloudFront-scoped AWS WAF resources are managed through `us-east-1`, so keeping the whole edge
side there avoids confusion.

## A1. Create the private S3 bucket

1. Set the console Region selector to **US East (N. Virginia) us-east-1**.
2. Open **S3** > **Buckets** > **Create bucket**.
3. **Bucket type**: General purpose.
4. **Bucket name**: your `DASHBOARD_BUCKET`.
5. **Object Ownership**: **ACLs disabled (recommended)**. This is the `BucketOwnerEnforced` setting.
6. **Block Public Access settings for this bucket**: leave **Block all public access** checked. All
   four sub-settings must stay on. The dashboard is never served from S3 directly.
7. **Bucket Versioning**: **Enable**.
8. **Default encryption**: **Server-side encryption with Amazon S3 managed keys (SSE-S3)**. Leave
   **Bucket Key** enabled.
9. Add any tags your account requires. The templates set `Project`, `Purpose`, `Environment`, and
   `ManagedBy`; with no stack, `ManagedBy` is more honestly `Manual`.
10. Choose **Create bucket**.

Do **not** enable Static website hosting at any point. The origin must be the REST endpoint so that
Origin Access Control works.

## A2. Add the lifecycle rules

The telemetry Lambda rewrites `data/dashboard.json` on every event and on every reconciliation pass.
With versioning enabled and no lifecycle rule, old versions accumulate indefinitely and nothing ever
cleans them up, because the bucket outlives any teardown you do later.

1. Open the bucket > **Management** > **Lifecycle rules** > **Create lifecycle rule**.
2. **Lifecycle rule name**: `ExpireNoncurrentDashboardVersions`.
3. **Choose a rule scope**: **Apply to all objects in the bucket**, then check the acknowledgement.
4. Under **Lifecycle rule actions**, check **Permanently delete noncurrent versions of objects**.
5. **Days after objects become noncurrent**: `7`.
6. Leave **Number of newer versions to retain** empty.
7. Choose **Create rule**.
8. Choose **Create lifecycle rule** again.
9. **Lifecycle rule name**: `AbortIncompleteMultipartUploads`.
10. Scope: **Apply to all objects in the bucket**, acknowledge.
11. Check **Delete expired object delete markers or incomplete multipart uploads**, then check
    **Delete incomplete multipart uploads** and set **7** days.
12. Choose **Create rule**.

## A3. Create the WAF IP set

1. Open **WAF & Shield** > **IP sets**.
2. In the **Region** dropdown on that page, choose **Global (CloudFront)**. This is the equivalent of
   the templates' `Scope: CLOUDFRONT`. If you create the IP set in a regional scope by mistake it
   will not be selectable by a CloudFront Web ACL.
3. Choose **Create IP set**.
4. **IP set name**: `DevOpsSalesDashboard-ApprovedIPv4`.
5. **Description**: `Approved public IPv4 ranges for the DevOps dashboard`.
6. **Region**: Global (CloudFront).
7. **IP version**: **IPv4**.
8. **IP addresses**: your `PRESENTER_CIDR`, one CIDR per line. Add an approved corporate egress range
   only if your network and security teams confirm it.
9. Choose **Create IP set**.

Never add `0.0.0.0/0` here. That converts a network-restricted dashboard into a public one.

## A4. Create the Web ACL with a default action of Block

1. Still in **WAF & Shield**, open **Web ACLs**, Region **Global (CloudFront)**.
2. Choose **Create web ACL**.
3. **Resource type**: **Amazon CloudFront distributions**. The Region field locks to Global.
4. **Name**: `DevOpsSalesDashboard-WebACL`.
5. **CloudWatch metric name**: accept the generated value.
6. **Associated AWS resources**: leave empty. The distribution does not exist yet; you attach it in A9.
7. Choose **Next**.
8. On **Add rules and rule groups**, choose **Add rules** > **Add my own rules and rule groups**.
9. **Rule type**: **IP set**.
10. **Name**: `AllowApprovedViewerIPv4`.
11. **IP set**: `DevOpsSalesDashboard-ApprovedIPv4`.
12. **IP address to use as the originating address**: **Source IP address**.
13. **Action**: **Allow**.
14. Choose **Add rule**.
15. **Default web ACL action for requests that don't match any rules**: **Block**.

    This is the single most important setting in Part A. If it is left on Allow, the IP set becomes
    decorative and the dashboard is reachable from anywhere.

16. Choose **Next** through **Set rule priority** (there is only one rule, priority 0).
17. On **Configure metrics**, leave CloudWatch metrics and **Sampled requests** enabled.
18. Choose **Next**, review, then **Create web ACL**.

## A5. Create the response headers policy

1. Open **CloudFront** > **Policies** > **Response headers** tab.
2. Choose **Create response headers policy**.
3. **Name**: `DevOpsSalesDashboard-SecurityHeaders`.
4. **Description**: `Security headers for the static DevOps dashboard`.
5. Under **Security headers**, enable each of the following and check **Override origin** for all six:

   | Header | Value |
   |---|---|
   | Strict-Transport-Security | Max-age `31536000`, **do not** check includeSubdomains, **do not** check preload |
   | X-Content-Type-Options | Enable (emits `nosniff`) |
   | X-Frame-Options | `DENY` |
   | Referrer-Policy | `no-referrer` |
   | Content-Security-Policy | the single line in step 6 |
   | X-XSS-Protection | Enable, and check **Mode block** (emits `1; mode=block`) |

6. Paste this as the Content-Security-Policy value, on one line:

   ```text
   default-src 'self'; connect-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; font-src 'self' data:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'none'
   ```

   `style-src 'unsafe-inline'` is required because Cloudscape injects inline styles. `font-src data:`
   is required because Cloudscape's global stylesheet embeds its Open Sans fonts as base64 data URIs.
   Removing either will break the UI. `frame-ancestors 'none'` plus `X-Frame-Options: DENY` means the
   dashboard cannot be embedded in an iframe, including inside a slide deck or a portal page — if you
   need that later, this is the pair to revisit.

7. Under **Custom headers**, choose **Add header**:
   - **Header**: `Cache-Control`
   - **Value**: `no-cache`
   - **Override origin**: leave **unchecked**.

   Unchecked matters. The telemetry Lambda writes `Cache-Control: no-store, max-age=0` on the JSON
   snapshot, and this custom header must not override it.

8. Choose **Create**.

## A6. Create the OAC and the distribution

1. Open **CloudFront** > **Distributions** > **Create distribution**.
2. **Origin domain**: start typing your bucket name and select it from the **S3 buckets** group in the
   dropdown. If the console offers a website-endpoint variant, do not pick it.
3. **Origin path**: leave empty.
4. **Origin access**: choose **Origin access control settings (recommended)**.
5. Choose **Create new OAC**:
   - **Name**: `DevOpsSalesDashboard-OAC`
   - **Description**: `DevOpsSalesDashboard private S3 origin access`
   - **Origin type**: **S3**
   - **Signing behavior**: **Sign requests (recommended)**
   - Choose **Create**
6. CloudFront now shows a yellow banner saying the S3 bucket policy must be updated. Leave it for now;
   A7 handles it.
7. **Enable Origin Shield**: No.
8. Under **Default cache behavior**:
   - **Compress objects automatically**: **Yes**
   - **Viewer protocol policy**: **Redirect HTTP to HTTPS**
   - **Allowed HTTP methods**: **GET, HEAD**
   - **Restrict viewer access**: **No** (access control is the WAF IP allowlist, not signed URLs)
   - **Cache policy**: **CachingOptimized**
   - **Origin request policy**: none
   - **Response headers policy**: `DevOpsSalesDashboard-SecurityHeaders`
9. Under **Web Application Firewall (WAF)**, choose **Do not enable security protections**. That
   option would create a *new* managed Web ACL. You attach the one you already built in A9.
10. Under **Settings**:
    - **Price class**: **Use North America and Europe** (equivalent to `PriceClass_100`)
    - **Alternate domain name (CNAME)**: leave empty
    - **Custom SSL certificate**: leave empty, so the default `*.cloudfront.net` certificate is used
    - **Supported HTTP versions**: check **HTTP/2** and **HTTP/3**
    - **Default root object**: `index.html`
    - **IPv6**: **uncheck / Off**

      Turning IPv6 off is deliberate. If it stays on, a presenter whose network prefers IPv6 will
      arrive over an address your IPv4-only IP set cannot match, and WAF will block them. This is the
      most common cause of "it worked yesterday" failures with this pattern.
11. Add tags if required, then choose **Create distribution**.
12. Wait for **Last modified** to stop showing **Deploying** (typically a few minutes).
13. Record the **Distribution domain name** as `DISTRIBUTION_DOMAIN` and the **ARN**/ID as
    `DISTRIBUTION_ID`.

## A7. Apply the bucket policy

1. On the distribution page, the banner offers **Copy policy**. Choose it. Alternatively go to
   **Origins** > select the origin > **Edit** > **Copy policy**.
2. Open **S3** > your bucket > **Permissions** > **Bucket policy** > **Edit**.
3. Paste the policy below rather than the copied one. It is the copied CloudFront statement plus the
   TLS-only deny that CloudFront does not add for you. Substitute `DASHBOARD_BUCKET`, `ACCOUNT_ID`,
   and `DISTRIBUTION_ID`.

   ```json
   {
     "Version": "2012-10-17",
     "Statement": [
       {
         "Sid": "AllowCloudFrontReadOnly",
         "Effect": "Allow",
         "Principal": { "Service": "cloudfront.amazonaws.com" },
         "Action": "s3:GetObject",
         "Resource": "arn:aws:s3:::DASHBOARD_BUCKET/*",
         "Condition": {
           "StringEquals": {
             "AWS:SourceArn": "arn:aws:cloudfront::ACCOUNT_ID:distribution/DISTRIBUTION_ID"
           }
         }
       },
       {
         "Sid": "DenyInsecureTransport",
         "Effect": "Deny",
         "Principal": "*",
         "Action": "s3:*",
         "Resource": [
           "arn:aws:s3:::DASHBOARD_BUCKET",
           "arn:aws:s3:::DASHBOARD_BUCKET/*"
         ],
         "Condition": { "Bool": { "aws:SecureTransport": "false" } }
       }
     ]
   }
   ```

4. Choose **Save changes**.

Note that the CloudFront principal is granted `s3:GetObject` only. The telemetry Lambda's write access
comes from its own IAM role in Part C, not from this policy.

## A8. Add the `data/*` cache behavior

Without this, the JSON snapshot is served under the default `CachingOptimized` policy and the
dashboard can sit on a cached snapshot for up to a day.

1. Open the distribution > **Behaviors** > **Create behavior**.
2. **Path pattern**: `data/*`

   No leading slash is needed; CloudFront treats `data/*` and `/data/*` identically, and both match a
   request for `/data/dashboard.json`.
3. **Origin and origin groups**: the S3 origin you created.
4. **Compress objects automatically**: **Yes**
5. **Viewer protocol policy**: **Redirect HTTP to HTTPS**
6. **Allowed HTTP methods**: **GET, HEAD**
7. **Restrict viewer access**: **No**
8. **Cache policy**: **CachingDisabled**
9. **Origin request policy**: none
10. **Response headers policy**: `DevOpsSalesDashboard-SecurityHeaders`
11. Choose **Create behavior**.
12. Back on the **Behaviors** tab, confirm the ordering: `data/*` must have **Precedence 0** and
    `Default (*)` must be last. CloudFront evaluates top-down and uses the first match, so if
    `Default (*)` were first the new behavior would never apply.

## A9. Attach the Web ACL to the distribution

1. Open **WAF & Shield** > **Web ACLs** > Region **Global (CloudFront)**.
2. Open `DevOpsSalesDashboard-WebACL`.
3. Open the **Associated AWS resources** tab > **Add AWS resources**.
4. **Resource type**: **Amazon CloudFront distribution**.
5. Check your distribution and choose **Add**.
6. Wait for the distribution to finish deploying.

Verify from the CloudFront side too: distribution > **Security** (or the **General** tab's AWS WAF
field) should now name `DevOpsSalesDashboard-WebACL`.

At this point opening `https://DISTRIBUTION_DOMAIN` from your approved network should return an S3
`AccessDenied` or `NoSuchKey` style error, because no files have been uploaded. From a
non-approved network you should get a WAF `403 Forbidden` instead. Both are correct at this stage,
and the difference between them is a useful early confirmation that WAF is doing its job.

---

# Part B — Build and upload the UI

The build needs Node.js and npm. AWS CloudShell already has both plus an authenticated AWS CLI, which
makes it the least-friction option, and nothing about the build requires access to your VPC.

## B1. Build

1. Open **CloudShell** from the console toolbar.
2. **Actions** > **Upload file**, and upload `DevOpsDashboardImplementation.zip`.
3. Run:

   ```bash
   unzip -o DevOpsDashboardImplementation.zip
   cd DevOpsDashboardImplementation
   chmod +x scripts/*.sh
   ./scripts/build-dashboard.sh
   ```

   The `chmod` is not optional if the archive was ever repacked on Windows. PowerShell's
   `Compress-Archive` does not write Unix permission bits, so `unzip` extracts the scripts as mode
   `644` and `./scripts/build-dashboard.sh` fails with `permission denied`. Running `chmod +x` first
   works whether or not the bit survived. Alternatively invoke the interpreter directly and skip the
   question entirely: `bash scripts/build-dashboard.sh`.

   That runs `npm install` and `npm run build`, producing `dashboard/dist/`. Expect roughly a 1 MB CSS
   file and an 800 KB JS bundle; Cloudscape is a large design system and the Vite size warning is
   normal here.

Optional, before building: edit `dashboard/public/config.json` to set the client-facing `title`,
`subtitle`, and `environment`. That file is delivered to the viewer's browser, so it must not contain
account numbers, internal hostnames, credentials, or prompts.

## B2. Upload

`dashboard/dist/` is generated output and is not shipped in the archive, so the build in B1 must run
first. The wrapper below does both in the right order:

```bash
bash scripts/deploy-dashboard.sh DASHBOARD_BUCKET DISTRIBUTION_ID
```

To run the steps separately:

```bash
bash scripts/build-dashboard.sh
bash scripts/upload-dashboard.sh DASHBOARD_BUCKET DISTRIBUTION_ID
```

Running the upload before a build exits with `Dashboard dist/ not found` and prints the commands to
run. That is the guard working, not a missing file in the package.

If you prefer to run the commands yourself, this is what the script does:

```bash
aws s3 sync dashboard/dist/ s3://DASHBOARD_BUCKET/ --delete --exclude 'data/*'

aws s3 cp dashboard/dist/index.html s3://DASHBOARD_BUCKET/index.html \
  --content-type 'text/html' --cache-control 'no-cache, max-age=0'

aws s3 cp dashboard/dist/config.json s3://DASHBOARD_BUCKET/config.json \
  --content-type 'application/json' --cache-control 'no-cache, max-age=0'

aws cloudfront create-invalidation --distribution-id DISTRIBUTION_ID --paths '/*'
```

The `--exclude 'data/*'` on a `--delete` sync is not optional. Without it, every UI redeploy wipes the
live telemetry snapshot that Part C generates.

## B3. First browser test

1. From an IP inside the WAF IP set, open `https://DISTRIBUTION_DOMAIN`.
2. The dashboard shell should render.
3. It will show a warning banner that live telemetry is unavailable, because `data/dashboard.json` does
   not exist yet. That is expected until C8.

## B4. Which branding changes need a rebuild

Not all UI changes require the build step. Three files pass through Vite untouched from
`dashboard/public/` to the distribution root, so they can be replaced directly in S3.

| What you are changing | File | Rebuild? |
|---|---|---|
| Brand logo | `brand-logo.svg` | No |
| Tab icon | `favicon.svg` | No |
| Title, subtitle, environment, eyebrow, logo path | `config.json` | No |
| Palette / design tokens | `src/styles.css` | Yes, bundled into a hashed asset |
| Layout or component changes | `src/App.jsx` | Yes |
| Fallback tab title, meta tags | `index.html` | Yes |

The no-rebuild path matters most for the logo. The mark shipped in this package is a placeholder, and
replacing it with your approved asset is a file upload plus an invalidation, nothing more.

## B5. No-rebuild deployment through the S3 console

The S3 console has no text editor, so "editing" `config.json` means uploading a replacement object.

1. Prepare the file locally: the new `brand-logo.svg`, or an edited copy of `config.json`.
2. Open **S3** > your dashboard bucket. The file goes at the **bucket root**, not inside a folder.
3. Choose **Upload** > **Add files**, and select it. The object key must exactly match the existing
   one, for example `brand-logo.svg`, so it overwrites rather than creating a new object.
4. Expand **Properties**. Confirm **Content-Type** was inferred correctly from the extension:
   `image/svg+xml` for the SVGs, `application/json` for `config.json`. Override it under
   **Metadata** > **System defined** if it is wrong.
5. For `config.json`, add **Metadata** > **System defined** > `Cache-Control` = `no-cache, max-age=0`.
6. Choose **Upload**.
7. Open **CloudFront** > your distribution > **Invalidations** > **Create invalidation**.
8. Enter the specific paths rather than `/*`:

   ```text
   /brand-logo.svg
   /config.json
   ```

9. Choose **Create invalidation** and wait for it to complete, usually under a minute.
10. Hard-refresh the dashboard from an allowlisted IP.

Metadata entered in the upload dialog applies to every file in that upload, so upload files needing
different `Cache-Control` values separately.

## B6. Full rebuild without any CLI

Use this when CloudShell is unavailable. The build still needs Node.js somewhere, but every AWS
interaction is console-only.

1. On a workstation with Node.js 18 or later:

   ```bash
   cd dashboard
   npm install
   npm run build
   ```

   `dashboard/dist/` will contain `index.html`, `config.json`, `brand-logo.svg`, `favicon.svg`, and
   `assets/` holding one hashed `.css` and one hashed `.js`. The hashes change on every build.
2. Open **S3** > your dashboard bucket.
3. **Upload the hashed assets first**, so `index.html` is never live while pointing at files that do
   not exist yet. Choose **Upload** > **Add folder** and select `dist/assets`. Optionally set
   **Metadata** > **System defined** > `Cache-Control` = `public, max-age=31536000, immutable`; the
   filenames are content-hashed so they are safe to cache permanently. Choose **Upload**.
4. Then choose **Upload** > **Add files** and select `dist/index.html` plus `dist/config.json`. Add
   **Metadata** > **System defined** > `Cache-Control` = `no-cache, max-age=0`. Choose **Upload**.
5. If the brand assets changed, upload `dist/brand-logo.svg` and `dist/favicon.svg` as a third batch.
6. **CloudFront** > distribution > **Invalidations** > **Create invalidation** > path `/*` >
   **Create invalidation**.
7. Hard-refresh from an allowlisted IP.

Two differences from `upload-dashboard.sh` worth knowing:

- The console never deletes. Uploading does not remove the previous build's hashed assets, so
  `assets/` accumulates orphaned `index-*.css` and `index-*.js` files. They are unreferenced and
  harmless, but you can delete them once the new build is confirmed working.
- Because nothing is deleted, this path cannot accidentally wipe `data/dashboard.json`. It is the
  safer of the two options in that respect.

## B7. Rolling back a UI deployment

Bucket versioning is enabled, so the previous UI is recoverable.

1. **S3** > bucket > toggle **Show versions** on.
2. Locate the object, for example `index.html`, and find the version from before the deployment.
3. Select that version and choose **Download**.
4. Re-upload it as a new current version using the steps in B5 or B6.
5. Invalidate `/*`.

Prefer download-and-re-upload over deleting the newer version. Deleting a specific version ID is
permanent.

The `ExpireNoncurrentDashboardVersions` lifecycle rule from A2 removes noncurrent versions after the
number of days set in `NoncurrentVersionRetentionDays`, 7 by default. That is your rollback window.
Raise it if you need longer.

---

# Part C — Telemetry in the pipeline Region

Switch the console Region selector to `PIPELINE_REGION`. Everything in Part C lives beside the
pipeline so that the CodePipeline EventBridge rule and the Lambda are local to it and you do not need
a cross-Region event bus route. The Lambda writes across to the `us-east-1` bucket; that is a
deliberate, and very small, cross-Region write.

## C1. Create the IAM policy

1. Open **IAM** > **Policies** > **Create policy**.
2. Switch to the **JSON** tab and paste the following, substituting `PIPELINE_REGION`, `ACCOUNT_ID`,
   `PIPELINE_NAME`, and `DASHBOARD_BUCKET`.

   ```json
   {
     "Version": "2012-10-17",
     "Statement": [
       {
         "Sid": "ReadObservedPipeline",
         "Effect": "Allow",
         "Action": [
           "codepipeline:GetPipeline",
           "codepipeline:GetPipelineExecution",
           "codepipeline:GetPipelineState",
           "codepipeline:ListActionExecutions",
           "codepipeline:ListPipelineExecutions"
         ],
         "Resource": "arn:aws:codepipeline:PIPELINE_REGION:ACCOUNT_ID:PIPELINE_NAME"
       },
       {
         "Sid": "ReadWriteDashboardData",
         "Effect": "Allow",
         "Action": [
           "s3:GetObject",
           "s3:PutObject"
         ],
         "Resource": "arn:aws:s3:::DASHBOARD_BUCKET/data/*"
       },
       {
         "Sid": "LambdaLogs",
         "Effect": "Allow",
         "Action": [
           "logs:CreateLogGroup",
           "logs:CreateLogStream",
           "logs:PutLogEvents"
         ],
         "Resource": "arn:aws:logs:PIPELINE_REGION:ACCOUNT_ID:log-group:/aws/lambda/DevOpsSalesDashboardTelemetry:*"
       }
     ]
   }
   ```

   Two notes. The CodePipeline ARN has no resource-type prefix — it is
   `arn:aws:codepipeline:region:account:PipelineName`, not `.../pipeline/PipelineName`. And the S3
   grant is scoped to the `data/` prefix only, so this role cannot modify the UI files it serves
   alongside. `GetPipelineState` is included to match the CloudFormation template; the current handler
   does not call it, and you can drop it if your reviewers prefer a tighter grant.

3. Choose **Next**.
4. **Policy name**: `DevOpsSalesDashboard-TelemetryPolicy`.
5. Choose **Create policy**.

## C2. Create the execution role

1. Open **IAM** > **Roles** > **Create role**.
2. **Trusted entity type**: **AWS service**. **Use case**: **Lambda**. Choose **Next**.
3. Search for and check `DevOpsSalesDashboard-TelemetryPolicy`. Choose **Next**.
4. **Role name**: `DevOpsSalesDashboard-TelemetryRole`.
5. Choose **Create role**.

Do not also attach `AWSLambdaBasicExecutionRole`. Its logs grant is broader than the scoped one you
just wrote, and attaching both silently widens the permission.

## C3. Create the Lambda function

1. Open **Lambda** > **Functions** > **Create function**.
2. **Author from scratch**.
3. **Function name**: `DevOpsSalesDashboardTelemetry`.
4. **Runtime**: **Python 3.12**.
5. **Architecture**: leave the default.
6. Expand **Change default execution role** > **Use an existing role** >
   `DevOpsSalesDashboard-TelemetryRole`.
7. Choose **Create function**.

The function needs no layers and no packaged dependencies. It imports only the standard library plus
`boto3`, which the managed Python runtime already provides.

## C4. Paste the handler code and fix the handler name

1. On the function page, open the **Code** tab.
2. In the editor, open `lambda_function.py` and delete its contents.
3. Paste the entire contents of `telemetry/handler.py` from this package.
4. Choose **Deploy**.
5. Scroll to **Runtime settings** and choose **Edit**.
6. Change **Handler** from `lambda_function.lambda_handler` to:

   ```text
   lambda_function.handler
   ```

7. Choose **Save**.

Step 6 is the step people miss. The module's entry point is `handler`, not `lambda_handler`. If you
skip it, every invocation fails with `Unable to import module 'lambda_function'` or a missing-handler
error. The CloudFormation template avoids this by naming the file `index.py` and setting
`index.handler`; if you would rather match that exactly, upload a zip containing `handler.py` renamed
to `index.py` and set the handler to `index.handler`.

## C5. General configuration and concurrency

1. **Configuration** > **General configuration** > **Edit**:
   - **Memory**: `256` MB
   - **Timeout**: `0` min `30` sec
   - Choose **Save**.
2. **Configuration** > **Concurrency and recursion detection** > **Concurrency** > **Edit**:
   - Select **Reserve concurrency** and set it to `1`.
   - Choose **Save**.

Reserved concurrency of 1 is a correctness requirement, not a cost control. The function does a
read-modify-write on a single S3 object; serialising invocations is what makes that safe without a
database. Throttled events are retried asynchronously by Lambda, and because every invocation
re-reads authoritative state from CodePipeline, out-of-order arrival is self-correcting.

Reserving concurrency draws from the account's pool and requires at least 10 unreserved executions to
remain. In a busy shared account the save can fail with a limit error; if it does, resolve the account
concurrency budget with the account owner rather than skipping this step.

## C6. Environment variables

**Configuration** > **Environment variables** > **Edit**, then add all eight:

| Key | Value |
|---|---|
| `PIPELINE_NAME` | your `PIPELINE_NAME` |
| `DASHBOARD_BUCKET` | your `DASHBOARD_BUCKET` |
| `DASHBOARD_BUCKET_REGION` | `us-east-1` |
| `DASHBOARD_EVENT_SOURCE` | `devops.pipeline.dashboard` |
| `HISTORY_LIMIT` | `12` |
| `TIMELINE_LIMIT` | `60` |
| `DATA_KEY` | `data/dashboard.json` |
| `WRITE_EXECUTION_SNAPSHOTS` | `DISABLED` |

Choose **Save**.

`PIPELINE_NAME` and `DASHBOARD_BUCKET` are read with `os.environ[...]` and have no defaults; if either
is missing or misspelled the function fails on cold start before doing anything. The other six have
in-code defaults matching the values above, but set them explicitly so the configuration is
self-documenting for the next person.

`WRITE_EXECUTION_SNAPSHOTS=DISABLED` keeps the function from writing a second, duplicate
`data/executions/<id>.json` object on every invocation. The UI never reads those files. Set it to
`ENABLED` only if you specifically want retained per-execution copies for post-demo review.

## C7. Create the three EventBridge rules

All three are on the **default** event bus in `PIPELINE_REGION`.

Each rule needs a `lambda:InvokeFunction` resource-based permission on the target function. In
practice the EventBridge console adds this for you when you save a rule with a Lambda target, but the
documentation does not guarantee it, and a missing permission produces a rule that fires and silently
fails with no error surfaced on the rule itself. So treat it as something to verify rather than assume.

After creating all three rules, open **Lambda** > your function > **Configuration** > **Permissions** >
**Resource-based policy statements**. You should see three statements with principal
`events.amazonaws.com`, one per rule ARN. If any is missing, add it from CloudShell:

```bash
aws lambda add-permission \
  --region PIPELINE_REGION \
  --function-name DevOpsSalesDashboardTelemetry \
  --statement-id AllowRULENAME \
  --action lambda:InvokeFunction \
  --principal events.amazonaws.com \
  --source-arn arn:aws:events:PIPELINE_REGION:ACCOUNT_ID:rule/RULE_NAME
```

Run it once per missing rule, using a distinct `--statement-id` each time.

### Rule 1 — CodePipeline state changes

1. Open **Amazon EventBridge** > **Rules**. Confirm **Event bus** is `default`.
2. Choose **Create rule**.
3. **Name**: `DevOpsSalesDashboard-PipelineEvents`.
4. **Description**: `Triggers a dashboard refresh for pipeline, stage, and action state changes`.
5. **Rule type**: **Rule with an event pattern**. Choose **Next**.
6. **Event source**: **AWS events or EventBridge partner events**.
7. Scroll to **Creation method** and choose **Custom pattern (JSON editor)**.
8. Paste, substituting `PIPELINE_NAME`:

   ```json
   {
     "source": ["aws.codepipeline"],
     "detail-type": [
       "CodePipeline Pipeline Execution State Change",
       "CodePipeline Stage Execution State Change",
       "CodePipeline Action Execution State Change"
     ],
     "detail": {
       "pipeline": ["PIPELINE_NAME"]
     }
   }
   ```

9. Choose **Next**.
10. **Target types**: **AWS service**. **Select a target**: **Lambda function**. **Function**:
    `DevOpsSalesDashboardTelemetry`.
11. Choose **Next**, add tags if required, **Next**, then **Create rule**.

The pipeline name in `detail.pipeline` must match exactly, including case. A typo here produces a rule
that never fires and no error anywhere.

### Rule 2 — Custom sidecar events

1. **Create rule**.
2. **Name**: `DevOpsSalesDashboard-CustomEvents`.
3. **Description**: `Receives ServiceNow, Jira, quality, and Bedrock dashboard signals from sidecars`.
4. **Rule type**: **Rule with an event pattern**. **Next**.
5. **Creation method**: **Custom pattern (JSON editor)**. Paste:

   ```json
   {
     "source": ["devops.pipeline.dashboard"],
     "detail": {
       "pipeline": ["PIPELINE_NAME"]
     }
   }
   ```

6. Target: the same Lambda function. Create the rule.

If you changed `DASHBOARD_EVENT_SOURCE` in C6, the `source` value here must match it exactly.

### Rule 3 — One-minute reconciliation heartbeat

1. **Create rule**.
2. **Name**: `DevOpsSalesDashboard-Heartbeat`.
3. **Description**: `One-minute reconciliation refresh in case a best-effort CodePipeline event is missed`.
4. **Rule type**: **Schedule**.
5. The console may offer to continue in **EventBridge Scheduler**. Choose the option to continue
   creating an **EventBridge rule** instead. A rule is what you want here because it can be enabled and
   disabled in place, which is the between-demos off switch described in F2. If your console only
   offers Scheduler, a 1-minute rate schedule targeting the same Lambda is functionally equivalent —
   you will disable the schedule rather than the rule.
6. **Schedule pattern**: a schedule that runs at a regular rate. **Rate expression**: `1` **Minutes**.
7. Target: the same Lambda function. Create the rule.

This rule is why the dashboard cannot get permanently stuck. CodePipeline's event delivery to
EventBridge is documented as best effort, so a dropped state-change event is possible; the heartbeat
re-reads the CodePipeline APIs every minute and corrects the display.

## C8. Seed the first snapshot

1. Open the function > **Test** tab.
2. **Create new event**, **Event name**: `SeedDashboard`.
3. **Event JSON**: `{}`
4. **Save**, then **Test**.
5. The response should look like:

   ```json
   {
     "ok": true,
     "bucket": "DASHBOARD_BUCKET",
     "key": "data/dashboard.json",
     "executionId": "...",
     "status": "SUCCEEDED"
   }
   ```

6. Switch the Region selector to `us-east-1`, open **S3** > your bucket, and confirm
   `data/dashboard.json` now exists.
7. Reload the dashboard in the browser. The warning banner should clear and the page should populate
   with your real pipeline structure, latest execution, stage status, revision metadata, and history.

An empty-string `executionId` or `"status": "WAITING"` means the function ran correctly but
`ListPipelineExecutions` returned nothing — the pipeline has never executed. Run it once.

## C9. Set log retention

The log group is created by the first invocation, so do this after C8.

1. Open **CloudWatch** > **Log groups** in `PIPELINE_REGION`.
2. Open `/aws/lambda/DevOpsSalesDashboardTelemetry`.
3. **Actions** > **Edit retention setting**.
4. Choose `30 days`, or whatever your account standard requires, and save.

Left at the default, these logs never expire. With the heartbeat running every minute that is a slow
but permanent accumulation in a shared account.

---

# Part D — Wire the existing sidecars

This part is unchanged from `IMPLEMENTATION_GUIDE.md` sections 9 through 16, which cover the code
changes in detail. The console work is only the IAM grant.

For each existing ServiceNow / Jira / SAST / test / quality-gate / Bedrock Lambda that will publish a
dashboard signal:

1. Open **IAM** > **Roles** and open the role that Lambda uses.
2. **Add permissions** > **Create inline policy**.
3. Switch to the **JSON** tab and paste, substituting `PIPELINE_REGION` and `ACCOUNT_ID`:

   ```json
   {
     "Version": "2012-10-17",
     "Statement": [
       {
         "Sid": "PublishDashboardSignals",
         "Effect": "Allow",
         "Action": "events:PutEvents",
         "Resource": "arn:aws:events:PIPELINE_REGION:ACCOUNT_ID:event-bus/default"
       }
     ]
   }
   ```

4. **Next**, name it `PublishDevOpsDashboardSignals`, and choose **Create policy**.
5. Copy `integration-snippets/dashboard_events.py` into that Lambda's package or shared layer.
6. Set these environment variables on that Lambda:

   ```text
   DASHBOARD_EVENT_SOURCE=devops.pipeline.dashboard
   DASHBOARD_EVENT_REGION=PIPELINE_REGION
   DASHBOARD_EVENT_BUS=default
   PIPELINE_NAME=PIPELINE_NAME
   ```

If a sidecar Lambda lives in a different Region, `DASHBOARD_EVENT_REGION` must still point at
`PIPELINE_REGION`, because that is where the rule listening for these events lives.

Then propagate the real execution ID into each sidecar, as covered in guide section 10. A sidecar that
sends the wrong ID will not corrupt the display — the event is correlated as historical and shown only
in the timeline — but its results will be missing from the current-run cards, which during a live demo
looks like the integration silently failed.

---

# Part E — Verification

## E1. Security

- [ ] Bucket **Block all public access**: all four settings on
- [ ] Bucket **Object Ownership**: ACLs disabled
- [ ] Bucket **Static website hosting**: disabled
- [ ] Bucket policy grants `s3:GetObject` to `cloudfront.amazonaws.com`, conditioned on your exact
      distribution ARN, and denies non-TLS access
- [ ] Both lifecycle rules present and Enabled
- [ ] Distribution origin uses **Origin access control**, not a legacy OAI, not a website endpoint
- [ ] Distribution **IPv6** is off
- [ ] Distribution allows **GET, HEAD** only
- [ ] `data/*` behavior exists, uses **CachingDisabled**, and has precedence above `Default (*)`
- [ ] Web ACL default action is **Block** and is associated with the distribution
- [ ] IP set contains only approved CIDRs
- [ ] Lambda role grants S3 write on `data/*` only
- [ ] No AWS credentials or secrets in any file under `dashboard/`

Then prove two negatives:

1. Open `https://DASHBOARD_BUCKET.s3.us-east-1.amazonaws.com/index.html` directly. It must fail.
   Success here means the bucket is public and you should stop and fix it before anything else.
2. From a network whose public IPv4 is not in the IP set (a phone hotspot works), open the
   distribution URL. WAF must return 403.

## E2. Function

- [ ] Manual `{}` test returns `ok: true` and creates `data/dashboard.json`
- [ ] Stage ribbon matches the current CodePipeline stage list and order
- [ ] Starting a pipeline run changes the active stage without a page reload
- [ ] Execution duration increases while running
- [ ] All five KPI cards render on one row at the presentation screen resolution
- [ ] Recent executions table populates
- [ ] Resource-based policy on the Lambda shows three `events.amazonaws.com` statements
- [ ] A sidecar event published with a deliberately wrong execution ID appears in the timeline but does
      not clear the current run's quality, integration, or Bedrock panels

## E3. If something is wrong

Guide section 25 has the full troubleshooting table. The failures specific to building this by hand:

| Symptom | Manual-setup cause |
|---|---|
| Every invocation errors on import or handler | C4 step 6 was skipped; handler is still `lambda_function.lambda_handler` |
| Rule shows invocations but Lambda shows none | Resource-based policy statement missing; add it with `aws lambda add-permission` as shown in C7 |
| Rule shows no invocations at all | `detail.pipeline` does not exactly match the pipeline name, or the rule is in the wrong Region |
| `AccessDenied` writing to S3 | Bucket name typo in the IAM policy, or the object key falls outside the `data/` prefix |
| Dashboard loads but JSON is stale | `data/*` behavior missing, or ordered below `Default (*)` |
| Blocked from an approved network | Distribution IPv6 still enabled, or your egress address changed |
| Cold start fails immediately | `PIPELINE_NAME` or `DASHBOARD_BUCKET` environment variable missing |

---

# Part F — Operating it

## F1. Changing the presenter IP

No resource needs recreating. **WAF & Shield** > **IP sets** (Global/CloudFront) >
`DevOpsSalesDashboard-ApprovedIPv4` > **Edit** > add the new CIDR, remove stale ones, **Save**. The
Web ACL rule references the set by ARN, so it picks up the change immediately.

Re-check the presenter address on the morning of the demo. Corporate NAT and VPN egress addresses
change more often than people expect, and this is the single most common day-of failure.

## F2. Pausing the heartbeat between demos

Left enabled, the heartbeat is roughly 43,000 Lambda invocations, 170,000 CodePipeline read API calls,
and 43,000 S3 writes per month whether or not anyone is presenting. The cost is negligible; the
CloudTrail and CloudWatch noise in a shared account is the real reason to turn it off.

**EventBridge** > **Rules** > `DevOpsSalesDashboard-Heartbeat` > **Disable**.

With it off, the dashboard still updates on every CodePipeline and sidecar event. What you lose is the
automatic correction when a best-effort event is never delivered. Re-enable it before any rehearsal or
live demo.

## F3. Updating the UI later

```bash
./scripts/build-dashboard.sh
./scripts/upload-dashboard.sh DASHBOARD_BUCKET DISTRIBUTION_ID
```

Neither touches `data/*`. Adding a pipeline stage needs no UI change, because the stage ribbon is
generated from the live pipeline definition.

---

# Part G — Teardown

Without a stack, deletion is manual and order-sensitive. Reverse of creation:

1. **EventBridge** > **Rules**: delete the three `DevOpsSalesDashboard-*` rules.
2. **Lambda**: delete `DevOpsSalesDashboardTelemetry`.
3. **CloudWatch** > **Log groups**: delete `/aws/lambda/DevOpsSalesDashboardTelemetry`.
4. **IAM**: delete role `DevOpsSalesDashboard-TelemetryRole`, then policy
   `DevOpsSalesDashboard-TelemetryPolicy` (the role must go first).
5. **WAF** > Web ACL > **Associated AWS resources**: remove the distribution. The Web ACL cannot be
   deleted while a distribution is attached.
6. **CloudFront**: **Disable** the distribution, wait for it to finish deploying, then **Delete**. A
   distribution cannot be deleted while enabled, and the disable can take several minutes.
7. **WAF**: delete the Web ACL, then the IP set.
8. **CloudFront** > **Policies** > **Response headers**: delete
   `DevOpsSalesDashboard-SecurityHeaders`. It cannot be deleted while any behavior references it, so
   this has to follow step 6.
9. **CloudFront** > **Origin access**: delete `DevOpsSalesDashboard-OAC`.
10. **S3**: empty the bucket including all noncurrent versions, then delete the bucket.
11. On each sidecar role, remove the `PublishDevOpsDashboardSignals` inline policy, and remove the
    `dashboard_events.py` calls and environment variables. The original external integrations do not
    need them.

---

# Appendix — CloudFormation parameter to console mapping

For reviewers comparing this procedure against the templates.

## Edge stack

| Template parameter or property | Console equivalent |
|---|---|
| `ProjectName` | Resource names you chose in section 0 |
| `AllowedIPv4Cidrs` | IP set addresses (A3) |
| `EnvironmentLabel` | Tag values (A1, A6) |
| `NoncurrentVersionRetentionDays` | Lifecycle rule days (A2) |
| `DeletionPolicy: Retain` on the bucket | No equivalent; the bucket only goes away when you delete it (G10) |
| `OwnershipControls: BucketOwnerEnforced` | ACLs disabled (A1) |
| `CachePolicyId: 658327ea-...` | Managed policy **CachingOptimized** (A6) |
| `CachePolicyId: 4135ea2d-...` | Managed policy **CachingDisabled** (A8) |
| `IPV6Enabled: false` | IPv6 unchecked (A6) |
| `WebACLId` | Web ACL association (A9) |

## Telemetry stack

| Template parameter or property | Console equivalent |
|---|---|
| `PipelineName` | `PIPELINE_NAME` env var (C6) and both event patterns (C7) |
| `DashboardBucketName` | `DASHBOARD_BUCKET` env var (C6) and IAM policy resource (C1) |
| `DashboardBucketRegion` | `DASHBOARD_BUCKET_REGION` env var (C6) |
| `DashboardEventSource` | `DASHBOARD_EVENT_SOURCE` env var (C6) and Rule 2 `source` (C7) |
| `HistoryLimit` | `HISTORY_LIMIT` env var (C6) |
| `HeartbeatState` | Enable/disable the heartbeat rule (F2) |
| `WriteExecutionSnapshots` | `WRITE_EXECUTION_SNAPSHOTS` env var (C6) |
| `Handler: index.handler` | `lambda_function.handler` (C4), unless you upload a zip containing `index.py` |
| `ReservedConcurrentExecutions: 1` | Reserve concurrency (C5) |
| `AWS::Lambda::Permission` resources | Verify, and add if missing, the three resource-based policy statements (C7) |
| `DefaultEventBusArn` output | `arn:aws:events:PIPELINE_REGION:ACCOUNT_ID:event-bus/default` (D3) |
