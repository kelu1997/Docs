#!/usr/bin/env bash
# One-step UI deployment: build, then upload and invalidate.
#
# The UI is a React/Vite app, so dashboard/dist/ is generated output and is deliberately
# not shipped in the archive. That means deployment is always two steps. This wrapper runs
# both so the order cannot be got wrong.
#
# Scripts are invoked through `bash` rather than executed directly, so this works even if
# the archive was repacked somewhere that dropped the Unix execute bit.

set -euo pipefail

if [[ $# -lt 2 ]]; then
  cat >&2 <<'EOF'
Usage: scripts/deploy-dashboard.sh <dashboard-bucket-name> <cloudfront-distribution-id> [aws-profile]

Builds the dashboard and uploads it, then creates a CloudFront invalidation.
Equivalent to running these two in order:

  bash scripts/build-dashboard.sh
  bash scripts/upload-dashboard.sh <bucket> <distribution-id> [profile]
EOF
  exit 2
fi

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "==> Building dashboard"
bash "$ROOT/scripts/build-dashboard.sh"

echo
echo "==> Uploading to s3://$1 and invalidating $2"
bash "$ROOT/scripts/upload-dashboard.sh" "$@"

echo
echo "Done. Open the CloudFront URL from an IP in the WAF allowlist and hard-refresh."
