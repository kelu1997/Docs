#!/usr/bin/env bash
# Build the static dashboard into dashboard/dist/.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if ! command -v npm >/dev/null 2>&1; then
  cat >&2 <<'EOF'
npm was not found on PATH.

The dashboard is a React/Vite application, so building it needs Node.js and npm. The AWS
Console cannot build it. Options:

  - AWS CloudShell already has Node.js and npm, and an authenticated AWS CLI.
  - Any workstation with Node.js 18 or later. Build there, then upload the contents of
    dashboard/dist/ through the S3 console (see CONSOLE_MANUAL_SETUP.md, section B6).
EOF
  exit 1
fi

cd "$ROOT/dashboard"
npm install
npm run build

if [[ ! -f "$ROOT/dashboard/dist/index.html" ]]; then
  echo "Build finished but dashboard/dist/index.html is missing. Check the output above." >&2
  exit 1
fi

printf '\nBuilt dashboard at %s/dashboard/dist\n' "$ROOT"
printf 'Next: bash scripts/upload-dashboard.sh <bucket> <distribution-id>\n'
