#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 2 ]]; then
  echo "Usage: $0 <dashboard-bucket-name> <cloudfront-distribution-id> [aws-profile]"
  exit 2
fi

BUCKET="$1"
DIST="$2"
PROFILE_ARGS=()
if [[ $# -ge 3 ]]; then PROFILE_ARGS=(--profile "$3"); fi
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DIST_DIR="$ROOT/dashboard/dist"

if [[ ! -d "$DIST_DIR" ]]; then
  cat >&2 <<EOF
Dashboard dist/ not found at:
  $DIST_DIR

dist/ is generated output. It is deliberately not shipped in the archive, so the UI has to
be built before it can be uploaded. Run both steps:

  bash scripts/build-dashboard.sh
  bash scripts/upload-dashboard.sh $BUCKET $DIST

or use the single-step wrapper, which does the same thing in the right order:

  bash scripts/deploy-dashboard.sh $BUCKET $DIST
EOF
  exit 1
fi

# Exclude data/* so UI deployments never overwrite/delete live telemetry snapshots.
aws "${PROFILE_ARGS[@]}" s3 sync "$DIST_DIR/" "s3://$BUCKET/" \
  --delete \
  --exclude 'data/*'

# Force index/config to revalidate at the browser; hashed Vite assets can stay cached.
aws "${PROFILE_ARGS[@]}" s3 cp "$DIST_DIR/index.html" "s3://$BUCKET/index.html" \
  --content-type 'text/html' \
  --cache-control 'no-cache, max-age=0'
aws "${PROFILE_ARGS[@]}" s3 cp "$DIST_DIR/config.json" "s3://$BUCKET/config.json" \
  --content-type 'application/json' \
  --cache-control 'no-cache, max-age=0'

aws "${PROFILE_ARGS[@]}" cloudfront create-invalidation --distribution-id "$DIST" --paths '/*'
