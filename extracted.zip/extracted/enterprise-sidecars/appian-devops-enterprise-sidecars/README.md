# Appian DevOps Demo — Enterprise Sidecar Integrations

This package adds **non-blocking enterprise sidecars** around the existing CodePipeline:

```text
Source → SAST → DeployToTest → ValidateAndTest → CentralQualityGate
```

It does **not** modify or block that core delivery path.

## Included capabilities

- CodePipeline pipeline/stage/action events → Amazon EventBridge
- ServiceNow update adapter (MOCK by default; REAL-ready)
- Jira update adapter (MOCK by default; REAL-ready)
- Amazon Bedrock-ready failure RCA (MOCK by default)
- Bounded failure evidence collection from CodePipeline, CodeBuild, Step Functions, and Lambda/CloudWatch
- S3 execution evidence archive
- DynamoDB idempotency/result records
- SNS failure/analysis notifications
- EventBridge delivery DLQ
- Lambda asynchronous processing-failure queue
- CloudWatch alarms
- Secrets Manager placeholders for ServiceNow/Jira credentials
- SSM Parameter Store routing policy
- Optional SAM/CloudFormation template

## Architecture

```text
Existing CodePipeline
      │
      │ state-change events (best effort)
      ▼
Amazon EventBridge
      │
      ├─────────────────────────────┐
      ▼                             ▼
Integration Router Lambda     Failure Analyzer Lambda
      │                             │
      ├─ ServiceNow                 ├─ CodePipeline execution details
      ├─ Jira                       ├─ CodeBuild logs
      ├─ SNS                        ├─ Step Functions history
      └─ S3 evidence                ├─ Lambda/CloudWatch logs
                                    ├─ redact + truncate
                                    └─ Bedrock (MOCK/REAL/DISABLED)
                                           │
                                           ▼
                                  Failure Analysis Complete
                                           │
                                           ▼
                                      EventBridge
                                           │
                                           ▼
                                  Integration Router
                                  → SNOW / Jira / SNS

Supporting: DynamoDB, SQS DLQs, Secrets Manager, SSM, CloudWatch
```

## Safe defaults

Everything can be deployed without real external connections:

- `ServiceNow mode = MOCK`
- `Jira mode = MOCK`
- `Bedrock mode = MOCK`

That means you can demonstrate event capture, integration routing, evidence creation, failure handling, and AI-shaped RCA output without needing ServiceNow, Jira, or Bedrock access yet.

## Start here

1. Read [`QUICKSTART.md`](QUICKSTART.md).
2. For console-first deployment, follow [`docs/02_CONSOLE_IMPLEMENTATION.md`](docs/02_CONSOLE_IMPLEMENTATION.md).
3. Run the demo cases in [`docs/03_DEMO_RUNBOOK.md`](docs/03_DEMO_RUNBOOK.md).
4. When credentials/access arrive, use [`docs/04_TURN_INTEGRATIONS_REAL.md`](docs/04_TURN_INTEGRATIONS_REAL.md).
5. For operations/security, read [`docs/05_OPERATIONS_AND_SECURITY.md`](docs/05_OPERATIONS_AND_SECURITY.md).
6. For post-demo production hardening, read [`docs/06_PRODUCTION_HARDENING.md`](docs/06_PRODUCTION_HARDENING.md).
7. Reference assumptions are summarized in [`docs/07_REFERENCE_NOTES.md`](docs/07_REFERENCE_NOTES.md).
8. For the observability layer and Amazon Managed Grafana display path, read [`docs/08_OBSERVABILITY_AND_GRAFANA.md`](docs/08_OBSERVABILITY_AND_GRAFANA.md).

## Rebuilding the deployment packages

Each zip must contain both the handler and the shared `observability.py`
module. After editing anything under `backend/`, run:

```powershell
pwsh -File tools/build-deployment-packages.ps1
```

This rebuilds both zips and regenerates `SHA256SUMS.txt`.

## Files

```text
appian-devops-enterprise-sidecars/
├── README.md
├── QUICKSTART.md
├── backend/
│   ├── common/observability.py        # EMF metrics + structured logging
│   ├── integration-router/lambda_function.py
│   └── failure-analyzer/lambda_function.py
├── config/
│   └── routing-config.example.json
├── deployment/
│   ├── integration-router.zip         # handler + observability.py
│   └── failure-analyzer.zip           # handler + observability.py
├── infrastructure/
│   ├── template.yaml
│   ├── event-pattern-all.json
│   └── event-pattern-failures.json
├── tools/
│   └── build-deployment-packages.ps1
├── docs/
│   ├── 01_ARCHITECTURE.md
│   ├── 02_CONSOLE_IMPLEMENTATION.md
│   ├── 03_DEMO_RUNBOOK.md
│   ├── 04_TURN_INTEGRATIONS_REAL.md
│   ├── 05_OPERATIONS_AND_SECURITY.md
│   ├── 06_PRODUCTION_HARDENING.md
│   ├── 07_REFERENCE_NOTES.md
│   └── 08_OBSERVABILITY_AND_GRAFANA.md
└── tests/
    └── test_static.py
```

## Design rule

**Generative AI never controls pipeline pass/fail.** The existing `CentralQualityGate` remains authoritative. Bedrock only produces asynchronous diagnostic summaries and recommendations after a failure has already occurred.

## VPC requirement

None by default. The entire sidecar layer can run without customer-managed VPC resources when ServiceNow/Jira endpoints are internet-accessible. Private enterprise endpoints can later be reached by selectively VPC-attaching only the relevant Lambda(s).
