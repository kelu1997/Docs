"""Publish sidecar activity to the DevOps dashboard through EventBridge.

The dashboard (DevOpsDashboardImplementation) renders its integration feed and its
Bedrock panel only from custom EventBridge events. This sidecar layer already performs
the ServiceNow/Jira updates and the failure RCA, but historically reported them solely
to CloudWatch, so both dashboard panels stayed empty. This module is the missing
publish step, shared by the integration router and the failure analyzer.

Contract (DevOpsDashboardImplementation/telemetry/EVENT_CONTRACT.md). All of these must
line up or the telemetry Lambda discards the event with no error anywhere:

- ``Source``           == the telemetry stack's ``DashboardEventSource``
- ``detail.pipeline``  == the telemetry stack's ``PipelineName``, byte-exact. The rule
                          filters on it. Override with ``DASHBOARD_PIPELINE_NAME`` when
                          the dashboard was deployed with a different spelling from the
                          name that appears in CodePipeline events.
- ``detail.executionId`` == the execution currently on screen. Integration events with a
                          stale ID still appear in the timeline flagged ``historical``;
                          bedrock events are dropped outright.
- ``detail.kind``      ``integration`` or ``bedrock`` here

Unlike quality signals, neither of these kinds nests its fields under ``metrics`` -- the
telemetry Lambda reads them straight off ``detail``.

Emission is best effort, matching observability.py: these sidecars are non-blocking
observers, and a dashboard problem must never fail an invocation or change a pipeline
outcome. Every failure path is logged through obs and swallowed.

Redaction contract: callers MUST pass already-redacted text. This module truncates but
does not attempt to redact secrets.
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from typing import Any, Iterable, Optional

import boto3
from botocore.exceptions import BotoCoreError, ClientError

import observability as obs

_FALSE_VALUES = {"false", "0", "no", "off"}
ENABLED = os.getenv("DASHBOARD_SIGNALS_ENABLED", "true").strip().lower() not in _FALSE_VALUES

EVENT_SOURCE = os.getenv("DASHBOARD_EVENT_SOURCE", "devops.pipeline.dashboard")
EVENT_BUS = os.getenv("DASHBOARD_EVENT_BUS", "default")
EVENT_REGION = os.getenv("DASHBOARD_EVENT_REGION") or os.getenv("AWS_REGION")
DETAIL_TYPE = "DevOps Dashboard Signal"
# Optional override for when the dashboard's PipelineName differs from the pipeline name
# carried in CodePipeline events. Left blank, the caller's value is used as-is.
PIPELINE_NAME_OVERRIDE = os.getenv("DASHBOARD_PIPELINE_NAME", "").strip()

# The dashboard truncates message-like fields; matching here keeps the published event
# and the rendered card identical.
MAX_MESSAGE_CHARS = 700
MAX_SUMMARY_CHARS = 1800
MAX_ACTION_CHARS = 600
MAX_ACTIONS = 6

# The dashboard passes unrecognized statuses through to the UI, where they render as a
# neutral grey badge. Map this layer's vocabulary onto the statuses the UI colours.
_STATUS_MAP = {
    "SUCCEEDED": "SUCCEEDED",
    "SUCCESS": "SUCCEEDED",
    "MOCK_SENT": "SUCCEEDED",
    "PASSED": "SUCCEEDED",
    "COMPLETED": "SUCCEEDED",
    "FAILED": "FAILED",
    "FAILURE": "FAILED",
    "ERROR": "FAILED",
    "STARTED": "IN_PROGRESS",
    "IN_PROGRESS": "IN_PROGRESS",
    "SUPERSEDED": "SUPERSEDED",
    "CANCELED": "CANCELED",
    "STOPPED": "STOPPED",
}

_events = boto3.client("events", region_name=EVENT_REGION)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def normalize_status(value: Any) -> str:
    raw = str(value or "").strip().upper().replace("-", "_").replace(" ", "_")
    if raw.startswith("HTTP_2"):
        # _send_servicenow/_send_jira return "HTTP_200" style results on the REAL path.
        return "SUCCEEDED"
    return _STATUS_MAP.get(raw, raw or "PENDING")


def _text(value: Any, limit: int) -> Optional[str]:
    if value is None:
        return None
    text = str(value).replace("\x00", " ").strip()
    if not text:
        return None
    return text[:limit]


def _publish(detail: dict, kind: str) -> bool:
    """Send one detail payload. Returns True when EventBridge accepted it.

    Never raises. Missing configuration is reported once and skipped rather than
    retried, because none of these conditions can resolve themselves mid-invocation.
    """
    if not ENABLED:
        return False

    pipeline = PIPELINE_NAME_OVERRIDE or detail.get("pipeline")
    if not pipeline or pipeline == "unknown":
        # The dashboard rule filters on detail.pipeline, so an event without it can
        # never be delivered. Skip rather than pay for a call that cannot match.
        obs.log(
            "DashboardSignalSkipped",
            level="WARNING",
            reason="NO_PIPELINE_NAME",
            signalKind=kind,
            hint="Set DASHBOARD_PIPELINE_NAME to the dashboard's PipelineName.",
        )
        return False

    execution_id = detail.get("executionId")
    if not execution_id or execution_id == "unknown":
        obs.log(
            "DashboardSignalSkipped",
            level="WARNING",
            reason="NO_EXECUTION_ID",
            signalKind=kind,
        )
        return False

    payload = {k: v for k, v in {**detail, "pipeline": pipeline}.items() if v is not None}
    payload.setdefault("timestamp", _now())

    try:
        response = _events.put_events(
            Entries=[
                {
                    "Source": EVENT_SOURCE,
                    "DetailType": DETAIL_TYPE,
                    "Detail": json.dumps(payload, default=str),
                    "EventBusName": EVENT_BUS,
                }
            ]
        )
    except (BotoCoreError, ClientError) as exc:
        # Most likely cause: the execution role is missing events:PutEvents.
        obs.log(
            "DashboardSignalFailed",
            level="WARNING",
            signalKind=kind,
            error=str(exc),
            errorType=type(exc).__name__,
        )
        return False

    if response.get("FailedEntryCount"):
        entries = response.get("Entries") or [{}]
        obs.log(
            "DashboardSignalRejected",
            level="WARNING",
            signalKind=kind,
            rejection=entries[0],
        )
        return False

    return True


def integration_status(
    *,
    pipeline: str,
    execution_id: str,
    integration: str,
    operation: str,
    status: str,
    stage: Optional[str] = None,
    external_id: Optional[str] = None,
    external_url: Optional[str] = None,
    message: Optional[str] = None,
) -> bool:
    """Publish one row of the dashboard's ServiceNow/Jira/external updates feed.

    ``status`` describes whether the outbound update itself succeeded, not the pipeline
    state that triggered it -- the feed answers "did we manage to update the ticket".
    """
    return _publish(
        {
            "kind": "integration",
            "pipeline": pipeline,
            "executionId": execution_id,
            "integration": _text(integration, 100),
            "operation": _text(operation, 180),
            "stage": _text(stage, 120),
            "status": normalize_status(status),
            "externalId": _text(external_id, 200),
            "externalUrl": _text(external_url, 1200),
            "message": _text(message, MAX_MESSAGE_CHARS),
        },
        "integration",
    )


def bedrock_analysis(
    *,
    pipeline: str,
    execution_id: str,
    status: str,
    summary: str,
    root_cause: Optional[str] = None,
    recommended_actions: Optional[Iterable[str]] = None,
    stage: Optional[str] = None,
    model_id: Optional[str] = None,
    analysis_id: Optional[str] = None,
) -> bool:
    """Publish the dashboard's Bedrock failure-analysis panel.

    Publish only summarized, already-redacted fields. Never send raw logs, prompts or
    evidence bodies to the dashboard; those stay in the S3 evidence object.
    """
    actions = [
        _text(item, MAX_ACTION_CHARS)
        for item in list(recommended_actions or [])[:MAX_ACTIONS]
    ]
    return _publish(
        {
            "kind": "bedrock",
            "pipeline": pipeline,
            "executionId": execution_id,
            "status": normalize_status(status),
            "stage": _text(stage, 120),
            "summary": _text(summary, MAX_SUMMARY_CHARS),
            "rootCause": _text(root_cause, MAX_SUMMARY_CHARS),
            "recommendedActions": [item for item in actions if item],
            "modelId": _text(model_id, 300),
            "analysisId": _text(analysis_id, 200),
        },
        "bedrock",
    )
