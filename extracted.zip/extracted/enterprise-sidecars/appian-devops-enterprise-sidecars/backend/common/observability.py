"""Structured logging and CloudWatch EMF metrics for the DevOps sidecar Lambdas.

Why EMF (Embedded Metric Format) rather than PutMetricData:

* The metric document is written to stdout and CloudWatch Logs extracts the
  metrics asynchronously, so no ``cloudwatch:PutMetricData`` permission is
  required and no additional IAM change is needed.
* Metric emission cannot add latency to, or fail, the sidecar invocation.

One EMF document carries both:

* low-cardinality metric *dimensions* (Pipeline, Integration, Level, ...), and
* high-cardinality context *properties* (execution IDs, ticket references,
  RCA text).

Amazon Managed Grafana can therefore drive metric panels from CloudWatch
metrics and detail/table panels from CloudWatch Logs Insights against the same
single emission, with no DynamoDB read path.

Redaction contract: callers MUST pass already-redacted text. This module
truncates values but deliberately does not attempt to redact secrets.
"""

from __future__ import annotations

import json
import os
import sys
import time
from typing import Any, Mapping, Sequence

# Overridden by each Lambda at import time so the field is correct even when the
# environment variable is not set.
COMPONENT = os.getenv("SIDECAR_COMPONENT", "unknown")

NAMESPACE = os.getenv("METRICS_NAMESPACE", "AppianDevOps/Sidecars")

_FALSE_VALUES = {"false", "0", "no", "off"}
_ENABLED = os.getenv("METRICS_ENABLED", "true").strip().lower() not in _FALSE_VALUES

# CloudWatch hard limits.
_MAX_DIMENSION_VALUE_CHARS = 255
_MAX_DIMENSIONS_PER_SET = 30

_MAX_PROPERTY_CHARS = int(os.getenv("MAX_PROPERTY_CHARS", "1500"))

_LEVELS = {"DEBUG": 10, "INFO": 20, "WARNING": 30, "ERROR": 40}
_MIN_LEVEL = _LEVELS.get(os.getenv("LOG_LEVEL", "INFO").strip().upper(), 20)


def now_ms() -> int:
    """Epoch milliseconds, the timestamp unit EMF expects."""
    return int(time.time() * 1000)


def _write(payload: dict) -> None:
    """Emit exactly one single-line JSON document to stdout.

    Single-line output is required: CloudWatch Logs treats each line as one
    event, and both EMF metric extraction and Logs Insights JSON field
    discovery need the whole event to be one JSON object.
    """
    try:
        sys.stdout.write(json.dumps(payload, default=str, separators=(",", ":")) + "\n")
        sys.stdout.flush()
    except Exception:  # noqa: BLE001 - telemetry must never break the sidecar
        pass


def _property(value: Any) -> Any:
    """Coerce an arbitrary value into a Logs Insights friendly scalar."""
    if value is None:
        return None
    if isinstance(value, bool) or isinstance(value, (int, float)):
        return value
    if isinstance(value, (list, tuple, set)):
        text = "; ".join(str(item) for item in value)
    elif isinstance(value, Mapping):
        text = json.dumps(value, default=str)
    else:
        text = str(value)
    text = text.strip()
    if not text:
        return None
    return text[:_MAX_PROPERTY_CHARS]


def _dimension(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    return text[:_MAX_DIMENSION_VALUE_CHARS]


def log(event: str, level: str = "INFO", **fields: Any) -> None:
    """Emit a structured JSON log line with no associated metric."""
    level = level.upper()
    if _LEVELS.get(level, 20) < _MIN_LEVEL:
        return
    payload: dict[str, Any] = {
        "level": level,
        "event": event,
        "component": COMPONENT,
        "emittedAt": now_ms(),
    }
    for key, value in fields.items():
        prepared = _property(value)
        if prepared is not None:
            payload[key] = prepared
    _write(payload)


def emit(
    event: str,
    metrics: Mapping[str, Any],
    dimensions: Mapping[str, Any] | None = None,
    dimension_sets: Sequence[Sequence[str]] | None = None,
    **properties: Any,
) -> None:
    """Emit one EMF document carrying metrics, dimensions and context.

    Args:
        event: logical event name, always emitted as the ``event`` field so
            Logs Insights queries can filter on it.
        metrics: mapping of metric name to either a numeric value (unit
            ``Count``) or a ``(value, unit)`` tuple.
        dimensions: low-cardinality dimension name to value. Values that are
            empty or None are dropped.
        dimension_sets: explicit dimension groupings. Defaults to a single set
            containing every supplied dimension. Names not present in
            ``dimensions`` are filtered out; an empty set is valid EMF and
            aggregates at the namespace level.
        **properties: high-cardinality context fields. Queryable in Logs
            Insights but never turned into metric dimensions.
    """
    if not _ENABLED:
        log(event, **{**properties, **(dimensions or {})})
        return

    clean_dimensions: dict[str, str] = {}
    for name, value in (dimensions or {}).items():
        prepared = _dimension(value)
        if prepared is not None:
            clean_dimensions[name] = prepared

    metric_definitions: list[dict[str, str]] = []
    metric_values: dict[str, float] = {}
    for name, raw in metrics.items():
        if isinstance(raw, tuple) and len(raw) == 2:
            value, unit = raw
        else:
            value, unit = raw, "Count"
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            continue
        metric_definitions.append({"Name": name, "Unit": str(unit)})
        metric_values[name] = value

    if not metric_definitions:
        # EMF requires at least one metric; degrade to a structured log line.
        log(event, **{**properties, **clean_dimensions})
        return

    if dimension_sets is None:
        requested_sets: Sequence[Sequence[str]] = [list(clean_dimensions)]
    else:
        requested_sets = dimension_sets

    resolved_sets: list[list[str]] = []
    for candidate in requested_sets:
        filtered = [name for name in candidate if name in clean_dimensions][:_MAX_DIMENSIONS_PER_SET]
        if filtered not in resolved_sets:
            resolved_sets.append(filtered)
    if not resolved_sets:
        resolved_sets = [[]]

    payload: dict[str, Any] = {}
    for key, value in properties.items():
        prepared = _property(value)
        if prepared is not None:
            payload[key] = prepared

    # Dimensions and metrics take precedence over context on key collisions.
    payload.update(clean_dimensions)
    payload.update(metric_values)
    payload["event"] = event
    payload["component"] = COMPONENT
    payload["_aws"] = {
        "Timestamp": now_ms(),
        "CloudWatchMetrics": [
            {
                "Namespace": NAMESPACE,
                "Dimensions": resolved_sets,
                "Metrics": metric_definitions,
            }
        ],
    }
    _write(payload)
