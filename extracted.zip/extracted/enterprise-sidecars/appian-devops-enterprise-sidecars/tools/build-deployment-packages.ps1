<#
.SYNOPSIS
Rebuilds the two Lambda deployment zips and regenerates SHA256SUMS.txt.

.DESCRIPTION
Each zip must be self-contained, so the shared modules under backend/common are
copied in alongside the function's own lambda_function.py. There is no Lambda
layer to manage.

Run this after editing anything under backend/.

.EXAMPLE
pwsh -File tools/build-deployment-packages.ps1
#>
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
$sharedModules = @(
    'backend/common/observability.py',
    'backend/common/dashboard_signals.py'
)
$deployment = Join-Path $root 'deployment'

foreach ($relative in $sharedModules) {
    if (-not (Test-Path (Join-Path $root $relative))) {
        throw "Shared module not found: $relative"
    }
}
if (-not (Test-Path $deployment)) {
    New-Item -ItemType Directory -Path $deployment | Out-Null
}

$functions = @(
    @{ Name = 'integration-router'; Source = 'backend/integration-router' },
    @{ Name = 'failure-analyzer';   Source = 'backend/failure-analyzer' }
)

foreach ($function in $functions) {
    $sourceDir = Join-Path $root $function.Source
    $handler = Join-Path $sourceDir 'lambda_function.py'
    if (-not (Test-Path $handler)) {
        throw "Handler not found: $handler"
    }

    $staging = Join-Path ([System.IO.Path]::GetTempPath()) ("sidecar-" + $function.Name + "-" + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $staging | Out-Null
    try {
        Copy-Item $handler -Destination $staging
        foreach ($relative in $sharedModules) {
            Copy-Item (Join-Path $root $relative) -Destination $staging
        }

        $zip = Join-Path $deployment ($function.Name + '.zip')
        if (Test-Path $zip) { Remove-Item $zip }
        Compress-Archive -Path (Join-Path $staging '*') -DestinationPath $zip

        $size = (Get-Item $zip).Length
        Write-Host ("built {0,-22} {1,7} bytes" -f ($function.Name + '.zip'), $size)
    }
    finally {
        Remove-Item -Recurse -Force $staging
    }
}

# Regenerate the integrity manifest over the files it originally covered, plus
# the new shared module.
$manifestTargets = @(
    'backend/common/observability.py',
    'backend/common/dashboard_signals.py',
    'backend/integration-router/lambda_function.py',
    'backend/failure-analyzer/lambda_function.py',
    'deployment/integration-router.zip',
    'deployment/failure-analyzer.zip',
    'config/routing-config.example.json',
    'infrastructure/template.yaml',
    'infrastructure/event-pattern-all.json',
    'infrastructure/event-pattern-failures.json'
)

$lines = foreach ($relative in $manifestTargets) {
    $path = Join-Path $root $relative
    if (-not (Test-Path $path)) {
        throw "Manifest target missing: $relative"
    }
    $hash = (Get-FileHash -Path $path -Algorithm SHA256).Hash.ToLower()
    "$hash  $relative"
}

$manifest = Join-Path $root 'SHA256SUMS.txt'
Set-Content -Path $manifest -Value $lines -Encoding ascii
Write-Host ("regenerated {0} ({1} entries)" -f 'SHA256SUMS.txt', $lines.Count)
