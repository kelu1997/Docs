# 04 — Turning the Mock Integrations Real

Do this only after the mock architecture is stable.

---

# A. Real ServiceNow

The supplied adapter supports a straightforward ServiceNow Table API update of an existing record.

## Secret format

Update the ServiceNow Secrets Manager secret to real values:

```json
{
  "baseUrl": "https://your-instance.service-now.com",
  "username": "pipeline.integration.user",
  "password": "REPLACE_WITH_REAL_SECRET",
  "table": "change_request",
  "recordSysId": "fallback-sys-id",
  "field": "work_notes"
}
```

The router sends a `PATCH` request to:

```text
/api/now/table/<table>/<sys_id>
```

with a request body such as:

```json
{
  "work_notes": "Pipeline ... SAST SUCCEEDED ..."
}
```

The ServiceNow calling user must have the roles/ACL access required to update that record/table.

## Optional per-execution record

Add a CodePipeline pipeline variable:

```text
ServiceNowRecordSysId
```

If present, the execution's resolved value overrides the fallback secret `recordSysId`.

Do not put ServiceNow credentials in pipeline variables.

## Enable it

Edit the SSM routing parameter:

```json
"servicenow": {
  "enabled": true,
  "mode": "REAL"
}
```

Keep all other routing fields.

Run a controlled pipeline execution and verify the expected change record receives a work note.

If your client uses OAuth, a custom Scripted REST API, a MID Server, or a different change-management model, replace only `_send_servicenow()` in the Integration Router; the EventBridge architecture stays unchanged.

---

# B. Real Jira Cloud

The supplied adapter supports adding a Jira Cloud issue comment through REST API v3.

## Secret format

```json
{
  "baseUrl": "https://your-company.atlassian.net",
  "email": "pipeline-user@example.com",
  "apiToken": "REPLACE_WITH_REAL_TOKEN",
  "issueKey": "DEVOPS-123"
}
```

The router posts to:

```text
/rest/api/3/issue/<issueKey>/comment
```

using Atlassian Document Format for the comment body.

The Jira user/app must have permission to browse the project/issue and add comments.

## Optional per-execution issue

Add a CodePipeline pipeline variable:

```text
JiraIssueKey
```

When present, it overrides the fallback secret `issueKey`.

## Enable it

Change Jira routing mode in the SSM parameter:

```json
"mode": "REAL"
```

Run a controlled pipeline execution and verify comments appear.

If the client uses Jira Data Center, OAuth, Forge, a proxy, or a custom issue-correlation mechanism, replace only `_send_jira()`; the surrounding architecture stays the same.

---

# C. Real Amazon Bedrock failure analysis

The analyzer uses the Bedrock Runtime `Converse` API when:

```text
BEDROCK_MODE=REAL
```

## 1. Choose a model or inference profile

Use a model/inference profile supported in your account and Region.

Set the Failure Analyzer environment variable:

```text
BEDROCK_MODEL_ID=<model-or-inference-profile-id>
```

The package deliberately does not hard-code a particular foundation model so the architecture does not depend on a model name that may change or differ by Region/account.

## 1a. Inference parameters differ by model

Supported `inferenceConfig` fields are model-specific, and a model that does not
support one returns a `ValidationException` rather than ignoring it. Reasoning-style
models in particular reject `temperature`:

```text
This model doesn't support the temperature field. Remove temperature and try again.
```

So `temperature` and `topP` are optional and omitted by default:

```text
BEDROCK_TEMPERATURE   blank => field omitted
BEDROCK_TOP_P         blank => field omitted
BEDROCK_MAX_TOKENS    900
```

If a model rejects a field you did set, `_converse()` logs a warning, drops that
field, and retries once rather than failing the analysis. Clear the corresponding
environment variable afterwards to avoid the wasted round trip on every failure.

Raise `BEDROCK_MAX_TOKENS` for reasoning models: their thinking tokens count against
the same budget, so the default 900 can truncate the JSON response and drop the
analysis into the LOW-confidence parse fallback.

## 2. IAM

The demo policy already includes:

```text
bedrock:InvokeModel
```

For production, restrict this from `Resource: *` to the exact model/inference profile resources your organization approves.

## 3. Switch mode

Failure Analyzer → **Configuration → Environment variables**:

```text
BEDROCK_MODE=REAL
```

Save.

## 4. Optional Bedrock Guardrail

The Lambda already performs application-side credential-pattern redaction before Bedrock.

For another layer, create a Bedrock Guardrail configured for the sensitive-information/content policies your organization wants. Create/publish a guardrail version and set:

```text
BEDROCK_GUARDRAIL_ID=<id-or-arn>
BEDROCK_GUARDRAIL_VERSION=<published-version>
```

The analyzer then supplies `guardrailConfig` with the Converse request.

## 5. Test

Force a known mock SAST/Tosca quality failure.

Inspect:

```text
S3 / executions/<pipeline>/<execution>/failures/
```

The resulting analysis should contain:

```json
{
  "summary": "...",
  "probableCause": "...",
  "failedComponent": "...",
  "evidence": ["..."],
  "recommendedActions": ["..."],
  "confidence": "HIGH|MEDIUM|LOW",
  "analysisMode": "BEDROCK"
}
```

## 6. Model entitlement, before you flip the switch

There is no longer a **Model access** page in the Bedrock console. Access to all
foundation models is enabled by default *provided the invoking identity holds AWS
Marketplace permissions*: on the first invocation of a third-party model in an
account, Bedrock initiates the subscription automatically in the background.

The analyzer's execution role deliberately does **not** hold those permissions. A
pipeline sidecar should not be able to create Marketplace subscriptions, and for
models without a product ID (Amazon, DeepSeek, Mistral AI, Meta, Qwen, OpenAI) the
`aws-marketplace:ProductId` condition key does not exist, so the grant cannot be
scoped. Bootstrap entitlement once from an administrative identity instead; after
that, invocation needs no Marketplace permissions at all.

Three prerequisites must be satisfied before the first invocation:

1. The bootstrapping identity has `aws-marketplace:Subscribe`, `:Unsubscribe`,
   and `:ViewSubscriptions`.
2. For Anthropic models, the one-time First Time Use form is submitted — once per
   account, or once at the organization management account, which the member
   accounts then inherit.
3. The account has a valid payment method for AWS Marketplace purchases.

Bootstrap by opening the model from the console **model catalog** in the playground
and sending one prompt, or programmatically:

```powershell
aws bedrock list-foundation-model-agreement-offers --model-id <foundation-model-id>
aws bedrock put-use-case-for-model-access --form-data <base64-json>   # Anthropic only
aws bedrock create-foundation-model-agreement --model-id <foundation-model-id> --offer-token <token>
aws bedrock get-foundation-model-availability --model-id <foundation-model-id>
```

These commands require AWS CLI 2.27.42 or later. Entitlement is per foundation
model, not per inference profile, so resolve a `us.`-prefixed profile to its
underlying model IDs first with `aws bedrock get-inference-profile`. A model
subscribed in one Region becomes available in every Region where it is offered.

Confirm before flipping `BEDROCK_MODE=REAL`:

```json
{
  "agreementAvailability": { "status": "AVAILABLE" },
  "authorizationStatus": "AUTHORIZED",
  "entitlementAvailability": "AVAILABLE",
  "regionAvailability": "AVAILABLE"
}
```

## 7. Troubleshooting REAL mode

Symptoms are visible as `event="AnalysisFailed"` with `AnalysisMode=REAL` in the
analyzer log group, and as the `AnalysisFailure` metric.

| Error | Cause | Fix |
|---|---|---|
| `ValidationException: This model doesn't support the temperature field` | Reasoning-style models reject `temperature`/`topP` rather than ignoring them | Leave `BEDROCK_TEMPERATURE`/`BEDROCK_TOP_P` blank. `_converse()` drops the field and retries once, so this degrades to a warning rather than a failure |
| `ValidationException` about on-demand throughput | A bare foundation-model ID was used where an inference profile is required | Set `BEDROCK_MODEL_ID` to the `us.`-prefixed profile ID |
| `AccessDeniedException` naming `aws-marketplace:Subscribe` | Model was never entitled in the account; auto-subscribe failed because the Lambda role has no Marketplace permissions | Bootstrap entitlement per section 6. Do not add Marketplace permissions to the analyzer role |
| `AccessDeniedException` with no Marketplace mention | Missing `bedrock:InvokeModel`, or the profile ARN was granted without the underlying foundation-model ARNs | Grant both the `inference-profile/...` ARN and the `foundation-model/...` ARN in each of the profile's member Regions |
| Guardrail configured but calls fail | `bedrock:ApplyGuardrail` is not granted | Add it on the `guardrail/...` ARN alongside `bedrock:InvokeModel` |
| `confidence: LOW` with `probableCause: "See summary and collected evidence."` | The model response was truncated, so the JSON parse fell back | Raise `BEDROCK_MAX_TOKENS`; reasoning models spend thinking tokens against the same budget |

Two timing quirks worth knowing. During the up-to-15-minute subscription setup
window, calls can succeed briefly and then start returning
`AccessDeniedException` — an intermittent result here is expected, not a bug.
And after granting missing permissions, allow about 2 minutes before retrying.

When retesting, start a **new** pipeline execution. A failed analysis leaves no
`SUCCEEDED` record, but re-driving the same event from `ProcessingFailureQueue`
can collide with the `ANALYSIS#<eventId>` idempotency check.

To unblock verification without waiting on entitlement, point `BEDROCK_MODEL_ID`
at an Amazon Nova model. Amazon's own models are not sold through AWS Marketplace,
so no agreement is required.

## Guardrail / redaction principle

Do not treat a guardrail as the only secret-protection mechanism.

The intended order is:

```text
bounded failure evidence
      ↓
application-side redaction
      ↓
optional Bedrock Guardrail
      ↓
foundation model
```

---

# D. Private endpoints later

The current stack requires no customer-managed VPC.

If ServiceNow/Jira/other APIs are reachable only through private networking, VPC-attach the Integration Router and provide the required corporate routing/NAT/VPN/Direct Connect/proxy path.

The Failure Analyzer does not need to be VPC-attached unless its own dependencies require private networking.
