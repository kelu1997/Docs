# 02 — Console Implementation Guide

This is the recommended path for the current demo because the existing CodePipeline was built console-first.

## Starting assumption

Your current pipeline already works as:

```text
Source → SAST → DeployToTest → ValidateAndTest → CentralQualityGate
```

Do not add ServiceNow, Jira or Bedrock actions inside CodePipeline.

## Do not also deploy the Amplify dashboard router

The `appian-amplify-eventbridge-dashboard` package ships its **own**
integration-router Lambda using an incompatible DynamoDB schema
(`executionId`/`eventKey` keys with `itemType` tagging). Both routers subscribe
to the same CodePipeline events and both write ServiceNow/Jira updates.

Running both produces duplicate ticket updates and two divergent tables. Deploy
only the router from this package. If the dashboard package is already deployed,
disable its EventBridge rule and delete its Lambda first.

## Before you start — rebuild the deployment packages

Each zip must contain the handler **and** the shared `observability.py` module
that emits CloudWatch EMF metrics and structured JSON logs. Run:

```powershell
pwsh -File tools/build-deployment-packages.ps1
```

This rebuilds both zips and regenerates `SHA256SUMS.txt`. Verify each zip
contains two files before uploading:

```text
lambda_function.py
observability.py
```

The display path built on those emissions is
[`08_OBSERVABILITY_AND_GRAFANA.md`](08_OBSERVABILITY_AND_GRAFANA.md).

---

# Checkpoint A — Supporting storage and queues

## 1. Create the evidence S3 bucket

1. Open **Amazon S3**.
2. Choose **Create bucket**.
3. Name it something globally unique, for example:

```text
<account-or-company>-appian-devops-evidence
```

4. Keep **Block all public access** enabled.
5. Enable **Bucket Versioning**.
6. Use default server-side encryption (SSE-S3 is sufficient for the demo).
7. Create the bucket.
8. Open the bucket → **Management** → **Create lifecycle rule**.
9. Name it:

```text
ExpireDemoEvidence
```

10. Apply it to all objects.
11. Expire current and noncurrent objects after **30 days** for the demo.
12. Save.

Record the bucket name as:

```text
EVIDENCE_BUCKET
```

## 2. Create the DynamoDB table

1. Open **DynamoDB** → **Tables** → **Create table**.
2. Table name:

```text
AppianDevOpsSidecarEvents
```

3. Partition key:

```text
EventKey
```

4. Type: **String**.
5. Leave sort key empty.
6. Capacity mode: **On-demand**.
7. Create the table.
8. Open the table → **Additional settings** → **Time to Live (TTL)**.
9. Enable TTL using:

```text
ExpiresAt
```

## 3. Create the EventBridge delivery DLQ

1. Open **Amazon SQS**.
2. Choose **Create queue**.
3. Type: **Standard**.
4. Name:

```text
appian-demo-eventbridge-delivery-dlq
```

5. Enable server-side encryption.
6. Set message retention to **14 days**.
7. Create.

## 4. Create the Lambda processing-failure queue

Create another standard queue:

```text
appian-demo-sidecar-processing-failures
```

Use the same encryption and 14-day retention settings.

These queues have different meanings:

```text
EventBridge cannot deliver → EventBridge delivery DLQ
Lambda receives but cannot process → processing-failure queue
```

## 5. Create the SNS topic

1. Open **Amazon SNS** → **Topics** → **Create topic**.
2. Type: **Standard**.
3. Name:

```text
appian-demo-sidecar-notifications
```

4. Create.
5. Optional: choose **Create subscription**.
6. Protocol: **Email**.
7. Enter your demo notification address.
8. Confirm the subscription from the email AWS sends.

Record the topic ARN.

---

# Checkpoint B — Configuration and secret placeholders

## Which parts of this checkpoint are optional

| Step | MOCK-only demo | Why |
|---|---|---|
| 6 — SSM routing parameter | **Skippable** | The router resolves its policy from `ROUTING_CONFIG_JSON` (inline JSON env var), then `ROUTING_PARAMETER` (SSM), then `DEFAULT_ROUTING_CONFIG` baked into the code. Leave both variables unset and the built-in MOCK defaults apply. |
| 7 — ServiceNow secret | Skippable | `SERVICENOW_SECRET_ARN` uses `os.getenv(..., "")`, and `_load_secret()` is only reached after the `mode != "REAL"` guard. |
| 8 — Jira secret | Skippable | Same as above for `JIRA_SECRET_ARN`. |

The whole of Checkpoint B is therefore optional for a MOCK demo. The Failure
Analyzer uses neither Secrets Manager nor SSM.

## Choosing a routing source

| Source | Set | Change routing by |
|---|---|---|
| Built-in defaults | nothing | editing `DEFAULT_ROUTING_CONFIG` and rebuilding |
| Inline JSON | `ROUTING_CONFIG_JSON` | editing the Lambda environment variable |
| Parameter Store | `ROUTING_PARAMETER` | editing the SSM parameter, no Lambda change |

Inline JSON is the lightest option that still lets you change routing live —
paste the contents of `config/routing-config.example.json` as one line into the
environment variable. Parameter Store remains the only option that avoids
touching the Lambda at all, which is why steps 6, 12 and 13 still describe it.

If you skip steps 7 and 8 — the right call when the pipeline will not be
converted in place and real ServiceNow/Jira wiring is never planned for this
artifact — then also:

- omit `SERVICENOW_SECRET_ARN` and `JIRA_SECRET_ARN` from step 12, and
- delete the `ReadExternalIntegrationSecrets` statement from the step 13 policy.

Leaving the literal placeholder text `"SERVICENOW_SECRET_ARN"` in that policy's
`Resource` array is a malformed ARN and IAM will refuse to save it.

Likewise, if you skip step 6, omit `ROUTING_PARAMETER` from step 12 and delete
the `ReadRoutingPolicy` statement from step 13.

Demo 7 in `03_DEMO_RUNBOOK.md` still works without the secrets. Setting an
integration to `REAL` makes `_load_secret("")` raise
`Secret ARN is not configured`, so the integration fails, Lambda retries, the
event lands in the processing-failure queue, and CodePipeline is unaffected —
the same demonstration with no outbound network calls.

Skipping the secrets also avoids the Secrets Manager recovery-window collision:
deleted secrets are retained for 7 to 30 days, and `infrastructure/template.yaml`
uses fixed names, so a delete-and-redeploy cycle fails on a name conflict.

## 6. Create the routing parameter

1. Open **Systems Manager**.
2. Choose **Parameter Store** → **Create parameter**.
3. Name:

```text
/devops/YOUR_PIPELINE_NAME/sidecar-routing
```

4. Tier: **Standard**.
5. Type: **String**.
6. Copy the complete contents of:

```text
config/routing-config.example.json
```

into the Value field.
7. Create the parameter.

Default behavior:

```text
ServiceNow: MOCK
Jira:       MOCK
Updates:    pipeline + stage + AI-analysis events
```

To later update after every individual CodePipeline action too, add `ACTION` to the `levels` arrays.

## 7. Create the ServiceNow placeholder secret

1. Open **Secrets Manager** → **Store a new secret**.
2. Choose **Other type of secret**.
3. Use plaintext JSON:

```json
{
  "baseUrl": "https://REPLACE_ME.service-now.com",
  "username": "REPLACE_ME",
  "password": "REPLACE_ME",
  "table": "change_request",
  "recordSysId": "REPLACE_ME",
  "field": "work_notes"
}
```

4. Secret name:

```text
YOUR_PIPELINE_NAME/sidecars/servicenow
```

5. Store it and copy the secret ARN.

No real values are required while routing mode is `MOCK`.

## 8. Create the Jira placeholder secret

Create another secret:

```json
{
  "baseUrl": "https://REPLACE_ME.atlassian.net",
  "email": "REPLACE_ME",
  "apiToken": "REPLACE_ME",
  "issueKey": "REPLACE_ME"
}
```

Name:

```text
YOUR_PIPELINE_NAME/sidecars/jira
```

Copy the ARN.

---

# Checkpoint C — Integration Router Lambda

## 9. Create the Lambda

1. Open **AWS Lambda** → **Create function**.
2. Choose **Author from scratch**.
3. Name:

```text
YOUR_PIPELINE_NAME-integration-router
```

4. Runtime: **Python 3.14**.
5. Architecture: **x86_64**.
6. Create a new basic Lambda execution role.
7. Create the function.

## 10. Upload the code

1. On the **Code** tab choose **Upload from** → **.zip file**.
2. Upload:

```text
deployment/integration-router.zip
```

3. Save.
4. Handler must be:

```text
lambda_function.lambda_handler
```

5. Confirm the **Code source** panel now lists both files:

```text
lambda_function.py
observability.py
```

If `observability.py` is missing, the function will fail on cold start with
`ModuleNotFoundError`. Rebuild the zip with
`tools/build-deployment-packages.ps1` and upload again.

## 11. General configuration

Set:

```text
Memory: 512 MB
Timeout: 30 seconds
```

The Lambda does not need VPC attachment for mock mode or public SaaS endpoints.

### Leave the log format as Text

Under **Configuration → Monitoring and operations tools → Logging
configuration**, leave **Log format** set to **Text**.

The handler writes EMF metric documents and structured JSON log lines directly
to stdout. Selecting **JSON** wraps each of those lines inside a `message`
string, which breaks CloudWatch EMF metric extraction and forces every Logs
Insights query in `08_OBSERVABILITY_AND_GRAFANA.md` to be rewritten with a
`message.` prefix. This is the most common way to silently lose the metrics.

## 12. Environment variables

Add:

```text
TABLE_NAME                 AppianDevOpsSidecarEvents
EVIDENCE_BUCKET            <your evidence bucket>
ROUTING_PARAMETER          /devops/YOUR_PIPELINE_NAME/sidecar-routing
                           # omit if you skipped step 6
SERVICENOW_SECRET_ARN      <ServiceNow secret ARN — omit if you skipped step 7>
JIRA_SECRET_ARN            <Jira secret ARN — omit if you skipped step 8>
NOTIFICATION_TOPIC_ARN     <SNS topic ARN>
RETENTION_DAYS             30
HTTP_TIMEOUT_SECONDS       15
LOG_LEVEL                  INFO
METRICS_NAMESPACE          AppianDevOps/Sidecars
METRICS_ENABLED            true
SIDECAR_COMPONENT          integration-router
DASHBOARD_SIGNALS_ENABLED  true
DASHBOARD_EVENT_SOURCE     devops.pipeline.dashboard
DASHBOARD_PIPELINE_NAME    <omit unless the dashboard's PipelineName differs>
```

The last three drive the observability layer. `SIDECAR_COMPONENT` is optional —
the handler defaults it correctly in code — but setting it makes the console
configuration self-documenting. Set `METRICS_ENABLED=false` to fall back to
plain structured logs with no metric extraction.

The `DASHBOARD_*` variables feed the dashboard's ServiceNow/Jira/external updates
feed and are all optional; the defaults shown are what the code already uses. Set
`DASHBOARD_SIGNALS_ENABLED=false` to stop publishing without touching IAM.
`DASHBOARD_PIPELINE_NAME` is only needed when the dashboard telemetry stack was
deployed with a pipeline name spelled differently from the one in CodePipeline
events — its rule matches `detail.pipeline` byte-exactly, and a mismatch is a
silent drop.

## 13. Add IAM permissions to the Router role

Open **Configuration → Permissions → Execution role** and add an inline policy.

Replace placeholders:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "SidecarState",
      "Effect": "Allow",
      "Action": [
        "dynamodb:GetItem",
        "dynamodb:PutItem"
      ],
      "Resource": "DYNAMODB_TABLE_ARN"
    },
    {
      "Sid": "ArchiveEvidence",
      "Effect": "Allow",
      "Action": "s3:PutObject",
      "Resource": "arn:aws:s3:::EVIDENCE_BUCKET_NAME/*"
    },
    {
      "Sid": "ReadRoutingPolicy",
      "Effect": "Allow",
      "Action": "ssm:GetParameter",
      "Resource": "ROUTING_PARAMETER_ARN"
    },
    {
      "Sid": "ReadExternalIntegrationSecrets",
      "Effect": "Allow",
      "Action": "secretsmanager:GetSecretValue",
      "Resource": [
        "SERVICENOW_SECRET_ARN",
        "JIRA_SECRET_ARN"
      ]
    },    {
      "Sid": "ReadOptionalExecutionCorrelation",
      "Effect": "Allow",
      "Action": "codepipeline:GetPipelineExecution",
      "Resource": "CODEPIPELINE_ARN"
    },
    {
      "Sid": "SendNotifications",
      "Effect": "Allow",
      "Action": "sns:Publish",
      "Resource": "SNS_TOPIC_ARN"
    },
    {
      "Sid": "RetainFailedAsyncInvocations",
      "Effect": "Allow",
      "Action": "sqs:SendMessage",
      "Resource": "PROCESSING_FAILURE_QUEUE_ARN"
    },
    {
      "Sid": "PublishDevOpsDashboardSignals",
      "Effect": "Allow",
      "Action": "events:PutEvents",
      "Resource": "arn:aws:events:REGION:ACCOUNT_ID:event-bus/default"
    }
  ]
}
```

The role already has basic CloudWatch Logs permissions from the Lambda console.

**No metrics permission is required.** The function emits CloudWatch metrics via
EMF documents written to stdout, which CloudWatch Logs extracts. Do not add
`cloudwatch:PutMetricData`.

**If you skipped steps 7 and 8**, delete the `ReadExternalIntegrationSecrets`
statement entirely. Do not leave the placeholder strings in its `Resource` array
— they are not valid ARNs and IAM will reject the policy on save. Add the
statement back if and when you create the secrets to go `REAL`.

**If you are not running the DevOps dashboard**, delete the
`PublishDevOpsDashboardSignals` statement. It only feeds the dashboard's
ServiceNow/Jira/external updates feed. Without it the router logs
`DashboardSignalFailed` and carries on: the ServiceNow, Jira and SNS updates still
happen, and the invocation still succeeds. Prefer setting
`DASHBOARD_SIGNALS_ENABLED=false` if you want the log lines gone too.

**If you skipped step 6**, delete the `ReadRoutingPolicy` statement too, for the
same reason.

## 14. Configure async failure handling

1. Lambda → **Configuration** → **Asynchronous invocation**.
2. Choose **Edit**.
3. Maximum event age: **1 hour**.
4. Retry attempts: **2**.
5. On-failure destination: **SQS**.
6. Select:

```text
appian-demo-sidecar-processing-failures
```

7. Save.

---

# Checkpoint D — Failure Analyzer Lambda

## 15. Create the analyzer

Create another Python 3.14 Lambda:

```text
YOUR_PIPELINE_NAME-failure-analyzer
```

Use:

```text
Memory: 768 MB
Timeout: 60 seconds
```

Upload:

```text
deployment/failure-analyzer.zip
```

Handler:

```text
lambda_function.lambda_handler
```

Confirm the zip delivered both `lambda_function.py` and `observability.py`, and
leave **Log format** set to **Text** for the same reason as step 11.

## 16. Analyzer environment variables

Add:

```text
TABLE_NAME                 AppianDevOpsSidecarEvents
EVIDENCE_BUCKET            <your evidence bucket>
RETENTION_DAYS             30
BEDROCK_MODE               MOCK
BEDROCK_MODEL_ID           <leave blank for now>
BEDROCK_GUARDRAIL_ID       <leave blank>
BEDROCK_GUARDRAIL_VERSION  <leave blank>
BEDROCK_MAX_TOKENS         900
BEDROCK_TEMPERATURE        <leave blank>
BEDROCK_TOP_P              <leave blank>
MAX_LOG_EVENTS             120
MAX_CONTEXT_CHARS          45000
LOG_LEVEL                  INFO
METRICS_NAMESPACE          AppianDevOps/Sidecars
METRICS_ENABLED            true
SIDECAR_COMPONENT          failure-analyzer
DASHBOARD_SIGNALS_ENABLED  true
DASHBOARD_EVENT_SOURCE     devops.pipeline.dashboard
DASHBOARD_PIPELINE_NAME    <omit unless the dashboard's PipelineName differs>
```

Leave `BEDROCK_MODE=MOCK` until you deliberately enable real model calls.

The `DASHBOARD_*` variables feed the dashboard's Bedrock analysis panel and follow
the same rules as the router's — see step 12. The analyzer's role already has
`events:PutEvents` for its `PublishAnalysisComplete` hand-off, so no IAM change is
needed here. In `MOCK` mode the panel reports `modelId=MOCK_ANALYSIS` rather than a
model name, so the display never implies a real inference call happened.

## 17. Analyzer IAM policy

Add an inline policy to its execution role. Replace placeholders:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "ReadPipelineExecution",
      "Effect": "Allow",
      "Action": [
        "codepipeline:ListActionExecutions",
        "codepipeline:GetPipeline"
      ],
      "Resource": "CODEPIPELINE_ARN"
    },
    {
      "Sid": "ReadCodeBuild",
      "Effect": "Allow",
      "Action": "codebuild:BatchGetBuilds",
      "Resource": "*"
    },
    {
      "Sid": "ReadFailureLogs",
      "Effect": "Allow",
      "Action": "logs:FilterLogEvents",
      "Resource": [
        "arn:aws:logs:REGION:ACCOUNT_ID:log-group:/aws/codebuild/*",
        "arn:aws:logs:REGION:ACCOUNT_ID:log-group:/aws/lambda/*"
      ]
    },
    {
      "Sid": "ReadStepFunctionsFailureHistory",
      "Effect": "Allow",
      "Action": [
        "states:GetExecutionHistory",
        "states:DescribeExecution"
      ],
      "Resource": "arn:aws:states:REGION:ACCOUNT_ID:execution:*:*"
    },
    {
      "Sid": "WriteEvidence",
      "Effect": "Allow",
      "Action": "s3:PutObject",
      "Resource": "arn:aws:s3:::EVIDENCE_BUCKET_NAME/*"
    },
    {
      "Sid": "AnalysisState",
      "Effect": "Allow",
      "Action": [
        "dynamodb:GetItem",
        "dynamodb:PutItem"
      ],
      "Resource": "DYNAMODB_TABLE_ARN"
    },
    {
      "Sid": "PublishAnalysisComplete",
      "Effect": "Allow",
      "Action": "events:PutEvents",
      "Resource": "*"
    },
    {
      "Sid": "InvokeBedrockWhenEnabled",
      "Effect": "Allow",
      "Action": "bedrock:InvokeModel",
      "Resource": "*"
    },
    {
      "Sid": "RetainFailedAsyncInvocations",
      "Effect": "Allow",
      "Action": "sqs:SendMessage",
      "Resource": "PROCESSING_FAILURE_QUEUE_ARN"
    }
  ]
}
```

For the final client implementation, tighten the broad CodeBuild/Bedrock resources once the exact projects/model or inference profile are known.

As with the router, no `cloudwatch:PutMetricData` is needed — EMF emission uses
the existing CloudWatch Logs permissions.

Note that `BEDROCK_MODE=MOCK` does **not** reduce the AWS permissions the
analyzer needs. Mock mode skips only the model call; every evidence-collection
call above still runs for real. `codepipeline:ListActionExecutions`,
`codepipeline:GetPipeline` and `codebuild:BatchGetBuilds` are not wrapped in
error handling, so a single missing permission aborts the analysis before
evidence is written to S3 and before the `Failure Analysis Complete` event is
published. Verify all three in a rehearsal.

## 18. Configure analyzer async failures

Use the same settings as the Router:

```text
Maximum event age: 1 hour
Retry attempts: 2
On failure: processing-failure SQS queue
```

---

# Checkpoint E — EventBridge rules

## 19. Rule 1: all pipeline activity → Integration Router

1. Open **Amazon EventBridge** → **Rules** → **Create rule**.
2. Name:

```text
YOUR_PIPELINE_NAME-sidecar-observer
```

3. Event bus: **default**.
4. Rule type: **Rule with an event pattern**.
5. Event source: **AWS events or EventBridge partner events**.
6. Choose **Custom pattern (JSON editor)**.
7. Paste and replace the pipeline name:

```json
{
  "source": ["aws.codepipeline"],
  "detail-type": [
    "CodePipeline Pipeline Execution State Change",
    "CodePipeline Stage Execution State Change",
    "CodePipeline Action Execution State Change"
  ],
  "detail": {
    "pipeline": ["YOUR_PIPELINE_NAME"]
  }
}
```

8. Target: **AWS service → Lambda function**.
9. Select the Integration Router Lambda.
10. Configure retry policy:

```text
Maximum event age: 1 hour
Retry attempts: 6
```

11. Configure DLQ: the EventBridge delivery DLQ.
12. Create the rule.

The console normally adds Lambda invoke permission when you select the Lambda as a rule target. Verify the rule target is enabled.

## 20. Rule 2: failed actions → Failure Analyzer

Create:

```text
YOUR_PIPELINE_NAME-failure-analysis
```

Pattern:

```json
{
  "source": ["aws.codepipeline"],
  "detail-type": [
    "CodePipeline Action Execution State Change"
  ],
  "detail": {
    "pipeline": ["YOUR_PIPELINE_NAME"],
    "state": ["FAILED"]
  }
}
```

Target:

```text
YOUR_PIPELINE_NAME-failure-analyzer
```

Use the same 1-hour / 6-retry / EventBridge-DLQ settings.

## 21. Rule 3: analysis complete → Integration Router

Create:

```text
YOUR_PIPELINE_NAME-analysis-complete-router
```

Pattern:

```json
{
  "source": ["devops.sidecar"],
  "detail-type": ["Failure Analysis Complete"],
  "detail": {
    "pipeline": ["YOUR_PIPELINE_NAME"]
  }
}
```

Target the Integration Router Lambda with the same retry/DLQ settings.

## 22. If EventBridge reports SQS DLQ permission errors

Add this resource policy to the EventBridge delivery queue, replacing the three rule ARNs:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AllowEventBridgeToUseDLQ",
      "Effect": "Allow",
      "Principal": {
        "Service": "events.amazonaws.com"
      },
      "Action": "sqs:SendMessage",
      "Resource": "EVENTBRIDGE_DLQ_ARN",
      "Condition": {
        "ArnEquals": {
          "aws:SourceArn": [
            "OBSERVER_RULE_ARN",
            "FAILURE_RULE_ARN",
            "ANALYSIS_COMPLETE_RULE_ARN"
          ]
        }
      }
    }
  ]
}
```

---

# Checkpoint F — CloudWatch alarms

## 23. Lambda error alarms

Create one alarm for each Lambda:

```text
Metric namespace: AWS/Lambda
Metric: Errors
FunctionName: <function>
Statistic: Sum
Period: 5 minutes
Threshold: > 0
Evaluation periods: 1
```

Notification action: your SNS topic.

## 24. Queue alarms

Create alarms on:

```text
AWS/SQS → ApproximateNumberOfMessagesVisible
```

for both queues.

Use:

```text
Threshold > 0
Period 5 minutes
Evaluation periods 1
```

Send alarm notifications to the SNS topic.

### Optional — alarms on the sidecar's own metrics

Once a pipeline run has published EMF metrics, the namespace
`AppianDevOps/Sidecars` becomes available under **Custom namespaces**. Useful
additions are `IntegrationFailure > 0` and `AnalysisFailure > 0`, dimensioned by
`Pipeline`. These are more specific than the Lambda `Errors` alarms because they
identify *which* integration failed.

Log group retention is set in step 30, since the Grafana display path depends on
it.

---

# Checkpoint G — First end-to-end test

## 25. Run a passing pipeline

Start a normal pipeline execution with mock SAST/Tosca passing.

CodePipeline should behave exactly as before:

```text
Source                SUCCEEDED
SAST                  SUCCEEDED
ValidateAndTest       SUCCEEDED
CentralQualityGate    SUCCEEDED
```

Now inspect the observer layer.

### CloudWatch

Open the Integration Router log group. You should see messages resembling:

```text
MOCK ServiceNow update: Pipeline ... stage=SAST ... state=SUCCEEDED
MOCK Jira update: Pipeline ... stage=SAST ... state=SUCCEEDED
```

### S3

Your evidence bucket should contain:

```text
executions/<pipeline>/<execution-id>/events/*.json
```

### DynamoDB

The table should contain `INT#...#SERVICENOW`, `INT#...#JIRA`, and possibly `INT#...#SNS` records.

The sidecars have now proven they can observe the live pipeline without being part of its blocking execution path.

---

# Checkpoint H — Failure + RCA demonstration

## 26. Force a pipeline quality failure

Use the existing pipeline mock control, for example:

```text
SastMode = MOCK_FAIL
```

or the current Tosca mock failure option.

Expected core behavior:

```text
SAST / ValidateAndTest     reports result
CentralQualityGate         FAILED
```

## 27. Verify the failed-action event

The Failure Analyzer should receive the failed `EvaluateQualityGate` action event.

Open its CloudWatch log group.

It should:

1. call CodePipeline for action execution details;
2. capture upstream output variables such as SAST/Tosca status;
3. collect bounded provider logs where available;
4. redact/truncate evidence;
5. generate a MOCK RCA;
6. write the analysis to S3;
7. emit a `Failure Analysis Complete` EventBridge event.

## 28. Verify analysis evidence

S3 should now contain:

```text
executions/<pipeline>/<execution-id>/failures/<event-id>_analysis.json
```

## 29. Verify SNOW/Jira analysis updates

The Analysis Complete rule invokes the Integration Router again.

Its log should contain mock updates resembling:

```text
AI analysis: Pipeline failure detected in CentralQualityGate / EvaluateQualityGate...
Recommended actions: ...
```

This completes the mock architecture.

---

# Checkpoint I — Display path (Amazon Managed Grafana)

Amazon Managed Grafana cannot read DynamoDB — it is not a supported data source.
The sidecar table stays what it was designed to be, an idempotency and result
store. Grafana reads CloudWatch metrics and CloudWatch Logs Insights instead,
which is what the EMF emissions from steps 12 and 16 exist for.

## 30. Set log group retention

These log groups are now a data source, not throwaway diagnostics.

For each of:

```text
/aws/lambda/YOUR_PIPELINE_NAME-integration-router
/aws/lambda/YOUR_PIPELINE_NAME-failure-analyzer
```

1. Open **CloudWatch** → **Log groups**.
2. Select the group.
3. Choose **Actions** → **Edit retention setting**.
4. Set **30 days**.

## 31. Confirm metric extraction worked

Before building any panels, verify CloudWatch actually parsed the EMF documents.

1. Open **CloudWatch** → **Metrics** → **All metrics**.
2. Choose **Custom namespaces**.
3. Confirm `AppianDevOps/Sidecars` is present with `PipelineEventsObserved` and
   `IntegrationSuccess`.

If the namespace is absent after a pipeline run, the function log format was
almost certainly switched to JSON. Return to step 11.

## 32. Create the workspace

1. Enable **IAM Identity Center** in this account and Region if it is not
   already on.
2. Open **Amazon Managed Grafana** → **Create workspace**.
3. Authentication: **AWS IAM Identity Center**.
4. Permission type: **Service managed**.
5. Under data sources, tick **Amazon CloudWatch**. The service-managed role then
   receives the permissions it needs:

```text
cloudwatch:ListMetrics
cloudwatch:GetMetricData
logs:DescribeLogGroups
logs:StartQuery
logs:StopQuery
logs:GetQueryResults
logs:GetLogGroupFields
tag:GetResources
```

6. Create the workspace, then assign your Identity Center user as **Admin**.

The workspace has no public endpoint and no shared secret. Access is Identity
Center only.

## 33. Add the data source and build the dashboard

1. Open the workspace URL and sign in through Identity Center.
2. Go to **Connections** → **Data sources** → **CloudWatch**.
3. Set the Region. Leave authentication as the workspace IAM role.
4. Create a dashboard and add a **Textbox** variable named `executionId`.
5. Build the five panels from
   [`08_OBSERVABILITY_AND_GRAFANA.md`](08_OBSERVABILITY_AND_GRAFANA.md):
   stage/action state timeline, ServiceNow/Jira audit trail, AI failure
   analysis, integration outcome rate, and sidecar health.

Grafana's CloudWatch data source does not support Logs Insights results as
variable queries, which is why `executionId` is a textbox rather than a
dropdown.

## 34. Demo sequencing

Grafana queries CloudWatch metrics and Logs Insights, both of which carry
ingestion and query latency of seconds. It is not a live-progress view.

Keep the **CodePipeline console** open for live stage progression. It is native,
needs no build, and is the authoritative view. Cut to Grafana once the failure
has landed, for the integration audit trail and the RCA. That order is natural
anyway, because the analyzer only runs after a failure.

---

# Optional — Deploy the same resources with SAM/CloudFormation

The console-first build above is easiest while you are iterating.

The package also includes:

```text
infrastructure/template.yaml
```

for a reproducible implementation later.

From an AWS-authenticated terminal with AWS SAM CLI:

```bash
pwsh -File tools/build-deployment-packages.ps1
cd infrastructure
sam deploy --guided
```

`sam build` is no longer used. Both functions now declare `CodeUri` as the
prebuilt zip (`../deployment/<function>.zip`) because each package must contain
`observability.py` alongside the handler, and the per-function source
directories do not hold the shared module. Build the zips first with the tools
script, then deploy.

The template also declares both Lambda log groups with a configurable
`LogRetentionDays`, and pins `LogFormat: Text` so an IaC deployment cannot drift
onto the JSON log format that breaks EMF extraction.

Use the exact existing CodePipeline name for `PipelineName` and leave `BedrockMode=MOCK` initially.

Do not deploy the template on top of manually created resources with the same names unless you intentionally migrate ownership to CloudFormation.


---

# Optional — Per-execution ServiceNow/Jira ticket correlation

The router can resolve ticket IDs from CodePipeline pipeline variables if you later want each pipeline execution tied to a different change/issue.

Optional pipeline variables:

```text
ServiceNowRecordSysId
JiraIssueKey
```

When present on a pipeline execution, these override the fixed `recordSysId` / `issueKey` values in Secrets Manager.

This is intentionally optional. Do **not** put credentials or API tokens in CodePipeline variables; those belong in Secrets Manager.
