# 08 — Observability Layer and Amazon Managed Grafana

This replaces the Amplify dashboard as the display path. It requires no
frontend code, no API Gateway, no public endpoint, and no DynamoDB schema
change.

Amazon Managed Grafana cannot read DynamoDB — it is not a supported data
source. The sidecar table therefore stays exactly as designed: an idempotency
and result store, never a display store. Grafana reads CloudWatch metrics and
CloudWatch Logs Insights instead.

---

## Why EMF

Both Lambdas emit **Embedded Metric Format** documents to stdout. CloudWatch
Logs extracts the metrics asynchronously.

Consequences that matter:

- No `cloudwatch:PutMetricData` permission is required. **IAM does not change.**
- Metric emission cannot add latency to, or fail, the sidecar invocation.
- One document carries both metric dimensions *and* high-cardinality context,
  so metric panels and detail tables come from the same emission.

Low-cardinality values become dimensions. High-cardinality values (execution
IDs, ticket text, RCA prose) become properties: queryable in Logs Insights,
never turned into metrics.

## One real emitted document

Captured from the failure analyzer running against
`tests/sample-action-failure.json`:

```json
{
  "executionId": "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee",
  "failureEventId": "22222222-2222-2222-2222-222222222222",
  "failedStage": "CentralQualityGate",
  "failedAction": "EvaluateQualityGate",
  "provider": "Lambda",
  "summary": "Pipeline failure detected in CentralQualityGate / EvaluateQualityGate.",
  "probableCause": "Central quality gate FAILED: Tosca=FAILED",
  "recommendedActions": "Review the failed action's bounded log/evidence excerpt.; Correct the underlying issue or approved configuration.; Rerun the pipeline and confirm the Central Quality Gate passes.",
  "evidenceKey": "executions/.../failures/2222..._analysis.json",
  "Pipeline": "YOUR_PIPELINE_NAME",
  "AnalysisMode": "MOCK",
  "Confidence": "MEDIUM",
  "AnalysisCompleted": 1,
  "AnalysisDurationMillis": 1,
  "event": "AnalysisCompleted",
  "component": "failure-analyzer",
  "_aws": {
    "Timestamp": 1788478979561,
    "CloudWatchMetrics": [
      {
        "Namespace": "AppianDevOps/Sidecars",
        "Dimensions": [["Pipeline"], ["Pipeline", "AnalysisMode"], ["Pipeline", "AnalysisMode", "Confidence"]],
        "Metrics": [
          {"Name": "AnalysisCompleted", "Unit": "Count"},
          {"Name": "AnalysisDurationMillis", "Unit": "Milliseconds"}
        ]
      }
    ]
  }
}
```

## Field conventions

| Convention | Meaning | Examples |
|---|---|---|
| `PascalCase` | metric dimension | `Pipeline`, `Integration`, `Mode`, `Level`, `State`, `AnalysisMode`, `Confidence` |
| `camelCase` | context property | `executionId`, `eventId`, `stage`, `action`, `updateMessage`, `summary`, `evidenceKey` |
| `event` | logical event name, always present | `PipelineEventObserved`, `AnalysisCompleted` |
| `component` | which Lambda emitted it | `integration-router`, `failure-analyzer` |

## Metric catalogue

Namespace: `AppianDevOps/Sidecars` (override with `METRICS_NAMESPACE`).

| Metric | Emitter | `event` | Dimension sets |
|---|---|---|---|
| `PipelineEventsObserved` | router | `PipelineEventObserved` | Pipeline / +Level / +State |
| `IntegrationSuccess` | router | `IntegrationUpdateSucceeded` | Pipeline / +Integration / +Mode |
| `IntegrationLatencyMillis` | router | success and failure | Pipeline / +Integration / +Mode |
| `IntegrationFailure` | router | `IntegrationUpdateFailed` | Pipeline / +Integration / +Mode |
| `IntegrationDuplicateSkipped` | router | `IntegrationUpdateSkipped` | Pipeline / +Integration / +Mode |
| `NotificationsPublished` | router | `NotificationPublished` | Pipeline / +Level / +State |
| `RouterProcessingFailure` | router | `RouterProcessingFailed` | Pipeline / +Level |
| `AnalysisCompleted` | analyzer | `AnalysisCompleted` | Pipeline / +AnalysisMode / +Confidence |
| `AnalysisDurationMillis` | analyzer | completed and failed | Pipeline / +AnalysisMode |
| `AnalysisDuplicateSkipped` | analyzer | `AnalysisSkippedDuplicate` | Pipeline |
| `AnalysisFailure` | analyzer | `AnalysisFailed` | Pipeline / +AnalysisMode |

`updateMessage` on `IntegrationUpdateSucceeded` is the exact text that would
land in a ServiceNow work note or Jira comment. In MOCK mode it is the whole
integration story, which is what makes the audit-trail panel worth showing.

---

## Grafana panels

Log group names below assume the console naming from
`02_CONSOLE_IMPLEMENTATION.md`. Replace `YOUR_PIPELINE_NAME`.

### Panel 1 — Stage and action progression (State timeline)

Data source: CloudWatch, query mode **Logs**, log group
`/aws/lambda/YOUR_PIPELINE_NAME-integration-router`.

```
fields @timestamp, coalesce(action, stage) as unit, State as status
| filter event = "PipelineEventObserved"
| filter Level in ["STAGE", "ACTION"]
| filter executionId = "$executionId"
| sort @timestamp asc
```

Visualization: **State timeline**, value field `status`. Add value mappings so
`SUCCEEDED` is green, `FAILED` red, `STARTED` amber.

### Panel 2 — ServiceNow / Jira audit trail (Table)

```
fields @timestamp, Integration, Mode, Level, State, stage, action, result, updateMessage
| filter event = "IntegrationUpdateSucceeded"
| filter executionId = "$executionId"
| sort @timestamp desc
| limit 50
```

Visualization: **Table**. This is the panel that replaces "let me show you a
CloudWatch log line."

### Panel 3 — AI failure analysis (Table)

Log group `/aws/lambda/YOUR_PIPELINE_NAME-failure-analyzer`.

```
fields @timestamp, failedStage, failedAction, provider, Confidence, AnalysisMode,
       summary, probableCause, recommendedActions, evidenceKey
| filter event = "AnalysisCompleted"
| filter executionId = "$executionId"
| sort @timestamp desc
| limit 10
```

Visualization: **Table**, or **Logs** if you prefer the prose to wrap. Label the
panel so the advisory boundary is explicit, per
`05_OPERATIONS_AND_SECURITY.md` — for example
`AI diagnostic (advisory — CentralQualityGate remains authoritative)`.

### Panel 4 — Integration outcome rate (Time series)

Data source: CloudWatch, query mode **Metrics**.

```
Namespace:  AppianDevOps/Sidecars
Metrics:    IntegrationSuccess, IntegrationFailure
Dimensions: Pipeline = YOUR_PIPELINE_NAME, Integration = *
Statistic:  Sum
Period:     60
```

Use two queries (A = success, B = failure) and a Math expression
`B/(A+B)*100` if you want a failure-percentage panel for Demo 7.

### Panel 5 — Sidecar health (Time series)

Metrics query, no Logs Insights needed:

- `AWS/Lambda` → `Errors`, `FunctionName` = each sidecar function, Sum
- `AWS/SQS` → `ApproximateNumberOfMessagesVisible` for both queues, Maximum
- `AppianDevOps/Sidecars` → `AnalysisDurationMillis`, p90

This is telemetry the Amplify dashboard had no equivalent for.

### The `$executionId` variable

Grafana's CloudWatch data source does **not** support Logs Insights results as
variable queries — variable support covers regions, namespaces, metric names,
dimension values, log groups and resource ARNs only.

Use a **Textbox** variable named `executionId` and paste the execution ID, or a
**Custom** variable if you want a fixed demo list. To browse without a variable,
drop the `executionId` filter line and rely on `sort @timestamp desc`.

---

## Console instruction delta

Against `02_CONSOLE_IMPLEMENTATION.md`.

### Unchanged

Checkpoints A, B, E and F are unaffected. You still need the evidence bucket,
the DynamoDB table (idempotency, not display), both SQS queues, the SNS topic,
the SSM routing parameter, both placeholder secrets, all three EventBridge
rules and the four alarms.

**IAM does not change.** EMF needs no `cloudwatch:PutMetricData`; writing to
stdout is already covered by the basic Lambda execution role. Both inline
policies in steps 13 and 17 stay exactly as written.

### Changed

**Steps 10 and 15 — upload the rebuilt zips.** The zips now contain two files,
`lambda_function.py` and `observability.py`. Rebuild before uploading:

```powershell
pwsh -File tools/build-deployment-packages.ps1
```

Handler stays `lambda_function.lambda_handler`.

**Step 12 — router environment variables.** Add:

```text
METRICS_NAMESPACE     AppianDevOps/Sidecars
METRICS_ENABLED       true
SIDECAR_COMPONENT     integration-router
```

**Step 16 — analyzer environment variables.** Add:

```text
METRICS_NAMESPACE     AppianDevOps/Sidecars
METRICS_ENABLED       true
SIDECAR_COMPONENT     failure-analyzer
```

`SIDECAR_COMPONENT` is optional — each handler defaults it correctly in code —
but setting it explicitly makes the console configuration self-documenting.

**Steps 11 and 15 — leave the log format as Text.** Under
**Configuration → Monitoring and operations tools → Logging configuration**,
do **not** switch to JSON. The handlers already write JSON to stdout. Setting
the function log format to JSON nests each line under a `message` string, which
breaks EMF extraction and forces every query above to be rewritten with a
`message.` prefix.

### New — set log group retention

The console guide never had this step and `05_OPERATIONS_AND_SECURITY.md` only
recommends it. It now matters, because these log groups are a Grafana data
source rather than throwaway diagnostics.

For each of `/aws/lambda/YOUR_PIPELINE_NAME-integration-router` and
`/aws/lambda/YOUR_PIPELINE_NAME-failure-analyzer`: open **CloudWatch → Log
groups**, choose the group, then **Actions → Edit retention setting** and set
30 days.

### New — Checkpoint I: Amazon Managed Grafana

1. Enable **IAM Identity Center** in the account and Region if it is not
   already on.
2. Open **Amazon Managed Grafana** → **Create workspace**. Authentication:
   **AWS IAM Identity Center**. Permission type: **Service managed**.
3. Under data sources, tick **Amazon CloudWatch**. The service-managed role
   then receives the CloudWatch metric and Logs Insights permissions it needs
   (`cloudwatch:ListMetrics`, `cloudwatch:GetMetricData`,
   `logs:DescribeLogGroups`, `logs:StartQuery`, `logs:StopQuery`,
   `logs:GetQueryResults`, `logs:GetLogGroupFields`, `tag:GetResources`).
4. Assign your Identity Center user to the workspace as **Admin**.
5. Open the workspace URL, sign in through Identity Center, then
   **Connections → Data sources → CloudWatch** and set the Region. Leave auth
   as the workspace IAM role.
6. Create the dashboard, add the `executionId` textbox variable, then build the
   five panels above.

The workspace has no public endpoint and no shared secret. Access is Identity
Center only.

### New — do not deploy the Amplify dashboard router

The `appian-amplify-eventbridge-dashboard` package ships its **own**
integration-router Lambda with an incompatible DynamoDB schema
(`executionId`/`eventKey` keys, `itemType` tagging). Both routers subscribe to
the same CodePipeline events and both write ServiceNow/Jira updates.

Running both produces duplicate ticket updates and two divergent tables. Deploy
only the sidecar router from this package. If the dashboard package is already
deployed, disable its EventBridge rule and delete its Lambda before the demo.

---

## Demo sequencing note

Grafana reads CloudWatch metrics and Logs Insights, both of which carry
ingestion and query latency of seconds. It is not a live-progress view.

Keep the **CodePipeline console** open for live stage progression — it is
native, needs no build, and is the authoritative view, which is a stronger
claim than a custom rendering. Cut to Grafana once the failure has landed, for
the integration audit trail and the RCA. That order is natural anyway, since
the analyzer only runs after a failure.

---

## Verifying emission before the demo

`tools/build-deployment-packages.ps1` rebuilds the zips and regenerates
`SHA256SUMS.txt`. To confirm EMF validity without deploying, run the emission
smoke test kept alongside the extracted package — it stubs boto3, runs both
handlers against the bundled sample events, and asserts that every emitted
document satisfies the EMF contract (numeric metric values, non-empty string
dimensions, epoch-millisecond timestamps).

After deploying, confirm extraction worked: **CloudWatch → Metrics → All
metrics → Custom namespaces → AppianDevOps/Sidecars**. If the namespace is
absent after a pipeline run, the log format was probably switched to JSON.
