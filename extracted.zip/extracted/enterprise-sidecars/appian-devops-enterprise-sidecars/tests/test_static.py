import ast
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_python_files_parse():
    for path in [
        ROOT / "backend/common/observability.py",
        ROOT / "backend/common/dashboard_signals.py",
        ROOT / "backend/integration-router/lambda_function.py",
        ROOT / "backend/failure-analyzer/lambda_function.py",
    ]:
        ast.parse(path.read_text())


def test_handlers_import_shared_observability():
    """Each zip is built with observability.py at its root, so the import is flat."""
    for path in [
        ROOT / "backend/integration-router/lambda_function.py",
        ROOT / "backend/failure-analyzer/lambda_function.py",
    ]:
        source = path.read_text()
        assert "import observability as obs" in source
        assert "obs.COMPONENT = " in source


def test_shared_modules_are_packaged_into_every_zip():
    """Anything under backend/common must be copied in by the build script.

    A shared module that is imported but not listed in $sharedModules is silently
    excluded from the zip and fails at import time in Lambda, so the build script is
    the invariant worth guarding rather than the import itself.
    """
    build_script = (ROOT / "tools/build-deployment-packages.ps1").read_text()
    for module in (ROOT / "backend/common").glob("*.py"):
        relative = f"backend/common/{module.name}"
        assert relative in build_script, f"{relative} is not copied into the zips"

    for path in [
        ROOT / "backend/integration-router/lambda_function.py",
        ROOT / "backend/failure-analyzer/lambda_function.py",
    ]:
        source = path.read_text()
        assert "import dashboard_signals" in source


def test_json_files_parse():
    paths = list((ROOT / "config").glob("*.json")) + list((ROOT / "infrastructure").glob("*.json")) + list((ROOT / "tests").glob("sample-*.json"))
    for path in paths:
        json.loads(path.read_text())


def test_failure_pattern_is_action_only():
    pattern = json.loads((ROOT / "infrastructure/event-pattern-failures.json").read_text())
    assert pattern["detail-type"] == ["CodePipeline Action Execution State Change"]
    assert pattern["detail"]["state"] == ["FAILED"]


def test_mock_defaults():
    config = json.loads((ROOT / "config/routing-config.example.json").read_text())
    assert config["integrations"]["servicenow"]["mode"] == "MOCK"
    assert config["integrations"]["jira"]["mode"] == "MOCK"
