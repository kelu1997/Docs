# CloudFormation

`official-demo-reference.yaml` is a **greenfield/reference stack** for the official demo architecture. It creates its own:

- source S3 bucket (versioned)
- artifact bucket
- CodePipeline V2 in QUEUED mode, stages `Source → SAST → DeployToTest → ValidateAndTest → CentralQualityGate`
- CodeBuild SAST project
- placeholder SonarQube token secret
- mock test adapter Lambda (Tosca functional regression plus load test)
- mock Appian adapter Lambda (package validation, unit tests, deploy to TEST)
- Step Functions Standard workflow
- central quality-gate Lambda
- IAM roles and 14-day log groups

The workflow definition in this template is generated from
`../step-functions/validate-and-test-mock-v2.asl.json`, and `../tools/validate_project.py`
asserts the two still match. Edit the ASL file, not the template.

## Do not use it to modify the pipeline you already built

Your current build is console-first. Follow `../docs/CONSOLE_IMPLEMENTATION.md` and reuse your existing Source/CodePipeline/Step Functions resources.

Use this template for one of three purposes:

1. client handoff / IaC reference;
2. a clean-room rebuild in a separate stack/account;
3. later consolidation once you intentionally decide to replace the manually-built demo with an IaC-managed version.

## Lambda code comes from S3

The three Lambdas are **not** inlined. CloudFormation caps inline `ZipFile` code at 4096
characters and every adapter is larger than that, so each function is sourced from S3.

Before creating the stack, package and upload each one:

```bash
for name in mock-tosca-adapter mock-appian-adapter central-quality-gate; do
  (cd "../lambdas/$name" && zip -q "/tmp/$name.zip" lambda_function.py)
  aws s3 cp "/tmp/$name.zip" "s3://YOUR_CODE_BUCKET/lambdas/$name.zip"
done
```

The ZIP must contain `lambda_function.py` at its root, because every function uses the
handler `lambda_function.lambda_handler`.

## Greenfield deployment

1. Package and upload the three Lambda ZIPs as above.
2. Open CloudFormation → Create stack → With new resources.
3. Upload `official-demo-reference.yaml`.
4. Set `LambdaCodeS3Bucket` to the bucket from step 1. Adjust the three key parameters only if you used different paths.
5. Set `ProjectName` if desired.
6. Leave Sonar URL/project defaults while using mock SAST.
7. Acknowledge IAM resource creation.
8. Create the stack.
9. Upload `../placeholder-source.zip` to the generated Source bucket using the stack output `SourceObjectKey`.
10. Open the created CodePipeline and choose Release change.
11. Use the test matrix in `../docs/DEMO_RUNBOOK.md`.

Before `SastMode=REAL`, update the generated Sonar secret and CodeBuild Sonar URL/project configuration.
