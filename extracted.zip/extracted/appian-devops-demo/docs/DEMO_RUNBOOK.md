# Demo runbook

Use **Release change** for every execution so the developer can set the V2 pipeline variables.

Stage order:

```text
Source → SAST → DeployToTest → ValidateAndTest → CentralQualityGate
```

## Normal happy-path demonstration

```text
ToscaTestSet         = REGRESSION_1
MockToscaOutcome     = PASS
MockAppianOutcome    = PASS
MockDeployOutcome    = PASS
LoadTestProfile      = BASELINE_LOAD
MockLoadTestOutcome  = PASS
SastMode             = MOCK_PASS
```

Expected:

```text
Source               SUCCEEDED
SAST                 SUCCEEDED  → SAST_STATUS=PASSED
DeployToTest         SUCCEEDED  → APPIAN_DEPLOYMENT_STATUS=COMPLETED
ValidateAndTest      SUCCEEDED  → Tosca=PASSED, LoadTest=PASSED
CentralQualityGate   SUCCEEDED
```

Central gate outputs should include:

```text
CENTRAL_GATE_STATUS=PASSED
SAST_STATUS=PASSED
DEPLOY_STATUS=COMPLETED
DEPLOY_ENVIRONMENT=TEST
PACKAGE_VALIDATION_STATUS=PASSED
APPIAN_UNIT_TEST_STATUS=PASSED
TOSCA_STATUS=PASSED
TOSCA_ADAPTER_MODE=MOCK
TOSCA_TEST_SET=REGRESSION_1
LOAD_TEST_STATUS=PASSED
LOAD_TEST_PROFILE=BASELINE_LOAD
LOAD_TEST_ADAPTER_MODE=MOCK
```

## Developer selects a different Tosca scope

```text
ToscaTestSet = REGRESSION_2
```

Verify Step Functions output:

```text
resolvedTestSet=REGRESSION_2
executionListKey=DEMO_REGRESSION_2
```

## AUTO demonstration

```text
ToscaTestSet=AUTO
```

Verify:

```text
requestedTestSet=AUTO
resolvedTestSet=FULL_REGRESSION
selectionMode=AUTO_SAFE_FALLBACK
selectionReason=NO_PACKAGE_IMPACT_DATA_FULL_REGRESSION_SELECTED
```

Explain that full regression is selected conservatively until real Appian package-impact metadata is available.

## Developer selects a different load profile

```text
LoadTestProfile = PEAK_LOAD
```

Verify the `loadTest` block in the Step Functions output:

```text
resolvedProfile=PEAK_LOAD
scenarioKey=DEMO_PEAK_LOAD
virtualUsers=250
durationSeconds=900
thresholds.p95Ms=3000
thresholds.errorRatePct=2.0
```

Compare against `SMOKE_LOAD` (10 users / 1500 ms) to show that the profile drives both
the load applied and the thresholds it is judged against.

## Tosca quality failure

```text
ToscaTestSet     = REGRESSION_1
MockToscaOutcome = FAIL
```

Expected:

```text
Source               SUCCEEDED
SAST                 SUCCEEDED
DeployToTest         SUCCEEDED
ValidateAndTest      SUCCEEDED
CentralQualityGate   FAILED
```

The Step Functions output must show:

```text
Tosca status=FAILED
failedTests=2
```

This proves the adapter itself executed successfully and the **central policy gate** rejected the quality result.

## Load-test failure

```text
MockLoadTestOutcome = FAIL
LoadTestProfile     = BASELINE_LOAD
```

Expected:

```text
Source               SUCCEEDED
SAST                 SUCCEEDED
DeployToTest         SUCCEEDED
ValidateAndTest      SUCCEEDED
CentralQualityGate   FAILED
```

The Step Functions `loadTest` block must show an observed p95 above the 2000 ms
threshold, an error rate above 1.0%, and a two-entry `breachSummary`. The central gate
failure message repeats those breaches, for example:

```text
Central quality gate FAILED: LoadTest=FAILED [p95 latency 2434ms exceeded threshold
2000ms; error rate 2.48% exceeded threshold 1.0%]
```

Point out that the verdict is computed from the observed metrics against the profile
thresholds, not asserted independently of them.

## SAST quality failure

```text
SastMode = MOCK_FAIL
```

Expected:

```text
Source               SUCCEEDED
SAST                 SUCCEEDED  → SAST_STATUS=FAILED
DeployToTest         SUCCEEDED
ValidateAndTest      SUCCEEDED
CentralQualityGate   FAILED
```

This demonstrates the same centralized policy behavior for SAST.

## Deploy failure

```text
MockDeployOutcome = FAIL
```

Expected:

```text
Source               SUCCEEDED
SAST                 SUCCEEDED
DeployToTest         FAILED
ValidateAndTest      (not started)
CentralQualityGate   (not started)
```

This is the one failure mode that is **not** routed to the central quality gate. A
deploy failure is an infrastructure/promotion failure, not a quality result: if the
package never reached TEST there is nothing to test, so the pipeline stops immediately.
Use this to explain why `DeployToTest` sits before the test stages.

## Invalid developer input

```text
ToscaTestSet=REGRESSION_99
```

or

```text
LoadTestProfile=PEAK_LOAD_99
```

Expected:

```text
ValidateAndTest=FAILED
```

These are configuration/orchestration failures, so the pipeline should stop before the central quality gate.

## What to say during the demo

- `DeployToTest` runs immediately after SAST, so every test stage exercises a genuinely deployed build rather than an inert artifact.
- Deploy failures stop the pipeline; quality failures are always routed to the central gate. Those are deliberately different paths.
- Package validation and Appian unit tests are mocked adapters with production-shaped contracts, not skipped placeholders.
- The Tosca adapter is mocked, but its asynchronous START/STATUS/RESULT contract is shaped so the real Tosca implementation replaces the adapter internals rather than the pipeline architecture.
- The load test follows the same asynchronous contract shape, so a real load generator drops into the same states.
- Load-test thresholds are per profile, and the PASS/FAIL verdict is computed from the observed metrics rather than asserted. The figures are illustrative demo values, not a measured capacity model for the client's Appian environment.
- `AUTO` currently widens to full regression rather than pretending package impact analysis exists.
- The central quality gate is already real and is the authoritative release-policy decision.
- SAST is a first-class stage. It can be switched from mock status to real SonarQube scanning without changing downstream gate wiring.
