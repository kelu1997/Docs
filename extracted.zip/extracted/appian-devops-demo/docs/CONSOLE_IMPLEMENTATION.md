# Console implementation — from the current checkpoint

## Starting assumption

You already have:

```text
S3 Source
   ↓
ValidateAndTest
   ↓
Temporary Step Functions workflow
```

Your package-validation placeholder currently succeeds and you do not yet have Appian connectivity.

The target for this build segment is:

```text
Source
   ↓
SAST
   ↓
DeployToTest                     mock Appian import into TEST
   ↓
ValidateAndTest                  runs against the deployed TEST build
   ├─ package validation         mock adapter
   ├─ Appian unit tests          mock adapter
   ├─ developer-selectable Tosca suite
   ├─ mock Tosca adapter START → STATUS → RESULT
   ├─ developer-selectable load profile
   └─ mock load adapter LOAD_START → LOAD_STATUS → LOAD_RESULT
   ↓
CentralQualityGate
   ↓
PASS / FAIL
```

`DeployToTest` is placed immediately after SAST so nothing downstream tests an
inert artifact. A deploy failure stops the pipeline at that stage; quality results
are always routed to `CentralQualityGate` instead.

---

# Part A — create the mock Tosca adapter

## A1. Create the Lambda

1. Open **AWS Lambda**.
2. Choose **Create function** → **Author from scratch**.
3. Function name: `appian-demo-mock-tosca-adapter`.
4. Runtime: **Python 3.14**.
5. Architecture: **x86_64**.
6. Create a new role with basic Lambda permissions.
7. Create the function.
8. Open `lambdas/mock-tosca-adapter/lambda_function.py` from this package.
9. Replace the contents of `lambda_function.py` in the console with that file.
10. Choose **Deploy**.
11. Set timeout to **30 seconds** and memory to **256 MB**.
12. Copy the function ARN.

No secrets, VPC, Appian permissions, Tosca permissions, or S3 permissions are needed for this mock.

This one function serves two contracts: functional regression (`START`/`STATUS`/`RESULT`)
and load testing (`LOAD_START`/`LOAD_STATUS`/`LOAD_RESULT`).

## A2. Test the adapter directly

Create these Lambda test events.

START:

```json
{
  "operation": "START",
  "pipelineExecutionId": "manual-001",
  "executionListKey": "DEMO_REGRESSION_1"
}
```

Expected: `status=RUNNING` and a `mock-tosca-...` execution ID.

STATUS (use the returned execution ID):

```json
{
  "operation": "STATUS",
  "executionId": "mock-tosca-example"
}
```

Expected: `status=COMPLETE`, `complete=true`.

RESULT pass:

```json
{
  "operation": "RESULT",
  "executionId": "mock-tosca-example",
  "mockOutcome": "PASS",
  "plannedTestCount": 8
}
```

Expected: `status=PASSED`, `failedTests=0`.

RESULT fail:

```json
{
  "operation": "RESULT",
  "executionId": "mock-tosca-example",
  "mockOutcome": "FAIL",
  "plannedTestCount": 8
}
```

Expected: `status=FAILED`, `failedTests=2`.

LOAD_START:

```json
{
  "operation": "LOAD_START",
  "pipelineExecutionId": "manual-001",
  "scenarioKey": "DEMO_BASELINE_LOAD",
  "virtualUsers": 50,
  "durationSeconds": 600
}
```

Expected: `status=RUNNING` and a `mock-load-...` execution ID.

LOAD_STATUS:

```json
{
  "operation": "LOAD_STATUS",
  "executionId": "mock-load-example"
}
```

Expected: `status=COMPLETE`, `complete=true`.

LOAD_RESULT pass:

```json
{
  "operation": "LOAD_RESULT",
  "executionId": "mock-load-example",
  "mockOutcome": "PASS",
  "virtualUsers": 50,
  "durationSeconds": 600,
  "p95ThresholdMs": 2000,
  "errorRateThresholdPct": 1.0
}
```

Expected: `status=PASSED`, `p95Ms` below 2000, `errorRatePct` below 1.0, and `breachSummary=[]`.

LOAD_RESULT fail: the same event with `"mockOutcome": "FAIL"`.

Expected: `status=FAILED`, `p95Ms` above 2000, and a two-entry `breachSummary` naming
the latency and error-rate breaches.

The status is computed by comparing the observed metrics against the supplied
thresholds rather than echoing `mockOutcome`, so the numbers on screen always agree
with the verdict.

---

# Part A2b — create the mock Appian adapter

## A2b.1 Create the Lambda

1. Open **Lambda** → **Create function** → **Author from scratch**.
2. Function name: `appian-demo-mock-appian-adapter`.
3. Runtime: **Python 3.14**, architecture **x86_64**.
4. Create a new role with basic Lambda permissions.
5. Replace `lambda_function.py` with `lambdas/mock-appian-adapter/lambda_function.py`.
6. **Deploy**, then set timeout **30 seconds** and memory **256 MB**.
7. Copy the function ARN.

This function serves three Step Functions operations (`VALIDATE_PACKAGE`,
`UNIT_TESTS_START`, `UNIT_TESTS_STATUS`, `UNIT_TESTS_RESULT`) and the `DeployToTest`
CodePipeline Lambda action.

## A2b.2 Allow it to report CodePipeline job results

Because the deploy operation runs as a CodePipeline Lambda action, it must report a
terminal job result. Add this inline policy to its execution role:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "ReportDeployJobResult",
      "Effect": "Allow",
      "Action": [
        "codepipeline:PutJobSuccessResult",
        "codepipeline:PutJobFailureResult"
      ],
      "Resource": "*"
    }
  ]
}
```

Policy name: `ReportDeployJobResult`.

Do not add a log statement that prints the full CodePipeline event.

## A2b.3 Direct-test the deploy operation

The deploy path expects a CodePipeline job envelope, so test it from the pipeline
rather than the Lambda console. The Step Functions operations can be tested directly:

```json
{
  "operation": "VALIDATE_PACKAGE",
  "pipelineExecutionId": "manual-001",
  "sourceVersion": "placeholder-version",
  "sourceETag": "placeholder-etag"
}
```

Expected: `status=PASSED` with a stable `packageSha256` and `objectCount`.

---

# Part B — update Step Functions

## B1. Give the Step Functions role permission to invoke the mock adapters

1. Open **Step Functions** → your existing state machine → **Details**.
2. Open its **Execution role** in IAM.
3. Add an inline policy:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "InvokeMockAdapters",
      "Effect": "Allow",
      "Action": "lambda:InvokeFunction",
      "Resource": [
        "YOUR_MOCK_TOSCA_LAMBDA_ARN",
        "YOUR_MOCK_APPIAN_LAMBDA_ARN"
      ]
    }
  ]
}
```

Policy name: `InvokeMockAdapters`.

## B2. Replace the state-machine definition

1. Open `step-functions/validate-and-test-mock-v2.asl.json`.
2. Replace every mock test adapter ARN with your `appian-demo-mock-tosca-adapter` ARN.
3. Replace every mock Appian adapter ARN with your `appian-demo-mock-appian-adapter` ARN.
4. Open your existing **Standard** state machine → **Edit** → **Code**.
5. Replace the complete current definition with the edited JSON.
6. Save.

Do not change the workflow to Express. The load-test poll loop assumes a Standard
workflow's execution duration.

## B3. Direct-test Step Functions

Use:

```json
{
  "pipelineExecutionId": "manual-sfn-001",
  "environment": "TEST",
  "sourceVersion": "placeholder-version",
  "sourceETag": "placeholder-etag",
  "deployedEnvironment": "TEST",
  "deploymentUuid": "manual-deploy-001",
  "toscaTestSet": "REGRESSION_1",
  "mockToscaOutcome": "PASS",
  "mockAppianOutcome": "PASS",
  "loadTestProfile": "BASELINE_LOAD",
  "mockLoadTestOutcome": "PASS"
}
```

Expected terminal status: **Succeeded**.

Expected output highlights:

```json
{
  "packageValidation": {"status": "PASSED"},
  "appianUnitTests": {"status": "PASSED"},
  "tosca": {
    "resolvedTestSet": "REGRESSION_1",
    "executionListKey": "DEMO_REGRESSION_1",
    "adapterMode": "MOCK",
    "status": "PASSED"
  },
  "loadTest": {
    "resolvedProfile": "BASELINE_LOAD",
    "scenarioKey": "DEMO_BASELINE_LOAD",
    "adapterMode": "MOCK",
    "status": "PASSED",
    "virtualUsers": 50,
    "breachSummary": []
  }
}
```

Repeat with:

- `REGRESSION_2`
- `FULL_REGRESSION`
- `AUTO` — must resolve to `FULL_REGRESSION`
- `mockToscaOutcome=FAIL` — state machine must still **Succeed**, while the output says `tosca.status=FAILED`
- `loadTestProfile=SMOKE_LOAD` and `PEAK_LOAD` — verify the virtual-user count and thresholds change
- `mockLoadTestOutcome=FAIL` — state machine must still **Succeed**, while `loadTest.status=FAILED` and `breachSummary` names the breached thresholds
- `environment=DEV` — still accepted, for direct console execution with no preceding deploy
- `loadTestProfile=PEAK_LOAD_99` — must **Fail** with `InvalidLoadTestProfile`

That last set of behaviors is deliberate: the adapters successfully reported a failed
quality result; the central quality gate will reject it.

---

# Part C — create the Central Quality Gate

## C1. Create Lambda

1. Open **Lambda** → **Create function**.
2. Name: `appian-demo-central-quality-gate`.
3. Runtime: **Python 3.14**.
4. Architecture: **x86_64**.
5. Create a new basic execution role.
6. Replace `lambda_function.py` with `lambdas/central-quality-gate/lambda_function.py`.
7. Deploy.
8. Set timeout to **30 seconds**, memory **256 MB**.
9. Copy the function ARN.

Do not add a log statement that prints the full CodePipeline event.

## C2. Central-gate Lambda IAM

Open its execution role and add:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "ReadValidationExecution",
      "Effect": "Allow",
      "Action": "states:DescribeExecution",
      "Resource": "arn:aws:states:YOUR_REGION:YOUR_ACCOUNT_ID:execution:YOUR_STATE_MACHINE_NAME:*"
    },
    {
      "Sid": "ReportPipelineResult",
      "Effect": "Allow",
      "Action": [
        "codepipeline:PutJobSuccessResult",
        "codepipeline:PutJobFailureResult"
      ],
      "Resource": "*"
    }
  ]
}
```

Name: `EvaluateCentralQualityGate`.

---

# Part D — create the SonarQube-ready SAST CodeBuild project

The stage can operate immediately in `MOCK_PASS`/`MOCK_FAIL` mode. When SonarQube connectivity exists, change the pipeline execution variable to `REAL`.

## D1. Create placeholder Sonar token secret

1. Open **Secrets Manager** → **Store a new secret**.
2. Secret type: **Other type of secret**.
3. Key/value:

```text
token = REPLACE_ME_BEFORE_REAL_SAST
```

4. Secret name: `appian-demo/sonarqube/token`.
5. Store it.
6. Copy the secret ARN.

## D2. Create CodeBuild project

1. Open **CodeBuild** → **Build projects** → **Create build project**.
2. Project name: `appian-demo-sast`.
3. Source provider: **CodePipeline**.
4. Environment:
   - Managed image
   - Operating system: Amazon Linux
   - Image: `aws/codebuild/amazonlinux-x86_64-standard:6.0` (5.0 is also supported)
   - Compute: small/general-purpose is sufficient for the demo
   - New service role
5. Buildspec: choose **Insert build commands** / buildspec editor and paste the complete contents of **one** of these, depending on what you want the SAST stage to do:

   | File | Use when | Publishes the dashboard SAST card? |
   |---|---|---|
   | `codebuild/sast/buildspec-mock.yml` | Demo mode. Deterministic PASSED/FAILED with severity counts. | **Yes**, in `post_build`, as soon as the scan finishes |
   | `codebuild/sast/buildspec.yml` | SonarQube connectivity exists and you want `SAST_MODE=REAL` to drive a real scan. | No |

   For the demo, paste **`buildspec-mock.yml`**. It is the only one that publishes the SAST
   card at the SAST step; with `buildspec.yml` the card stays on `WAITING` until the central
   quality gate publishes it at the very end of the pipeline, and then without severity
   counts. See Part E7 for the two options and which environment variables each needs.
6. Add project environment variables:

| Name | Value | Type |
|---|---|---|
| `SAST_MODE` | `MOCK_PASS` | Plaintext |
| `SONAR_HOST_URL` | `https://replace-me.invalid` | Plaintext |
| `SONAR_PROJECT_KEY` | `appian-devops-demo` | Plaintext |
| `SONAR_TOKEN` | `appian-demo/sonarqube/token:token` | Secrets Manager |

7. Create the project.

## D3. CodeBuild role permissions

Open the CodeBuild service role and add permission to read the Sonar token secret:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "secretsmanager:GetSecretValue",
      "Resource": "YOUR_SONAR_SECRET_ARN"
    }
  ]
}
```

The role also needs normal CodeBuild log permissions and access to the CodePipeline artifact bucket; the console-created CodeBuild role/pipeline integration normally establishes the baseline, but verify S3 access if the first build reports artifact AccessDenied.

### Dashboard publishing permission

If you pasted `buildspec-mock.yml`, its `post_build` phase calls `aws events put-events`, so
the **CodeBuild service role** needs its own `events:PutEvents`. This is separate from the
grant given to the gate Lambda in Part E7; they are different roles.

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "PublishDevOpsDashboardSignals",
      "Effect": "Allow",
      "Action": "events:PutEvents",
      "Resource": "arn:aws:events:REGION:ACCOUNT_ID:event-bus/default"
    }
  ]
}
```

Without it the build still succeeds and SAST still passes or fails correctly, because
publishing is best effort by design. The build log will say
`Dashboard SAST signal not published. Check events:PutEvents on the CodeBuild service role.`

### REAL mode later

Before selecting `REAL`:

1. Replace the placeholder token in Secrets Manager with a real SonarQube token.
2. Edit `SONAR_HOST_URL` and `SONAR_PROJECT_KEY`.
3. Ensure CodeBuild can reach the SonarQube server and `binaries.sonarsource.com` (or pre-stage the scanner if outbound internet is prohibited).
4. Ensure the pipeline artifact contains scan-compatible source.

A red Sonar quality gate becomes `SAST_STATUS=FAILED`; the build itself remains successful so the central gate can make the release decision. Scanner/network/compute-engine errors fail the SAST action directly.

---

# Part E — update CodePipeline

## E1. Pipeline properties

1. Open **CodePipeline** → your pipeline → **Edit**.
2. Pipeline type: **V2**.
3. Execution mode: **Queued**.

Queued execution is appropriate because every execution deploys into and tests against
the same shared TEST environment. Two concurrent executions would overwrite each
other's deployment and invalidate both test runs.

## E2. Pipeline variables

Create/verify:

| Name | Default |
|---|---|
| `ToscaTestSet` | `FULL_REGRESSION` |
| `MockToscaOutcome` | `PASS` |
| `MockAppianOutcome` | `PASS` |
| `MockDeployOutcome` | `PASS` |
| `LoadTestProfile` | `BASELINE_LOAD` |
| `MockLoadTestOutcome` | `PASS` |
| `SastMode` | `MOCK_PASS` |

Descriptions:

- Tosca: `Allowed: REGRESSION_1, REGRESSION_2, FULL_REGRESSION, AUTO`
- Mock Tosca outcome: `DEMO ONLY: PASS or FAIL`
- Mock Appian outcome: `DEMO ONLY: PASS or FAIL (Appian expression-rule tests)`
- Mock deploy outcome: `DEMO ONLY: PASS or FAIL (deploy to TEST)`
- Load profile: `Allowed: SMOKE_LOAD, BASELINE_LOAD, PEAK_LOAD`
- Mock load outcome: `DEMO ONLY: PASS or FAIL`
- SAST: `Allowed: MOCK_PASS, MOCK_FAIL, REAL`

## E3. Source action

1. Give the S3 source action the namespace `SourceVariables`.
2. Keep your existing bucket/object key.
3. Keep automatic change detection disabled for this demo so the developer can choose pipeline variables before **Release change**.
4. S3 bucket versioning should remain enabled.

This implementation uses only the consistently available S3 output variables:

```text
#{SourceVariables.VersionId}
#{SourceVariables.ETag}
```

The known bucket/object key are not needed until real package validation is added.

## E4. Add SAST stage

Add a stage immediately after Source:

```text
SAST
```

Add CodeBuild action:

| Field | Value |
|---|---|
| Action name | `RunSastScan` |
| Provider | AWS CodeBuild |
| Project | `appian-demo-sast` |
| Input artifact | `SourceArtifact` |
| Namespace | `SastVariables` |

In the action's environment-variable override, set:

```json
[
  {
    "name": "SAST_MODE",
    "value": "#{variables.SastMode}",
    "type": "PLAINTEXT"
  },
  {
    "name": "PIPELINE_NAME",
    "value": "appian-demo-pipeline",
    "type": "PLAINTEXT"
  },
  {
    "name": "PIPELINE_EXECUTION_ID",
    "value": "#{codepipeline.PipelineExecutionId}",
    "type": "PLAINTEXT"
  }
]
```

If the console presents individual rows instead of JSON, enter the same name/value/type as three rows.

`PIPELINE_NAME` and `PIPELINE_EXECUTION_ID` exist so `buildspec-mock.yml` can publish the
SAST card at the SAST step. Replace `appian-demo-pipeline` with your pipeline's exact name;
it must be byte-identical to the dashboard telemetry stack's `PipelineName` or the event is
filtered out with no error. Without both variables the buildspec logs
`Dashboard SAST signal skipped: PIPELINE_NAME/PIPELINE_EXECUTION_ID are not set on the SAST action.`
and the card stays on `WAITING` until the gate publishes it at the end of the run.

## E3b. Add UnitTests stage (optional, recommended)

A fast unit/smoke stage immediately after `Source` fails a broken build before anything is
scanned or deployed. Unlike the later quality stages, this one **blocks by default**: there
is no value in deploying to TEST when the unit suite is red.

### Create the CodeBuild project

1. **CodeBuild** → **Create build project**, name `appian-demo-unit-tests`.
2. Source provider: **CodePipeline**. Environment: same managed image as the SAST project.
3. Buildspec: **Insert build commands** and paste `codebuild/unit-tests/buildspec.yml`.
4. Project environment variables:

   | Name | Value | Notes |
   |---|---|---|
   | `UNIT_TEST_MODE` | `MOCK_PASS` | `MOCK_PASS`, `MOCK_FAIL` or `REAL` |
   | `UNIT_TEST_SUITE` | `Application unit and smoke tests` | Label shown on the dashboard card |
   | `UNIT_TEST_BLOCKING` | `true` | `false` defers the verdict to CentralQualityGate |

   For `REAL` mode also set `UNIT_TEST_COMMAND` (for example `pytest --junitxml=reports/results.xml`)
   and optionally `UNIT_TEST_REPORT_DIR` (default `reports`). The buildspec sums `tests`,
   `failures`, `errors` and `skipped` across every JUnit XML it finds there, counting errors
   as failures. A non-zero exit from the command is also treated as a failure, so a suite that
   crashes before writing a report still turns the stage red.

5. On the CodeBuild **service role**, add `events:PutEvents` on the default event bus, using
   the same policy as Part D3. Without it the tests still run and still gate correctly; only
   the dashboard card is skipped, and the build log says so.

### Add the pipeline stage

1. **CodePipeline** → **Edit** → add a stage between `Source` and `SAST`, named `UnitTests`.
2. Add a **CodeBuild** action:

   | Field | Value |
   |---|---|
   | Action name | `RunUnitTests` |
   | Project | `appian-demo-unit-tests` |
   | Input artifact | `SourceArtifact` |
   | Namespace | `UnitTestVariables` |

3. Environment-variable override:

```json
[
  {
    "name": "UNIT_TEST_MODE",
    "value": "#{variables.UnitTestMode}",
    "type": "PLAINTEXT"
  },
  {
    "name": "PIPELINE_NAME",
    "value": "appian-demo-pipeline",
    "type": "PLAINTEXT"
  },
  {
    "name": "PIPELINE_EXECUTION_ID",
    "value": "#{codepipeline.PipelineExecutionId}",
    "type": "PLAINTEXT"
  }
]
```

4. Add pipeline variable `UnitTestMode`, default `MOCK_PASS`, description
   `DEMO ONLY: MOCK_PASS, MOCK_FAIL or REAL`.

### Optional: let the gate record the result

Only useful when `UNIT_TEST_BLOCKING=false`, because a blocking failure stops the pipeline
before the gate runs. Add to the `EvaluateQualityGate` UserParameters:

```text
"unitTestStatus":"#{UnitTestVariables.UNIT_TEST_STATUS}"
```

The gate then contributes `UnitTests=<status>` to its failure reason and returns
`UNIT_TEST_STATUS` as an output variable. Omitting it defaults to `SKIPPED`, which the gate
tolerates.

### Nothing to change on the dashboard

The stage ribbon is generated from `GetPipeline`, so `UnitTests` appears in the ribbon and in
the per-stage timing tables automatically. The card on the Quality screen is driven by the
`unitTests` event category, which the buildspec publishes directly. `validate_project.py`
checks the CloudFormation reference rather than the live pipeline, so adding this stage in the
console does not break local validation.

---

## E4b. Add DeployToTest stage

Add a stage **immediately after `SAST`** and **before `ValidateAndTest`**:

```text
DeployToTest
```

Add an AWS Lambda action:

| Field | Value |
|---|---|
| Action name | `DeployPackageToTest` |
| Lambda | `appian-demo-mock-appian-adapter` |
| Input artifacts | none |
| Output artifacts | none |
| Namespace | `DeployTestVariables` |

User parameters:

```json
{"targetEnvironment":"TEST","releaseId":"#{codepipeline.PipelineExecutionId}","mockDeployOutcome":"#{variables.MockDeployOutcome}"}
```

This action exports:

```text
#{DeployTestVariables.APPIAN_TARGET_ENVIRONMENT}
#{DeployTestVariables.APPIAN_DEPLOYMENT_UUID}
#{DeployTestVariables.APPIAN_DEPLOYMENT_STATUS}
#{DeployTestVariables.APPIAN_OBSERVED_STATES}
```

Unlike the quality stages, `MockDeployOutcome=FAIL` fails **this stage** and stops the
pipeline. That is intentional: if the package never reached TEST, there is nothing for
the downstream stages to test, so there is no quality result for the central gate to
weigh.

## E5. Update ValidateAndTest action

Edit your existing Step Functions action.

Set namespace:

```text
ValidationTestVariables
```

State machine: your updated Standard state machine.

Input type: **Literal**.

Use this exact input:

```json
{"pipelineExecutionId":"#{codepipeline.PipelineExecutionId}","environment":"TEST","sourceVersion":"#{SourceVariables.VersionId}","sourceETag":"#{SourceVariables.ETag}","deployedEnvironment":"#{DeployTestVariables.APPIAN_TARGET_ENVIRONMENT}","deploymentUuid":"#{DeployTestVariables.APPIAN_DEPLOYMENT_UUID}","toscaTestSet":"#{variables.ToscaTestSet}","mockToscaOutcome":"#{variables.MockToscaOutcome}","mockAppianOutcome":"#{variables.MockAppianOutcome}","loadTestProfile":"#{variables.LoadTestProfile}","mockLoadTestOutcome":"#{variables.MockLoadTestOutcome}"}
```

`environment` is now `TEST` because `DeployToTest` has already promoted the package.
The workflow still accepts `DEV` so you can execute it directly from the Step
Functions console without a preceding deploy.

No Step Functions input artifact is required for this literal-input workflow.

## E6. Add CentralQualityGate stage

Add a stage after `ValidateAndTest`:

```text
CentralQualityGate
```

Add an AWS Lambda action:

| Field | Value |
|---|---|
| Action name | `EvaluateQualityGate` |
| Lambda | `appian-demo-central-quality-gate` |
| Input artifacts | none |
| Output artifacts | none |
| Namespace | `CentralGateVariables` |

User parameters (replace `appian-demo-pipeline` with your pipeline's exact name):

```json
{"validationExecutionArn":"#{ValidationTestVariables.ExecutionArn}","pipelineName":"appian-demo-pipeline","pipelineExecutionId":"#{codepipeline.PipelineExecutionId}","sastStatus":"#{SastVariables.SAST_STATUS}","sastMode":"#{SastVariables.SAST_MODE_USED}","sastDetail":"#{SastVariables.SAST_DETAIL}","deployStatus":"#{DeployTestVariables.APPIAN_DEPLOYMENT_STATUS}","deployEnvironment":"#{DeployTestVariables.APPIAN_TARGET_ENVIRONMENT}","deploymentUuid":"#{DeployTestVariables.APPIAN_DEPLOYMENT_UUID}","demoAllowSkippedChecks":"true","demoAllowMockedTosca":"true","demoAllowMockedLoadTest":"true"}
```

`pipelineName` and `pipelineExecutionId` exist only to correlate the dashboard's quality
signals. The Lambda-action event does not include `pipelineContext`, so they cannot be
derived at runtime and have to be passed here. Omitting them does not affect the
PASS/FAIL decision; it only leaves the dashboard's quality cards on `WAITING`.

Save the pipeline.

---

# Part E7 — Dashboard quality signals (optional)

Skip this part if you are not running the DevOps dashboard.

The dashboard seeds its **SAST**, **Automated tests** and **Central quality gate** cards to
`WAITING` and only replaces them when it receives a custom EventBridge event. The central
quality gate is the one place where every quality result for a run is available, so it
publishes all three. No new Lambda, no new file: the publisher is part of
`lambdas/central-quality-gate/lambda_function.py`.

Three things must line up or the cards stay on `WAITING`.

### 1. Grant `events:PutEvents`

Open the gate Lambda → **Configuration** → **Permissions** → click its execution role →
**Add permissions** → **Create inline policy** → JSON. Name it
`PublishDevOpsDashboardSignals`.

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "PublishDevOpsDashboardSignals",
      "Effect": "Allow",
      "Action": "events:PutEvents",
      "Resource": "arn:aws:events:REGION:ACCOUNT_ID:event-bus/default"
    }
  ]
}
```

Without it the gate logs `Dashboard signal for … not published: ClientError` and still
returns the correct PASS/FAIL. The release decision never depends on telemetry, so this
policy is safe to remove later to turn the signals off.

### 2. Set the event source

Gate Lambda → **Configuration** → **Environment variables**:

| Key | Value |
|---|---|
| `DASHBOARD_EVENT_SOURCE` | must equal the dashboard's `DashboardEventSource` (default `devops.pipeline.dashboard`) |

Leave it unset to accept the same default. `DASHBOARD_EVENT_BUS` defaults to `default` and
only needs setting if the dashboard listens on a custom bus.

### 3. Pass the correlation identifiers

The dashboard drops a quality event whose `executionId` does not match the execution on
screen, and its EventBridge rule filters on `detail.pipeline`. The CodePipeline
Lambda-action event does **not** include `pipelineContext`, so neither value can be read at
runtime — both have to come through user parameters. This is the `pipelineName` and
`pipelineExecutionId` pair already present in the E6 user parameters above.

Confirm `pipelineName` is byte-identical to the dashboard's `PipelineName`. A mismatch in
either the source or the pipeline name is a silent drop, with no error anywhere.

### Verifying

Run the pipeline, then open the gate Lambda's CloudWatch log group. Silence means all three
events were accepted. Every skip or rejection is logged with its reason:

```text
Dashboard signal skipped: no pipeline name available for detail.pipeline.
Dashboard signal skipped: no pipelineExecutionId available to correlate.
Dashboard signal for tests not published: ClientError: ... AccessDeniedException
Dashboard signal for tests rejected by EventBridge: {...}
```

Then confirm the cards leave `WAITING` on the dashboard.

### Who publishes the SAST card, and when

There are two valid arrangements. Pick one; running both blanks the severity counters.

**Option 1 — publish at the SAST step (recommended).** `buildspec-mock.yml` publishes the
card in `post_build`, so it populates minutes before the gate runs and carries the
Critical/High/Medium/Low counts it just produced. Requires all three of:

1. `buildspec-mock.yml` pasted into the CodeBuild project (Part D2).
2. `PIPELINE_NAME` and `PIPELINE_EXECUTION_ID` on the SAST action (Part E4).
3. `events:PutEvents` on the **CodeBuild service role** (Part D3).

Then set `PUBLISH_SAST_SIGNAL=false` on the gate Lambda so it does not republish the card
later without the counts.

**Option 2 — publish at the gate only.** Leave `PUBLISH_SAST_SIGNAL` unset. The card stays
on `WAITING` until the very end of the pipeline. Severity counters only appear if you also
pass `sastCritical`/`sastHigh`/`sastMedium`/`sastLow` through the gate's UserParameters from
`#{SastVariables.SAST_CRITICAL}` and friends.

### If the SAST card is not updating at the SAST step

Open the CodeBuild log for `RunSastScan` and look for exactly one of these lines. Each names
its own cause:

```text
Dashboard SAST signal published.                     -> working
Dashboard SAST signal skipped: PIPELINE_NAME/PIPELINE_EXECUTION_ID are not set on the SAST action.
Dashboard SAST signal skipped: could not build the event payload.
Dashboard SAST signal not published. Check events:PutEvents on the CodeBuild service role.
```

No line at all means the project is running `buildspec.yml`, which contains no publish step.
Re-paste `buildspec-mock.yml`.

If it says published but the card still does not move, the event was accepted by EventBridge
but discarded by the dashboard's rule. Check that `PIPELINE_NAME` is byte-identical to the
telemetry stack's `PipelineName`, and that `DASHBOARD_EVENT_SOURCE` matches the stack's
`DashboardEventSource` if you overrode it.

---

# Part F — CodePipeline service-role permissions

Open the existing CodePipeline service role and verify/add permissions for the four action providers.

Replace the ARNs below.

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "RunSastCodeBuild",
      "Effect": "Allow",
      "Action": [
        "codebuild:StartBuild",
        "codebuild:BatchGetBuilds"
      ],
      "Resource": "YOUR_CODEBUILD_PROJECT_ARN"
    },
    {
      "Sid": "RunValidationStateMachine",
      "Effect": "Allow",
      "Action": [
        "states:StartExecution",
        "states:DescribeStateMachine"
      ],
      "Resource": "YOUR_STATE_MACHINE_ARN"
    },
    {
      "Sid": "MonitorValidationStateMachine",
      "Effect": "Allow",
      "Action": "states:DescribeExecution",
      "Resource": "arn:aws:states:YOUR_REGION:YOUR_ACCOUNT_ID:execution:YOUR_STATE_MACHINE_NAME:*"
    },
    {
      "Sid": "InvokePipelineLambdaActions",
      "Effect": "Allow",
      "Action": "lambda:InvokeFunction",
      "Resource": [
        "YOUR_CENTRAL_GATE_LAMBDA_ARN",
        "YOUR_MOCK_APPIAN_LAMBDA_ARN"
      ]
    }
  ]
}
```

The mock Appian adapter ARN is required because `DeployToTest` invokes it as a
CodePipeline Lambda action.

Keep the existing S3/artifact-store permissions already used by your pipeline.

---

# Part G — upload the placeholder source

Use the provided `placeholder-source.zip`.

1. Open your source S3 bucket.
2. Upload `placeholder-source.zip` under the exact object key configured in the Source action.
3. If your source key has a different filename, rename the ZIP before upload; the contents do not matter yet.
4. Confirm a new S3 VersionId exists.

---

# Part H — run the checkpoint tests

Run the matrix in `DEMO_RUNBOOK.md`.

Minimum acceptance tests:

1. All defaults (`SastMode=MOCK_PASS`, `ToscaTestSet=REGRESSION_1`, `LoadTestProfile=BASELINE_LOAD`, every `Mock*Outcome=PASS`) → pipeline green, five stages green.
2. `REGRESSION_2` → verify resolved execution list changes.
3. `AUTO` → verify it resolves to `FULL_REGRESSION` with safe-fallback reason.
4. `MockToscaOutcome=FAIL` → SAST green, DeployToTest green, ValidateAndTest green, **CentralQualityGate red**.
5. `SastMode=MOCK_FAIL`, everything else PASS → SAST green, ValidateAndTest green, **CentralQualityGate red**.
6. `MockLoadTestOutcome=FAIL` → DeployToTest green, ValidateAndTest green, **CentralQualityGate red** with a `LoadTest=FAILED` message naming the breached thresholds.
7. `LoadTestProfile=PEAK_LOAD` → verify `loadTest.virtualUsers=250` and the wider 3000 ms / 2.0% thresholds in the workflow output.
8. `MockDeployOutcome=FAIL` → SAST green, **DeployToTest red**, and ValidateAndTest / CentralQualityGate never run.

Test 8 is the one that proves the new stage ordering matters: a failed deploy stops the
pipeline before any test stage, because there is nothing deployed to test.

At that point the official demo architecture is functioning end to end even though Appian-specific connectivity remains deferred.
