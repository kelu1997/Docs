# Replacement plan — mock to connected implementation

The point of the current package is that each deferred capability can be replaced independently.

## 1. Package validation

Current state:

```text
ValidatePackage (Lambda Task) → mock-appian-adapter VALIDATE_PACKAGE
```

The mock derives a stable digest and object count from the S3 object version identity.
Replace the adapter internals with the real Appian inspect call; the state machine does
not change.

The package validator can read the exact S3 object version selected by CodePipeline. The source bucket and object key are known deployment configuration; `SourceVariables.VersionId` is already carried through the workflow.

When real package validation is active, keep its central-gate result as `PASSED`/`FAILED` and eventually set `demoAllowSkippedChecks=false`.

## 1b. Deploy to TEST

Current state:

```text
DeployToTest stage → mock-appian-adapter DEPLOY (CodePipeline Lambda action)
```

The mock returns a deterministic deployment UUID and the state sequence a real import
passes through (`IN_PROGRESS,COMPLETED_AND_SYNCING,COMPLETED`) without a poll loop.

Replace with the real Appian import:

```text
Submit package import to TEST
   ↓
Poll deployment status
   ↓
Terminal? (treat COMPLETED_AND_SYNCING as non-terminal)
   ↓
put_job_success_result / put_job_failure_result
```

Keep the exported variable names (`APPIAN_TARGET_ENVIRONMENT`, `APPIAN_DEPLOYMENT_UUID`,
`APPIAN_DEPLOYMENT_STATUS`) so the `ValidateAndTest` input and the central-gate user
parameters do not change. Store the Appian import credentials in Secrets Manager and
grant access only to this adapter Lambda.

A real import can take longer than the Lambda timeout. If that happens, convert this
action to a Step Functions invoke or add a CodePipeline approval-style poll rather than
raising the Lambda timeout indefinitely.

Delete pipeline variable `MockDeployOutcome` when the real import is active.

## 2. Appian DEV unit tests

Current state:

```text
StartAppianUnitTests → WaitForAppianUnitTests → GetAppianUnitTestStatus
   → AreAppianUnitTestsComplete → GetAppianUnitTestResult
```

The poll loop is already the real shape. Replace the adapter internals with the
client-built Appian Web API calls:

```text
Start Appian rule tests
   ↓
Wait
   ↓
Poll status
   ↓
Retrieve result
```

Recommended adapter contract:

```json
{"operation":"UNIT_TESTS_START","environment":"TEST","pipelineExecutionId":"..."}
{"operation":"UNIT_TESTS_STATUS","testRunId":"..."}
{"operation":"UNIT_TESTS_RESULT","testRunId":"..."}
```

Store Appian API credentials in Secrets Manager and grant access only to the Appian adapter Lambda.

Delete pipeline variable `MockAppianOutcome` when the real API is active.

## 3. Tosca

Current implementation:

```text
Mock Tosca Lambda
START → STATUS → RESULT
```

Do **not** redesign the state machine. Replace the internals of `lambdas/mock-tosca-adapter/lambda_function.py` or deploy a new real adapter Lambda with the same contract.

Production-shaped request contract:

```json
{
  "operation": "START",
  "pipelineExecutionId": "...",
  "executionListKey": "REGRESSION_EXECUTION_LIST_ID"
}
```

Status:

```json
{
  "operation": "STATUS",
  "executionId": "external-run-id"
}
```

Result:

```json
{
  "operation": "RESULT",
  "executionId": "external-run-id"
}
```

Expected normalized result:

```json
{
  "adapterMode": "REAL",
  "status": "PASSED",
  "totalTests": 19,
  "passedTests": 19,
  "failedTests": 0
}
```

Delete pipeline variable `MockToscaOutcome` when the real adapter is active and set `demoAllowMockedTosca=false` in the central gate action.

## 3b. Load test

Current implementation:

```text
Mock load adapter (same Lambda as Tosca)
LOAD_START → LOAD_STATUS → LOAD_RESULT
```

Do **not** redesign the state machine. Replace the internals or deploy a real adapter
Lambda with the same contract, fronting whichever load generator the client standardizes
on (JMeter on Fargate, Gatling, k6, Tosca's load capability, or a managed service).

Request contract:

```json
{
  "operation": "LOAD_START",
  "pipelineExecutionId": "...",
  "scenarioKey": "DEMO_BASELINE_LOAD",
  "virtualUsers": 50,
  "durationSeconds": 600
}
```

```json
{"operation": "LOAD_STATUS", "executionId": "external-run-id"}
```

```json
{
  "operation": "LOAD_RESULT",
  "executionId": "external-run-id",
  "virtualUsers": 50,
  "durationSeconds": 600,
  "p95ThresholdMs": 2000,
  "errorRateThresholdPct": 1.0
}
```

Expected normalized result:

```json
{
  "adapterMode": "REAL",
  "status": "PASSED",
  "p95Ms": 1240,
  "avgMs": 595,
  "errorRatePct": 0.31,
  "throughputRps": 34.0,
  "totalRequests": 20400,
  "failedRequests": 63,
  "breachSummary": []
}
```

Two things matter when going real:

1. Keep computing `status` by comparing observed metrics against the supplied
   thresholds. The workflow passes thresholds in and expects the adapter to judge
   against them, so threshold policy stays in one place.
2. A real load run takes minutes. `IsLoadTestComplete` allows 120 polls at 3-second
   waits (about 6 minutes). Raise the poll ceiling or the `WaitForLoadTest` interval to
   match the real scenario duration, and keep the workflow **Standard**.

The profile values baked into `PrepareSmokeLoad` / `PrepareBaselineLoad` /
`PreparePeakLoad` are demo figures duplicated in `config/load-test-profiles.json`.
Replace them with numbers derived from the client's actual traffic before presenting any
of this as a capacity assessment.

Delete pipeline variable `MockLoadTestOutcome` when the real generator is active and set
`demoAllowMockedLoadTest=false` in the central gate action.

## 4. AUTO test selection

Current:

```text
AUTO → FULL_REGRESSION
```

Future:

```text
Appian package/change metadata
   ↓
Impact resolver
   ↓
Object/component-to-test mapping
   ↓
One or more Tosca execution lists
```

Unknown impact should widen scope rather than omit tests.

The included `config/tosca-test-map.json` is the starting point for externalizing suite metadata. It is not consumed dynamically by the current workflow.

## 5. SonarQube

Current CodeBuild buildspec already supports `REAL`.

To enable:

1. Put a real token in `appian-demo/sonarqube/token`.
2. Set the CodeBuild project's `SONAR_HOST_URL`.
3. Set `SONAR_PROJECT_KEY`.
4. Ensure networking from CodeBuild to SonarQube.
5. Ensure the input artifact contains source that SonarQube analyzers can meaningfully inspect.
6. Run with `SastMode=REAL`.

A red Sonar quality gate is normalized to `SAST_STATUS=FAILED` and is rejected by CentralQualityGate. A scanner/infrastructure error fails the SAST action directly.

## 6. Tighten the central gate

During the current mock phase:

```json
"demoAllowSkippedChecks":"true",
"demoAllowMockedTosca":"true",
"demoAllowMockedLoadTest":"true"
```

After the deploy, package validation, Appian tests, real Tosca, and a real load generator are connected:

```json
"demoAllowSkippedChecks":"false",
"demoAllowMockedTosca":"false",
"demoAllowMockedLoadTest":"false"
```

At that point the central gate requires every configured quality control to be genuinely passed.

## 7. Promotion beyond TEST

The mock deploy adapter already accepts `targetEnvironment=PROD`, but no PROD stage is
wired. When the client is ready, the shape is the same as `DeployToTest`:

```text
CentralQualityGate → ManualApproval → DeployToProd → smoke test
```

Reuse the same adapter and the same exported variable names. Do not let a PROD stage
bypass `CentralQualityGate`; the gate is what makes the promotion decision defensible.
