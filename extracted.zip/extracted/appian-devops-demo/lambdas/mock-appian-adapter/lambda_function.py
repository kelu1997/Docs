"""Mock Appian adapter for the Appian DevOps demo.

Covers the three Appian-side operations the demo previously skipped, plus a
mocked promotion deploy, using contracts shaped so the real implementation
replaces the adapter internals rather than the pipeline architecture.

Two invocation contexts are supported:

1. Step Functions (plain payload in / payload out)
       VALIDATE_PACKAGE
       UNIT_TESTS_START -> UNIT_TESTS_STATUS -> UNIT_TESTS_RESULT

2. CodePipeline Lambda action (CodePipeline.job event, UserParameters JSON)
       DEPLOY   - mocked Appian package import into a target environment

Everything is deterministic and derived from the inputs. No Appian connectivity,
no secrets, no VPC, and no outbound network access are required.

Do not log the complete CodePipeline event: it can contain temporary artifact
credentials.
"""

from __future__ import annotations

import hashlib
import json
from typing import Any, Dict, List

import boto3

codepipeline = boto3.client("codepipeline")

ADAPTER_MODE = "MOCK"

DIRECT_OPERATIONS = {
    "VALIDATE_PACKAGE",
    "UNIT_TESTS_START",
    "UNIT_TESTS_STATUS",
    "UNIT_TESTS_RESULT",
}
ALLOWED_OUTCOMES = {"PASS", "FAIL"}
ALLOWED_DEPLOY_ENVIRONMENTS = {"TEST", "PROD"}

# Plausible fixed scope for the mocked Appian expression-rule test run. Real
# scope will come from the client's Web API and cons!APPLICATIONS_TO_TEST.
UNIT_TEST_TOTAL = 24
UNIT_TEST_FAILURES_ON_FAIL = 2
UNIT_TEST_FAILURE_SUMMARY = [
    "ACME_getCustomerStatus: expected ACTIVE, returned null",
    "ACME_calculateRenewalDate: expected 2026-09-30, returned 2026-09-29",
]


def _require(source: Dict[str, Any], name: str) -> Any:
    value = source.get(name)
    if value is None or value == "":
        raise ValueError(f"Missing required field: {name}")
    return value


def _digest(*parts: str) -> str:
    seed = ":".join(str(part) for part in parts).encode("utf-8")
    return hashlib.sha256(seed).hexdigest()


def _deterministic_uuid(*parts: str) -> str:
    d = _digest(*parts)
    return f"{d[0:8]}-{d[8:12]}-{d[12:16]}-{d[16:20]}-{d[20:32]}"


# ---------------------------------------------------------------------------
# Step Functions operations
# ---------------------------------------------------------------------------


def _validate_package(event: Dict[str, Any]) -> Dict[str, Any]:
    """Mocked Appian package inspection.

    Real implementation reads the exact S3 object version CodePipeline selected
    and calls the Appian inspect endpoint. The mock derives a stable digest and
    object count from the source version identity so the same artifact always
    reports the same numbers.
    """
    pipeline_execution_id = str(_require(event, "pipelineExecutionId"))
    source_version = str(_require(event, "sourceVersion"))
    source_etag = str(event.get("sourceETag") or "no-etag")

    digest = _digest(source_version, source_etag)
    object_count = int(digest[:4], 16) % 200 + 60

    return {
        "adapterMode": ADAPTER_MODE,
        "operation": "VALIDATE_PACKAGE",
        "pipelineExecutionId": pipeline_execution_id,
        "status": "PASSED",
        "packageSha256": digest,
        "sourceVersion": source_version,
        "objectCount": object_count,
        "inspectionId": _deterministic_uuid("inspect", source_version, source_etag),
    }


def _unit_tests_start(event: Dict[str, Any]) -> Dict[str, Any]:
    environment = str(_require(event, "environment")).upper()
    pipeline_execution_id = str(_require(event, "pipelineExecutionId"))
    return {
        "adapterMode": ADAPTER_MODE,
        "operation": "UNIT_TESTS_START",
        "environment": environment,
        "testRunId": _deterministic_uuid("ruletests", environment, pipeline_execution_id),
        "status": "RUNNING",
    }


def _unit_tests_status(event: Dict[str, Any]) -> Dict[str, Any]:
    # The mock completes on the first poll. The Step Functions poll loop is kept
    # so the real adapter can return IN PROGRESS until Appian finishes.
    test_run_id = str(_require(event, "testRunId"))
    return {
        "adapterMode": ADAPTER_MODE,
        "operation": "UNIT_TESTS_STATUS",
        "testRunId": test_run_id,
        "status": "COMPLETE",
        "complete": True,
    }


def _unit_tests_result(event: Dict[str, Any]) -> Dict[str, Any]:
    test_run_id = str(_require(event, "testRunId"))
    outcome = str(event.get("mockOutcome") or "PASS").upper()
    if outcome not in ALLOWED_OUTCOMES:
        raise ValueError("mockOutcome must be PASS or FAIL")

    failed = 0 if outcome == "PASS" else UNIT_TEST_FAILURES_ON_FAIL
    passed = UNIT_TEST_TOTAL - failed

    return {
        "adapterMode": ADAPTER_MODE,
        "operation": "UNIT_TESTS_RESULT",
        "testRunId": test_run_id,
        "status": "PASSED" if failed == 0 else "FAILED",
        "totalTests": UNIT_TEST_TOTAL,
        "passedTests": passed,
        "failedTests": failed,
        "failureSummary": UNIT_TEST_FAILURE_SUMMARY[:failed],
    }


def _handle_direct(event: Dict[str, Any]) -> Dict[str, Any]:
    operation = str(_require(event, "operation")).upper()
    if operation not in DIRECT_OPERATIONS:
        raise ValueError(f"Unsupported operation: {operation}")
    if operation == "VALIDATE_PACKAGE":
        return _validate_package(event)
    if operation == "UNIT_TESTS_START":
        return _unit_tests_start(event)
    if operation == "UNIT_TESTS_STATUS":
        return _unit_tests_status(event)
    return _unit_tests_result(event)


# ---------------------------------------------------------------------------
# CodePipeline Lambda action: mocked promotion deploy
# ---------------------------------------------------------------------------


def _mock_deploy(parameters: Dict[str, Any]) -> Dict[str, str]:
    target_environment = str(_require(parameters, "targetEnvironment")).upper()
    if target_environment not in ALLOWED_DEPLOY_ENVIRONMENTS:
        raise ValueError(
            f"targetEnvironment must be one of {sorted(ALLOWED_DEPLOY_ENVIRONMENTS)}"
        )

    release_id = str(parameters.get("releaseId") or "unknown-release")
    outcome = str(parameters.get("mockDeployOutcome") or "PASS").upper()
    if outcome not in ALLOWED_OUTCOMES:
        raise ValueError("mockDeployOutcome must be PASS or FAIL")

    deployment_uuid = _deterministic_uuid("deploy", target_environment, release_id)

    if outcome == "FAIL":
        raise RuntimeError(
            f"Appian import to {target_environment} reported FAILED "
            f"(deployment {deployment_uuid})."
        )

    # The real adapter polls until terminal and treats COMPLETED_AND_SYNCING as
    # non-terminal. The mock records the states it passed through so the
    # narrative survives without a poll loop.
    return {
        "APPIAN_ADAPTER_MODE": ADAPTER_MODE,
        "APPIAN_TARGET_ENVIRONMENT": target_environment,
        "APPIAN_DEPLOYMENT_UUID": deployment_uuid,
        "APPIAN_DEPLOYMENT_STATUS": "COMPLETED",
        "APPIAN_OBSERVED_STATES": "IN_PROGRESS,COMPLETED_AND_SYNCING,COMPLETED",
        "APPIAN_RELEASE_ID": release_id,
    }


def _get_user_parameters(job: Dict[str, Any]) -> Dict[str, Any]:
    raw = (
        job.get("data", {})
        .get("actionConfiguration", {})
        .get("configuration", {})
        .get("UserParameters", "{}")
    )
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValueError(f"UserParameters is not valid JSON: {exc}") from exc
    if not isinstance(parsed, dict):
        raise ValueError("UserParameters must be a JSON object")
    return parsed


def _handle_codepipeline(job: Dict[str, Any]) -> None:
    job_id = job.get("id")
    if not job_id:
        raise ValueError("CodePipeline job is missing its id")

    try:
        parameters = _get_user_parameters(job)
        output_variables = _mock_deploy(parameters)
        codepipeline.put_job_success_result(
            jobId=job_id,
            outputVariables=output_variables,
        )
    except Exception as exc:  # CodePipeline must receive a terminal result.
        codepipeline.put_job_failure_result(
            jobId=job_id,
            failureDetails={
                "type": "JobFailed",
                "message": f"Appian deployment failed: {type(exc).__name__}: {exc}"[:5000],
            },
        )


def lambda_handler(event: Dict[str, Any], context: Any) -> Any:
    job = event.get("CodePipeline.job") if isinstance(event, dict) else None
    if isinstance(job, dict):
        _handle_codepipeline(job)
        return None
    return _handle_direct(event)
