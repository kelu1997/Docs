"""Central release-quality gate for the Appian DevOps demo CodePipeline.

The Lambda is invoked as a CodePipeline Lambda action. It reads the completed
ValidateAndTest Step Functions execution, combines it with the SAST result and the
DeployToTest outcome, and reports one authoritative PASS/FAIL decision back to
CodePipeline.

It is also the single place where every quality result for a run is available, so it
publishes the dashboard's SAST / Automated tests / Central quality gate signals to
EventBridge on the way out. Those signals are strictly best effort: they are emitted
on both the pass and the fail path, and a telemetry failure is logged and ignored
rather than allowed to change the release decision.

Do not log the complete CodePipeline event: it can contain temporary artifact
credentials.
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import boto3
from botocore.exceptions import BotoCoreError, ClientError

stepfunctions = boto3.client("stepfunctions")
codepipeline = boto3.client("codepipeline")
events = boto3.client(
    "events",
    region_name=os.environ.get("DASHBOARD_EVENT_REGION") or os.environ.get("AWS_REGION"),
)


MAX_REPORTED_FAILURES = 5
MAX_DETAIL_CHARS = 800

# The gate reason is rendered as a single line on the dashboard card.
MAX_GATE_REASON_CHARS = 260

# The mocked and real Appian import both report COMPLETED rather than PASSED.
DEPLOY_SUCCESS_STATUSES = {"COMPLETED", "PASSED"}

# --- dashboard signal contract ---------------------------------------------------
# See DevOpsDashboardImplementation/telemetry/EVENT_CONTRACT.md. All four of these
# must line up or the dashboard silently discards the event:
#   Source              == the telemetry stack's DashboardEventSource
#   detail.pipeline     == the telemetry stack's PipelineName, exactly (rule filter)
#   detail.executionId  == the execution currently on screen
#   detail.category     in DASHBOARD_CATEGORIES, case sensitive
# detail.metrics is flattened onto the card by the telemetry Lambda, so the keys the
# UI reads (critical/high/medium/low/tool, passed/failed/skipped/total,
# decision/reason) belong inside metrics rather than at the top level of detail.
DASHBOARD_EVENT_SOURCE = os.environ.get("DASHBOARD_EVENT_SOURCE", "devops.pipeline.dashboard")
DASHBOARD_EVENT_BUS = os.environ.get("DASHBOARD_EVENT_BUS", "default")
DASHBOARD_DETAIL_TYPE = "DevOps Dashboard Signal"
DASHBOARD_CATEGORIES = frozenset({"sast", "unitTests", "tests", "load", "qualityGate"})

# The telemetry Lambda replaces quality.sast wholesale on each event, so when the SAST
# stage publishes its own card at scan time this gate must stay out of the way: a later
# publish here with no severity counts would blank the counters the scan already
# reported. Set PUBLISH_SAST_SIGNAL=false whenever the SAST buildspec publishes.
PUBLISH_SAST_SIGNAL = os.environ.get(
    "PUBLISH_SAST_SIGNAL", "true"
).strip().lower() not in {"false", "0", "no", "off"}

# detail.metrics string values are truncated to 300 characters by the telemetry
# Lambda. Truncating here keeps the published event and the rendered card identical.
MAX_METRIC_CHARS = 280

# The dashboard passes unrecognized statuses through to the UI, where they render as a
# neutral grey badge. Map this project's vocabulary onto the statuses the UI colours so
# a green run actually looks green.
DASHBOARD_STATUS_MAP = {
    "PASSED": "SUCCEEDED",
    "PASS": "SUCCEEDED",
    "OK": "SUCCEEDED",
    "COMPLETED": "SUCCEEDED",
    "SUCCEEDED": "SUCCEEDED",
    "SKIPPED": "PENDING",
    "NOT_RUN": "PENDING",
    "UNKNOWN": "PENDING",
    "FAILED": "FAILED",
    "FAIL": "FAILED",
    "ERROR": "FAILED",
}


def _bool(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def _bounded_detail(failures: Any) -> str:
    """Render failing items as a bounded suffix for the failure message.

    put_job_failure_result caps the message, so this is deliberately truncated
    rather than complete. The full list stays in the workflow output.
    """
    if not isinstance(failures, list) or not failures:
        return ""
    shown = [str(item) for item in failures[:MAX_REPORTED_FAILURES]]
    detail = "; ".join(shown)[:MAX_DETAIL_CHARS]
    omitted = len(failures) - len(shown)
    if omitted > 0:
        detail = f"{detail} (+{omitted} more)"
    return f" [{detail}]"


def _fail(job_id: str, message: str) -> None:
    codepipeline.put_job_failure_result(
        jobId=job_id,
        failureDetails={"type": "JobFailed", "message": message[:5000]},
    )


def _get_user_parameters(job: Dict[str, Any]) -> Dict[str, Any]:
    raw = (
        job.get("data", {})
        .get("actionConfiguration", {})
        .get("configuration", {})
        .get("UserParameters", "{}")
    )
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise ValueError(f"UserParameters is not valid JSON: {exc}") from exc
    if not isinstance(parsed, dict):
        raise ValueError("UserParameters must be a JSON object")
    return parsed


def _int(value: Any) -> int:
    """Coerce a workflow test count to an int, treating anything unusable as 0.

    Deferred stages report SKIPPED with the count keys absent, so a missing value is
    normal rather than exceptional.
    """
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def _dashboard_status(value: Any) -> str:
    """Map a project status onto a status the dashboard UI colours."""
    raw = str(value or "UNKNOWN").strip().upper().replace("-", "_").replace(" ", "_")
    return DASHBOARD_STATUS_MAP.get(raw, raw)


def _sanitize_metrics(metrics: Dict[str, Any]) -> Dict[str, Any]:
    """Drop empty values and bound string lengths.

    None is removed rather than published: the UI uses `?? '—'` fallbacks, and an
    explicit null renders as a bare em dash that looks like a broken metric.
    """
    clean: Dict[str, Any] = {}
    for key, value in (metrics or {}).items():
        if value is None:
            continue
        if isinstance(value, str):
            text = value.strip()
            if not text:
                continue
            clean[str(key)] = text[:MAX_METRIC_CHARS]
        else:
            clean[str(key)] = value
    return clean


def _publish_dashboard_signal(
    *,
    pipeline: str,
    execution_id: str,
    category: str,
    status: str,
    metrics: Dict[str, Any],
    stage: Optional[str] = None,
    title: Optional[str] = None,
    message: Optional[str] = None,
) -> bool:
    """Publish one quality signal to EventBridge. Returns True when it was accepted.

    Never raises. This is a release gate: a dashboard telemetry problem must not be
    able to change a PASS/FAIL decision, so every failure path is logged and
    swallowed. Missing configuration is skipped with a reason rather than retried,
    because none of these conditions can resolve themselves mid-execution.
    """
    if category not in DASHBOARD_CATEGORIES:
        print(
            f"Dashboard signal skipped: category {category!r} is not one of "
            f"{sorted(DASHBOARD_CATEGORIES)} and would be discarded by the dashboard."
        )
        return False

    if not pipeline:
        # The dashboard's EventBridge rule filters on detail.pipeline, so an event
        # without it is never delivered. Skip rather than pay for a call that cannot
        # match any rule.
        print("Dashboard signal skipped: no pipeline name available for detail.pipeline.")
        return False

    if not execution_id:
        # quality events are correlated on executionId and dropped when it does not
        # match the execution on screen; a missing value is guaranteed to be dropped.
        print("Dashboard signal skipped: no pipelineExecutionId available to correlate.")
        return False

    detail = {
        "pipeline": pipeline,
        "executionId": execution_id,
        "kind": "quality",
        "category": category,
        "status": _dashboard_status(status),
        "stage": stage,
        "metrics": _sanitize_metrics(metrics),
        "title": title,
        "message": message,
        "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    }
    detail = {k: v for k, v in detail.items() if v is not None}

    try:
        response = events.put_events(
            Entries=[
                {
                    "Source": DASHBOARD_EVENT_SOURCE,
                    "DetailType": DASHBOARD_DETAIL_TYPE,
                    "Detail": json.dumps(detail),
                    "EventBusName": DASHBOARD_EVENT_BUS,
                }
            ]
        )
    except (BotoCoreError, ClientError) as exc:
        # Most likely cause: the execution role is missing events:PutEvents.
        print(f"Dashboard signal for {category} not published: {type(exc).__name__}: {exc}")
        return False

    if response.get("FailedEntryCount"):
        entries = response.get("Entries") or [{}]
        print(f"Dashboard signal for {category} rejected by EventBridge: {entries[0]}")
        return False

    return True


def _publish_sast_signal(
    pipeline: str,
    execution_id: str,
    status: str,
    mode: str,
    detail: str,
    tool: str = "",
    severities: Optional[Dict[str, Any]] = None,
) -> None:
    """Publish the SAST card.

    Skipped entirely when PUBLISH_SAST_SIGNAL is false, which is the correct setting
    once the SAST buildspec publishes its own card at scan time. Severity counts come
    from the buildspec's exported-variables via this action's UserParameters; any count
    the buildspec does not export is omitted rather than sent as 0, so the card shows an
    em dash for "not measured" instead of claiming a confident zero.
    """
    if not PUBLISH_SAST_SIGNAL:
        print("SAST dashboard signal skipped: PUBLISH_SAST_SIGNAL is disabled "
              "(the SAST stage publishes its own card).")
        return

    metrics: Dict[str, Any] = {
        # SAST_TOOL when the buildspec exports it, else the product name. The adapter
        # mode is deliberately not appended here: this string renders on the client
        # facing SAST card. The authoritative mode is still returned to CodePipeline as
        # the SAST_MODE output variable and logged, so it stays auditable.
        "tool": tool or "SonarQube",
        "detail": detail,
    }
    for name in ("critical", "high", "medium", "low"):
        raw = (severities or {}).get(name)
        if raw is None or str(raw).strip() == "":
            continue
        metrics[name] = _int(raw)

    findings = sum(metrics.get(n, 0) for n in ("critical", "high", "medium", "low"))
    print(f"SAST dashboard signal: status={status} mode={mode} detail={detail}")
    message = f"Static analysis completed: {detail}"
    if any(n in metrics for n in ("critical", "high", "medium", "low")):
        message = f"{message} ({findings} findings)"

    _publish_dashboard_signal(
        pipeline=pipeline,
        execution_id=execution_id,
        category="sast",
        status=status,
        stage="SAST",
        title=f"SAST {status}",
        message=message,
        metrics=metrics,
    )


def _publish_tests_signal(
    pipeline: str,
    execution_id: str,
    appian: Dict[str, Any],
    tosca: Dict[str, Any],
    load_test: Dict[str, Any],
    appian_status: str,
    tosca_status: str,
    load_status: str,
    load_profile: str,
) -> None:
    """Publish the Automated tests card.

    The dashboard has one tests card, so the Appian expression-rule run and the Tosca
    functional regression are aggregated into it. Load testing has no card of its own;
    its headline numbers ride along as extra metrics that land in the dashboard JSON
    (the current UI does not render them).
    """
    passed = _int(appian.get("passedTests")) + _int(tosca.get("passedTests"))
    failed = _int(appian.get("failedTests")) + _int(tosca.get("failedTests"))
    total = _int(appian.get("totalTests")) + _int(tosca.get("totalTests"))
    # The adapters report total/passed/failed only; anything unaccounted for is
    # surfaced as skipped rather than silently dropped from the pass-rate bar.
    skipped = max(0, total - passed - failed)

    frameworks = []
    if appian_status not in {"UNKNOWN", "SKIPPED"}:
        frameworks.append("Appian rule tests")
    if tosca_status not in {"UNKNOWN", "SKIPPED"}:
        frameworks.append("Tosca")
    framework = " + ".join(frameworks) if frameworks else "No functional suite ran"
    # The adapter mode is intentionally not appended to this label; it renders on the
    # client facing tests card. TOSCA_ADAPTER_MODE is still returned to CodePipeline.

    status = "FAILED" if (
        failed > 0
        # ERROR must count as a failure too: an AGENT_ERROR reports zero failed tests
        # because nothing ran, and a plain `failed > 0` check would call that a pass.
        or tosca_status not in {"PASSED", "SKIPPED", "UNKNOWN"}
        or appian_status not in {"PASSED", "SKIPPED", "UNKNOWN"}
    ) else "PASSED"

    metrics: Dict[str, Any] = {
        "passed": passed,
        "failed": failed,
        "skipped": skipped,
        "total": total,
        "framework": framework,
        "toscaTestSet": str(tosca.get("resolvedTestSet") or "UNKNOWN"),
    }

    _publish_dashboard_signal(
        pipeline=pipeline,
        execution_id=execution_id,
        category="tests",
        status=status,
        stage="ValidateAndTest",
        title=f"Automated tests {status}",
        message=f"{passed}/{total} passed via {framework}.",
        metrics=metrics,
    )


def _publish_load_signal(
    pipeline: str,
    execution_id: str,
    load_test: Dict[str, Any],
    load_status: str,
    load_profile: str,
) -> None:
    """Publish the Load and performance card.

    Load testing has its own card rather than riding along on the tests card: its
    numbers are latency and throughput against thresholds, not pass/fail counts, and
    aggregating them into a pass-rate bar misrepresents both.
    """
    if not load_test:
        return

    observed = load_test.get("observed") or {}
    thresholds = load_test.get("thresholds") or {}
    breaches = load_test.get("breachSummary") or []

    metrics: Dict[str, Any] = {
        "profile": load_profile,
        "requestedProfile": str(load_test.get("requestedProfile") or ""),
        "scenarioKey": str(load_test.get("scenarioKey") or ""),
        "virtualUsers": load_test.get("virtualUsers"),
        "durationSeconds": load_test.get("durationSeconds"),
        "p95Ms": observed.get("p95Ms"),
        "avgMs": observed.get("avgMs"),
        "errorRatePct": observed.get("errorRatePct"),
        "throughputRps": observed.get("throughputRps"),
        "totalRequests": observed.get("totalRequests"),
        "failedRequests": observed.get("failedRequests"),
        "p95ThresholdMs": thresholds.get("p95Ms"),
        "errorRateThresholdPct": thresholds.get("errorRatePct"),
    }
    if breaches:
        metrics["breaches"] = "; ".join(str(b) for b in breaches)

    message = (
        "; ".join(str(b) for b in breaches)
        if breaches
        else f"Load profile {load_profile} completed within its latency and error-rate thresholds."
    )

    _publish_dashboard_signal(
        pipeline=pipeline,
        execution_id=execution_id,
        category="load",
        status=load_status,
        stage="ValidateAndTest",
        title=f"Load test {load_status}",
        message=message,
        metrics=metrics,
    )


def _publish_gate_signal(
    pipeline: str,
    execution_id: str,
    decision: str,
    reason: str,
    extra_metrics: Optional[Dict[str, Any]] = None,
) -> None:
    """Publish the Central quality gate card.

    ``decision`` and ``reason`` must sit inside metrics: the telemetry Lambda flattens
    metrics onto the card, and the UI reads ``quality.qualityGate.decision`` /
    ``.reason``. Putting them at the top level of the detail leaves the card on its
    placeholder text.
    """
    metrics: Dict[str, Any] = {
        "decision": decision,
        "reason": reason[:MAX_GATE_REASON_CHARS],
    }
    if extra_metrics:
        metrics.update(extra_metrics)

    _publish_dashboard_signal(
        pipeline=pipeline,
        execution_id=execution_id,
        category="qualityGate",
        status="PASSED" if decision == "PASS" else "FAILED",
        stage="CentralQualityGate",
        title=f"Central quality gate {decision}",
        message=reason,
        metrics=metrics,
    )


def lambda_handler(event: Dict[str, Any], context: Any) -> None:
    job = event.get("CodePipeline.job")
    if not isinstance(job, dict) or not job.get("id"):
        raise ValueError("This Lambda must be invoked by a CodePipeline Lambda action")

    job_id = job["id"]

    try:
        parameters = _get_user_parameters(job)
        execution_arn = parameters["validationExecutionArn"]
        # Correlation identifiers for the dashboard. The CodePipeline Lambda-action
        # event does not carry pipelineContext, so both values have to be passed in
        # through UserParameters. Missing values only disable dashboard signals.
        pipeline_name = str(parameters.get("pipelineName") or "")
        pipeline_execution_id = str(parameters.get("pipelineExecutionId") or "")
        sast_status = str(parameters.get("sastStatus", "UNKNOWN")).upper()
        sast_mode = str(parameters.get("sastMode", "UNKNOWN")).upper()
        sast_detail = str(parameters.get("sastDetail", "UNSPECIFIED"))
        sast_tool = str(parameters.get("sastTool") or "")
        # Severity counts are optional: a buildspec that does not export them leaves the
        # corresponding counters blank on the dashboard rather than showing a false 0.
        sast_severities = {
            "critical": parameters.get("sastCritical"),
            "high": parameters.get("sastHigh"),
            "medium": parameters.get("sastMedium"),
            "low": parameters.get("sastLow"),
        }
        # DeployToTest runs before ValidateAndTest, so its result arrives as an
        # action variable rather than through the workflow output. A hard deploy
        # failure already fails its own stage; this is a consistency check.
        deploy_status = str(parameters.get("deployStatus") or "SKIPPED").upper()
        # Optional. A blocking unit/smoke stage fails its own stage and the gate never
        # runs, so this only carries a value when that stage is configured non-blocking
        # and defers its verdict here. Left empty when the parameter is absent, so the
        # check below is skipped entirely rather than treated as a SKIPPED result that
        # demoAllowSkippedChecks=false would then fail the gate on.
        unit_test_status = str(parameters.get("unitTestStatus") or "").upper()
        deploy_environment = str(parameters.get("deployEnvironment") or "NOT_RECORDED").upper()
        deployment_uuid = str(parameters.get("deploymentUuid") or "NOT_RECORDED")
        allow_skipped = _bool(parameters.get("demoAllowSkippedChecks"), default=True)
        allow_mocked_tosca = _bool(parameters.get("demoAllowMockedTosca"), default=True)
        allow_mocked_load_test = _bool(parameters.get("demoAllowMockedLoadTest"), default=True)

        execution = stepfunctions.describe_execution(executionArn=execution_arn)
        if execution.get("status") != "SUCCEEDED":
            workflow_status = execution.get("status", "UNKNOWN")
            reason = (
                "Central quality gate could not evaluate results because the "
                f"validation workflow status is {workflow_status}."
            )
            # No test data exists on this path, so only the gate card is published.
            # SAST already has a result and is worth showing alongside the red gate.
            _publish_sast_signal(
                pipeline_name, pipeline_execution_id, sast_status, sast_mode, sast_detail,
                sast_tool, sast_severities,
            )
            _publish_gate_signal(pipeline_name, pipeline_execution_id, "FAIL", reason)
            _fail(job_id, reason)
            return

        output = json.loads(execution.get("output") or "{}")
        package = output.get("packageValidation", {})
        appian = output.get("appianUnitTests", {})
        tosca = output.get("tosca", {})
        # Workflows built before the load-test stage existed omit this block
        # entirely; treat that as SKIPPED rather than UNKNOWN.
        load_test = output.get("loadTest", {})

        package_status = str(package.get("status", "UNKNOWN")).upper()
        appian_status = str(appian.get("status", "UNKNOWN")).upper()
        tosca_status = str(tosca.get("status", "UNKNOWN")).upper()
        tosca_mode = str(tosca.get("adapterMode", "UNKNOWN")).upper()
        tosca_test_set = str(tosca.get("resolvedTestSet", "UNKNOWN"))
        tosca_failures = tosca.get("failureSummary") or []
        load_status = str(load_test.get("status", "SKIPPED")).upper() if load_test else "SKIPPED"
        load_mode = str(load_test.get("adapterMode", "UNKNOWN")).upper() if load_test else "NONE"
        load_profile = str(load_test.get("resolvedProfile", "NONE")) if load_test else "NONE"
        load_breaches = load_test.get("breachSummary") or []

        failures: List[str] = []
        permitted_deferred = {"PASSED", "SKIPPED"} if allow_skipped else {"PASSED"}

        if sast_status not in permitted_deferred:
            failures.append(f"SAST={sast_status} ({sast_detail})")
        if deploy_status not in DEPLOY_SUCCESS_STATUSES | {"SKIPPED"}:
            failures.append(f"DeployToTest={deploy_status}")
        if unit_test_status and unit_test_status not in permitted_deferred:
            failures.append(f"UnitTests={unit_test_status}")
        if package_status not in permitted_deferred:
            failures.append(f"PackageValidation={package_status}")
        if appian_status not in permitted_deferred:
            failures.append(f"AppianUnitTests={appian_status}")
        if tosca_status != "PASSED":
            # Carry the failing test detail into the CodePipeline failure message so
            # downstream failure analysis sees more than a status code.
            failures.append(f"Tosca={tosca_status}{_bounded_detail(tosca_failures)}")
        if tosca_mode == "MOCK" and not allow_mocked_tosca:
            failures.append("Tosca adapter is still MOCK")
        if load_status not in permitted_deferred:
            # Threshold breaches are the actionable part of a load-test failure.
            failures.append(f"LoadTest={load_status}{_bounded_detail(load_breaches)}")
        if load_mode == "MOCK" and not allow_mocked_load_test:
            failures.append("Load-test adapter is still MOCK")

        # Publish before reporting the decision so the cards are already populated by
        # the time the stage turns red or green on the dashboard.
        _publish_sast_signal(
            pipeline_name, pipeline_execution_id, sast_status, sast_mode, sast_detail,
            sast_tool, sast_severities,
        )
        _publish_tests_signal(
            pipeline_name,
            pipeline_execution_id,
            appian,
            tosca,
            load_test,
            appian_status,
            tosca_status,
            load_status,
            load_profile,
        )
        _publish_load_signal(
            pipeline_name, pipeline_execution_id, load_test, load_status, load_profile,
        )

        if failures:
            message = "Central quality gate FAILED: " + "; ".join(failures)
            _publish_gate_signal(
                pipeline_name,
                pipeline_execution_id,
                "FAIL",
                "; ".join(failures),
                {"blockingChecks": len(failures)},
            )
            _fail(job_id, message)
            return

        _publish_gate_signal(
            pipeline_name,
            pipeline_execution_id,
            "PASS",
            "All required SAST, deployment, package, functional and load checks were satisfied.",
        )

        codepipeline.put_job_success_result(
            jobId=job_id,
            outputVariables={
                "CENTRAL_GATE_STATUS": "PASSED",
                "SAST_STATUS": sast_status,
                "SAST_MODE": sast_mode,
                "DEPLOY_STATUS": deploy_status,
                "DEPLOY_ENVIRONMENT": deploy_environment,
                "DEPLOYMENT_UUID": deployment_uuid,
                "PACKAGE_VALIDATION_STATUS": package_status,
                "UNIT_TEST_STATUS": unit_test_status or "NOT_REPORTED",
                "APPIAN_UNIT_TEST_STATUS": appian_status,
                "TOSCA_STATUS": tosca_status,
                "TOSCA_ADAPTER_MODE": tosca_mode,
                "TOSCA_TEST_SET": tosca_test_set,
                "LOAD_TEST_STATUS": load_status,
                "LOAD_TEST_PROFILE": load_profile,
                "LOAD_TEST_ADAPTER_MODE": load_mode,
            },
        )
    except Exception as exc:  # CodePipeline must receive a terminal result.
        _fail(job_id, f"Central quality gate evaluation error: {type(exc).__name__}: {exc}")
