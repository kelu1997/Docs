"""Mock external-test adapter for the Appian DevOps demo.

Two asynchronous test contracts live behind one adapter, because both are
"submit a run to an external test system, poll it, then collect a normalized
result". Replace the internals with real API calls later while retaining the
event/response shapes used by the Step Functions workflow.

Functional regression (Tosca):

    START -> STATUS -> RESULT

Non-functional load/performance:

    LOAD_START -> LOAD_STATUS -> LOAD_RESULT

Everything is deterministic and derived from the inputs. No Tosca connectivity,
no load-generator infrastructure, no secrets, and no outbound network access are
required.
"""

from __future__ import annotations

import hashlib
from typing import Any, Dict, List


FUNCTIONAL_OPERATIONS = {"START", "STATUS", "RESULT"}
LOAD_OPERATIONS = {"LOAD_START", "LOAD_STATUS", "LOAD_RESULT"}
ALLOWED_OPERATIONS = FUNCTIONAL_OPERATIONS | LOAD_OPERATIONS
ALLOWED_OUTCOMES = {"PASS", "FAIL"}

# Functional regression additionally supports an execution-infrastructure failure, which
# is a different story from tests failing: the DEX agent never accepted the TestEvent, so
# no test actually ran. Kept separate from ALLOWED_OUTCOMES because the load-test path
# only understands PASS/FAIL.
ALLOWED_FUNCTIONAL_OUTCOMES = {"PASS", "FAIL", "AGENT_ERROR"}

ADAPTER_MODE = "MOCK"

# Think time between requests for a single simulated virtual user. Only used to
# turn a virtual-user count into a plausible throughput figure.
MOCK_THINK_TIME_MS = 900


def _require(event: Dict[str, Any], name: str) -> Any:
    value = event.get(name)
    if value is None or value == "":
        raise ValueError(f"Missing required field: {name}")
    return value


def _positive_int(event: Dict[str, Any], name: str) -> int:
    value = int(_require(event, name))
    if value < 1:
        raise ValueError(f"{name} must be >= 1")
    return value


def _positive_number(event: Dict[str, Any], name: str) -> float:
    value = float(_require(event, name))
    if value <= 0:
        raise ValueError(f"{name} must be > 0")
    return value


def _execution_id(pipeline_execution_id: str, execution_list_key: str) -> str:
    seed = f"{pipeline_execution_id}:{execution_list_key}".encode("utf-8")
    digest = hashlib.sha256(seed).hexdigest()[:16]
    return f"mock-tosca-{digest}"


def _load_execution_id(pipeline_execution_id: str, scenario_key: str) -> str:
    seed = f"load:{pipeline_execution_id}:{scenario_key}".encode("utf-8")
    digest = hashlib.sha256(seed).hexdigest()[:16]
    return f"mock-load-{digest}"


def _jitter(execution_id: str, offset: int) -> float:
    """Stable pseudo-random value in [0, 1) derived from the execution identity.

    The same execution always reports the same numbers, so a rerun of the demo
    tells the same story.
    """
    digest = hashlib.sha256(execution_id.encode("utf-8")).hexdigest()
    return int(digest[offset : offset + 4], 16) / 65536.0


# ---------------------------------------------------------------------------
# Functional regression operations
# ---------------------------------------------------------------------------


def _functional(operation: str, event: Dict[str, Any]) -> Dict[str, Any]:
    if operation == "START":
        pipeline_execution_id = str(_require(event, "pipelineExecutionId"))
        execution_list_key = str(_require(event, "executionListKey"))
        return {
            "adapterMode": ADAPTER_MODE,
            "operation": "START",
            "executionId": _execution_id(pipeline_execution_id, execution_list_key),
            "executionListKey": execution_list_key,
            "status": "RUNNING",
        }

    execution_id = str(_require(event, "executionId"))

    if operation == "STATUS":
        # The mock completes on the first status poll. The Step Functions loop is
        # still present so the real adapter can return RUNNING until Tosca finishes.
        return {
            "adapterMode": ADAPTER_MODE,
            "operation": "STATUS",
            "executionId": execution_id,
            "status": "COMPLETE",
            "complete": True,
        }

    outcome = str(_require(event, "mockOutcome")).upper()
    if outcome not in ALLOWED_FUNCTIONAL_OUTCOMES:
        raise ValueError("mockOutcome must be PASS, FAIL or AGENT_ERROR")

    planned_test_count = _positive_int(event, "plannedTestCount")

    if outcome == "AGENT_ERROR":
        # Execution-infrastructure failure, not a test failure. Zero passed AND zero
        # failed against a non-zero planned count is what makes this distinguishable
        # from a functional regression: nothing ran, so there is no verdict to report.
        # Downstream failure analysis reads these strings, so they describe the agent
        # rather than the application.
        return {
            "adapterMode": ADAPTER_MODE,
            "operation": "RESULT",
            "executionId": execution_id,
            "status": "ERROR",
            "totalTests": planned_test_count,
            "passedTests": 0,
            "failedTests": 0,
            "executedTests": 0,
            "failureSummary": [
                "Tosca DEX agent did not accept the execution: no agent in pool "
                "DEX_POOL_APPIAN reported READY within the 300s dispatch window",
                f"TestEvent for {planned_test_count} planned test cases was never "
                "dispatched; the agent's last heartbeat was 14m before submission",
            ],
        }

    failed = 0 if outcome == "PASS" else min(2, planned_test_count)
    passed = planned_test_count - failed

    return {
        "adapterMode": ADAPTER_MODE,
        "operation": "RESULT",
        "executionId": execution_id,
        "status": "PASSED" if failed == 0 else "FAILED",
        "totalTests": planned_test_count,
        "passedTests": passed,
        "failedTests": failed,
        "failureSummary": [] if failed == 0 else [
            "TC-1042: Expense approval regression - expected approver role not applied",
            "TC-1187: Request detail view - required field validation not raised",
        ][:failed],
    }


# ---------------------------------------------------------------------------
# Load / performance operations
# ---------------------------------------------------------------------------


def _load_start(event: Dict[str, Any]) -> Dict[str, Any]:
    pipeline_execution_id = str(_require(event, "pipelineExecutionId"))
    scenario_key = str(_require(event, "scenarioKey"))
    virtual_users = _positive_int(event, "virtualUsers")
    duration_seconds = _positive_int(event, "durationSeconds")

    return {
        "adapterMode": ADAPTER_MODE,
        "operation": "LOAD_START",
        "executionId": _load_execution_id(pipeline_execution_id, scenario_key),
        "scenarioKey": scenario_key,
        "virtualUsers": virtual_users,
        "durationSeconds": duration_seconds,
        "status": "RUNNING",
    }


def _load_status(event: Dict[str, Any]) -> Dict[str, Any]:
    # The mock completes on the first poll. The Step Functions loop is retained so
    # a real load run can report RUNNING for its full ramp-up plus steady state.
    execution_id = str(_require(event, "executionId"))
    return {
        "adapterMode": ADAPTER_MODE,
        "operation": "LOAD_STATUS",
        "executionId": execution_id,
        "status": "COMPLETE",
        "complete": True,
    }


def _load_result(event: Dict[str, Any]) -> Dict[str, Any]:
    """Normalized load-test result with an honest threshold evaluation.

    `mockOutcome` only steers whether the simulated run lands under or over the
    supplied thresholds. The reported PASSED/FAILED status is then computed by
    actually comparing observed metrics against those thresholds, so the demo
    never claims a verdict its own numbers contradict.
    """
    execution_id = str(_require(event, "executionId"))
    outcome = str(_require(event, "mockOutcome")).upper()
    if outcome not in ALLOWED_OUTCOMES:
        raise ValueError("mockOutcome must be PASS or FAIL")

    virtual_users = _positive_int(event, "virtualUsers")
    duration_seconds = _positive_int(event, "durationSeconds")
    p95_threshold_ms = _positive_number(event, "p95ThresholdMs")
    error_rate_threshold_pct = _positive_number(event, "errorRateThresholdPct")

    latency_jitter = _jitter(execution_id, 0)
    error_jitter = _jitter(execution_id, 4)
    throughput_jitter = _jitter(execution_id, 8)

    if outcome == "PASS":
        p95_ms = p95_threshold_ms * (0.55 + 0.30 * latency_jitter)
        error_rate_pct = error_rate_threshold_pct * (0.05 + 0.35 * error_jitter)
    else:
        p95_ms = p95_threshold_ms * (1.15 + 0.30 * latency_jitter)
        error_rate_pct = error_rate_threshold_pct * (1.60 + 0.90 * error_jitter)

    p95_ms = int(round(p95_ms))
    error_rate_pct = round(error_rate_pct, 2)
    avg_ms = int(round(p95_ms * 0.48))

    seconds_per_request = (avg_ms + MOCK_THINK_TIME_MS) / 1000.0
    throughput_rps = round(
        virtual_users / seconds_per_request * (0.92 + 0.16 * throughput_jitter), 1
    )
    total_requests = int(round(throughput_rps * duration_seconds))
    failed_requests = int(round(total_requests * error_rate_pct / 100.0))

    breaches: List[str] = []
    if p95_ms > p95_threshold_ms:
        breaches.append(
            f"p95 latency {p95_ms}ms exceeded threshold {int(p95_threshold_ms)}ms"
        )
    if error_rate_pct > error_rate_threshold_pct:
        breaches.append(
            f"error rate {error_rate_pct}% exceeded threshold {error_rate_threshold_pct}%"
        )

    return {
        "adapterMode": ADAPTER_MODE,
        "operation": "LOAD_RESULT",
        "executionId": execution_id,
        "status": "FAILED" if breaches else "PASSED",
        "virtualUsers": virtual_users,
        "durationSeconds": duration_seconds,
        "p95ThresholdMs": int(p95_threshold_ms),
        "errorRateThresholdPct": error_rate_threshold_pct,
        "p95Ms": p95_ms,
        "avgMs": avg_ms,
        "errorRatePct": error_rate_pct,
        "throughputRps": throughput_rps,
        "totalRequests": total_requests,
        "failedRequests": failed_requests,
        "breachSummary": breaches,
    }


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    operation = str(_require(event, "operation")).upper()
    if operation not in ALLOWED_OPERATIONS:
        raise ValueError(f"Unsupported operation: {operation}")

    if operation in FUNCTIONAL_OPERATIONS:
        return _functional(operation, event)
    if operation == "LOAD_START":
        return _load_start(event)
    if operation == "LOAD_STATUS":
        return _load_status(event)
    return _load_result(event)
