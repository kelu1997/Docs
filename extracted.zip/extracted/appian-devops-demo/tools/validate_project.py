#!/usr/bin/env python3
"""Local consistency checks for the demo package (no AWS credentials required)."""

from __future__ import annotations

import json
import py_compile
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]

EXPECTED_STAGES = [
    "Source",
    "SAST",
    "DeployToTest",
    "ValidateAndTest",
    "CentralQualityGate",
]

EXPECTED_VARIABLES = {
    "ToscaTestSet",
    "MockToscaOutcome",
    "MockAppianOutcome",
    "MockDeployOutcome",
    "LoadTestProfile",
    "MockLoadTestOutcome",
    "SastMode",
}

# CloudFormation refuses inline Lambda code above this size.
CFN_ZIPFILE_LIMIT = 4096


class CfnLoader(yaml.SafeLoader):
    pass


def _cfn_tag(loader, tag_suffix, node):
    if isinstance(node, yaml.ScalarNode):
        return loader.construct_scalar(node)
    if isinstance(node, yaml.SequenceNode):
        return loader.construct_sequence(node)
    return loader.construct_mapping(node)


CfnLoader.add_multi_constructor("!", _cfn_tag)


def _transitions(state):
    targets = []
    if "Next" in state:
        targets.append(state["Next"])
    targets += [choice["Next"] for choice in state.get("Choices", [])]
    if "Default" in state:
        targets.append(state["Default"])
    targets += [catcher["Next"] for catcher in state.get("Catch", [])]
    return targets


def validate_state_machine(definition, label) -> None:
    states = definition["States"]
    assert definition["StartAt"] in states, label

    for name, state in states.items():
        for target in _transitions(state):
            assert target in states, (label, name, target)

    reachable = set()
    pending = [definition["StartAt"]]
    while pending:
        name = pending.pop()
        if name in reachable:
            continue
        reachable.add(name)
        pending.extend(_transitions(states[name]))
    unreachable = sorted(set(states) - reachable)
    assert not unreachable, (label, "unreachable states", unreachable)


def validate_load_test_states(definition, label) -> None:
    """The load test must run after functional regression and feed the output."""
    states = definition["States"]
    for required in (
        "ResolveLoadProfile",
        "PrepareSmokeLoad",
        "PrepareBaselineLoad",
        "PreparePeakLoad",
        "StartMockLoadTest",
        "WaitForLoadTest",
        "GetMockLoadTestStatus",
        "IsLoadTestComplete",
        "GetMockLoadTestResult",
        "LoadTestTimedOut",
        "LoadTestAdapterTechnicalFailure",
    ):
        assert required in states, (label, "missing state", required)

    assert states["GetMockToscaResult"]["Next"] == "ResolveLoadProfile", (
        label,
        "load test must run after the functional suite",
    )
    assert states["GetMockLoadTestResult"]["Next"] == "ValidationComplete", label

    output = states["ValidationComplete"]["Output"]
    assert "loadTest" in output, (label, "loadTest missing from workflow output")
    assert "deployment" in output, (label, "deployment missing from workflow output")

    # Every profile must supply both thresholds the adapter judges against.
    for profile in ("PrepareSmokeLoad", "PrepareBaselineLoad", "PreparePeakLoad"):
        assign = states[profile]["Assign"]
        for key in (
            "loadProfileResolved",
            "loadScenarioKey",
            "loadVirtualUsers",
            "loadDurationSeconds",
            "loadP95ThresholdMs",
            "loadErrorRateThresholdPct",
        ):
            assert key in assign, (label, profile, key)


def validate_profiles_match_workflow(definition) -> None:
    """config/load-test-profiles.json must not drift from the baked-in values."""
    profiles = json.loads((ROOT / "config/load-test-profiles.json").read_text())
    states = definition["States"]
    state_for = {
        "SMOKE_LOAD": "PrepareSmokeLoad",
        "BASELINE_LOAD": "PrepareBaselineLoad",
        "PEAK_LOAD": "PreparePeakLoad",
    }
    assert set(profiles) == set(state_for), sorted(profiles)
    for name, state_name in state_for.items():
        assign = states[state_name]["Assign"]
        profile = profiles[name]
        assert assign["loadProfileResolved"] == name, name
        assert assign["loadScenarioKey"] == profile["scenarioKey"], name
        assert assign["loadVirtualUsers"] == profile["virtualUsers"], name
        assert assign["loadDurationSeconds"] == profile["durationSeconds"], name
        assert assign["loadP95ThresholdMs"] == profile["p95ThresholdMs"], name
        assert (
            assign["loadErrorRateThresholdPct"] == profile["errorRateThresholdPct"]
        ), name


def validate_no_oversized_inline_code(raw_cfn: str) -> None:
    """Guard the pre-existing failure mode: inline Lambda code over 4096 chars."""
    lines = raw_cfn.split("\n")
    for i, line in enumerate(lines):
        if line.strip() != "ZipFile: |":
            continue
        body_indent = len(line) - len(line.lstrip()) + 2
        j, size = i + 1, 0
        while j < len(lines):
            ln = lines[j]
            if ln.strip() and len(ln) - len(ln.lstrip()) < body_indent:
                break
            size += len(ln[body_indent:]) + 1
            j += 1
        assert size <= CFN_ZIPFILE_LIMIT, (
            f"inline ZipFile at line {i + 1} is {size} chars, over the "
            f"{CFN_ZIPFILE_LIMIT} limit; source it from S3 instead"
        )


def main() -> None:
    v2_path = ROOT / "step-functions/validate-and-test-mock-v2.asl.json"
    v2 = json.loads(v2_path.read_text())
    validate_state_machine(v2, v2_path.name)
    validate_load_test_states(v2, v2_path.name)
    validate_profiles_match_workflow(v2)

    # The first-generation definition is superseded but must stay well formed.
    legacy_path = ROOT / "step-functions/validate-and-test-mock.asl.json"
    validate_state_machine(json.loads(legacy_path.read_text()), legacy_path.name)

    json.loads((ROOT / "config/tosca-test-map.json").read_text())

    py_compile.compile(str(ROOT / "lambdas/mock-tosca-adapter/lambda_function.py"), doraise=True)
    py_compile.compile(str(ROOT / "lambdas/mock-appian-adapter/lambda_function.py"), doraise=True)
    py_compile.compile(str(ROOT / "lambdas/central-quality-gate/lambda_function.py"), doraise=True)

    raw_cfn = (ROOT / "cloudformation/official-demo-reference.yaml").read_text()
    validate_no_oversized_inline_code(raw_cfn)
    cfn = yaml.load(raw_cfn, Loader=CfnLoader)

    pipeline = cfn["Resources"]["Pipeline"]["Properties"]
    assert pipeline["PipelineType"] == "V2"
    assert pipeline["ExecutionMode"] == "QUEUED"

    stages = [stage["Name"] for stage in pipeline["Stages"]]
    assert stages == EXPECTED_STAGES, stages
    # The whole point of the ordering: deploy before anything tests the build.
    assert stages.index("DeployToTest") == stages.index("SAST") + 1, stages
    assert stages.index("DeployToTest") < stages.index("ValidateAndTest"), stages

    variables = {v["Name"] for v in pipeline["Variables"]}
    assert variables == EXPECTED_VARIABLES, sorted(variables)

    deploy_action = pipeline["Stages"][stages.index("DeployToTest")]["Actions"][0]
    deploy_params = json.loads(deploy_action["Configuration"]["UserParameters"])
    assert deploy_params["targetEnvironment"] == "TEST", deploy_params

    validate_action = pipeline["Stages"][stages.index("ValidateAndTest")]["Actions"][0]
    workflow_input = json.loads(validate_action["Configuration"]["Input"])
    assert workflow_input["environment"] == "TEST", workflow_input
    for key in ("loadTestProfile", "mockLoadTestOutcome", "deployedEnvironment"):
        assert key in workflow_input, (key, workflow_input)

    gate_action = pipeline["Stages"][stages.index("CentralQualityGate")]["Actions"][0]
    gate_params = json.loads(gate_action["Configuration"]["UserParameters"])
    for key in ("deployStatus", "demoAllowMockedLoadTest"):
        assert key in gate_params, (key, gate_params)

    # The template's definition is generated from the ASL file; they must match.
    inlined = json.loads(
        cfn["Resources"]["ValidationStateMachine"]["Properties"]["DefinitionString"]
    )
    assert set(inlined["States"]) == set(v2["States"]), "CFN definition drifted from the ASL file"

    test_map = json.loads((ROOT / "config/tosca-test-map.json").read_text())
    assert test_map["AUTO"]["fallback"] == "FULL_REGRESSION"

    print("Local validation passed:")
    print("- JSON syntax, state transitions, and state reachability (both definitions)")
    print("- load-test states present, ordered after functional regression, and in the output")
    print("- load profiles match the values baked into the workflow")
    print("- Python syntax for all three Lambdas")
    print("- CloudFormation YAML syntax/basic structure")
    print("- no inline Lambda code over the 4096-character limit")
    print(f"- stage order: {' -> '.join(stages)}")
    print("- pipeline V2/QUEUED, variables, deploy target, and gate wiring")
    print("- CFN state-machine definition matches the ASL file")
    print("- AUTO fallback invariant")


if __name__ == "__main__":
    main()
