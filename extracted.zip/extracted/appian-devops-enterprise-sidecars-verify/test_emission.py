"""Functional smoke test for the EMF emission layer.

Stubs boto3 so both handlers can run locally against the bundled sample events,
then asserts that valid EMF documents reach stdout.
"""

import io
import json
import os
import sys
import types
from contextlib import redirect_stdout
from pathlib import Path

PKG = Path(__file__).resolve().parent.parent / "enterprise-sidecars" / "appian-devops-enterprise-sidecars"

ROUTING_CONFIG = json.loads((PKG / "config" / "routing-config.example.json").read_text())


class FakeClient:
    def __init__(self, service):
        self.service = service

    def get_parameter(self, **kwargs):
        return {"Parameter": {"Value": json.dumps(ROUTING_CONFIG)}}

    def get_item(self, **kwargs):
        return {}

    def put_item(self, **kwargs):
        return {}

    def put_object(self, **kwargs):
        return {}

    def publish(self, **kwargs):
        return {"MessageId": "fake"}

    def get_pipeline_execution(self, **kwargs):
        return {"pipelineExecution": {"variables": []}}

    def list_action_executions(self, **kwargs):
        return {
            "actionExecutionDetails": [
                {
                    "stageName": "CentralQualityGate",
                    "actionName": "EvaluateQualityGate",
                    "status": "Failed",
                    "input": {"actionTypeId": {"provider": "Lambda"}},
                    "output": {
                        "executionResult": {
                            "errorDetails": {
                                "code": "JobFailed",
                                "message": "Central quality gate FAILED: Tosca=FAILED",
                            }
                        },
                        "outputVariables": {},
                    },
                },
                {
                    "stageName": "SAST",
                    "actionName": "RunSastScan",
                    "status": "Succeeded",
                    "input": {"actionTypeId": {"provider": "CodeBuild"}, "namespace": "SastVariables"},
                    "output": {
                        "outputVariables": {
                            "SAST_STATUS": "FAILED",
                            "SAST_MODE_USED": "MOCK_FAIL",
                            "SAST_DETAIL": "MOCK_QUALITY_GATE_ERROR",
                        }
                    },
                },
            ]
        }

    def get_pipeline(self, **kwargs):
        return {
            "pipeline": {
                "stages": [
                    {
                        "name": "CentralQualityGate",
                        "actions": [
                            {
                                "name": "EvaluateQualityGate",
                                "configuration": {"FunctionName": "demo-central-quality-gate"},
                            }
                        ],
                    }
                ]
            }
        }

    def filter_log_events(self, **kwargs):
        return {"events": [{"message": "Central quality gate FAILED: Tosca=FAILED"}]}

    def put_events(self, **kwargs):
        return {"FailedEntryCount": 0}


def install_boto3_stub():
    boto3 = types.ModuleType("boto3")
    boto3.client = lambda service, *a, **k: FakeClient(service)
    boto3.resource = lambda service, *a, **k: FakeClient(service)
    sys.modules["boto3"] = boto3

    botocore = types.ModuleType("botocore")
    exceptions = types.ModuleType("botocore.exceptions")

    class ClientError(Exception):
        pass

    exceptions.ClientError = ClientError
    botocore.exceptions = exceptions
    sys.modules["botocore"] = botocore
    sys.modules["botocore.exceptions"] = exceptions


def load_handler(function_dir, module_alias):
    """Import a handler with the shared module importable, as the zip layout does."""
    sys.path.insert(0, str(PKG / "backend" / "common"))
    sys.path.insert(0, str(PKG / "backend" / function_dir))
    for stale in ("lambda_function", "observability"):
        sys.modules.pop(stale, None)
    import lambda_function

    sys.modules[module_alias] = lambda_function
    return lambda_function


def emf_documents(text):
    docs = []
    for line in text.splitlines():
        line = line.strip()
        if not line.startswith("{"):
            continue
        try:
            parsed = json.loads(line)
        except json.JSONDecodeError:
            continue
        if "_aws" in parsed:
            docs.append(parsed)
    return docs


def validate_emf(doc):
    """Assert the document satisfies the EMF contract CloudWatch enforces."""
    aws_node = doc["_aws"]
    assert isinstance(aws_node["Timestamp"], int), "Timestamp must be epoch millis"
    for directive in aws_node["CloudWatchMetrics"]:
        assert directive["Namespace"], "Namespace is required"
        assert directive["Metrics"], "at least one metric is required"
        for metric in directive["Metrics"]:
            name = metric["Name"]
            assert name in doc, f"metric {name} has no top-level value"
            assert isinstance(doc[name], (int, float)), f"metric {name} must be numeric"
        for dimension_set in directive["Dimensions"]:
            assert len(dimension_set) <= 30, "max 30 dimensions per set"
            for dimension in dimension_set:
                assert dimension in doc, f"dimension {dimension} has no value"
                assert isinstance(doc[dimension], str) and doc[dimension], "dimension values must be non-empty strings"


def main():
    os.environ.update(
        {
            "TABLE_NAME": "fake-table",
            "EVIDENCE_BUCKET": "fake-bucket",
            "ROUTING_PARAMETER": "/fake/routing",
            "NOTIFICATION_TOPIC_ARN": "arn:aws:sns:us-east-1:123456789012:fake",
            "BEDROCK_MODE": "MOCK",
            "METRICS_NAMESPACE": "AppianDevOps/Sidecars",
            "LOG_LEVEL": "INFO",
        }
    )
    install_boto3_stub()

    failures = []

    # ---- Integration Router against a stage-success event -------------------
    router = load_handler("integration-router", "router_module")
    event = json.loads((PKG / "tests" / "sample-stage-success.json").read_text())
    buffer = io.StringIO()
    with redirect_stdout(buffer):
        router.lambda_handler(event, None)
    docs = emf_documents(buffer.getvalue())
    events_seen = {d["event"] for d in docs}
    for doc in docs:
        validate_emf(doc)
    print(f"router emitted {len(docs)} EMF documents: {sorted(events_seen)}")
    for required in ("PipelineEventObserved", "IntegrationUpdateSucceeded"):
        if required not in events_seen:
            failures.append(f"router missing {required}")
    router_update = next((d for d in docs if d["event"] == "IntegrationUpdateSucceeded"), None)
    if router_update:
        for field in ("Pipeline", "Integration", "Mode", "executionId", "updateMessage"):
            if field not in router_update:
                failures.append(f"router IntegrationUpdateSucceeded missing {field}")
        if router_update.get("component") != "integration-router":
            failures.append("router component field incorrect")

    # ---- Failure Analyzer against an action-failure event -------------------
    sys.modules.pop("lambda_function", None)
    sys.modules.pop("observability", None)
    analyzer = load_handler("failure-analyzer", "analyzer_module")
    event = json.loads((PKG / "tests" / "sample-action-failure.json").read_text())
    buffer = io.StringIO()
    with redirect_stdout(buffer):
        result = analyzer.lambda_handler(event, None)
    docs = emf_documents(buffer.getvalue())
    events_seen = {d["event"] for d in docs}
    for doc in docs:
        validate_emf(doc)
    print(f"analyzer emitted {len(docs)} EMF documents: {sorted(events_seen)}")
    if "AnalysisCompleted" not in events_seen:
        failures.append("analyzer missing AnalysisCompleted")
    completed = next((d for d in docs if d["event"] == "AnalysisCompleted"), None)
    if completed:
        for field in ("Pipeline", "AnalysisMode", "Confidence", "summary", "probableCause", "recommendedActions", "evidenceKey", "AnalysisDurationMillis"):
            if field not in completed:
                failures.append(f"analyzer AnalysisCompleted missing {field}")
        if completed.get("failedAction") != "EvaluateQualityGate":
            failures.append("analyzer did not resolve the failed action")
        if completed.get("component") != "failure-analyzer":
            failures.append("analyzer component field incorrect")
    if not result.get("ok"):
        failures.append("analyzer did not return ok")

    print()
    if failures:
        for failure in failures:
            print("FAIL", failure)
        return 1
    print("PASS  emission layer verified for both handlers")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
