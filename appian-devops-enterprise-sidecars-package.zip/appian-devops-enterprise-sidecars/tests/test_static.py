import ast
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_python_files_parse():
    for path in [
        ROOT / "backend/integration-router/lambda_function.py",
        ROOT / "backend/failure-analyzer/lambda_function.py",
    ]:
        ast.parse(path.read_text())


def test_json_files_parse():
    paths = list((ROOT / "config").glob("*.json")) + list((ROOT / "infrastructure").glob("*.json")) + list((ROOT / "tests").glob("sample-*.json"))
    for path in paths:
        json.loads(path.read_text())


def test_failure_pattern_is_action_only():
    pattern = json.loads((ROOT / "infrastructure/event-pattern-failures.json").read_text())
    assert pattern["detail-type"] == ["CodePipeline Action Execution State Change"]
    assert pattern["detail"]["state"] == ["FAILED"]


def test_mock_defaults():
    config = json.loads((ROOT / "config/routing-config.example.json").read_text())
    assert config["integrations"]["servicenow"]["mode"] == "MOCK"
    assert config["integrations"]["jira"]["mode"] == "MOCK"
