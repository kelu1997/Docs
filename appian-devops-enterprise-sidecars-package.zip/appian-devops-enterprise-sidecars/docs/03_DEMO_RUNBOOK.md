# 03 — Demo Runbook

Use this after the console implementation is complete.

## Demo 1 — Non-blocking stage updates

Run the pipeline with passing mocks.

Expected CodePipeline:

```text
Source                SUCCEEDED
SAST                  SUCCEEDED
ValidateAndTest       SUCCEEDED
CentralQualityGate    SUCCEEDED
```

Then show that the pipeline has not gained extra blocking stages.

Open CloudWatch → Integration Router logs and show mock entries such as:

```text
MOCK ServiceNow update: ... stage=SAST ... state=SUCCEEDED
MOCK Jira update: ... stage=SAST ... state=SUCCEEDED
```

Talking point:

> Release execution remains focused on delivery and quality gating. Operational system synchronization happens asynchronously from CodePipeline state-change events.

## Demo 2 — Evidence trail

Open the evidence S3 bucket:

```text
executions/<pipeline>/<execution-id>/events/
```

Open one event JSON to show:

- pipeline execution ID
- level: pipeline/stage/action
- stage/action name
- state
- original EventBridge event

Talking point:

> Every execution can produce an auditable evidence trail without requiring each integration to be a pipeline stage.

## Demo 3 — ServiceNow/Jira routing configuration

Open Systems Manager Parameter Store and show:

```text
/devops/<pipeline>/sidecar-routing
```

Default routing uses:

```text
PIPELINE
STAGE
ANALYSIS
```

To demonstrate design flexibility, explain that adding:

```text
ACTION
```

causes action-level updates too, with no Lambda or CodePipeline change.

## Demo 4 — SAST quality failure

Start with the existing mock control:

```text
SastMode = MOCK_FAIL
```

Expected:

```text
SAST                  SUCCEEDED
CentralQualityGate    FAILED
```

The SAST action is green because it successfully reported a negative quality result. The central gate is red because release policy rejected that result.

Now open the Failure Analyzer logs/evidence.

It should capture the action execution information and upstream output variables, including values such as:

```text
SAST_STATUS=FAILED
SAST_MODE_USED=MOCK_FAIL
SAST_DETAIL=...
```

With `BEDROCK_MODE=MOCK`, the analyzer still generates the same structured RCA contract that the future real model will use.

## Demo 5 — Tosca quality failure

Run the existing Tosca mock failure path.

Expected again:

```text
ValidateAndTest       SUCCEEDED
CentralQualityGate    FAILED
```

The analyzer should see upstream Tosca output variables where the action exposes them, then create an RCA evidence file.

## Demo 6 — AI analysis routed back to SNOW/Jira

After any failed action:

```text
Failure Analyzer
   ↓
Failure Analysis Complete event
   ↓
EventBridge
   ↓
Integration Router
```

Show the Integration Router logs containing:

```text
AI analysis: ...
Recommended actions: ...
```

This is the mock ServiceNow/Jira comment payload.

## Demo 7 — Integration outage does not stop delivery

For a controlled test, temporarily edit the SSM routing config and set a real mode while keeping placeholder credentials, or otherwise force the Integration Router to fail.

Expected:

- Integration Router reports an error.
- Lambda retries asynchronously.
- failed processing eventually lands in the processing-failure queue if retries are exhausted.
- CodePipeline itself remains unaffected.

Restore routing mode to `MOCK` afterward.

## Demo 8 — Action-level updates

Edit the SSM config and change an integration from:

```json
"levels": ["PIPELINE", "STAGE", "ANALYSIS"]
```

to:

```json
"levels": ["PIPELINE", "STAGE", "ACTION", "ANALYSIS"]
```

Run the pipeline again.

You should now see mock ServiceNow/Jira updates for individual actions such as:

```text
RunSast
RunValidationAndTests
EvaluateQualityGate
```

No EventBridge rule, Lambda code, or CodePipeline definition changes are required.

## Demo 9 — Optional per-execution change/issue IDs

If you later add these pipeline variables:

```text
ServiceNowRecordSysId
JiraIssueKey
```

the router uses the resolved values for that execution rather than the fixed fallback IDs in Secrets Manager.

This lets a release execution update its own change request or Jira work item while credentials remain safely in Secrets Manager.
