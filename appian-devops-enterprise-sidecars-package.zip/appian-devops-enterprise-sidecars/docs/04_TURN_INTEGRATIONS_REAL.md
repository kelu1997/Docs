# 04 — Turning the Mock Integrations Real

Do this only after the mock architecture is stable.

---

# A. Real ServiceNow

The supplied adapter supports a straightforward ServiceNow Table API update of an existing record.

## Secret format

Update the ServiceNow Secrets Manager secret to real values:

```json
{
  "baseUrl": "https://your-instance.service-now.com",
  "username": "pipeline.integration.user",
  "password": "REPLACE_WITH_REAL_SECRET",
  "table": "change_request",
  "recordSysId": "fallback-sys-id",
  "field": "work_notes"
}
```

The router sends a `PATCH` request to:

```text
/api/now/table/<table>/<sys_id>
```

with a request body such as:

```json
{
  "work_notes": "Pipeline ... SAST SUCCEEDED ..."
}
```

The ServiceNow calling user must have the roles/ACL access required to update that record/table.

## Optional per-execution record

Add a CodePipeline pipeline variable:

```text
ServiceNowRecordSysId
```

If present, the execution's resolved value overrides the fallback secret `recordSysId`.

Do not put ServiceNow credentials in pipeline variables.

## Enable it

Edit the SSM routing parameter:

```json
"servicenow": {
  "enabled": true,
  "mode": "REAL"
}
```

Keep all other routing fields.

Run a controlled pipeline execution and verify the expected change record receives a work note.

If your client uses OAuth, a custom Scripted REST API, a MID Server, or a different change-management model, replace only `_send_servicenow()` in the Integration Router; the EventBridge architecture stays unchanged.

---

# B. Real Jira Cloud

The supplied adapter supports adding a Jira Cloud issue comment through REST API v3.

## Secret format

```json
{
  "baseUrl": "https://your-company.atlassian.net",
  "email": "pipeline-user@example.com",
  "apiToken": "REPLACE_WITH_REAL_TOKEN",
  "issueKey": "DEVOPS-123"
}
```

The router posts to:

```text
/rest/api/3/issue/<issueKey>/comment
```

using Atlassian Document Format for the comment body.

The Jira user/app must have permission to browse the project/issue and add comments.

## Optional per-execution issue

Add a CodePipeline pipeline variable:

```text
JiraIssueKey
```

When present, it overrides the fallback secret `issueKey`.

## Enable it

Change Jira routing mode in the SSM parameter:

```json
"mode": "REAL"
```

Run a controlled pipeline execution and verify comments appear.

If the client uses Jira Data Center, OAuth, Forge, a proxy, or a custom issue-correlation mechanism, replace only `_send_jira()`; the surrounding architecture stays the same.

---

# C. Real Amazon Bedrock failure analysis

The analyzer uses the Bedrock Runtime `Converse` API when:

```text
BEDROCK_MODE=REAL
```

## 1. Choose a model or inference profile

Use a model/inference profile supported in your account and Region.

Set the Failure Analyzer environment variable:

```text
BEDROCK_MODEL_ID=<model-or-inference-profile-id>
```

The package deliberately does not hard-code a particular foundation model so the architecture does not depend on a model name that may change or differ by Region/account.

## 2. IAM

The demo policy already includes:

```text
bedrock:InvokeModel
```

For production, restrict this from `Resource: *` to the exact model/inference profile resources your organization approves.

## 3. Switch mode

Failure Analyzer → **Configuration → Environment variables**:

```text
BEDROCK_MODE=REAL
```

Save.

## 4. Optional Bedrock Guardrail

The Lambda already performs application-side credential-pattern redaction before Bedrock.

For another layer, create a Bedrock Guardrail configured for the sensitive-information/content policies your organization wants. Create/publish a guardrail version and set:

```text
BEDROCK_GUARDRAIL_ID=<id-or-arn>
BEDROCK_GUARDRAIL_VERSION=<published-version>
```

The analyzer then supplies `guardrailConfig` with the Converse request.

## 5. Test

Force a known mock SAST/Tosca quality failure.

Inspect:

```text
S3 / executions/<pipeline>/<execution>/failures/
```

The resulting analysis should contain:

```json
{
  "summary": "...",
  "probableCause": "...",
  "failedComponent": "...",
  "evidence": ["..."],
  "recommendedActions": ["..."],
  "confidence": "HIGH|MEDIUM|LOW",
  "analysisMode": "BEDROCK"
}
```

## Guardrail / redaction principle

Do not treat a guardrail as the only secret-protection mechanism.

The intended order is:

```text
bounded failure evidence
      ↓
application-side redaction
      ↓
optional Bedrock Guardrail
      ↓
foundation model
```

---

# D. Private endpoints later

The current stack requires no customer-managed VPC.

If ServiceNow/Jira/other APIs are reachable only through private networking, VPC-attach the Integration Router and provide the required corporate routing/NAT/VPN/Direct Connect/proxy path.

The Failure Analyzer does not need to be VPC-attached unless its own dependencies require private networking.
