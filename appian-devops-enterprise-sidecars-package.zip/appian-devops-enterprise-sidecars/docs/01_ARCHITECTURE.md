# 01 — Architecture

## Objective

Add enterprise release-management and diagnostics capabilities without making them blocking CodePipeline stages.

Existing delivery path remains:

```text
Source → SAST → ValidateAndTest → CentralQualityGate
```

Sidecars observe it asynchronously:

```text
CodePipeline
    │
    ▼
EventBridge
    ├──────────────────────────────┐
    │                              │
    ▼                              ▼
Integration Router           Failure Analyzer
    │                              │
    ├─ ServiceNow                  ├─ CodePipeline action data
    ├─ Jira                        ├─ CodeBuild log excerpts
    ├─ SNS                         ├─ Step Functions history
    └─ S3 evidence                 ├─ Lambda log excerpts
                                   ├─ output variables from all actions
                                   ├─ redaction + truncation
                                   └─ Bedrock / mock RCA
                                          │
                                          ▼
                               Failure Analysis Complete
                                          │
                                          ▼
                                     EventBridge
                                          │
                                          ▼
                                  Integration Router
                              → SNOW / Jira / SNS / S3
```

## Why this is non-blocking

ServiceNow, Jira, notifications, evidence archiving and Bedrock are not actions inside CodePipeline. If one of them is unavailable, CodePipeline continues according to its own delivery and Central Quality Gate logic.

Failures in the observer layer are retained in SQS and surfaced through CloudWatch alarms instead of changing the release result.

## Event types

The observer subscribes to:

- `CodePipeline Pipeline Execution State Change`
- `CodePipeline Stage Execution State Change`
- `CodePipeline Action Execution State Change`

The failure analyzer subscribes only to:

- `CodePipeline Action Execution State Change` with `state=FAILED`

This avoids duplicate AI analyses for the same underlying failed action.

## Failure evidence strategy

The analyzer first calls CodePipeline `ListActionExecutions` for the failed pipeline execution. This gives it:

- failed action/provider
- error details
- external execution ID
- output variables from every action in the execution

That last item is important for this pipeline design. A Sonar or Tosca quality result may be reported successfully by an upstream action while `CentralQualityGate` is the action that actually fails. The analyzer therefore includes upstream variables such as:

```text
SAST_STATUS
SAST_MODE_USED
SAST_DETAIL
TOSCA_STATUS
TOSCA_TEST_SET
CENTRAL_GATE_STATUS
```

where available.

Provider-specific evidence is then collected when possible:

| Failed provider | Evidence source |
|---|---|
| CodeBuild | `BatchGetBuilds` + bounded CloudWatch log events |
| Step Functions | `GetExecutionHistory` for the Standard workflow |
| Lambda | bounded CloudWatch log events around the failure time |
| Other | CodePipeline error/external execution metadata |

## Bedrock boundary

Bedrock is diagnostic only. It does not participate in `CentralQualityGate` and never determines pipeline pass/fail.

Before model invocation:

1. evidence is bounded to a configurable size;
2. common credential/token patterns are redacted;
3. an optional Bedrock Guardrail can be applied;
4. the model is instructed to use only supplied evidence and return structured JSON.

Default deployment uses `BEDROCK_MODE=MOCK`, so no model access is required initially.

## Evidence archive

S3 layout:

```text
executions/
  <pipeline>/
    <pipeline-execution-id>/
      events/
        <event>.json
      failures/
        <failed-event-id>_analysis.json
```

The evidence bucket is private, encrypted, versioned and lifecycle-expired.

## DynamoDB responsibilities

One on-demand table is used for lightweight sidecar state:

- integration success/failure records
- duplicate suppression for successful outbound updates
- failure analysis results
- retention through TTL

Partition key:

```text
EventKey (String)
```

## Routing policy

SSM Parameter Store contains JSON configuration rather than hard-coding which events update ServiceNow/Jira.

Default:

```text
PIPELINE + STAGE + ANALYSIS
```

To update after every individual CodePipeline action too, add:

```text
ACTION
```

to each integration's `levels` list.

## Retry / failure layers

There are two intentionally separate queues:

### EventBridge delivery DLQ

Used if EventBridge cannot successfully deliver an event to its Lambda target after its retry policy.

### Lambda processing-failure queue

Used when EventBridge successfully hands the event to Lambda, but the Lambda continues to fail after asynchronous processing retries.

This distinction makes troubleshooting much clearer.

## Services used

- AWS CodePipeline — existing release pipeline
- Amazon EventBridge — event fabric
- AWS Lambda — integration router and failure analyzer
- Amazon Bedrock — optional real RCA
- Amazon S3 — evidence archive
- Amazon DynamoDB — idempotency/result state
- Amazon SNS — notifications
- Amazon SQS — failure retention/DLQs
- AWS Secrets Manager — ServiceNow/Jira credentials
- AWS Systems Manager Parameter Store — routing policy
- Amazon CloudWatch — logs, metrics and alarms
- AWS IAM — least-privilege permissions

No customer-managed VPC is required by default.
