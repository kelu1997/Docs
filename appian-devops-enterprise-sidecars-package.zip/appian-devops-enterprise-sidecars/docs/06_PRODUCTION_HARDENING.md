# 06 — Production Hardening Beyond the Demo

The supplied sidecar architecture is intentionally appropriate for the demo and a strong production starting point. The following items should be decided with the client's actual controls and integration contracts.

## 1. Reconciliation for guaranteed external-system completeness

CodePipeline service events delivered directly to EventBridge are documented as **best effort**.

For normal non-blocking operational updates, that is acceptable.

If the client requires a guarantee such as:

> Every completed action must eventually be reflected in ServiceNow/Jira.

add a scheduled reconciliation Lambda that periodically compares CodePipeline execution/action history with DynamoDB integration records and republishes any missing final-state updates.

Because the requirement is unknown today, the demo package does not add that extra polling component.

## 2. Ticket correlation strategy

The demo supports:

```text
ServiceNowRecordSysId
JiraIssueKey
```

as optional pipeline variables.

A production implementation may instead resolve tickets through:

- release metadata
- an Appian/package ID
- branch/release number
- ServiceNow change API lookup
- Jira issue lookup
- a dedicated release-correlation table

Choose one authoritative correlation model rather than relying on a fixed ticket ID.

## 3. Authentication

ServiceNow/Jira adapters currently support simple credential forms appropriate for proving the architecture.

Production may require:

- OAuth 2.0
- enterprise proxy
- ServiceNow OAuth/application registry
- Jira OAuth/app integration
- certificate-based outbound calls
- private endpoints or MID/proxy paths

These changes remain isolated inside the integration adapter functions.

## 4. KMS / retention

Apply the client's required KMS keys to:

- evidence S3 bucket
- SQS queues
- DynamoDB table
- Secrets Manager secrets
- SNS topic where required

Replace demo 30-day evidence retention with the client's release/audit retention policy.

## 5. Bedrock governance

Before real model invocation:

- select an organization-approved model or inference profile;
- restrict IAM to that resource;
- configure Bedrock Guardrails where appropriate;
- classify whether logs may contain PII/client data;
- define allowed evidence sources and maximum context size;
- record model ID, analysis timestamp and prompt/schema version with the evidence.

The current analyzer already records structured output and keeps the AI result advisory.

## 6. DLQ replay procedure

Define an operator procedure for:

```text
EventBridge delivery DLQ
processing-failure queue
```

A production implementation should include controlled replay tooling or an operations runbook rather than manually copying arbitrary SQS bodies into Lambda.

## 7. Observability

Consider adding metrics such as:

- ServiceNow update success/failure count
- Jira update success/failure count
- failure-analysis latency
- Bedrock invocation failure count
- processing DLQ depth
- EventBridge delivery DLQ depth
- evidence write failures

The current CloudWatch alarms cover the minimum functional health signals.

## 8. Cross-account / multi-pipeline architecture

If this evolves from one demo pipeline to many enterprise pipelines, move from pipeline-specific resources toward:

- central custom EventBridge bus
- resource/account-based event policies
- pipeline metadata registry
- shared integration adapters
- tenant/pipeline-aware routing configuration
- centralized evidence bucket prefixes and KMS policies

Do not prematurely introduce that complexity for the single-pipeline demo.
