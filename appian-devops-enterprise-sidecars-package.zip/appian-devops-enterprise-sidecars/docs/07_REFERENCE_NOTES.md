# 07 — Reference Notes

Implementation assumptions verified against current vendor documentation in September 2026:

- CodePipeline emits pipeline, stage and action execution state-change service events directly to EventBridge; delivery is best effort.
- `ListActionExecutions` exposes action execution details, error information, external execution identifiers and output variables.
- CodeBuild build details expose CloudWatch log group/stream information.
- Step Functions `GetExecutionHistory` can retrieve Standard workflow execution history (not Express workflows).
- Lambda asynchronous invocations can retry function errors and can use an on-failure destination such as SQS.
- Bedrock Runtime `Converse` accepts optional `guardrailConfig`.
- ServiceNow Table API supports PATCH of `/api/now/table/{table}/{sys_id}`.
- Jira Cloud REST API v3 supports adding issue comments at `/rest/api/3/issue/{issueIdOrKey}/comment`, with comment bodies supporting Atlassian Document Format.

Before production rollout, re-verify the exact client ServiceNow/Jira authentication model and the Bedrock model/inference profile approved in that AWS account/Region.
