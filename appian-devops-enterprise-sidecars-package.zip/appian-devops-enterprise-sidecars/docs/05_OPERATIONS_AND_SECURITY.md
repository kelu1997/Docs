# 05 — Operations and Security

## Pipeline safety

ServiceNow/Jira/Bedrock are observers, not release gates.

The authoritative delivery decision remains:

```text
CentralQualityGate
```

Never make Bedrock output automatically override a failed quality control.

## Secret handling

Credentials belong in Secrets Manager only.

Do not place credentials in:

- CodePipeline variables
- EventBridge events
- Lambda environment variables
- SSM routing JSON
- CloudWatch log messages
- S3 evidence objects

The analyzer contains regex redaction for common credential shapes, but prevention is stronger than redaction.

## Evidence minimization

The analyzer is intentionally bounded:

```text
MAX_LOG_EVENTS=120
MAX_CONTEXT_CHARS=45000
```

Do not send entire build logs to a model by default.

Evidence should be enough to diagnose the failing action, not a wholesale copy of the environment.

## S3

Recommended controls:

- Block Public Access: on
- encryption: on
- versioning: on
- lifecycle expiration: 30 days for demo; client retention policy for production
- access limited to DevOps/operator roles and the two sidecar Lambdas

If evidence may contain regulated data, use the client's required KMS key and bucket policy rather than SSE-S3.

## DynamoDB

The table stores small metadata/result records and uses TTL.

It is not intended as a permanent release database.

## EventBridge delivery

CodePipeline service events delivered directly to EventBridge are best-effort. The observer architecture is therefore suitable for operational synchronization and evidence enhancement, not for a required release authorization control.

Required controls belong in CodePipeline / the Central Quality Gate.

## Lambda retries

Both functions use asynchronous retry behavior plus a processing-failure SQS destination.

Operationally distinguish:

```text
EventBridge delivery DLQ
    EventBridge could not deliver to Lambda

Processing-failure queue
    Lambda received the event but could not complete processing
```

## Idempotency

Successful outbound integration calls are recorded in DynamoDB using the EventBridge event ID + integration name.

If Lambda retries because a different integration failed, already successful ServiceNow/Jira/SNS deliveries are skipped.

## CloudWatch alarms

Minimum alarms:

- Integration Router Lambda `Errors > 0`
- Failure Analyzer Lambda `Errors > 0`
- EventBridge delivery DLQ `ApproximateNumberOfMessagesVisible > 0`
- processing-failure queue `ApproximateNumberOfMessagesVisible > 0`

Route alarms to SNS or the organization's existing incident channel.

## CloudWatch log retention

Set both Lambda log groups to a finite retention period, for example:

```text
14 or 30 days
```

Do not retain demo logs indefinitely.

## CloudTrail

Use the organization's existing CloudTrail trail where present. CloudTrail provides AWS API auditability for administrative changes and sidecar API activity.

Do not create a duplicate organization-wide trail just for this demo unless required.

## IAM hardening before production

The package deliberately keeps a few discovery permissions broader while resources are not yet known:

- `codebuild:BatchGetBuilds`
- Bedrock model invocation

Once the client confirms exact CodeBuild projects, models/inference profiles, KMS keys and external integration design, scope those permissions down.

## ServiceNow/Jira authorization

Use dedicated least-privilege integration identities.

ServiceNow should have only the ACL/role access needed for the target change/record integration.

Jira should have only project/issue visibility and comment/update permissions required by the chosen workflow.

## Bedrock output handling

Treat generated RCA as advisory.

The UI/ticket text should clearly distinguish:

```text
Pipeline fact:
Central Quality Gate failed.

AI diagnostic:
Probable cause / recommended next actions.
```

This prevents a probabilistic model output from being confused with authoritative pipeline state.

## VPC

Default architecture is VPC-independent.

Only VPC-attach a Lambda when a real private endpoint requires it. Avoid introducing a VPC merely for architectural appearance; doing so adds networking, NAT/routing and operational dependencies without improving the demo.
