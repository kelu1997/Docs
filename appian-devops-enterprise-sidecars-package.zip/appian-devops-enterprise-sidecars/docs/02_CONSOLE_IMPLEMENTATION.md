# 02 — Console Implementation Guide

This is the recommended path for the current demo because the existing CodePipeline was built console-first.

## Starting assumption

Your current pipeline already works as:

```text
Source → SAST → ValidateAndTest → CentralQualityGate
```

Do not add ServiceNow, Jira or Bedrock actions inside CodePipeline.

---

# Checkpoint A — Supporting storage and queues

## 1. Create the evidence S3 bucket

1. Open **Amazon S3**.
2. Choose **Create bucket**.
3. Name it something globally unique, for example:

```text
<account-or-company>-appian-devops-evidence
```

4. Keep **Block all public access** enabled.
5. Enable **Bucket Versioning**.
6. Use default server-side encryption (SSE-S3 is sufficient for the demo).
7. Create the bucket.
8. Open the bucket → **Management** → **Create lifecycle rule**.
9. Name it:

```text
ExpireDemoEvidence
```

10. Apply it to all objects.
11. Expire current and noncurrent objects after **30 days** for the demo.
12. Save.

Record the bucket name as:

```text
EVIDENCE_BUCKET
```

## 2. Create the DynamoDB table

1. Open **DynamoDB** → **Tables** → **Create table**.
2. Table name:

```text
AppianDevOpsSidecarEvents
```

3. Partition key:

```text
EventKey
```

4. Type: **String**.
5. Leave sort key empty.
6. Capacity mode: **On-demand**.
7. Create the table.
8. Open the table → **Additional settings** → **Time to Live (TTL)**.
9. Enable TTL using:

```text
ExpiresAt
```

## 3. Create the EventBridge delivery DLQ

1. Open **Amazon SQS**.
2. Choose **Create queue**.
3. Type: **Standard**.
4. Name:

```text
appian-demo-eventbridge-delivery-dlq
```

5. Enable server-side encryption.
6. Set message retention to **14 days**.
7. Create.

## 4. Create the Lambda processing-failure queue

Create another standard queue:

```text
appian-demo-sidecar-processing-failures
```

Use the same encryption and 14-day retention settings.

These queues have different meanings:

```text
EventBridge cannot deliver → EventBridge delivery DLQ
Lambda receives but cannot process → processing-failure queue
```

## 5. Create the SNS topic

1. Open **Amazon SNS** → **Topics** → **Create topic**.
2. Type: **Standard**.
3. Name:

```text
appian-demo-sidecar-notifications
```

4. Create.
5. Optional: choose **Create subscription**.
6. Protocol: **Email**.
7. Enter your demo notification address.
8. Confirm the subscription from the email AWS sends.

Record the topic ARN.

---

# Checkpoint B — Configuration and secret placeholders

## 6. Create the routing parameter

1. Open **Systems Manager**.
2. Choose **Parameter Store** → **Create parameter**.
3. Name:

```text
/devops/YOUR_PIPELINE_NAME/sidecar-routing
```

4. Tier: **Standard**.
5. Type: **String**.
6. Copy the complete contents of:

```text
config/routing-config.example.json
```

into the Value field.
7. Create the parameter.

Default behavior:

```text
ServiceNow: MOCK
Jira:       MOCK
Updates:    pipeline + stage + AI-analysis events
```

To later update after every individual CodePipeline action too, add `ACTION` to the `levels` arrays.

## 7. Create the ServiceNow placeholder secret

1. Open **Secrets Manager** → **Store a new secret**.
2. Choose **Other type of secret**.
3. Use plaintext JSON:

```json
{
  "baseUrl": "https://REPLACE_ME.service-now.com",
  "username": "REPLACE_ME",
  "password": "REPLACE_ME",
  "table": "change_request",
  "recordSysId": "REPLACE_ME",
  "field": "work_notes"
}
```

4. Secret name:

```text
YOUR_PIPELINE_NAME/sidecars/servicenow
```

5. Store it and copy the secret ARN.

No real values are required while routing mode is `MOCK`.

## 8. Create the Jira placeholder secret

Create another secret:

```json
{
  "baseUrl": "https://REPLACE_ME.atlassian.net",
  "email": "REPLACE_ME",
  "apiToken": "REPLACE_ME",
  "issueKey": "REPLACE_ME"
}
```

Name:

```text
YOUR_PIPELINE_NAME/sidecars/jira
```

Copy the ARN.

---

# Checkpoint C — Integration Router Lambda

## 9. Create the Lambda

1. Open **AWS Lambda** → **Create function**.
2. Choose **Author from scratch**.
3. Name:

```text
YOUR_PIPELINE_NAME-integration-router
```

4. Runtime: **Python 3.14**.
5. Architecture: **x86_64**.
6. Create a new basic Lambda execution role.
7. Create the function.

## 10. Upload the code

1. On the **Code** tab choose **Upload from** → **.zip file**.
2. Upload:

```text
deployment/integration-router.zip
```

3. Save.
4. Handler must be:

```text
lambda_function.lambda_handler
```

## 11. General configuration

Set:

```text
Memory: 512 MB
Timeout: 30 seconds
```

The Lambda does not need VPC attachment for mock mode or public SaaS endpoints.

## 12. Environment variables

Add:

```text
TABLE_NAME                 AppianDevOpsSidecarEvents
EVIDENCE_BUCKET            <your evidence bucket>
ROUTING_PARAMETER          /devops/YOUR_PIPELINE_NAME/sidecar-routing
SERVICENOW_SECRET_ARN      <ServiceNow secret ARN>
JIRA_SECRET_ARN            <Jira secret ARN>
NOTIFICATION_TOPIC_ARN     <SNS topic ARN>
RETENTION_DAYS             30
HTTP_TIMEOUT_SECONDS       15
LOG_LEVEL                  INFO
```

## 13. Add IAM permissions to the Router role

Open **Configuration → Permissions → Execution role** and add an inline policy.

Replace placeholders:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "SidecarState",
      "Effect": "Allow",
      "Action": [
        "dynamodb:GetItem",
        "dynamodb:PutItem"
      ],
      "Resource": "DYNAMODB_TABLE_ARN"
    },
    {
      "Sid": "ArchiveEvidence",
      "Effect": "Allow",
      "Action": "s3:PutObject",
      "Resource": "arn:aws:s3:::EVIDENCE_BUCKET_NAME/*"
    },
    {
      "Sid": "ReadRoutingPolicy",
      "Effect": "Allow",
      "Action": "ssm:GetParameter",
      "Resource": "ROUTING_PARAMETER_ARN"
    },
    {
      "Sid": "ReadExternalIntegrationSecrets",
      "Effect": "Allow",
      "Action": "secretsmanager:GetSecretValue",
      "Resource": [
        "SERVICENOW_SECRET_ARN",
        "JIRA_SECRET_ARN"
      ]
    },
    {
      "Sid": "ReadOptionalExecutionCorrelation",
      "Effect": "Allow",
      "Action": "codepipeline:GetPipelineExecution",
      "Resource": "CODEPIPELINE_ARN"
    },
    {
      "Sid": "SendNotifications",
      "Effect": "Allow",
      "Action": "sns:Publish",
      "Resource": "SNS_TOPIC_ARN"
    },
    {
      "Sid": "RetainFailedAsyncInvocations",
      "Effect": "Allow",
      "Action": "sqs:SendMessage",
      "Resource": "PROCESSING_FAILURE_QUEUE_ARN"
    }
  ]
}
```

The role already has basic CloudWatch Logs permissions from the Lambda console.

## 14. Configure async failure handling

1. Lambda → **Configuration** → **Asynchronous invocation**.
2. Choose **Edit**.
3. Maximum event age: **1 hour**.
4. Retry attempts: **2**.
5. On-failure destination: **SQS**.
6. Select:

```text
appian-demo-sidecar-processing-failures
```

7. Save.

---

# Checkpoint D — Failure Analyzer Lambda

## 15. Create the analyzer

Create another Python 3.14 Lambda:

```text
YOUR_PIPELINE_NAME-failure-analyzer
```

Use:

```text
Memory: 768 MB
Timeout: 60 seconds
```

Upload:

```text
deployment/failure-analyzer.zip
```

Handler:

```text
lambda_function.lambda_handler
```

## 16. Analyzer environment variables

Add:

```text
TABLE_NAME                 AppianDevOpsSidecarEvents
EVIDENCE_BUCKET            <your evidence bucket>
RETENTION_DAYS             30
BEDROCK_MODE               MOCK
BEDROCK_MODEL_ID           <leave blank for now>
BEDROCK_GUARDRAIL_ID       <leave blank>
BEDROCK_GUARDRAIL_VERSION  <leave blank>
MAX_LOG_EVENTS             120
MAX_CONTEXT_CHARS          45000
LOG_LEVEL                  INFO
```

Leave `BEDROCK_MODE=MOCK` until you deliberately enable real model calls.

## 17. Analyzer IAM policy

Add an inline policy to its execution role. Replace placeholders:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "ReadPipelineExecution",
      "Effect": "Allow",
      "Action": [
        "codepipeline:ListActionExecutions",
        "codepipeline:GetPipeline"
      ],
      "Resource": "CODEPIPELINE_ARN"
    },
    {
      "Sid": "ReadCodeBuild",
      "Effect": "Allow",
      "Action": "codebuild:BatchGetBuilds",
      "Resource": "*"
    },
    {
      "Sid": "ReadFailureLogs",
      "Effect": "Allow",
      "Action": "logs:FilterLogEvents",
      "Resource": [
        "arn:aws:logs:REGION:ACCOUNT_ID:log-group:/aws/codebuild/*",
        "arn:aws:logs:REGION:ACCOUNT_ID:log-group:/aws/lambda/*"
      ]
    },
    {
      "Sid": "ReadStepFunctionsFailureHistory",
      "Effect": "Allow",
      "Action": "states:GetExecutionHistory",
      "Resource": "arn:aws:states:REGION:ACCOUNT_ID:execution:*:*"
    },
    {
      "Sid": "WriteEvidence",
      "Effect": "Allow",
      "Action": "s3:PutObject",
      "Resource": "arn:aws:s3:::EVIDENCE_BUCKET_NAME/*"
    },
    {
      "Sid": "AnalysisState",
      "Effect": "Allow",
      "Action": [
        "dynamodb:GetItem",
        "dynamodb:PutItem"
      ],
      "Resource": "DYNAMODB_TABLE_ARN"
    },
    {
      "Sid": "PublishAnalysisComplete",
      "Effect": "Allow",
      "Action": "events:PutEvents",
      "Resource": "*"
    },
    {
      "Sid": "InvokeBedrockWhenEnabled",
      "Effect": "Allow",
      "Action": "bedrock:InvokeModel",
      "Resource": "*"
    },
    {
      "Sid": "RetainFailedAsyncInvocations",
      "Effect": "Allow",
      "Action": "sqs:SendMessage",
      "Resource": "PROCESSING_FAILURE_QUEUE_ARN"
    }
  ]
}
```

For the final client implementation, tighten the broad CodeBuild/Bedrock resources once the exact projects/model or inference profile are known.

## 18. Configure analyzer async failures

Use the same settings as the Router:

```text
Maximum event age: 1 hour
Retry attempts: 2
On failure: processing-failure SQS queue
```

---

# Checkpoint E — EventBridge rules

## 19. Rule 1: all pipeline activity → Integration Router

1. Open **Amazon EventBridge** → **Rules** → **Create rule**.
2. Name:

```text
YOUR_PIPELINE_NAME-sidecar-observer
```

3. Event bus: **default**.
4. Rule type: **Rule with an event pattern**.
5. Event source: **AWS events or EventBridge partner events**.
6. Choose **Custom pattern (JSON editor)**.
7. Paste and replace the pipeline name:

```json
{
  "source": ["aws.codepipeline"],
  "detail-type": [
    "CodePipeline Pipeline Execution State Change",
    "CodePipeline Stage Execution State Change",
    "CodePipeline Action Execution State Change"
  ],
  "detail": {
    "pipeline": ["YOUR_PIPELINE_NAME"]
  }
}
```

8. Target: **AWS service → Lambda function**.
9. Select the Integration Router Lambda.
10. Configure retry policy:

```text
Maximum event age: 1 hour
Retry attempts: 6
```

11. Configure DLQ: the EventBridge delivery DLQ.
12. Create the rule.

The console normally adds Lambda invoke permission when you select the Lambda as a rule target. Verify the rule target is enabled.

## 20. Rule 2: failed actions → Failure Analyzer

Create:

```text
YOUR_PIPELINE_NAME-failure-analysis
```

Pattern:

```json
{
  "source": ["aws.codepipeline"],
  "detail-type": [
    "CodePipeline Action Execution State Change"
  ],
  "detail": {
    "pipeline": ["YOUR_PIPELINE_NAME"],
    "state": ["FAILED"]
  }
}
```

Target:

```text
YOUR_PIPELINE_NAME-failure-analyzer
```

Use the same 1-hour / 6-retry / EventBridge-DLQ settings.

## 21. Rule 3: analysis complete → Integration Router

Create:

```text
YOUR_PIPELINE_NAME-analysis-complete-router
```

Pattern:

```json
{
  "source": ["devops.sidecar"],
  "detail-type": ["Failure Analysis Complete"],
  "detail": {
    "pipeline": ["YOUR_PIPELINE_NAME"]
  }
}
```

Target the Integration Router Lambda with the same retry/DLQ settings.

## 22. If EventBridge reports SQS DLQ permission errors

Add this resource policy to the EventBridge delivery queue, replacing the three rule ARNs:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AllowEventBridgeToUseDLQ",
      "Effect": "Allow",
      "Principal": {
        "Service": "events.amazonaws.com"
      },
      "Action": "sqs:SendMessage",
      "Resource": "EVENTBRIDGE_DLQ_ARN",
      "Condition": {
        "ArnEquals": {
          "aws:SourceArn": [
            "OBSERVER_RULE_ARN",
            "FAILURE_RULE_ARN",
            "ANALYSIS_COMPLETE_RULE_ARN"
          ]
        }
      }
    }
  ]
}
```

---

# Checkpoint F — CloudWatch alarms

## 23. Lambda error alarms

Create one alarm for each Lambda:

```text
Metric namespace: AWS/Lambda
Metric: Errors
FunctionName: <function>
Statistic: Sum
Period: 5 minutes
Threshold: > 0
Evaluation periods: 1
```

Notification action: your SNS topic.

## 24. Queue alarms

Create alarms on:

```text
AWS/SQS → ApproximateNumberOfMessagesVisible
```

for both queues.

Use:

```text
Threshold > 0
Period 5 minutes
Evaluation periods 1
```

Send alarm notifications to the SNS topic.

---

# Checkpoint G — First end-to-end test

## 25. Run a passing pipeline

Start a normal pipeline execution with mock SAST/Tosca passing.

CodePipeline should behave exactly as before:

```text
Source                SUCCEEDED
SAST                  SUCCEEDED
ValidateAndTest       SUCCEEDED
CentralQualityGate    SUCCEEDED
```

Now inspect the observer layer.

### CloudWatch

Open the Integration Router log group. You should see messages resembling:

```text
MOCK ServiceNow update: Pipeline ... stage=SAST ... state=SUCCEEDED
MOCK Jira update: Pipeline ... stage=SAST ... state=SUCCEEDED
```

### S3

Your evidence bucket should contain:

```text
executions/<pipeline>/<execution-id>/events/*.json
```

### DynamoDB

The table should contain `INT#...#SERVICENOW`, `INT#...#JIRA`, and possibly `INT#...#SNS` records.

The sidecars have now proven they can observe the live pipeline without being part of its blocking execution path.

---

# Checkpoint H — Failure + RCA demonstration

## 26. Force a pipeline quality failure

Use the existing pipeline mock control, for example:

```text
SastMode = MOCK_FAIL
```

or the current Tosca mock failure option.

Expected core behavior:

```text
SAST / ValidateAndTest     reports result
CentralQualityGate         FAILED
```

## 27. Verify the failed-action event

The Failure Analyzer should receive the failed `EvaluateQualityGate` action event.

Open its CloudWatch log group.

It should:

1. call CodePipeline for action execution details;
2. capture upstream output variables such as SAST/Tosca status;
3. collect bounded provider logs where available;
4. redact/truncate evidence;
5. generate a MOCK RCA;
6. write the analysis to S3;
7. emit a `Failure Analysis Complete` EventBridge event.

## 28. Verify analysis evidence

S3 should now contain:

```text
executions/<pipeline>/<execution-id>/failures/<event-id>_analysis.json
```

## 29. Verify SNOW/Jira analysis updates

The Analysis Complete rule invokes the Integration Router again.

Its log should contain mock updates resembling:

```text
AI analysis: Pipeline failure detected in CentralQualityGate / EvaluateQualityGate...
Recommended actions: ...
```

This completes the mock architecture.

---

# Optional — Deploy the same resources with SAM/CloudFormation

The console-first build above is easiest while you are iterating.

The package also includes:

```text
infrastructure/template.yaml
```

for a reproducible implementation later.

From an AWS-authenticated terminal with AWS SAM CLI:

```bash
cd infrastructure
sam build
sam deploy --guided
```

Use the exact existing CodePipeline name for `PipelineName` and leave `BedrockMode=MOCK` initially.

Do not deploy the template on top of manually created resources with the same names unless you intentionally migrate ownership to CloudFormation.


---

# Optional — Per-execution ServiceNow/Jira ticket correlation

The router can resolve ticket IDs from CodePipeline pipeline variables if you later want each pipeline execution tied to a different change/issue.

Optional pipeline variables:

```text
ServiceNowRecordSysId
JiraIssueKey
```

When present on a pipeline execution, these override the fixed `recordSysId` / `issueKey` values in Secrets Manager.

This is intentionally optional. Do **not** put credentials or API tokens in CodePipeline variables; those belong in Secrets Manager.
