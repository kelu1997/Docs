import json
import logging
import os
import re
import time
from datetime import datetime, timedelta, timezone

import boto3
from botocore.exceptions import ClientError

LOG = logging.getLogger()
LOG.setLevel(os.getenv("LOG_LEVEL", "INFO"))

CODEPIPELINE = boto3.client("codepipeline")
CODEBUILD = boto3.client("codebuild")
LOGS = boto3.client("logs")
SFN = boto3.client("stepfunctions")
S3 = boto3.client("s3")
DDB = boto3.client("dynamodb")
EVENTS = boto3.client("events")
BEDROCK = boto3.client("bedrock-runtime")

TABLE_NAME = os.environ["TABLE_NAME"]
EVIDENCE_BUCKET = os.environ["EVIDENCE_BUCKET"]
BEDROCK_MODE = os.getenv("BEDROCK_MODE", "MOCK").upper()
BEDROCK_MODEL_ID = os.getenv("BEDROCK_MODEL_ID", "")
BEDROCK_GUARDRAIL_ID = os.getenv("BEDROCK_GUARDRAIL_ID", "")
BEDROCK_GUARDRAIL_VERSION = os.getenv("BEDROCK_GUARDRAIL_VERSION", "")
RETENTION_DAYS = int(os.getenv("RETENTION_DAYS", "30"))
MAX_LOG_EVENTS = int(os.getenv("MAX_LOG_EVENTS", "120"))
MAX_CONTEXT_CHARS = int(os.getenv("MAX_CONTEXT_CHARS", "45000"))

SECRET_PATTERNS = [
    (re.compile(r"(?i)(authorization\s*[:=]\s*)(bearer\s+)?[^\s,;]+"), r"\1[REDACTED]"),
    (re.compile(r"(?i)(x-api-key\s*[:=]\s*)[^\s,;]+"), r"\1[REDACTED]"),
    (re.compile(r"(?i)((?:password|passwd|pwd|secret|token|api[_-]?key)\s*[:=]\s*)[^\s,;\"]+"), r"\1[REDACTED]"),
    (re.compile(r"AKIA[0-9A-Z]{16}"), "[REDACTED_AWS_ACCESS_KEY]"),
    (re.compile(r"ASIA[0-9A-Z]{16}"), "[REDACTED_AWS_SESSION_KEY]"),
]


def _ttl() -> int:
    return int(time.time()) + RETENTION_DAYS * 86400


def _safe_part(value: str) -> str:
    text = str(value or "unknown")
    return "".join(c if c.isalnum() or c in "-_." else "_" for c in text)[:180]


def _redact(text: str) -> str:
    output = text
    for pattern, replacement in SECRET_PATTERNS:
        output = pattern.sub(replacement, output)
    return output


def _analysis_key(event_id: str) -> str:
    return f"ANALYSIS#{event_id}"


def _existing_analysis(event_id: str) -> dict | None:
    response = DDB.get_item(
        TableName=TABLE_NAME,
        Key={"EventKey": {"S": _analysis_key(event_id)}},
        ConsistentRead=True,
    )
    item = response.get("Item")
    if not item or item.get("Status", {}).get("S") != "SUCCEEDED":
        return None
    try:
        return json.loads(item.get("Analysis", {}).get("S", "{}"))
    except json.JSONDecodeError:
        return None


def _save_analysis(event_id: str, pipeline: str, execution_id: str, status: str, analysis: dict, evidence_key: str) -> None:
    DDB.put_item(
        TableName=TABLE_NAME,
        Item={
            "EventKey": {"S": _analysis_key(event_id)},
            "PipelineExecutionId": {"S": execution_id},
            "Pipeline": {"S": pipeline},
            "Status": {"S": status},
            "Analysis": {"S": json.dumps(analysis)[:350000]},
            "EvidenceKey": {"S": evidence_key},
            "ExpiresAt": {"N": str(_ttl())},
        },
    )


def _parse_event_time(event: dict) -> datetime:
    value = event.get("time")
    if value:
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            pass
    return datetime.now(timezone.utc)


def _list_action_executions(pipeline: str, execution_id: str) -> list[dict]:
    response = CODEPIPELINE.list_action_executions(
        pipelineName=pipeline,
        filter={"pipelineExecutionId": execution_id},
        maxResults=100,
    )
    return response.get("actionExecutionDetails", [])


def _find_failed_action(event: dict, actions: list[dict]) -> dict | None:
    detail = event.get("detail", {})
    stage = detail.get("stage")
    action = detail.get("action")
    candidates = [a for a in actions if a.get("status") == "Failed"]
    if stage:
        stage_matches = [a for a in candidates if a.get("stageName") == stage]
        if stage_matches:
            candidates = stage_matches
    if action:
        action_matches = [a for a in candidates if a.get("actionName") == action]
        if action_matches:
            candidates = action_matches
    if not candidates:
        return None
    candidates.sort(key=lambda x: x.get("lastUpdateTime") or x.get("startTime") or datetime.min.replace(tzinfo=timezone.utc), reverse=True)
    return candidates[0]


def _get_action_config(pipeline: str, stage_name: str | None, action_name: str | None) -> dict:
    if not stage_name or not action_name:
        return {}
    response = CODEPIPELINE.get_pipeline(name=pipeline)
    for stage in response.get("pipeline", {}).get("stages", []):
        if stage.get("name") != stage_name:
            continue
        for action in stage.get("actions", []):
            if action.get("name") == action_name:
                return action
    return {}


def _filter_log_events(log_group: str, log_stream: str | None, start: datetime, end: datetime) -> list[str]:
    kwargs = {
        "logGroupName": log_group,
        "startTime": int(start.timestamp() * 1000),
        "endTime": int(end.timestamp() * 1000),
        "limit": min(MAX_LOG_EVENTS, 10000),
    }
    if log_stream:
        kwargs["logStreamNames"] = [log_stream]
    response = LOGS.filter_log_events(**kwargs)
    return [event.get("message", "") for event in response.get("events", [])][-MAX_LOG_EVENTS:]


def _collect_codebuild_context(build_id: str, event_time: datetime) -> dict:
    response = CODEBUILD.batch_get_builds(ids=[build_id])
    builds = response.get("builds", [])
    if not builds:
        return {"type": "CodeBuild", "buildId": build_id, "note": "Build details not found"}
    build = builds[0]
    logs = build.get("logs", {})
    messages = []
    if logs.get("groupName"):
        try:
            messages = _filter_log_events(
                logs["groupName"], logs.get("streamName"),
                event_time - timedelta(minutes=10), event_time + timedelta(minutes=2),
            )
        except Exception as exc:
            messages = [f"Could not retrieve CodeBuild logs: {exc}"]
    return {
        "type": "CodeBuild",
        "buildId": build_id,
        "buildStatus": build.get("buildStatus"),
        "currentPhase": build.get("currentPhase"),
        "phases": build.get("phases", []),
        "logs": messages,
    }


def _collect_stepfunctions_context(execution_arn: str) -> dict:
    try:
        response = SFN.get_execution_history(
            executionArn=execution_arn,
            reverseOrder=True,
            includeExecutionData=True,
            maxResults=100,
        )
        events = response.get("events", [])
        compact = []
        for event in events[:100]:
            item = {"id": event.get("id"), "type": event.get("type"), "timestamp": str(event.get("timestamp"))}
            for key, value in event.items():
                if key.endswith("EventDetails") and isinstance(value, dict):
                    item["details"] = value
                    break
            compact.append(item)
        return {"type": "StepFunctions", "executionArn": execution_arn, "history": compact}
    except Exception as exc:
        return {"type": "StepFunctions", "executionArn": execution_arn, "note": f"Could not retrieve history: {exc}"}


def _collect_lambda_context(function_name: str, event_time: datetime) -> dict:
    log_group = f"/aws/lambda/{function_name}"
    try:
        messages = _filter_log_events(
            log_group, None,
            event_time - timedelta(minutes=5), event_time + timedelta(minutes=2),
        )
        return {"type": "Lambda", "functionName": function_name, "logs": messages}
    except Exception as exc:
        return {"type": "Lambda", "functionName": function_name, "note": f"Could not retrieve Lambda logs: {exc}"}


def _collect_provider_context(action: dict | None, action_config: dict, event_time: datetime) -> dict:
    if not action:
        return {"type": "Unknown", "note": "No failed action execution was found"}
    input_data = action.get("input", {})
    action_type = input_data.get("actionTypeId", {})
    provider = action_type.get("provider", "")
    output = action.get("output", {})
    result = output.get("executionResult", {})
    external_id = result.get("externalExecutionId")
    config = action_config.get("configuration", {})

    if provider == "CodeBuild" and external_id:
        return _collect_codebuild_context(external_id, event_time)
    if provider == "StepFunctions" and external_id and external_id.startswith("arn:"):
        return _collect_stepfunctions_context(external_id)
    if provider == "Lambda":
        function_name = config.get("FunctionName")
        if function_name:
            return _collect_lambda_context(function_name, event_time)

    log_stream_arn = result.get("logStreamARN")
    return {
        "type": provider or "Unknown",
        "externalExecutionId": external_id,
        "externalExecutionSummary": result.get("externalExecutionSummary"),
        "externalExecutionUrl": result.get("externalExecutionUrl"),
        "logStreamARN": log_stream_arn,
    }


def _build_context(event: dict) -> dict:
    detail = event.get("detail", {})
    pipeline = detail.get("pipeline", "unknown")
    execution_id = detail.get("execution-id") or detail.get("pipeline-execution-id") or "unknown"
    actions = _list_action_executions(pipeline, execution_id) if pipeline != "unknown" and execution_id != "unknown" else []
    failed_action = _find_failed_action(event, actions)
    action_config = _get_action_config(
        pipeline,
        failed_action.get("stageName") if failed_action else detail.get("stage"),
        failed_action.get("actionName") if failed_action else detail.get("action"),
    ) if pipeline != "unknown" else {}
    provider_context = _collect_provider_context(failed_action, action_config, _parse_event_time(event))
    action_summaries = []
    for action_item in actions:
        result = (action_item.get("output") or {}).get("executionResult") or {}
        action_summaries.append({
            "stageName": action_item.get("stageName"),
            "actionName": action_item.get("actionName"),
            "status": action_item.get("status"),
            "provider": ((action_item.get("input") or {}).get("actionTypeId") or {}).get("provider"),
            "namespace": (action_item.get("input") or {}).get("namespace"),
            "outputVariables": (action_item.get("output") or {}).get("outputVariables", {}),
            "errorDetails": result.get("errorDetails"),
            "externalExecutionSummary": result.get("externalExecutionSummary"),
        })
    return {
        "pipeline": pipeline,
        "pipelineExecutionId": execution_id,
        "event": {
            "id": event.get("id"),
            "detailType": event.get("detail-type"),
            "time": event.get("time"),
            "detail": detail,
        },
        "failedAction": failed_action,
        "actionSummaries": action_summaries,
        "providerContext": provider_context,
    }


def _truncate_and_redact(context: dict) -> tuple[dict, str]:
    raw = json.dumps(context, default=str, indent=2)
    redacted = _redact(raw)
    if len(redacted) > MAX_CONTEXT_CHARS:
        redacted = redacted[:MAX_CONTEXT_CHARS] + "\n...[TRUNCATED]"
    try:
        return json.loads(redacted), redacted
    except json.JSONDecodeError:
        return {"redactedContextText": redacted}, redacted


def _mock_analysis(context: dict) -> dict:
    failed = context.get("failedAction") or {}
    provider = (failed.get("input") or {}).get("actionTypeId", {}).get("provider", "Unknown")
    message = (((failed.get("output") or {}).get("executionResult") or {}).get("errorDetails") or {}).get("message")
    return {
        "summary": f"Pipeline failure detected in {failed.get('stageName', 'unknown stage')} / {failed.get('actionName', 'unknown action')}.",
        "probableCause": message or f"The {provider} action reported a failed execution. Review the collected evidence for the exact cause.",
        "failedComponent": failed.get("actionName") or context.get("event", {}).get("detail", {}).get("stage") or "unknown",
        "evidence": [
            f"Provider: {provider}",
            f"Pipeline execution: {context.get('pipelineExecutionId', 'unknown')}",
        ],
        "recommendedActions": [
            "Review the failed action's bounded log/evidence excerpt.",
            "Correct the underlying issue or approved configuration.",
            "Rerun the pipeline and confirm the Central Quality Gate passes.",
        ],
        "confidence": "MEDIUM",
        "analysisMode": "MOCK",
    }


def _bedrock_analysis(redacted_context_text: str) -> dict:
    if not BEDROCK_MODEL_ID:
        raise RuntimeError("BEDROCK_MODEL_ID must be set when BEDROCK_MODE=REAL")
    system_text = (
        "You are a DevSecOps failure-analysis assistant. Analyze only the supplied pipeline evidence. "
        "Do not invent facts. Return ONLY valid JSON with keys summary, probableCause, failedComponent, "
        "evidence (array of short strings), recommendedActions (array), confidence (LOW|MEDIUM|HIGH), analysisMode. "
        "Do not include secrets or credentials even if present."
    )
    user_text = "Analyze this redacted pipeline failure evidence:\n" + redacted_context_text
    kwargs = {
        "modelId": BEDROCK_MODEL_ID,
        "system": [{"text": system_text}],
        "messages": [{"role": "user", "content": [{"text": user_text}]}],
        "inferenceConfig": {"maxTokens": 900, "temperature": 0.1},
    }
    if BEDROCK_GUARDRAIL_ID and BEDROCK_GUARDRAIL_VERSION:
        kwargs["guardrailConfig"] = {
            "guardrailIdentifier": BEDROCK_GUARDRAIL_ID,
            "guardrailVersion": BEDROCK_GUARDRAIL_VERSION,
            "trace": "enabled",
        }
    response = BEDROCK.converse(**kwargs)
    blocks = response.get("output", {}).get("message", {}).get("content", [])
    text = "\n".join(block.get("text", "") for block in blocks if "text" in block).strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
    try:
        result = json.loads(text)
    except json.JSONDecodeError:
        result = {
            "summary": text[:1500] or "Bedrock returned no parseable analysis.",
            "probableCause": "See summary and collected evidence.",
            "failedComponent": "unknown",
            "evidence": [],
            "recommendedActions": ["Review the evidence archive manually."],
            "confidence": "LOW",
        }
    result["analysisMode"] = "BEDROCK"
    return result


def _analyze(context: dict, redacted_text: str) -> dict:
    if BEDROCK_MODE == "DISABLED":
        return {
            "summary": "Failure evidence captured; AI analysis is disabled.",
            "probableCause": "Not analyzed.",
            "failedComponent": (context.get("failedAction") or {}).get("actionName", "unknown"),
            "evidence": [],
            "recommendedActions": ["Review the archived failure evidence."],
            "confidence": "LOW",
            "analysisMode": "DISABLED",
        }
    if BEDROCK_MODE == "MOCK":
        return _mock_analysis(context)
    if BEDROCK_MODE == "REAL":
        return _bedrock_analysis(redacted_text)
    raise RuntimeError(f"Unsupported BEDROCK_MODE: {BEDROCK_MODE}")


def _archive_failure(pipeline: str, execution_id: str, event_id: str, context: dict, analysis: dict) -> str:
    key = (
        f"executions/{_safe_part(pipeline)}/{_safe_part(execution_id)}/failures/"
        f"{_safe_part(event_id)}_analysis.json"
    )
    body = {"context": context, "analysis": analysis}
    S3.put_object(
        Bucket=EVIDENCE_BUCKET,
        Key=key,
        Body=json.dumps(body, default=str, indent=2).encode("utf-8"),
        ContentType="application/json",
        ServerSideEncryption="AES256",
    )
    return key


def _publish_analysis_complete(event: dict, context: dict, analysis: dict, evidence_key: str) -> None:
    detail = event.get("detail", {})
    payload = {
        "pipeline": context["pipeline"],
        "pipelineExecutionId": context["pipelineExecutionId"],
        "stage": detail.get("stage"),
        "action": detail.get("action"),
        "failureEventId": event.get("id"),
        "analysisEvidenceKey": evidence_key,
        "analysis": analysis,
    }
    response = EVENTS.put_events(
        Entries=[{
            "Source": "devops.sidecar",
            "DetailType": "Failure Analysis Complete",
            "Detail": json.dumps(payload),
        }]
    )
    if response.get("FailedEntryCount", 0):
        raise RuntimeError(f"EventBridge PutEvents failed: {response}")


def lambda_handler(event, context):
    event_id = event.get("id", "unknown")
    existing = _existing_analysis(event_id)
    if existing:
        LOG.info("Analysis already completed for event %s; skipping duplicate", event_id)
        return {"ok": True, "duplicate": True, "analysis": existing}

    built_context = _build_context(event)
    redacted_context, redacted_text = _truncate_and_redact(built_context)
    analysis = _analyze(redacted_context, redacted_text)
    evidence_key = _archive_failure(
        built_context["pipeline"], built_context["pipelineExecutionId"], event_id,
        redacted_context, analysis,
    )
    _save_analysis(
        event_id, built_context["pipeline"], built_context["pipelineExecutionId"],
        "SUCCEEDED", analysis, evidence_key,
    )
    _publish_analysis_complete(event, built_context, analysis, evidence_key)
    LOG.info("Failure analysis complete event=%s evidence=%s", event_id, evidence_key)
    return {"ok": True, "analysis": analysis, "evidenceKey": evidence_key}
