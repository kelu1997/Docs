import base64
import fnmatch
import json
import logging
import os
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone

import boto3
from botocore.exceptions import ClientError

LOG = logging.getLogger()
LOG.setLevel(os.getenv("LOG_LEVEL", "INFO"))

DDB = boto3.client("dynamodb")
S3 = boto3.client("s3")
SSM = boto3.client("ssm")
SECRETS = boto3.client("secretsmanager")
SNS = boto3.client("sns")
CODEPIPELINE = boto3.client("codepipeline")

TABLE_NAME = os.environ["TABLE_NAME"]
EVIDENCE_BUCKET = os.environ["EVIDENCE_BUCKET"]
ROUTING_PARAMETER = os.environ["ROUTING_PARAMETER"]
SERVICENOW_SECRET_ARN = os.getenv("SERVICENOW_SECRET_ARN", "")
JIRA_SECRET_ARN = os.getenv("JIRA_SECRET_ARN", "")
NOTIFICATION_TOPIC_ARN = os.getenv("NOTIFICATION_TOPIC_ARN", "")
RETENTION_DAYS = int(os.getenv("RETENTION_DAYS", "30"))
HTTP_TIMEOUT_SECONDS = int(os.getenv("HTTP_TIMEOUT_SECONDS", "15"))


def _now_epoch() -> int:
    return int(time.time())


def _ttl() -> int:
    return _now_epoch() + RETENTION_DAYS * 86400


def _safe_part(value: str) -> str:
    text = str(value or "unknown")
    return "".join(c if c.isalnum() or c in "-_." else "_" for c in text)[:180]


def _get_routing_config() -> dict:
    response = SSM.get_parameter(Name=ROUTING_PARAMETER)
    return json.loads(response["Parameter"]["Value"])


def _normalize_event(event: dict) -> dict:
    detail_type = event.get("detail-type") or event.get("detailType") or "Unknown"
    detail = event.get("detail") or {}

    if event.get("source") == "devops.sidecar" and detail_type == "Failure Analysis Complete":
        return {
            "eventId": event.get("id", "unknown"),
            "source": event.get("source"),
            "detailType": detail_type,
            "level": "ANALYSIS",
            "pipeline": detail.get("pipeline", "unknown"),
            "pipelineExecutionId": detail.get("pipelineExecutionId", "unknown"),
            "stage": detail.get("stage"),
            "action": detail.get("action"),
            "state": "ANALYZED",
            "time": event.get("time") or datetime.now(timezone.utc).isoformat(),
            "analysis": detail.get("analysis", {}),
            "analysisEvidenceKey": detail.get("analysisEvidenceKey"),
            "failureEventId": detail.get("failureEventId"),
            "rawDetail": detail,
        }

    if detail_type.startswith("CodePipeline Pipeline"):
        level = "PIPELINE"
    elif detail_type.startswith("CodePipeline Stage"):
        level = "STAGE"
    elif detail_type.startswith("CodePipeline Action"):
        level = "ACTION"
    else:
        level = "UNKNOWN"

    return {
        "eventId": event.get("id", "unknown"),
        "source": event.get("source", "unknown"),
        "detailType": detail_type,
        "level": level,
        "pipeline": detail.get("pipeline", "unknown"),
        "pipelineExecutionId": detail.get("execution-id") or detail.get("pipeline-execution-id") or detail.get("executionId") or "unknown",
        "stage": detail.get("stage"),
        "action": detail.get("action"),
        "state": detail.get("state", "UNKNOWN"),
        "time": event.get("time") or datetime.now(timezone.utc).isoformat(),
        "rawDetail": detail,
    }


def _pattern_list_matches(value: str | None, patterns: list[str] | None) -> bool:
    if not patterns:
        return True
    value = value or ""
    return any(fnmatch.fnmatchcase(value, pattern) for pattern in patterns)


def _route_matches(route: dict, normalized: dict) -> bool:
    if not route.get("enabled", True):
        return False
    if route.get("levels") and normalized["level"] not in route["levels"]:
        return False
    if route.get("states") and normalized["state"] not in route["states"]:
        return False
    if not _pattern_list_matches(normalized.get("stage"), route.get("stages")):
        return False
    if not _pattern_list_matches(normalized.get("action"), route.get("actions")):
        return False
    return True



def _load_execution_correlation(normalized: dict, config: dict) -> dict:
    if normalized.get("source") != "aws.codepipeline":
        return {}
    pipeline = normalized.get("pipeline")
    execution_id = normalized.get("pipelineExecutionId")
    if not pipeline or pipeline == "unknown" or not execution_id or execution_id == "unknown":
        return {}
    try:
        response = CODEPIPELINE.get_pipeline_execution(
            pipelineName=pipeline, pipelineExecutionId=execution_id
        )
        variables = {
            item.get("name"): item.get("resolvedValue")
            for item in response.get("pipelineExecution", {}).get("variables", [])
            if item.get("name") and item.get("resolvedValue") is not None
        }
        integrations = config.get("integrations", {})
        snow_var = integrations.get("servicenow", {}).get("recordSysIdVariable", "ServiceNowRecordSysId")
        jira_var = integrations.get("jira", {}).get("issueKeyVariable", "JiraIssueKey")
        correlation = {}
        if variables.get(snow_var):
            correlation["serviceNowRecordSysId"] = variables[snow_var]
        if variables.get(jira_var):
            correlation["jiraIssueKey"] = variables[jira_var]
        return correlation
    except Exception as exc:
        LOG.warning("Could not resolve optional execution correlation variables: %s", exc)
        return {}

def _event_result_key(event_id: str, integration: str) -> str:
    return f"INT#{event_id}#{integration.upper()}"


def _already_succeeded(event_id: str, integration: str) -> bool:
    response = DDB.get_item(
        TableName=TABLE_NAME,
        Key={"EventKey": {"S": _event_result_key(event_id, integration)}},
        ConsistentRead=True,
    )
    item = response.get("Item")
    return bool(item and item.get("Status", {}).get("S") == "SUCCEEDED")


def _save_integration_result(normalized: dict, integration: str, status: str, detail: str) -> None:
    DDB.put_item(
        TableName=TABLE_NAME,
        Item={
            "EventKey": {"S": _event_result_key(normalized["eventId"], integration)},
            "PipelineExecutionId": {"S": normalized["pipelineExecutionId"]},
            "Pipeline": {"S": normalized["pipeline"]},
            "Integration": {"S": integration},
            "Status": {"S": status},
            "Detail": {"S": detail[:4000]},
            "OccurredAt": {"S": normalized["time"]},
            "ExpiresAt": {"N": str(_ttl())},
        },
    )


def _archive_event(normalized: dict, original_event: dict) -> str:
    prefix = (
        f"executions/{_safe_part(normalized['pipeline'])}/"
        f"{_safe_part(normalized['pipelineExecutionId'])}/events"
    )
    key = (
        f"{prefix}/{_safe_part(normalized['time'])}_"
        f"{_safe_part(normalized['level'])}_{_safe_part(normalized['eventId'])}.json"
    )
    body = {
        "normalized": normalized,
        "event": original_event,
    }
    S3.put_object(
        Bucket=EVIDENCE_BUCKET,
        Key=key,
        Body=json.dumps(body, default=str, indent=2).encode("utf-8"),
        ContentType="application/json",
        ServerSideEncryption="AES256",
    )
    return key


def _load_secret(arn: str) -> dict:
    if not arn:
        raise RuntimeError("Secret ARN is not configured")
    response = SECRETS.get_secret_value(SecretId=arn)
    value = response.get("SecretString")
    if value is None:
        value = base64.b64decode(response["SecretBinary"]).decode("utf-8")
    return json.loads(value)


def _http_json(method: str, url: str, payload: dict, headers: dict) -> tuple[int, str]:
    data = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(url=url, data=data, method=method)
    request.add_header("Content-Type", "application/json")
    request.add_header("Accept", "application/json")
    for key, value in headers.items():
        request.add_header(key, value)
    try:
        with urllib.request.urlopen(request, timeout=HTTP_TIMEOUT_SECONDS) as response:
            return response.status, response.read(12000).decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        body = exc.read(12000).decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code} from {url}: {body[:2000]}") from exc


def _format_message(normalized: dict) -> str:
    location = normalized["level"]
    if normalized.get("stage"):
        location += f" stage={normalized['stage']}"
    if normalized.get("action"):
        location += f" action={normalized['action']}"
    base = (
        f"Pipeline {normalized['pipeline']} execution {normalized['pipelineExecutionId']} | "
        f"{location} | state={normalized['state']}"
    )
    analysis = normalized.get("analysis") or {}
    if analysis:
        summary = analysis.get("summary") or analysis.get("probableCause") or "Failure analysis completed"
        actions = analysis.get("recommendedActions") or []
        base += f"\nAI analysis: {summary}"
        if actions:
            base += "\nRecommended actions: " + "; ".join(str(x) for x in actions[:5])
    return base[:12000]


def _send_servicenow(normalized: dict, route: dict) -> str:
    mode = str(route.get("mode", "MOCK")).upper()
    message = _format_message(normalized)
    if mode == "DISABLED":
        return "DISABLED"
    if mode == "MOCK":
        LOG.info("MOCK ServiceNow update: %s", message)
        return "MOCK_SENT"
    if mode != "REAL":
        raise RuntimeError(f"Unsupported ServiceNow mode: {mode}")

    secret = _load_secret(SERVICENOW_SECRET_ARN)
    base_url = secret["baseUrl"].rstrip("/")
    table = secret.get("table", "change_request")
    record_sys_id = (normalized.get("correlation") or {}).get("serviceNowRecordSysId") or secret["recordSysId"]
    field = secret.get("field", "work_notes")
    url = f"{base_url}/api/now/table/{table}/{record_sys_id}"
    headers = {}
    if secret.get("bearerToken"):
        headers["Authorization"] = f"Bearer {secret['bearerToken']}"
    else:
        credentials = f"{secret['username']}:{secret['password']}".encode("utf-8")
        headers["Authorization"] = "Basic " + base64.b64encode(credentials).decode("ascii")
    status, _ = _http_json("PATCH", url, {field: message}, headers)
    if not 200 <= status < 300:
        raise RuntimeError(f"ServiceNow returned HTTP {status}")
    return f"HTTP_{status}"


def _jira_adf(text: str) -> dict:
    return {
        "body": {
            "type": "doc",
            "version": 1,
            "content": [
                {
                    "type": "paragraph",
                    "content": [{"type": "text", "text": text[:30000]}],
                }
            ],
        }
    }


def _send_jira(normalized: dict, route: dict) -> str:
    mode = str(route.get("mode", "MOCK")).upper()
    message = _format_message(normalized)
    if mode == "DISABLED":
        return "DISABLED"
    if mode == "MOCK":
        LOG.info("MOCK Jira update: %s", message)
        return "MOCK_SENT"
    if mode != "REAL":
        raise RuntimeError(f"Unsupported Jira mode: {mode}")

    secret = _load_secret(JIRA_SECRET_ARN)
    base_url = secret["baseUrl"].rstrip("/")
    issue_key = (normalized.get("correlation") or {}).get("jiraIssueKey") or secret["issueKey"]
    url = f"{base_url}/rest/api/3/issue/{issue_key}/comment"
    headers = {}
    if secret.get("bearerToken"):
        headers["Authorization"] = f"Bearer {secret['bearerToken']}"
    else:
        credentials = f"{secret['email']}:{secret['apiToken']}".encode("utf-8")
        headers["Authorization"] = "Basic " + base64.b64encode(credentials).decode("ascii")
    status, _ = _http_json("POST", url, _jira_adf(message), headers)
    if not 200 <= status < 300:
        raise RuntimeError(f"Jira returned HTTP {status}")
    return f"HTTP_{status}"


def _publish_notification(normalized: dict, config: dict) -> None:
    if not NOTIFICATION_TOPIC_ARN:
        return
    notify = config.get("notifications", {})
    if not notify.get("enabled", True):
        return
    if notify.get("levels") and normalized["level"] not in notify["levels"]:
        return
    if notify.get("states") and normalized["state"] not in notify["states"]:
        return
    if _already_succeeded(normalized["eventId"], "SNS"):
        return
    subject = f"DevOps {normalized['state']}: {normalized['pipeline']}"[:100]
    SNS.publish(TopicArn=NOTIFICATION_TOPIC_ARN, Subject=subject, Message=_format_message(normalized))
    _save_integration_result(normalized, "SNS", "SUCCEEDED", "PUBLISHED")


def _process_integration(normalized: dict, name: str, route: dict) -> None:
    if not _route_matches(route, normalized):
        return
    if _already_succeeded(normalized["eventId"], name):
        LOG.info("Skipping duplicate %s delivery for event %s", name, normalized["eventId"])
        return
    try:
        if name == "servicenow":
            result = _send_servicenow(normalized, route)
        elif name == "jira":
            result = _send_jira(normalized, route)
        else:
            raise RuntimeError(f"Unknown integration: {name}")
        _save_integration_result(normalized, name, "SUCCEEDED", result)
    except Exception as exc:
        _save_integration_result(normalized, name, "FAILED", str(exc))
        raise


def lambda_handler(event, context):
    normalized = _normalize_event(event)
    config = _get_routing_config()
    normalized["correlation"] = _load_execution_correlation(normalized, config)
    evidence_key = _archive_event(normalized, event)
    LOG.info(
        "Observed %s state=%s pipeline=%s execution=%s evidence=%s",
        normalized["level"], normalized["state"], normalized["pipeline"],
        normalized["pipelineExecutionId"], evidence_key,
    )

    integrations = config.get("integrations", {})
    errors = []
    for name in ("servicenow", "jira"):
        route = integrations.get(name, {})
        try:
            _process_integration(normalized, name, route)
        except Exception as exc:
            LOG.exception("%s integration failed", name)
            errors.append(f"{name}: {exc}")

    try:
        _publish_notification(normalized, config)
    except Exception as exc:
        LOG.exception("SNS notification failed")
        errors.append(f"sns: {exc}")

    if errors:
        # Raising lets Lambda asynchronous retries/on-failure destination retain the event,
        # without ever blocking CodePipeline itself.
        raise RuntimeError("; ".join(errors))

    return {
        "ok": True,
        "pipeline": normalized["pipeline"],
        "pipelineExecutionId": normalized["pipelineExecutionId"],
        "level": normalized["level"],
        "state": normalized["state"],
        "evidenceKey": evidence_key,
    }
