# Quick Start

Assumption: your existing pipeline is already:

```text
Source → SAST → ValidateAndTest → CentralQualityGate
```

## Fastest safe path

1. Create an S3 evidence bucket.
2. Create a DynamoDB table with partition key `EventKey` (String), on-demand billing, TTL attribute `ExpiresAt`.
3. Create two SQS queues:
   - EventBridge delivery DLQ
   - Lambda processing-failure queue
4. Create an SNS topic; optionally subscribe your email.
5. Create an SSM String parameter containing `config/routing-config.example.json`.
6. Create two placeholder Secrets Manager secrets for ServiceNow and Jira.
7. Create the Integration Router Lambda from `deployment/integration-router.zip`.
8. Create the Failure Analyzer Lambda from `deployment/failure-analyzer.zip` with `BEDROCK_MODE=MOCK`.
9. Add the IAM permissions listed in `docs/02_CONSOLE_IMPLEMENTATION.md`.
10. Create three EventBridge rules:
    - all CodePipeline state changes → Integration Router
    - failed **action** events → Failure Analyzer
    - `devops.sidecar / Failure Analysis Complete` → Integration Router
11. Run your pipeline with all mock results passing. Confirm S3/DynamoDB receive events.
12. Force `MockSastOutcome=FAIL` or `MockToscaOutcome=FAIL`. Confirm:
    - CodePipeline still behaves exactly as before
    - CentralQualityGate fails
    - Failure Analyzer creates an RCA record
    - ServiceNow/Jira MOCK updates appear in the Integration Router log
    - evidence is written to S3

## Why the Bedrock rule listens only to failed actions

CodePipeline emits action, stage, and pipeline failure events for one underlying failure. Analyzing only the failed **action** avoids duplicate Bedrock calls and gives the analyzer the most specific provider information.

## Later

- Set ServiceNow/Jira routing mode from `MOCK` → `REAL` after updating their secrets.
- Set `BEDROCK_MODE=REAL` and provide a model ID after Bedrock access is available.
- Add `ACTION` to the ServiceNow/Jira routing `levels` if you want a ticket update after every action rather than only pipeline/stage events.
